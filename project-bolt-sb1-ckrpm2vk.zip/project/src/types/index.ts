export interface User {
  id: string;
  email: string;
  username: string;
  points: number;
  level: number;
  streak: number;
}

export interface Tool {
  id: string;
  name: string;
  description: string;
  icon: any; // Lucide icon component type
  category: 'featured' | 'seo' | 'ai' | 'marketing' | 'education' | 'health' | 'career' | 'finance' | 'language' | 'travel' | 'entertainment' | 'lifestyle' | 'shopping' | 'events';
  isNew?: boolean;
  isLocked?: boolean;
  featured?: boolean;
  image?: string;
  items?: {
    id: string;
    name: string;
    icon: string;
    color?: string;
  }[];
}

export interface ContentPlan {
  title: string;
  description: string;
  keywords: string[];
  wordCount: number;
  seoScore: number;
  readabilityScore: number;
  content: string;
  sections: {
    title: string;
    content: string;
    wordCount: number;
    sources: string[];
    outline?: {
      level: number;
      title: string;
      paragraphs?: number;
    }[];
    metadata?: {
      style?: string;
      tone?: string;
      audience?: string;
    };
  }[];
  references: Array<{
    title: string;
    url: string;
    type: string;
  }>;
  metadata?: {
    topic: string;
    style: string;
    tone: string;
    audience: string;
    minWords: number;
    maxWords: number;
    targetKeyword?: string;
  };
}