import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import AuthGuard from './lib/auth/AuthGuard';
import MobileNav from './components/layout/MobileNav';
import { useEffect, useCallback, useState } from 'react';
import { supabase } from './lib/supabase';
import { useNavigate, useLocation } from 'react-router-dom';
import Header from './components/layout/Header';
import ToolGrid from './components/dashboard/ToolGrid';
import AnalyticsTools from './pages/AnalyticsTools';
import AITools from './pages/AITools';
import ContentTools from './pages/ContentTools';
import SEOTools from './pages/SEOTools';
import ChatPage from './pages/ChatPage';
import HelpPage from './pages/HelpPage';
import TradingTools from './pages/TradingTools';
import InteriorTools from './pages/InteriorTools';
import AchievementsPage from './pages/AchievementsPage';
import Sidebar from './components/layout/Sidebar';
import ActivityPage from './pages/ActivityPage';
import SettingsPage from './pages/SettingsPage';
import Auth from './pages/auth/Auth';
import Profile from './pages/auth/Profile';
import type { Section } from './components/layout/Sidebar';

function App() {
  const [activeSection, setActiveSection] = useState<Section>('dashboard');
  const [selectedTool, setSelectedTool] = React.useState<string | null>(null);
  const navigate = useNavigate();
  const location = useLocation();

  const handleSectionChange = useCallback((section: string) => {
    setActiveSection(section);
    setSelectedTool(null);
  }, [navigate]);


  // Handle OAuth callback
  useEffect(() => {
    if (location.hash && location.pathname === '/auth/callback') {
      const handleCallback = async () => {
        try {
          const { data: { session }, error } = await supabase.auth.getSession();
          
          if (error) throw error;
          if (session) {
            navigate('/dashboard', { replace: true });
          }
        } catch (error) {
          console.error('Auth callback error:', error);
          navigate('/auth', { replace: true });
        }
      };
      
      handleCallback();
    }
  }, [location, navigate]);
  return (
    <Routes>
      <Route path="/auth/*" element={<Auth />} />
      <Route path="/auth/callback" element={<div>Redirecting...</div>} />
      <Route
        path="/*"
        element={(
          <AuthGuard>
            <div className="min-h-screen bg-[#F8F9FA] flex flex-col md:flex-row md:pr-20 pb-16 md:pb-0">
              <Sidebar activeSection={activeSection} onSectionChange={handleSectionChange} />
              <MobileNav activeSection={activeSection} onSectionChange={handleSectionChange} />
              <div className="flex-1 flex flex-col relative w-full">
                <Header />
                <main className="flex-1 py-4 sm:py-8 px-2 sm:px-4 bg-[#F8F9FA]">
                  <Routes>
                    <Route path="/" element={<ToolGrid selectedTool={selectedTool} setSelectedTool={setSelectedTool} />} />
                    <Route path="/seo-tools" element={<SEOTools />} />
                    <Route path="/content" element={<ContentTools />} />
                    <Route path="/analytics" element={<AnalyticsTools />} />
                    <Route path="/ai" element={<AITools />} />
                    <Route path="/trading" element={<TradingTools />} />
                    <Route path="/interior" element={<InteriorTools />} />
                    <Route path="/activity" element={<ActivityPage />} />
                    <Route path="/achievements" element={<AchievementsPage />} />
                    <Route path="/chat" element={<ChatPage />} />
                    <Route path="/help" element={<HelpPage />} />
                    <Route path="/profile" element={<Profile />} />
                    <Route path="/settings" element={<SettingsPage />} />
                    <Route path="*" element={
                      <div className="flex items-center justify-center h-[400px] text-gray-500">صفحه مورد نظر یافت نشد</div>
                    } />
                  </Routes>
                </main>
                {/* Add bottom padding on mobile to account for navigation */}
                <div className="h-16 md:hidden" />
              </div>
            </div>
          </AuthGuard>
        )}
      />
    </Routes>
  );
}

export default App;