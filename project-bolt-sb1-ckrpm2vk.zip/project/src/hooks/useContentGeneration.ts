import { useState } from 'react';
import { openai } from '../lib/openai';
import { generateContent } from '../lib/content/generator';
import { ContentPlan } from '../types';

interface GenerateParams {
  topic: string;
  keywords: string[];
  style?: string;
  tone?: string;
  audience: string;
  minWords?: number;
  maxWords?: number;
  targetKeyword?: string;
}

export function useContentGeneration({ onProgress }: { onProgress?: (message: string) => void } = {}) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [contentPlan, setContentPlan] = useState<ContentPlan | null>(null);

  const generate = async (topic: string, keywords: string[], headings: any[]) => {
    try {
      setIsGenerating(true);
      setError(null);
      setContentPlan(null);

      onProgress?.('در حال تولید محتوا...');
      
      // First get research results
      const results = await searchAndAnalyze(topic);
      setSearchResults(results);

      const response = await openai.chat.completions.create({
        model: 'ModelsLab/Mixtral-8x7B-Instruct',
        temperature: 0.5,
        messages: [
          {
            role: 'system',
            content: `شما یک نویسنده حرفه‌ای محتوا هستید. لطفاً با استفاده از نتایج تحقیق و ساختار سرتیترها، یک محتوای جامع تولید کنید.

موضوع: ${topic}
کلمات کلیدی: ${keywords.join('، ')}

قوانین ساختاری:
1. محتوا باید در قالب HTML تمیز تولید شود
2. از تگ‌های معنایی HTML5 استفاده کنید
3. هر بخش باید ساختار مشخصی داشته باشد

ساختار کلی مقاله:
<article>
  <header>
    <h1>عنوان اصلی</h1>
    <p class="description">توضیحات مقدماتی</p>
    <div class="metadata">
      <span class="keywords">کلمات کلیدی</span>
      <span class="reading-time">زمان مطالعه</span>
    </div>
  </header>
  
  <section class="introduction">
    <p>مقدمه و معرفی موضوع</p>
  </section>
  
  <section class="main-content">
    <!-- بخش‌های اصلی محتوا -->
    <h2>عنوان بخش</h2>
    <p>محتوای بخش</p>
    <ul>
      <li>موارد لیست</li>
    </ul>
  </section>
  
  <section class="conclusion">
    <h2>جمع‌بندی</h2>
    <p>خلاصه و نتیجه‌گیری</p>
  </section>
</article>

 ساختار محتوا:
${headings.map(h => `${'-'.repeat(h.level)} ${h.title}`).join('\n')}

 نتایج تحقیق:
 ${results.map(r => `### ${r.title}\n${r.content}`).join('\n\n')}

 نکات مهم:
 1. از کلمات کلیدی به صورت طبیعی استفاده کنید
 2. محتوا باید کاملاً فارسی و روان باشد
 3. از ساختار سرتیترها پیروی کنید
 4. از نتایج تحقیق الهام بگیرید اما کپی نکنید
 5. محتوا باید جامع و کاربردی باشد
 6. از تگ‌های HTML برای ساختاردهی استفاده کنید
 7. هر بخش باید عنوان و محتوای مشخص داشته باشد
 8. از لیست‌ها و نقل قول‌ها در جای مناسب استفاده کنید`
          },
          {
            role: 'user',
            content: `لطفاً برای موضوع "${topic}" یک مقاله جامع با ساختار HTML تولید کنید.`
          }
        ]
      });

      const generatedContent = response.choices[0]?.message?.content;

      if (!generatedContent) {
        throw new Error('خطا در تولید محتوا');
      }
      
      // Clean up HTML and ensure proper structure
      const cleanContent = generatedContent
        .replace(/\n\s*\n/g, '\n') // Remove extra newlines
        .replace(/<\/?article>/g, '') // Remove outer article tags if present
        .replace(/<h([1-6])>(.*?)<\/h\1>/g, (_, level, text) => { // Clean up headings
          return `<h${level} class="heading-${level}">${text.trim()}</h${level}>`;
        })
        .replace(/<p>(.*?)<\/p>/g, (_, text) => { // Clean up paragraphs
          return `<p>${text.trim()}</p>`;
        })
        .replace(/<ul>([\s\S]*?)<\/ul>/g, (match) => { // Clean up lists
          return match.replace(/\s+/g, ' ').trim();
        })
        .replace(/<blockquote>([\s\S]*?)<\/blockquote>/g, (match) => { // Clean up quotes
          return match.replace(/\s+/g, ' ').trim();
        });

      return cleanContent;

    } catch (error) {
      console.error('Content generation error:', error);
      throw error;
    } finally {
      setIsGenerating(false);
      onProgress?.('');
    }
  };

  return {
    isGenerating,
    error,
    contentPlan,
    generate,
    setError,
    searchResults
  };
}