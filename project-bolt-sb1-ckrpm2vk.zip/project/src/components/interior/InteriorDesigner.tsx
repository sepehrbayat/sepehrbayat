import { Wand2, Settings2, AlertCircle, Upload, Download } from 'lucide-react';
import { trackToolUsage } from '../../lib/activity/tracking';

interface InteriorDesignerProps {
}

  const handleGenerate = async () => {
    try {
      // Track design start
      await trackToolUsage(
        'interior-designer',
        'طراحی داخلی',
        'شروع طراحی داخلی',
        {
          prompt,
          style,
          settings
        }
      );

      const designs = await generateDesigns({
        prompt,
        style,
        settings
      });

      // Track successful generation
      await trackToolUsage(
        'interior-designer',
        'طراحی موفق داخلی',
        'طراحی داخلی با موفقیت انجام شد',
        {
          prompt,
          designs
        }
      );

      setGeneratedDesigns(designs);
    } catch (error) {
      // Track error
      await trackToolUsage(
        'interior-designer',
        'خطا در طراحی داخلی',
        error instanceof Error ? error.message : 'خطای ناشناخته',
        { error: error }
      );
      throw error;
    }
  };