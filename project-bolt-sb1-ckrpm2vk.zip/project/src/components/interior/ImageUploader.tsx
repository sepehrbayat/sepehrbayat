import React, { useState } from 'react';
import { Upload, X } from 'lucide-react';

interface ImageUploaderProps {
  onImageSelect: (imageUrl: string | null) => void;
  onImageFile?: (file: File | null) => void;
  onUploadStateChange?: (isUploading: boolean) => void;
  placeholder?: string;
  className?: string;
  error?: string | null;
}

export default function ImageUploader({
  onImageSelect,
  onImageFile,
  onUploadStateChange,
  placeholder = 'آپلود تصویر',
  className = '',
  error = null
}: ImageUploaderProps) {
  const [preview, setPreview] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);

  const validateFile = (file: File): string | null => {
    // Validate file type more strictly
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png'];
    if (!validTypes.includes(file.type)) {
      return 'فقط فایل‌های JPG و PNG مجاز هستند';
    }

    // Check file size (2MB)
    if (file.size > 2 * 1024 * 1024) {
      return 'حجم فایل نباید بیشتر از 2 مگابایت باشد';
    }

    return null;
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const error = validateFile(file);
    if (error) {
      onImageSelect(null);
      if (onImageFile) onImageFile(null);
      if (onUploadStateChange) onUploadStateChange(false);
      setUploadSuccess(false);
      if (event.target) {
        event.target.value = ''; // Reset input
      }
      return;
    }

    setIsUploading(true);
    setUploadSuccess(false);
    if (onUploadStateChange) onUploadStateChange(true);

    // Show preview immediately
    const reader = new FileReader();
    reader.onerror = () => {
      setIsUploading(false);
      if (onUploadStateChange) onUploadStateChange(false);
      setUploadSuccess(false);
      if (error) error('خطا در خواندن تصویر. لطفاً تصویر دیگری را امتحان کنید');
    };
    reader.onloadend = () => {
      // Validate image data
      const result = reader.result as string;
      if (!result || !result.startsWith('data:image/')) {
        setIsUploading(false);
        if (onUploadStateChange) onUploadStateChange(false);
        setUploadSuccess(false);
        if (error) error('فرمت تصویر نامعتبر است. لطفاً تصویر دیگری را امتحان کنید');
        return;
      }
      
      // Create an image object to validate dimensions
      const img = new Image();
      img.onload = () => {
        // Convert dimensions if needed
        let width = img.width;
        let height = img.height;
        
        // Scale down large images to max 2048x2048
        if (width > 2048 || height > 2048) {
          const ratio = Math.min(2048 / width, 2048 / height);
          width = Math.floor(width * ratio);
          height = Math.floor(height * ratio);
        }

        // Check image dimensions
        if (img.width < 256 || img.height < 256) {
          setIsUploading(false);
          if (onUploadStateChange) onUploadStateChange(false);
          setUploadSuccess(false);
          if (error) error('ابعاد تصویر باید حداقل 256x256 پیکسل باشد');
          return;
        }
        
        // All validations passed
        setPreview(result);
        onImageSelect(result);
        if (onImageFile) onImageFile(file);
        if (onUploadStateChange) onUploadStateChange(false);
        setIsUploading(false);
        setUploadSuccess(true);
        // Hide success message after 3 seconds
        setTimeout(() => setUploadSuccess(false), 3000);
      };
      img.onerror = () => {
        setIsUploading(false);
        if (onUploadStateChange) onUploadStateChange(false);
        setUploadSuccess(false);
        if (error) error('خطا در پردازش تصویر. لطفاً تصویر دیگری را امتحان کنید');
      };
      img.src = result;
    };
    try {
      reader.readAsDataURL(file);
    } catch (e) {
      setIsUploading(false);
      if (onUploadStateChange) onUploadStateChange(false);
      setUploadSuccess(false);
      if (error) error('خطا در خواندن تصویر. لطفاً مطمئن شوید که فایل انتخابی یک تصویر معتبر است');
    }
  };

  const handleRemove = () => {
    setPreview(null);
    onImageSelect(null);
    if (onImageFile) onImageFile(null);
    if (onUploadStateChange) onUploadStateChange(false);
    setUploadSuccess(false);
  };

  return (
    <div className={`relative ${className}`}>
      <label
        htmlFor="image-upload"
        className={`relative flex flex-col items-center justify-center gap-2 w-full bg-gray-50 border-2 border-dashed transition-all rounded-lg p-4 cursor-pointer hover:bg-gray-100 group ${
          isUploading ? 'border-yellow-400 animate-pulse' :
          preview ? 'border-[#a63439]' : 'border-gray-200'
        } ${error ? 'border-red-300' : ''}`}
      >
        {preview ? (
          <>
            <img 
              src={preview} 
              alt="پیش‌نمایش"
              className={`w-full h-32 object-contain rounded transition-all ${uploadSuccess ? 'ring-4 ring-green-500/20' : ''}`}
            />
            <span className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 text-white opacity-0 group-hover:opacity-100 transition-opacity rounded-lg">
              تغییر تصویر
            </span>
            <button
              onClick={(e) => {
                e.preventDefault();
                handleRemove();
              }}
              className="absolute top-2 left-2 p-1 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <X className="w-4 h-4" />
            </button>
          </>
        ) : (
          <div className="flex flex-col items-center gap-2">
            <Upload className={`w-6 h-6 ${
              isUploading ? 'text-yellow-400 animate-spin' :
              error ? 'text-red-500' : 'text-gray-500'
            }`} />
            <span className={`text-sm ${
              isUploading ? 'text-yellow-600' :
              error ? 'text-red-600' : 'text-gray-600'
            }`}>
              {isUploading ? 'در حال آپلود...' : placeholder}
            </span>
          </div>
        )}
      </label>
      <input
        id="image-upload"
        type="file"
        accept=".jpg,.jpeg,.png,.avif"
        onChange={handleFileChange}
        className="hidden"
      />
      {error && (
        <p className="mt-2 text-xs text-red-600">{error}</p>
      )}
      {uploadSuccess && (
        <p className="mt-2 text-xs text-green-600 flex items-center gap-1 animate-fadeIn">
          <svg className="w-4 h-4" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
          تصویر با موفقیت آپلود شد
        </p>
      )}
    </div>
  );
}