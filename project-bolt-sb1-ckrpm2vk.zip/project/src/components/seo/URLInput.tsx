import React from 'react';
import { Search } from 'lucide-react';
import { useTranslation } from 'react-i18next';

interface URLInputProps {
  url: string;
  onUrlChange: (url: string) => void;
  onAnalyze: () => void;
  isAnalyzing: boolean;
}

export default function URLInput({ url, onUrlChange, onAnalyze, isAnalyzing }: URLInputProps) {
  const { t } = useTranslation();

  return (
    <div className="flex gap-4">
      <div className="flex-1">
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="url"
            value={url}
            onChange={(e) => onUrlChange(e.target.value)}
            placeholder={t('seo.analysis.enterUrl')}
            className="w-full bg-gray-50 border border-gray-200 rounded-lg px-10 py-2"
          />
        </div>
      </div>
      <button
        onClick={onAnalyze}
        disabled={isAnalyzing || !url}
        className="bg-[#a63439] text-white px-6 py-2 rounded-lg hover:bg-[#8a2a2e] transition-colors disabled:opacity-50"
      >
        {isAnalyzing ? t('seo.analysis.analyzing') : t('seo.analysis.analyze')}
      </button>
    </div>
  );
}