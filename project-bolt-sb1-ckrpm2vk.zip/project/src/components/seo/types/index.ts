export interface SEOMetric {
  name: string;
  value: string | number;
  description: string;
  status: 'good' | 'warning' | 'poor';
  context: Record<string, any>;
}

export interface SEOScore {
  score: number;
  label: string;
  recommendations: string[];
}

export interface PerformanceMetrics {
  security: {
    score: number;
    features: {
      https: boolean;
      csp: boolean;
      hsts: boolean;
      xss: boolean;
    };
  };
  userExperience: {
    score: number;
  };
}

export interface HistoricalDataPoint {
  date: string;
  performance: {
    desktop: number;
    mobile: number;
  };
  seo: {
    desktop: number;
    mobile: number;
  };
  url: string;
}