import React, { useState } from 'react';
import { Search, BarChart2, Loader2, Brain } from 'lucide-react';
import { analyzePage } from '../../../lib/seo/analyzer';
import { runLighthouseAudit } from '../../../lib/seo/lighthouse';

interface CompetitorData {
  url: string;
  seoScore: number;
  performance: number;
  contentScore: number;
  keywordDensity: Record<string, number>;
  backlinks: number;
  socialShares: number;
}

export default function CompetitorAnalysis() {
  const [competitors, setCompetitors] = useState<string[]>([]);
  const [newCompetitor, setNewCompetitor] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [competitorData, setCompetitorData] = useState<Record<string, CompetitorData>>({});
  const [error, setError] = useState<string | null>(null);

  const handleAddCompetitor = () => {
    if (!newCompetitor.trim()) return;
    
    try {
      new URL(newCompetitor);
      if (!competitors.includes(newCompetitor)) {
        setCompetitors([...competitors, newCompetitor]);
      }
      setNewCompetitor('');
      setError(null);
    } catch {
      setError('لطفاً یک آدرس معتبر وارد کنید');
    }
  };

  const handleRemoveCompetitor = (url: string) => {
    setCompetitors(competitors.filter(c => c !== url));
    const newData = { ...competitorData };
    delete newData[url];
    setCompetitorData(newData);
  };

  const analyzeCompetitors = async () => {
    if (competitors.length === 0) {
      setError('لطفاً حداقل یک رقیب اضافه کنید');
      return;
    }

    setIsAnalyzing(true);
    setError(null);

    try {
      const results: Record<string, CompetitorData> = {};

      for (const url of competitors) {
        try {
          const [analysis, lighthouse] = await Promise.all([
            analyzePage(url),
            runLighthouseAudit(url)
          ]);

          // Calculate scores
          const seoScore = lighthouse.seo;
          const performance = lighthouse.performance;
          const contentScore = analysis.content.readabilityScore;

          // Simulate backlinks and social shares
          const backlinks = Math.floor(Math.random() * 1000) + 100;
          const socialShares = Math.floor(Math.random() * 500) + 50;

          results[url] = {
            url,
            seoScore,
            performance,
            contentScore,
            keywordDensity: analysis.content.keywordDensity,
            backlinks,
            socialShares
          };
        } catch (error) {
          console.error(`Error analyzing ${url}:`, error);
        }
      }

      setCompetitorData(results);
    } catch (error) {
      console.error('Error analyzing competitors:', error);
      setError('خطا در تحلیل رقبا. لطفاً دوباره تلاش کنید.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="bg-white rounded-xl p-6 space-y-6">
      <div className="flex gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="url"
              value={newCompetitor}
              onChange={(e) => setNewCompetitor(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleAddCompetitor()}
              placeholder="آدرس سایت رقیب را وارد کنید..."
              className="w-full bg-gray-50 border border-gray-200 rounded-lg px-10 py-2"
            />
          </div>
        </div>
        <button
          onClick={handleAddCompetitor}
          disabled={!newCompetitor.trim()}
          className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 transition-colors disabled:opacity-50"
        >
          افزودن
        </button>
        <button
          onClick={analyzeCompetitors}
          disabled={isAnalyzing || competitors.length === 0}
          className="bg-[#a63439] text-white px-6 py-2 rounded-lg hover:bg-[#8a2a2e] transition-colors disabled:opacity-50 flex items-center gap-2"
        >
          {isAnalyzing ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>هوشِکس در حال فکر کردن...</span>
            </>
          ) : (
            <>
              <BarChart2 className="w-5 h-5" />
              <span>تحلیل رقبا</span>
            </>
          )}
        </button>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700">
          {error}
        </div>
      )}

      {competitors.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium">رقبای انتخاب شده</h3>
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <Brain className="w-4 h-4" />
              <span>تحلیل هوشمند</span>
            </div>
          </div>
          <div className="space-y-2">
            {competitors.map(url => (
              <div
                key={url}
                className="flex items-center justify-between bg-gray-50 rounded-lg p-3"
              >
                <span className="text-sm">{url}</span>
                <button
                  onClick={() => handleRemoveCompetitor(url)}
                  className="text-red-500 hover:text-red-600"
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {Object.keys(competitorData).length > 0 && (
        <div className="space-y-6">
          <h3 className="text-lg font-medium">نتایج تحلیل</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="py-3 text-right text-sm font-medium text-gray-500">سایت</th>
                  <th className="py-3 text-center text-sm font-medium text-gray-500">امتیاز سئو</th>
                  <th className="py-3 text-center text-sm font-medium text-gray-500">عملکرد</th>
                  <th className="py-3 text-center text-sm font-medium text-gray-500">امتیاز محتوا</th>
                  <th className="py-3 text-center text-sm font-medium text-gray-500">بک‌لینک‌ها</th>
                  <th className="py-3 text-center text-sm font-medium text-gray-500">اشتراک‌گذاری</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {Object.values(competitorData).map(data => (
                  <tr key={data.url} className="hover:bg-gray-50">
                    <td className="py-3 text-sm">{data.url}</td>
                    <td className="py-3 text-center">
                      <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        data.seoScore >= 80 ? 'bg-green-100 text-green-800' :
                        data.seoScore >= 60 ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {data.seoScore}
                      </div>
                    </td>
                    <td className="py-3 text-center">
                      <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        data.performance >= 80 ? 'bg-green-100 text-green-800' :
                        data.performance >= 60 ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {data.performance}
                      </div>
                    </td>
                    <td className="py-3 text-center">
                      <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        data.contentScore >= 80 ? 'bg-green-100 text-green-800' :
                        data.contentScore >= 60 ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {data.contentScore}
                      </div>
                    </td>
                    <td className="py-3 text-sm text-center">{data.backlinks.toLocaleString()}</td>
                    <td className="py-3 text-sm text-center">{data.socialShares.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="space-y-4">
            <h4 className="text-sm font-medium">کلمات کلیدی پرکاربرد رقبا</h4>
            <div className="grid grid-cols-2 gap-4">
              {Object.entries(competitorData).map(([url, data]) => (
                <div key={url} className="bg-gray-50 rounded-lg p-4">
                  <h5 className="text-sm font-medium mb-3">{url}</h5>
                  <div className="space-y-2">
                    {Object.entries(data.keywordDensity)
                      .sort(([, a], [, b]) => b - a)
                      .slice(0, 5)
                      .map(([keyword, density]) => (
                        <div key={keyword} className="flex items-center justify-between text-sm">
                          <span>{keyword}</span>
                          <span className="text-gray-500">{density.toFixed(1)}%</span>
                        </div>
                      ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}