import React, { useState } from 'react';
import { FileText, CheckCircle2, XCircle, Loader2, Brain } from 'lucide-react';
import { openai } from '../../../lib/openai';

interface ContentAnalysis {
  score: number;
  readability: number;
  keywordDensity: number;
  wordCount: number;
  paragraphCount: number;
  avgSentenceLength: number;
  suggestions: string[];
  missingKeywords: string[];
  improvements: {
    title: string;
    description: string;
    headings: string[];
    structure: {
      section: string;
      content: string[];
    }[];
    semanticKeywords: string[];
  };
  technicalImprovements: {
    category: string;
    items: string[];
  }[];
}

export default function ContentOptimizer() {
  const [content, setContent] = useState('');
  const [targetKeyword, setTargetKeyword] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<ContentAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = async () => {
    if (!content.trim() || !targetKeyword.trim()) {
      setError('لطفاً محتوا و کلمه کلیدی هدف را وارد کنید');
      return;
    }

    try {
      setIsAnalyzing(true);
      setError(null);

      const response = await openai.chat.completions.create({
        model: 'ModelsLab/Mixtral-8x7B-Instruct',
        temperature: 0.7,
        messages: [
          {
            role: 'system',
            content: `شما یک متخصص سئو و بهینه‌سازی محتوا هستید. لطفاً محتوای داده شده را برای کلمه کلیدی هدف تحلیل کنید و پیشنهادات بهبود ارائه دهید.

لطفاً خروجی را فقط در قالب JSON با این ساختار برگردانید:
{
  "score": عدد,
  "readability": عدد,
  "keywordDensity": عدد,
  "wordCount": عدد,
  "paragraphCount": عدد,
  "avgSentenceLength": عدد,
  "suggestions": ["پیشنهاد 1", "پیشنهاد 2"],
  "missingKeywords": ["کلمه کلیدی 1", "کلمه کلیدی 2"],
  "improvements": {
    "title": "عنوان پیشنهادی",
    "description": "توضیحات متا پیشنهادی",
    "headings": ["سرتیتر 1", "سرتیتر 2"],
    "structure": [
      {
        "section": "عنوان بخش",
        "content": ["محتوای پیشنهادی 1", "محتوای پیشنهادی 2"]
      }
    ],
    "semanticKeywords": ["کلمه معنایی 1", "کلمه معنایی 2"]
  },
  "technicalImprovements": [
    {
      "category": "ساختار",
      "items": ["پیشنهاد 1", "پیشنهاد 2"]
    }
  ]
  }
}`
          },
          {
            role: 'user',
            content: `لطفاً این محتوا را برای کلمه کلیدی "${targetKeyword}" تحلیل و بهینه کنید:

${content}`
          }
        ]
      });

      const contentAnalysis = JSON.parse(response.choices[0]?.message?.content || '{}');
      setAnalysis(contentAnalysis);

    } catch (error) {
      console.error('Error analyzing content:', error);
      setError('خطا در تحلیل محتوا. لطفاً دوباره تلاش کنید.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="bg-white rounded-xl p-6 space-y-6">
      <div className="grid grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium mb-2">محتوا</label>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="w-full h-64 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 resize-none"
            placeholder="محتوای مورد نظر را وارد کنید..."
          />
        </div>
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium mb-2">کلمه کلیدی هدف</label>
            <input
              type="text"
              value={targetKeyword}
              onChange={(e) => setTargetKeyword(e.target.value)}
              className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2"
              placeholder="کلمه کلیدی اصلی برای بهینه‌سازی محتوا"
            />
          </div>
          <button
            onClick={handleAnalyze}
            disabled={isAnalyzing || !content.trim() || !targetKeyword.trim()}
            className="w-full bg-[#a63439] text-white px-4 py-2 rounded-lg hover:bg-[#8a2a2e] transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>هوشِکس در حال فکر کردن...</span>
              </>
            ) : (
              <>
                <FileText className="w-5 h-5" />
                <span>تحلیل و بهینه‌سازی</span>
              </>
            )}
          </button>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700">
          {error}
        </div>
      )}

      {analysis && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium">نتایج تحلیل</h3>
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <Brain className="w-4 h-4" />
              <span>تحلیل هوشمند</span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="text-sm text-gray-500 mb-1">امتیاز سئو</div>
              <div className={`text-2xl font-bold ${
                analysis.score >= 80 ? 'text-green-600' :
                analysis.score >= 60 ? 'text-yellow-600' :
                'text-red-600'
              }`}>
                {analysis.score}/100
              </div>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="text-sm text-gray-500 mb-1">خوانایی</div>
              <div className={`text-2xl font-bold ${
                analysis.readability >= 80 ? 'text-green-600' :
                analysis.readability >= 60 ? 'text-yellow-600' :
                'text-red-600'
              }`}>
                {analysis.readability}/100
              </div>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="text-sm text-gray-500 mb-1">تراکم کلمه کلیدی</div>
              <div className={`text-2xl font-bold ${
                analysis.keywordDensity >= 0.5 && analysis.keywordDensity <= 2.5 ? 'text-green-600' :
                analysis.keywordDensity > 2.5 ? 'text-yellow-600' :
                'text-red-600'
              }`}>
                {analysis.keywordDensity.toFixed(1)}%
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-4 mt-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="text-sm text-gray-500 mb-1">تعداد کلمات</div>
              <div className="text-lg font-bold text-[#a63439]">
                {analysis.wordCount}
              </div>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="text-sm text-gray-500 mb-1">تعداد پاراگراف‌ها</div>
              <div className="text-lg font-bold text-[#a63439]">
                {analysis.paragraphCount}
              </div>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="text-sm text-gray-500 mb-1">میانگین طول جملات</div>
              <div className="text-lg font-bold text-[#a63439]">
                {analysis.avgSentenceLength}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="text-sm font-medium">پیشنهادات بهبود</h4>
            <div className="space-y-2">
              {analysis.suggestions.map((suggestion, index) => (
                <div key={index} className="flex items-start gap-2 text-sm">
                  <CheckCircle2 className="w-4 h-4 text-green-500 mt-1 flex-shrink-0" />
                  <span>{suggestion}</span>
                </div>
              ))}
            </div>
          </div>

          {analysis.missingKeywords.length > 0 && (
            <div className="space-y-4">
              <h4 className="text-sm font-medium">کلمات کلیدی مرتبط پیشنهادی</h4>
              <div className="space-y-2">
                {analysis.missingKeywords.map((keyword, index) => (
                  <div key={index} className="flex items-start gap-2 text-sm">
                    <XCircle className="w-4 h-4 text-red-500 mt-1 flex-shrink-0" />
                    <span>{keyword}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-4">
            <h4 className="text-sm font-medium">پیشنهادات ساختاری</h4>
            <div className="space-y-4">
              <div>
                <div className="text-sm text-gray-500 mb-1">عنوان پیشنهادی</div>
                <div className="bg-gray-50 rounded-lg p-3 text-sm">
                  {analysis.improvements.title}
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-500 mb-1">توضیحات متا پیشنهادی</div>
                <div className="bg-gray-50 rounded-lg p-3 text-sm">
                  {analysis.improvements.description}
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-500 mb-1">ساختار سرتیترها</div>
                <div className="space-y-2">
                  {analysis.improvements.headings.map((heading, index) => (
                    <div key={index} className="bg-gray-50 rounded-lg p-3 text-sm">
                      {heading}
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            <div>
              <div className="text-sm text-gray-500 mb-1">کلمات کلیدی معنایی مرتبط</div>
              <div className="flex flex-wrap gap-2">
                {analysis.improvements.semanticKeywords.map((keyword, index) => (
                  <span key={index} className="bg-[#a63439]/10 text-[#a63439] px-3 py-1 rounded-full text-sm">
                    {keyword}
                  </span>
                ))}
              </div>
            </div>
            
            <div>
              <div className="text-sm text-gray-500 mb-1">ساختار پیشنهادی محتوا</div>
              <div className="space-y-4">
                {analysis.improvements.structure.map((section, index) => (
                  <div key={index} className="bg-gray-50 rounded-lg p-4">
                    <h5 className="font-medium mb-2">{section.section}</h5>
                    <ul className="space-y-2">
                      {section.content.map((item, i) => (
                        <li key={i} className="text-sm text-gray-600">• {item}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <h4 className="text-sm font-medium">بهبودهای فنی</h4>
            <div className="grid grid-cols-2 gap-4">
              {analysis.technicalImprovements.map((improvement, index) => (
                <div key={index} className="bg-gray-50 rounded-lg p-4">
                  <h5 className="font-medium mb-2">{improvement.category}</h5>
                  <ul className="space-y-2">
                    {improvement.items.map((item, i) => (
                      <li key={i} className="text-sm text-gray-600 flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-500 mt-1 flex-shrink-0" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}