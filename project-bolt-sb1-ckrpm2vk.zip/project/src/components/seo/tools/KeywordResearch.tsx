import React, { useState } from 'react';
import { Search, Sparkles, ArrowRight, Loader2, Brain, Lightbulb } from 'lucide-react';
import { openai } from '../../../lib/openai';

interface KeywordSuggestion {
  keyword: string;
  volume: number;
  difficulty: number;
  intent: string;
  cpc: number;
  relatedKeywords: string[];
}

interface RelatedKeywordsPopup {
  keyword: string;
  suggestions: string[];
}

export default function KeywordResearch() {
  const [keyword, setKeyword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<KeywordSuggestion[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [selectedKeyword, setSelectedKeyword] = useState<RelatedKeywordsPopup | null>(null);

  const handleSearch = async () => {
    if (!keyword.trim()) {
      setError('لطفاً یک کلمه کلیدی وارد کنید');
      return;
    }

    try {
      setIsLoading(true);
      setError(null);

      const response = await openai.chat.completions.create({
        model: 'ModelsLab/Mixtral-8x7B-Instruct',
        temperature: 0.7,
        messages: [
          {
            role: 'system',
            content: `شما یک متخصص سئو و تحقیق کلمات کلیدی هستید. لطفاً برای کلمه کلیدی داده شده، کلمات کلیدی مرتبط را با این مشخصات پیشنهاد دهید:

1. حجم جستجو (ماهانه)
2. سختی رقابت (0-100)
3. قصد جستجو (اطلاعاتی، تجاری، مقایسه‌ای)
4. هزینه تقریبی تبلیغات (CPC)

لطفاً خروجی را فقط در قالب JSON با این ساختار برگردانید:
[{
  "keyword": "کلمه کلیدی",
  "volume": عدد,
  "difficulty": عدد,
  "intent": "نوع قصد",
  "cpc": عدد,
  "relatedKeywords": ["کلمه مرتبط 1", "کلمه مرتبط 2"]
}]`
          },
          {
            role: 'user',
            content: `لطفاً برای کلمه کلیدی "${keyword}" و کلمات مرتبط با آن، اطلاعات و آمار تخمینی ارائه دهید.`
          }
        ]
      });

      const suggestedKeywords = JSON.parse(response.choices[0]?.message?.content || '[]');
      setSuggestions(suggestedKeywords);

    } catch (error) {
      console.error('Error getting keyword suggestions:', error);
      setError('خطا در دریافت پیشنهادات. لطفاً دوباره تلاش کنید.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl p-6 space-y-6">
      <div className="flex gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              placeholder="کلمه کلیدی مورد نظر را وارد کنید..."
              className="w-full bg-gray-50 border border-gray-200 rounded-lg px-10 py-2"
            />
          </div>
        </div>
        <button
          onClick={handleSearch}
          disabled={isLoading || !keyword.trim()}
          className="bg-[#a63439] text-white px-6 py-2 rounded-lg hover:bg-[#8a2a2e] transition-colors disabled:opacity-50 flex items-center gap-2"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>هوشِکس در حال فکر کردن...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5" />
              <span>جستجو</span>
            </>
          )}
        </button>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700">
          {error}
        </div>
      )}

      {suggestions.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium">کلمات کلیدی پیشنهادی</h3>
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <Brain className="w-4 h-4" />
              <span>پیشنهادات هوشمند</span>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="py-3 text-right text-sm font-medium text-gray-500">کلمه کلیدی</th>
                  <th className="py-3 text-center text-sm font-medium text-gray-500">حجم جستجو</th>
                  <th className="py-3 text-center text-sm font-medium text-gray-500">سختی رقابت</th>
                  <th className="py-3 text-center text-sm font-medium text-gray-500">قصد جستجو</th>
                  <th className="py-3 text-center text-sm font-medium text-gray-500">CPC</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {suggestions.map((suggestion, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="py-3 text-sm">{suggestion.keyword}</td>
                    <td className="py-3 text-sm text-center">{suggestion.volume.toLocaleString()}</td>
                    <td className="py-3 text-center">
                      <div className="inline-flex items-center gap-2 px-2.5 py-0.5 rounded-full text-xs font-medium capitalize" style={{
                        backgroundColor: suggestion.difficulty <= 30 ? '#dcfce7' : 
                                      suggestion.difficulty <= 70 ? '#fef9c3' : '#fee2e2',
                        color: suggestion.difficulty <= 30 ? '#166534' :
                              suggestion.difficulty <= 70 ? '#854d0e' : '#991b1b'
                      }}>
                        {suggestion.difficulty <= 30 ? 'آسان' :
                         suggestion.difficulty <= 70 ? 'متوسط' : 'سخت'}
                        <button
                          onClick={() => setSelectedKeyword({
                            keyword: suggestion.keyword,
                            suggestions: suggestion.relatedKeywords
                          })}
                          className="brain-icon ml-1"
                        >
                          <Brain className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                    <td className="py-3 text-sm text-center">{suggestion.intent}</td>
                    <td className="py-3 text-sm text-center">${suggestion.cpc.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {selectedKeyword && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fadeIn">
          <div className="bg-white rounded-2xl w-full max-w-2xl relative overflow-hidden shadow-xl">
            <div className="bg-gradient-to-l from-[#a63439]/10 to-transparent border-b border-[#a63439]/10 p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-[#a63439]/10 text-[#a63439]">
                    <Lightbulb className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium">کلمات کلیدی مرتبط</h3>
                    <p className="text-sm text-gray-500">برای کلمه کلیدی "{selectedKeyword.keyword}"</p>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedKeyword(null)}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  ×
                </button>
              </div>
            </div>
            <div className="p-6 space-y-4">
              {selectedKeyword.suggestions.map((suggestion, index) => (
                <div
                  key={index}
                  className="bg-gradient-to-l from-[#a63439]/5 to-transparent border border-[#a63439]/10 rounded-xl p-4 hover:bg-[#a63439]/10 transition-all"
                >
                  <div className="flex items-center gap-3">
                    <ArrowRight className="w-4 h-4 text-[#a63439]" />
                    <p className="text-sm">{suggestion}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}