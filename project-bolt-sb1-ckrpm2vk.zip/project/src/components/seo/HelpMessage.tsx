import React from 'react';
import { Brain } from 'lucide-react';

export default function HelpMessage() {
  return (
    <div className="bg-gradient-to-l from-[#a63439]/5 to-transparent border border-[#a63439]/10 rounded-xl p-4 mb-6">
      <div className="flex items-center gap-3">
        <div className="relative">
          <div className="absolute inset-0 rounded-full bg-[#a63439]/5 flex items-center justify-center animate-pulse">
            <Brain className="w-5 h-5 text-[#a63439]" />
          </div>
        </div>
        <p className="text-sm text-gray-700">
          برای دریافت پیشنهادات هوشمند جهت بهبود هر متریک، روی نشانگر{' '}
          <Brain className="w-4 h-4 text-[#a63439] inline-block align-middle mx-1" />{' '}
          کنار آن کلیک کنید.
        </p>
      </div>
    </div>
  );
}