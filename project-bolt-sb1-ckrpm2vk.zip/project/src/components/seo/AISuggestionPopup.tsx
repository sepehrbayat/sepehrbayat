import React from 'react';
import { X, Loader2, Brain, Sparkles, ArrowRight } from 'lucide-react';

interface Suggestion {
  text: string;
  priority?: 'high' | 'medium' | 'low';
}

interface AISuggestionPopupProps {
  isOpen: boolean;
  onClose: () => void;
  metric: {
    name: string;
    value: string | number;
    description: string;
    status: 'good' | 'warning' | 'poor';
  };
  suggestions: string[] | null;
  isLoading: boolean;
}

export default function AISuggestionPopup({
  isOpen,
  onClose,
  metric,
  suggestions,
  isLoading
}: AISuggestionPopupProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fadeIn overflow-y-auto">
      <div 
        className="bg-white rounded-2xl w-full max-w-2xl relative overflow-hidden shadow-xl my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-l from-[#a63439]/10 to-transparent border-b border-[#a63439]/10 p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                metric.status === 'good' ? 'bg-green-100 text-green-600' :
                metric.status === 'warning' ? 'bg-yellow-100 text-yellow-600' :
                'bg-red-100 text-red-600'
              }`}>
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-medium">{metric.name}</h3>
                <p className="text-sm text-gray-500">{metric.description}</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors p-2 hover:bg-gray-100 rounded-full"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          
          <div className="mt-4 bg-white/50 rounded-xl p-4 border border-[#a63439]/10">
            <div className="text-sm text-gray-600 mb-1">مقدار فعلی</div>
            <div className={`text-2xl font-bold ${
              metric.status === 'good' ? 'text-green-600' :
              metric.status === 'warning' ? 'text-yellow-600' :
              'text-red-600'
            }`}>
              {metric.value}
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 max-h-[calc(100vh-16rem)] overflow-y-auto">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-12">
              <div className="relative mb-6 w-[120px] h-[120px] sm:w-[140px] sm:h-[140px]">
                <div className="absolute inset-0 rounded-full bg-[#a63439]/5 flex items-center justify-center animate-pulse">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Loader2 className="w-12 h-12 sm:w-14 sm:h-14 text-[#a63439] animate-spin" />
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Brain className="w-8 h-8 sm:w-10 sm:h-10 text-[#a63439]" />
                  </div>
                </div>
              </div>
              <div className="text-center">
                <p className="text-gray-700 font-medium mb-1">
                  هوشِکس در حال تحلیل و پیدا کردن بهترین راه‌حل‌ها است...
                </p>
                <p className="text-sm text-gray-500">
                  این فرآیند ممکن است چند ثانیه طول بکشد
                </p>
              </div>
            </div>
          ) : suggestions ? (
            <div className="space-y-4">
              <h4 className="text-sm font-medium text-gray-700 flex items-center gap-2 mb-6">
                <span className="w-2 h-2 rounded-full bg-[#a63439]" />
                پیشنهادات بهبود
              </h4>
              <div className="space-y-3">
                {suggestions.map((suggestion, index) => (
                  <div
                    key={index}
                    className="bg-gradient-to-l from-[#a63439]/5 to-transparent border border-[#a63439]/10 rounded-xl p-4 hover:bg-[#a63439]/10 transition-all group"
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-[#a63439]/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <ArrowRight className="w-4 h-4 text-[#a63439]" />
                      </div>
                      <p className="text-sm leading-relaxed text-gray-700">
                        {typeof suggestion === 'string' ? suggestion : suggestion.text}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : null}
        </div>
      </div>
      <div 
        className="fixed inset-0 -z-10" 
        onClick={onClose}
        aria-hidden="true"
      />
    </div>
  );
}