export const SCORE_THRESHOLDS = {
  GOOD: 90,
  WARNING: 70,
  POOR: 50
} as const;

export const METRIC_THRESHOLDS = {
  TTFB: {
    GOOD: 200,
    WARNING: 500
  },
  FCP: {
    GOOD: 1800,
    WARNING: 3000
  },
  LCP: {
    GOOD: 2500,
    WARNING: 4000
  },
  CLS: {
    GOOD: 0.1,
    WARNING: 0.25
  },
  TBT: {
    GOOD: 200,
    WARNING: 600
  }
} as const;

export const POLL_INTERVAL = 10000; // 10 seconds
export const MAX_POLL_ATTEMPTS = 30; // 5 minutes total