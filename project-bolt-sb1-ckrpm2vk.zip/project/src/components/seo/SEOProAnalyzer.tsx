import React, { useState, useEffect } from 'react';
import { Crown, Star, AlertCircle, Brain, HelpCircle } from 'lucide-react';
import { useAnalysis } from './hooks/useAnalysis';
import { useSuggestions } from './hooks/useSuggestions';
import AISuggestionPopup from './AISuggestionPopup';
import URLInput from './URLInput';
import DeviceTabs from './DeviceTabs';
import OverallScores from './metrics/OverallScores';
import CoreWebVitals from './metrics/CoreWebVitals';
import AccessibilityMetrics from './metrics/AccessibilityMetrics';
import PerformanceMetrics from './metrics/PerformanceMetrics';
import SecurityMetrics from './metrics/SecurityMetrics';
import MainThreadMetrics from './metrics/MainThreadMetrics';
import ContentMetrics from './metrics/ContentMetrics';
import MetaTagsMetrics from './metrics/MetaTagsMetrics';
import DOMMetrics from './metrics/DOMMetrics';
import HistoricalData from './metrics/HistoricalData';

interface SEOScore {
  score: number;
  label: string;
  recommendations: string[];
}

export default function SEOProAnalyzer() {
  const [technicalIssues, setTechnicalIssues] = useState<{
    critical: string[];
    major: string[];
    minor: string[];
  }>({
    critical: [],
    major: [],
    minor: []
  });
  const [optimizationScores, setOptimizationScores] = useState({
    images: 0,
    javascript: 0,
    css: 0,
    caching: 0,
    compression: 0
  });
  const [resourceStats, setResourceStats] = useState({
    totalSize: 0,
    totalRequests: 0,
    networkTimings: {
      ttfb: null,
      fcp: null,
      lcp: null,
      cls: null,
      tbt: null,
      si: null,
      tti: null
    },
    byType: {
      js: { size: 0, count: 0 },
      css: { size: 0, count: 0 },
      images: { size: 0, count: 0 },
      fonts: { size: 0, count: 0 },
      other: { size: 0, count: 0 }
    }
  });

  const {
    url,
    setUrl,
    isAnalyzing,
    error,
    desktopAnalysis,
    mobileAnalysis,
    desktopLighthouse,
    mobileLighthouse,
    selectedDevice,
    setSelectedDevice,
    historicalData,
    seoScore,
    performanceMetrics,
    analyzeSEO
  } = useAnalysis();

  const currentAnalysis = selectedDevice === 'desktop' ? desktopAnalysis : mobileAnalysis;
  const currentLighthouse = selectedDevice === 'desktop' ? desktopLighthouse : mobileLighthouse;

  // Update resource stats when lighthouse data changes
  useEffect(() => {
    if (currentLighthouse?.metrics) {
      setResourceStats(prev => ({
        ...prev,
        networkTimings: {
          ttfb: currentLighthouse.metrics.ttfb,
          fcp: currentLighthouse.metrics.firstContentfulPaint,
          lcp: currentLighthouse.metrics.lcp,
          cls: currentLighthouse.metrics.cls,
          tbt: currentLighthouse.metrics.tbt,
          si: currentLighthouse.metrics.speedIndex,
          tti: currentLighthouse.metrics.timeToInteractive
        },
        totalSize: currentLighthouse.metrics.totalByteWeight,
        totalRequests: currentLighthouse.metrics.resourceSummary.total,
        byType: {
          js: {
            size: currentLighthouse.metrics.resourceSummary.js,
            count: currentLighthouse.metrics.resourceSummary.js
          },
          css: {
            size: currentLighthouse.metrics.resourceSummary.css,
            count: currentLighthouse.metrics.resourceSummary.css
          },
          images: {
            size: currentLighthouse.metrics.resourceSummary.images,
            count: currentLighthouse.metrics.resourceSummary.images
          },
          fonts: {
            size: currentLighthouse.metrics.resourceSummary.fonts,
            count: currentLighthouse.metrics.resourceSummary.fonts
          },
          other: {
            size: currentLighthouse.metrics.resourceSummary.other,
            count: currentLighthouse.metrics.resourceSummary.other
          }
        }
      }));
    }
  }, [currentLighthouse]);
  const handleDeviceChange = (device: 'desktop' | 'mobile') => {
    if (!desktopAnalysis || !mobileAnalysis) return;
    setSelectedDevice(device);
  };

  const {
    selectedMetric,
    showSuggestions,
    suggestions,
    isLoadingSuggestions,
    handleMetricClick,
    setShowSuggestions
  } = useSuggestions();

  const [analysisPhase, setAnalysisPhase] = useState<'desktop' | 'mobile' | 'content' | 'technical' | null>(null);
  const [progress, setProgress] = useState(0);
  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#a63439] to-[#262e43] flex items-center justify-center">
              <Crown className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-medium">تحلیل سئو پیشرفته</h1>
                <div className="flex items-center gap-1 bg-gradient-to-r from-amber-500 to-amber-600 text-white text-xs px-2 py-0.5 rounded-full">
                  <Star className="w-3 h-3 fill-current" />
                  <span>PRO</span>
                </div>
              </div>
              <p className="text-gray-600">تحلیل عمیق و پیشرفته سئو سایت با هوش مصنوعی</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 space-y-6">
          <URLInput
            url={url}
            onUrlChange={setUrl}
            onAnalyze={analyzeSEO}
            isAnalyzing={isAnalyzing}
          />

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              <p>{error}</p>
            </div>
          )}

          {isAnalyzing && (
            <div className="bg-white rounded-xl p-8 text-center space-y-6">
              <div className="relative w-[120px] h-[120px] mx-auto">
                <div className="absolute inset-0 rounded-full bg-[#a63439]/5 flex items-center justify-center animate-pulse">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-[100px] h-[100px] rounded-full border-4 border-[#a63439] border-t-transparent animate-spin" />
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Brain className="w-12 h-12 text-[#a63439]" />
                  </div>
                </div>
              </div>
              <div>
                <p className="text-lg font-medium text-gray-800 mb-2">
                  {analysisPhase === 'desktop' && 'در حال تحلیل نسخه دسکتاپ...'}
                  {analysisPhase === 'mobile' && 'در حال تحلیل نسخه موبایل...'}
                  {analysisPhase === 'content' && 'در حال تحلیل محتوا...'}
                  {analysisPhase === 'technical' && 'در حال بررسی مسائل فنی...'}
                </p>
                <div className="w-full max-w-md mx-auto bg-gray-200 rounded-full h-2.5">
                  <div
                    className="bg-[#a63439] h-2.5 rounded-full transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <p className="text-sm text-gray-500 mt-2">
                  لطفاً صبور باشید. این فرایند ممکن است چند دقیقه طول بکشد.
                </p>
              </div>
            </div>
          )}

          {selectedMetric && (
            <AISuggestionPopup
              isOpen={showSuggestions}
              onClose={() => setShowSuggestions(false)}
              metric={selectedMetric}
              suggestions={suggestions}
              isLoading={isLoadingSuggestions}
            />
          )}

          {currentAnalysis && currentLighthouse && (
            <div className="space-y-8">
              <div className="flex items-center justify-between">
                <DeviceTabs
                  selectedDevice={selectedDevice}
                  onDeviceChange={handleDeviceChange}
                />
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <Brain className="w-4 h-4" />
                  <span>تحلیل هوشمند</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-gradient-to-br from-amber-50 to-amber-100 p-4 rounded-lg text-center">
                  <div className="text-4xl font-bold text-amber-800 mb-2">{Math.round(currentLighthouse?.performance || 0)}</div>
                  <div className="text-sm text-amber-700">عملکرد</div>
                </div>
                <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-lg text-center">
                  <div className="text-4xl font-bold text-blue-800 mb-2">{Math.round(currentLighthouse.seo)}</div>
                  <div className="text-sm text-blue-700">سئو</div>
                </div>
                <div className="bg-gradient-to-br from-green-50 to-green-100 p-4 rounded-lg text-center">
                  <div className="text-4xl font-bold text-green-800 mb-2">{Math.round(currentLighthouse.accessibility)}</div>
                  <div className="text-sm text-green-700">دسترسی‌پذیری</div>
                </div>
                <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-4 rounded-lg text-center">
                  <div className="text-4xl font-bold text-purple-800 mb-2">{Math.round(currentLighthouse.bestPractices)}</div>
                  <div className="text-sm text-purple-700">بهترین شیوه‌ها</div>
                </div>
              </div>
              
              <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="bg-white border border-gray-100 p-4 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1 flex items-center gap-1">
                    TTFB
                    <span className="group relative inline-block">
                      <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                      <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                        زمان دریافت اولین بایت از سرور
                      </div>
                    </span>
                  </div>
                  <div className={`text-lg font-bold flex items-center gap-2 ${
                    resourceStats.networkTimings.ttfb && resourceStats.networkTimings.ttfb <= 200 ? 'text-green-600' :
                    resourceStats.networkTimings.ttfb && resourceStats.networkTimings.ttfb <= 500 ? 'text-yellow-600' :
                    'text-red-600'
                  }`}>
                    {resourceStats.networkTimings.ttfb ? `${resourceStats.networkTimings.ttfb.toFixed(0)}ms` : '-'}
                    <button
                      onClick={() => handleMetricClick({
                        name: 'TTFB',
                        value: `${(currentLighthouse?.metrics?.ttfb || 0)}ms`,
                        description: 'زمان دریافت اولین بایت از سرور',
                        status: (currentLighthouse?.metrics?.ttfb || 0) <= 200 ? 'good' : (currentLighthouse?.metrics?.ttfb || 0) <= 500 ? 'warning' : 'poor',
                        context: {
                          metrics: currentLighthouse?.metrics,
                          device: selectedDevice
                        }
                      })}
                      className="brain-icon"
                    >
                      <Brain className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <div className="bg-white border border-gray-100 p-4 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1 flex items-center gap-1">
                    FCP
                    <span className="group relative inline-block">
                      <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                      <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                        زمان نمایش اولین محتوای صفحه
                      </div>
                    </span>
                  </div>
                  <div className={`text-lg font-bold flex items-center gap-2 ${
                    resourceStats.networkTimings.fcp && resourceStats.networkTimings.fcp <= 1800 ? 'text-green-600' :
                    resourceStats.networkTimings.fcp && resourceStats.networkTimings.fcp <= 3000 ? 'text-yellow-600' :
                    'text-red-600'
                  }`}>
                    {resourceStats.networkTimings.fcp ? `${(resourceStats.networkTimings.fcp / 1000).toFixed(1)}s` : '-'}
                    <button
                      onClick={() => handleMetricClick({
                        name: 'FCP',
                        value: `${((currentLighthouse?.metrics?.firstContentfulPaint || 0) / 1000).toFixed(1)}s`,
                        description: 'زمان نمایش اولین محتوای صفحه',
                        status: (currentLighthouse?.metrics?.firstContentfulPaint || 0) <= 1800 ? 'good' : (currentLighthouse?.metrics?.firstContentfulPaint || 0) <= 3000 ? 'warning' : 'poor',
                        context: {
                          metrics: currentLighthouse?.metrics,
                          device: selectedDevice
                        }
                      })}
                      className="brain-icon"
                    >
                      <Brain className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <div className="bg-white border border-gray-100 p-4 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1 flex items-center gap-1">
                    Speed Index
                    <span className="group relative inline-block">
                      <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                      <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                        شاخص سرعت بارگذاری کلی صفحه
                      </div>
                    </span>
                  </div>
                  <div className={`text-lg font-bold flex items-center gap-2 ${
                    resourceStats.networkTimings.si && resourceStats.networkTimings.si <= 3400 ? 'text-green-600' :
                    resourceStats.networkTimings.si && resourceStats.networkTimings.si <= 5800 ? 'text-yellow-600' :
                    'text-red-600'
                  }`}>
                    {resourceStats.networkTimings.si ? `${(resourceStats.networkTimings.si / 1000).toFixed(1)}s` : '-'}
                    <button
                      onClick={() => handleMetricClick({
                        name: 'Speed Index',
                        value: `${((currentLighthouse?.metrics?.speedIndex || 0) / 1000).toFixed(1)}s`,
                        description: 'شاخص سرعت بارگذاری کلی صفحه',
                        status: (currentLighthouse?.metrics?.speedIndex || 0) <= 3000 ? 'good' : (currentLighthouse?.metrics?.speedIndex || 0) <= 5000 ? 'warning' : 'poor',
                        context: {
                          metrics: currentLighthouse?.metrics,
                          device: selectedDevice
                        }
                      })}
                      className="brain-icon"
                    >
                      <Brain className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="bg-white border border-gray-100 p-4 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1 flex items-center gap-1">
                    TTI
                    <span className="group relative inline-block">
                      <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                      <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                        زمان تا تعامل‌پذیری کامل صفحه
                      </div>
                    </span>
                  </div>
                  <div className={`text-lg font-bold flex items-center gap-2 ${
                    resourceStats.networkTimings.tti && resourceStats.networkTimings.tti <= 3800 ? 'text-green-600' :
                    resourceStats.networkTimings.tti && resourceStats.networkTimings.tti <= 7300 ? 'text-yellow-600' :
                    'text-red-600'
                  }`}>
                    {resourceStats.networkTimings.tti ? `${(resourceStats.networkTimings.tti / 1000).toFixed(1)}s` : '-'}
                    <button
                      onClick={() => handleMetricClick({
                        name: 'TTI',
                        value: `${((currentLighthouse?.metrics?.timeToInteractive || 0) / 1000).toFixed(1)}s`,
                        description: 'زمان تا تعامل‌پذیری کامل صفحه',
                        status: (currentLighthouse?.metrics?.timeToInteractive || 0) <= 3500 ? 'good' : (currentLighthouse?.metrics?.timeToInteractive || 0) <= 7500 ? 'warning' : 'poor',
                        context: {
                          metrics: currentLighthouse?.metrics,
                          device: selectedDevice
                        }
                      })}
                      className="brain-icon"
                    >
                      <Brain className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="mt-6">
                <CoreWebVitals
                  lighthouse={currentLighthouse}
                  device={selectedDevice}
                  onMetricClick={handleMetricClick}
                />

                <AccessibilityMetrics
                  lighthouse={currentLighthouse}
                  onMetricClick={handleMetricClick}
                />

                <PerformanceMetrics
                  lighthouse={currentLighthouse}
                  device={selectedDevice}
                  onMetricClick={handleMetricClick}
                />

                <SecurityMetrics
                  lighthouse={currentLighthouse}
                  performanceMetrics={performanceMetrics}
                  onMetricClick={handleMetricClick}
                />

                <ContentMetrics
                  analysis={currentAnalysis}
                  onMetricClick={handleMetricClick}
                />

                <MetaTagsMetrics
                  analysis={currentAnalysis}
                  onMetricClick={handleMetricClick}
                />

                <MainThreadMetrics
                  lighthouse={currentLighthouse}
                  onMetricClick={handleMetricClick}
                />

                <DOMMetrics
                  lighthouse={currentLighthouse}
                  onMetricClick={handleMetricClick}
                />

                <HistoricalData
                  data={historicalData}
                  selectedDevice={selectedDevice}
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}