import React from 'react';
import { HelpCircle, Brain } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import type { LighthouseReport } from '../../../lib/seo/lighthouse';
import type { SEOAnalysis } from '../../../lib/seo/analyzer';

interface OverallScoresProps {
  seoScore: {
    score: number;
    label: string;
    recommendations: string[];
  };
  lighthouse: LighthouseReport;
  onMetricClick: (metric: any) => void;
  analysis: SEOAnalysis;
}

export default function OverallScores({ seoScore, lighthouse, onMetricClick, analysis }: OverallScoresProps) {
  const { t } = useTranslation();

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
      <div className="bg-gray-50 p-4 rounded-lg text-center">
        <div className={`text-4xl font-bold mb-2 flex items-center justify-center gap-2 ${
          seoScore.score >= 90 ? 'text-green-600' :
          seoScore.score >= 70 ? 'text-blue-600' :
          seoScore.score >= 50 ? 'text-yellow-600' : 'text-red-600'
        }`}>
          {seoScore.score}
          <span className="group relative inline-block">
            <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
            <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
              {t('seo.analysis.metrics.overall')}
            </div>
          </span>
          <button
            onClick={() => onMetricClick({
              name: 'امتیاز کلی',
              value: seoScore.score,
              description: 'امتیاز کلی سئو سایت شما بر اساس فاکتورهای مختلف فنی و محتوایی',
              status: seoScore.score >= 90 ? t('seo.analysis.status.good') : seoScore.score >= 70 ? t('seo.analysis.status.warning') : t('seo.analysis.status.poor'),
              context: {
                recommendations: seoScore.recommendations,
                metaTags: analysis?.metaTags,
                technical: analysis?.technical
              }
            })}
            className="text-[#a63439] hover:text-[#8a2a2e] p-1 rounded-full hover:bg-red-50 transition-colors"
          >
            <Brain className="w-4 h-4" />
          </button>
        </div>
        <div className="text-sm text-gray-600">{t('seo.analysis.metrics.overall')}</div>
      </div>

      <div className="bg-gradient-to-br from-purple-50 to-gray-50 p-4 rounded-lg text-center shadow-sm">
        <div className="text-4xl font-bold mb-2 text-purple-600 flex items-center justify-center gap-2">
          {Math.round(lighthouse.performance)}
          <span className="group relative inline-block">
            <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
            <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
              {t('seo.analysis.metrics.performance')}
            </div>
          </span>
          <button
            onClick={() => onMetricClick({
              name: 'عملکرد',
              value: Math.round(lighthouse.performance),
              description: 'سرعت بارگذاری و عملکرد کلی سایت شما',
              status: lighthouse.performance >= 90 ? t('seo.analysis.status.good') : lighthouse.performance >= 70 ? t('seo.analysis.status.warning') : t('seo.analysis.status.poor'),
              context: {
                metrics: lighthouse.metrics,
                coreWebVitals: lighthouse.coreWebVitals
              }
            })}
            className="text-[#a63439] hover:text-[#8a2a2e] p-1 rounded-full hover:bg-red-50 transition-colors"
          >
            <Brain className="w-4 h-4" />
          </button>
        </div>
        <div className="text-sm text-gray-600">{t('seo.analysis.metrics.performance')}</div>
      </div>

      <div className="bg-gradient-to-br from-blue-50 to-gray-50 p-4 rounded-lg text-center shadow-sm">
        <div className="text-4xl font-bold mb-2 text-blue-600">{Math.round(lighthouse.seo)}</div>
        <div className="text-sm text-gray-600">{t('seo.analysis.metrics.seo')}</div>
      </div>

      <div className="bg-gradient-to-br from-green-50 to-gray-50 p-4 rounded-lg text-center shadow-sm">
        <div className="text-4xl font-bold mb-2 text-green-600">{Math.round(lighthouse.accessibility)}</div>
        <div className="text-sm text-gray-600">{t('seo.analysis.metrics.accessibility')}</div>
      </div>
    </div>
  );
}