import React from 'react';
import { HelpCircle, Brain, Eye, Keyboard, FormInput as Forms, Palette } from 'lucide-react';
import type { LighthouseReport } from '../../../lib/lighthouse';

interface AccessibilityMetricsProps {
  lighthouse: LighthouseReport;
  onMetricClick: (metric: any) => void;
}

export default function AccessibilityMetrics({ lighthouse, onMetricClick }: AccessibilityMetricsProps) {
  return (
    <div>
      <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-[#a63439]" />
        دسترسی‌پذیری
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* ARIA Attributes */}
        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <h4 className="text-sm font-medium mb-4 flex items-center gap-2">
            <Eye className="w-4 h-4 text-[#a63439]" />
            ویژگی‌های ARIA
          </h4>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">تگ‌های ARIA</span>
              <div className="flex items-center gap-2">
                <span className={`text-sm font-medium ${
                  lighthouse.metrics.accessibility?.ariaElements >= 90 ? 'text-green-600' :
                  lighthouse.metrics.accessibility?.ariaElements >= 70 ? 'text-yellow-600' :
                  'text-red-600'
                }`}>
                  {lighthouse.metrics.accessibility?.ariaElements || 0}%
                </span>
                <button
                  onClick={() => onMetricClick({
                    name: 'تگ‌های ARIA',
                    value: `${lighthouse.metrics.accessibility?.ariaElements || 0}%`,
                    description: 'درصد المان‌های دارای ویژگی‌های ARIA',
                    status: lighthouse.metrics.accessibility?.ariaElements >= 90 ? 'good' :
                            lighthouse.metrics.accessibility?.ariaElements >= 70 ? 'warning' : 'poor',
                    context: { metrics: lighthouse.metrics }
                  })}
                  className="brain-icon"
                >
                  <Brain className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Color Contrast */}
        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <h4 className="text-sm font-medium mb-4 flex items-center gap-2">
            <Palette className="w-4 h-4 text-[#a63439]" />
            کنتراست رنگ‌ها
          </h4>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">نسبت کنتراست</span>
              <div className="flex items-center gap-2">
                <span className={`text-sm font-medium ${
                  lighthouse.metrics.accessibility?.colorContrast >= 4.5 ? 'text-green-600' :
                  lighthouse.metrics.accessibility?.colorContrast >= 3 ? 'text-yellow-600' :
                  'text-red-600'
                }`}>
                  {lighthouse.metrics.accessibility?.colorContrast || 0}:1
                </span>
                <button
                  onClick={() => onMetricClick({
                    name: 'نسبت کنتراست',
                    value: `${lighthouse.metrics.accessibility?.colorContrast || 0}:1`,
                    description: 'نسبت کنتراست رنگ متن و پس‌زمینه',
                    status: lighthouse.metrics.accessibility?.colorContrast >= 4.5 ? 'good' :
                            lighthouse.metrics.accessibility?.colorContrast >= 3 ? 'warning' : 'poor',
                    context: { metrics: lighthouse.metrics }
                  })}
                  className="brain-icon"
                >
                  <Brain className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Keyboard Navigation */}
        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <h4 className="text-sm font-medium mb-4 flex items-center gap-2">
            <Keyboard className="w-4 h-4 text-[#a63439]" />
            ناوبری با کیبورد
          </h4>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">قابلیت دسترسی</span>
              <div className="flex items-center gap-2">
                <span className={`text-sm font-medium ${
                  lighthouse.metrics.accessibility?.keyboardNav ? 'text-green-600' : 'text-red-600'
                }`}>
                  {lighthouse.metrics.accessibility?.keyboardNav ? 'فعال' : 'غیرفعال'}
                </span>
                <button
                  onClick={() => onMetricClick({
                    name: 'قابلیت دسترسی با کیبورد',
                    value: lighthouse.metrics.accessibility?.keyboardNav ? 'فعال' : 'غیرفعال',
                    description: 'امکان ناوبری کامل سایت با کیبورد',
                    status: lighthouse.metrics.accessibility?.keyboardNav ? 'good' : 'poor',
                    context: { metrics: lighthouse.metrics }
                  })}
                  className="brain-icon"
                >
                  <Brain className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Form Labels */}
        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <h4 className="text-sm font-medium mb-4 flex items-center gap-2">
            <Forms className="w-4 h-4 text-[#a63439]" />
            برچسب‌های فرم
          </h4>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">برچسب‌های معتبر</span>
              <div className="flex items-center gap-2">
                <span className={`text-sm font-medium ${
                  lighthouse.metrics.accessibility?.formLabels >= 90 ? 'text-green-600' :
                  lighthouse.metrics.accessibility?.formLabels >= 70 ? 'text-yellow-600' :
                  'text-red-600'
                }`}>
                  {lighthouse.metrics.accessibility?.formLabels || 0}%
                </span>
                <button
                  onClick={() => onMetricClick({
                    name: 'برچسب‌های فرم',
                    value: `${lighthouse.metrics.accessibility?.formLabels || 0}%`,
                    description: 'درصد فیلدهای فرم دارای برچسب معتبر',
                    status: lighthouse.metrics.accessibility?.formLabels >= 90 ? 'good' :
                            lighthouse.metrics.accessibility?.formLabels >= 70 ? 'warning' : 'poor',
                    context: { metrics: lighthouse.metrics }
                  })}
                  className="brain-icon"
                >
                  <Brain className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}