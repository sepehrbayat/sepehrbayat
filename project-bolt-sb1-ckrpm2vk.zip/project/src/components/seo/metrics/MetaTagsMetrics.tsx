import React from 'react';
import { HelpCircle, Brain } from 'lucide-react';
import type { SEOAnalysis } from '../../../lib/seo/analyzer';

interface MetaTagsMetricsProps {
  analysis: SEOAnalysis;
  onMetricClick: (metric: any) => void;
}

export default function MetaTagsMetrics({ analysis, onMetricClick }: MetaTagsMetricsProps) {
  return (
    <div>
      <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-[#a63439]" />
        متاتگ‌ها و ساختار
      </h3>
      <div className="grid grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <h4 className="text-sm font-medium mb-4">متاتگ‌های اصلی</h4>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between text-sm mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-gray-600">عنوان صفحه</span>
                  <span className="group relative inline-block">
                    <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                    <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                      تگ title صفحه
                    </div>
                  </span>
                  <button
                    onClick={() => onMetricClick({
                      name: 'عنوان صفحه',
                      value: analysis.metaTags.title || 'تنظیم نشده',
                      description: 'تگ title صفحه',
                      status: analysis.metaTags.title && analysis.metaTags.title.length >= 30 && analysis.metaTags.title.length <= 60 ? 'good' : 'poor',
                      context: {
                        metaTags: analysis.metaTags
                      }
                    })} 
                    className="brain-icon"
                  >
                    <Brain className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <div className="bg-white/50 rounded-lg p-2 text-xs">
                {analysis.metaTags.title || 'تنظیم نشده'}
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-sm mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-gray-600">توضیحات متا</span>
                  <span className="group relative inline-block">
                    <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                    <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                      تگ meta description صفحه
                    </div>
                  </span>
                  <button
                    onClick={() => onMetricClick({
                      name: 'توضیحات متا',
                      value: analysis.metaTags.description || 'تنظیم نشده',
                      description: 'تگ meta description صفحه',
                      status: analysis.metaTags.description && analysis.metaTags.description.length >= 120 && analysis.metaTags.description.length <= 160 ? 'good' : 'poor',
                      context: { metaTags: analysis.metaTags }
                    })}
                    className="text-[#a63439] hover:text-[#8a2a2e] p-1 rounded-full hover:bg-red-50 transition-colors"
                  >
                    <Brain className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <div className="bg-white/50 rounded-lg p-2 text-xs">
                {analysis.metaTags.description || 'تنظیم نشده'}
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <h4 className="text-sm font-medium mb-4">ساختار سرتیترها</h4>
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <span className="text-gray-600">تگ H1</span>
                <span className="group relative inline-block">
                  <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                  <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                    تعداد تگ‌های H1 در صفحه
                  </div>
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-medium">{analysis.headers.h1Count}</span>
                <button
                  onClick={() => onMetricClick({
                    name: 'تگ H1',
                    value: analysis.headers.h1Count,
                    description: 'تعداد تگ‌های H1 در صفحه',
                    status: analysis.headers.h1Count === 1 ? 'good' : 'poor',
                    context: { headers: analysis.headers }
                  })}
                  className="text-[#a63439] hover:text-[#8a2a2e] p-1 rounded-full hover:bg-red-50 transition-colors"
                >
                  <Brain className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <span className="text-gray-600">تگ H2</span>
                <span className="group relative inline-block">
                  <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                  <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                    تعداد تگ‌های H2 در صفحه
                  </div>
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-medium">{analysis.headers.h2Count}</span>
                <button
                  onClick={() => onMetricClick({
                    name: 'تگ H2',
                    value: analysis.headers.h2Count,
                    description: 'تعداد تگ‌های H2 در صفحه',
                    status: analysis.headers.h2Count >= 2 && analysis.headers.h2Count <= 6 ? 'good' : 'poor',
                    context: { headers: analysis.headers }
                  })}
                  className="text-[#a63439] hover:text-[#8a2a2e] p-1 rounded-full hover:bg-red-50 transition-colors"
                >
                  <Brain className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <span className="text-gray-600">تگ H3</span>
                <span className="group relative inline-block">
                  <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                  <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                    تعداد تگ‌های H3 در صفحه
                  </div>
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-medium">{analysis.headers.h3Count}</span>
                <button
                  onClick={() => onMetricClick({
                    name: 'تگ H3',
                    value: analysis.headers.h3Count,
                    description: 'تعداد تگ‌های H3 در صفحه',
                    status: analysis.headers.h3Count >= 2 ? 'good' : 'poor',
                    context: { headers: analysis.headers }
                  })}
                  className="text-[#a63439] hover:text-[#8a2a2e] p-1 rounded-full hover:bg-red-50 transition-colors"
                >
                  <Brain className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}