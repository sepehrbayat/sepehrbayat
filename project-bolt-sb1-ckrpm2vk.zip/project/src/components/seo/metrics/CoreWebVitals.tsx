import React from 'react';
import { HelpCircle, Brain } from 'lucide-react';
import type { LighthouseReport } from '../../../lib/seo/lighthouse';
import { METRIC_THRESHOLDS } from '../constants';

interface CoreWebVitalsProps {
  lighthouse: LighthouseReport;
  device: 'desktop' | 'mobile';
  onMetricClick: (metric: any) => void;
}

export default function CoreWebVitals({ lighthouse, device, onMetricClick }: CoreWebVitalsProps) {
  return (
    <div>
      <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-[#a63439]" />
        Core Web Vitals
      </h3>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {/* LCP */}
        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <div className="text-sm text-gray-600 mb-2 font-medium">LCP</div>
          <div className={`text-2xl font-bold flex items-center gap-2 ${
            lighthouse.coreWebVitals.lcp <= 2500 ? 'text-green-600' :
            lighthouse.coreWebVitals.lcp <= 4000 ? 'text-yellow-600' :
            'text-red-600'
          }`}>
            {(lighthouse.coreWebVitals.lcp / 1000).toFixed(1)}s
            <span className="group relative inline-block">
              <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
              <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                زمان نمایش بزرگترین محتوای صفحه. کمتر از 2.5 ثانیه عالی است.
              </div>
            </span>
            <button
              onClick={() => onMetricClick({
                name: 'LCP',
                value: `${(lighthouse.coreWebVitals.lcp / 1000).toFixed(1)}s`,
                description: 'زمان نمایش بزرگترین محتوای صفحه',
                status: lighthouse.coreWebVitals.lcp <= 2500 ? 'good' : lighthouse.coreWebVitals.lcp <= 4000 ? 'warning' : 'poor',
                context: {
                  metrics: lighthouse.metrics,
                  device
                }
              })} 
              className="brain-icon"
            >
              <Brain className="w-4 h-4" />
            </button>
          </div>
          <div className="text-xs text-gray-500 mt-1">
            Largest Contentful Paint
          </div>
        </div>

        {/* FID */}
        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <div className="text-sm text-gray-600 mb-2 font-medium">FID</div>
          <div className={`text-2xl font-bold flex items-center gap-2 ${
            lighthouse.coreWebVitals.fid <= 100 ? 'text-green-600' :
            lighthouse.coreWebVitals.fid <= 300 ? 'text-yellow-600' :
            'text-red-600'
          }`}>
            {lighthouse.coreWebVitals.fid.toFixed(0)}ms
            <span className="group relative inline-block">
              <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
              <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                تأخیر در اولین تعامل کاربر. کمتر از 100 میلی‌ثانیه عالی است.
              </div>
            </span>
            <button
              onClick={() => onMetricClick({
                name: 'FID',
                value: `${lighthouse.coreWebVitals.fid.toFixed(0)}ms`,
                description: 'تأخیر در اولین تعامل کاربر',
                status: lighthouse.coreWebVitals.fid <= 100 ? 'good' : lighthouse.coreWebVitals.fid <= 300 ? 'warning' : 'poor',
                context: {
                  metrics: lighthouse.metrics,
                  device
                }
              })} 
              className="brain-icon"
            >
              <Brain className="w-4 h-4" />
            </button>
          </div>
          <div className="text-xs text-gray-500 mt-1">
            First Input Delay
          </div>
        </div>

        {/* CLS */}
        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <div className="text-sm text-gray-600 mb-2 font-medium">CLS</div>
          <div className={`text-2xl font-bold flex items-center gap-2 ${
            lighthouse.coreWebVitals.cls <= 0.1 ? 'text-green-600' :
            lighthouse.coreWebVitals.cls <= 0.25 ? 'text-yellow-600' :
            'text-red-600'
          }`}>
            {lighthouse.coreWebVitals.cls.toFixed(3)}
            <span className="group relative inline-block">
              <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
              <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                میزان جابجایی ناخواسته محتوا. کمتر از 0.1 عالی است.
              </div>
            </span>
            <button
              onClick={() => onMetricClick({
                name: 'CLS',
                value: lighthouse.coreWebVitals.cls.toFixed(3),
                description: 'میزان جابجایی ناخواسته محتوا',
                status: lighthouse.coreWebVitals.cls <= 0.1 ? 'good' : lighthouse.coreWebVitals.cls <= 0.25 ? 'warning' : 'poor',
                context: {
                  metrics: lighthouse.metrics,
                  device
                }
              })} 
              className="brain-icon"
            >
              <Brain className="w-4 h-4" />
            </button>
          </div>
          <div className="text-xs text-gray-500 mt-1">
            Cumulative Layout Shift
          </div>
        </div>
        
        {/* TBT */}
        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <div className="text-sm text-gray-600 mb-2 font-medium">TBT</div>
          <div className={`text-2xl font-bold flex items-center gap-2 ${
            lighthouse.coreWebVitals.tbt <= 200 ? 'text-green-600' :
            lighthouse.coreWebVitals.tbt <= 600 ? 'text-yellow-600' :
            'text-red-600'
          }`}>
            {lighthouse.coreWebVitals.tbt.toFixed(0)}ms
            <span className="group relative inline-block">
              <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
              <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                زمان کل مسدود شدن صفحه. کمتر از 200 میلی‌ثانیه عالی است.
              </div>
            </span>
            <button
              onClick={() => onMetricClick({
                name: 'TBT',
                value: `${lighthouse.coreWebVitals.tbt.toFixed(0)}ms`,
                description: 'زمان کل مسدود شدن صفحه',
                status: lighthouse.coreWebVitals.tbt <= METRIC_THRESHOLDS.TBT.GOOD ? 'good' :
                        lighthouse.coreWebVitals.tbt <= METRIC_THRESHOLDS.TBT.WARNING ? 'warning' : 'poor',
                context: { metrics: lighthouse.metrics, device }
              })} 
              className="brain-icon"
            >
              <Brain className="w-4 h-4" />
            </button>
          </div>
          <div className="text-xs text-gray-500 mt-1">
            Total Blocking Time
          </div>
        </div>
      </div>
    </div>
  );
}