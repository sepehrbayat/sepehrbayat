import React from 'react';
import { HelpCircle, Brain } from 'lucide-react';
import type { LighthouseReport } from '../../../lib/seo/lighthouse';

interface MainThreadMetricsProps {
  lighthouse: LighthouseReport;
  onMetricClick: (metric: any) => void;
}

export default function MainThreadMetrics({ lighthouse, onMetricClick }: MainThreadMetricsProps) {
  return (
    <div>
      <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-[#a63439]" />
        عملکرد پردازش
      </h3>
      <div className="grid grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <h4 className="text-sm font-medium mb-4">زمان پردازش اصلی</h4>
          <div className="space-y-3">
            {Object.entries(lighthouse.metrics.mainThreadWork).map(([type, time]) => (
              <div key={type} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <span className="text-gray-600">{type}</span>
                  <span className="group relative inline-block">
                    <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                    <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                      {type === 'scriptEvaluation' ? 'زمان اجرای اسکریپت‌ها' :
                       type === 'styleLayout' ? 'زمان محاسبه استایل و لایه‌بندی' :
                       type === 'rendering' ? 'زمان رندر محتوا' :
                       type === 'painting' ? 'زمان نقاشی صفحه' : 'سایر عملیات'}
                    </div>
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-medium">{time}ms</span>
                  <button
                    onClick={() => onMetricClick({
                      name: type,
                      value: `${time}ms`,
                      description: `زمان صرف شده برای ${type}`,
                      status: time < 500 ? 'good' : time < 1000 ? 'warning' : 'poor',
                      context: {
                        metrics: lighthouse.metrics
                      }
                    })} 
                    className="brain-icon"
                  >
                    <Brain className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <h4 className="text-sm font-medium mb-4">منابع شخص ثالث</h4>
          <div className="space-y-4">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <span className="text-gray-600">حجم کل</span>
                <span className="group relative inline-block">
                  <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                  <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                    حجم کل منابع شخص ثالث
                  </div>
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-medium">{Math.round(lighthouse.metrics.thirdPartyUsage.totalBytes / 1024)} KB</span>
                <button
                  onClick={() => onMetricClick({
                    name: 'حجم منابع شخص ثالث',
                    value: `${Math.round(lighthouse.metrics.thirdPartyUsage.totalBytes / 1024)} KB`,
                    description: 'حجم کل منابع شخص ثالث',
                    status: lighthouse.metrics.thirdPartyUsage.totalBytes < 200000 ? 'good' : lighthouse.metrics.thirdPartyUsage.totalBytes < 500000 ? 'warning' : 'poor',
                    context: { metrics: lighthouse.metrics }
                  })}
                  className="text-[#a63439] hover:text-[#8a2a2e] p-1 rounded-full hover:bg-red-50 transition-colors"
                >
                  <Brain className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <span className="text-gray-600">زمان بلاک</span>
                <span className="group relative inline-block">
                  <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                  <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                    زمان بلاک شده توسط منابع شخص ثالث
                  </div>
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-medium">{lighthouse.metrics.thirdPartyUsage.totalBlockingTime}ms</span>
                <button
                  onClick={() => onMetricClick({
                    name: 'زمان بلاک شخص ثالث',
                    value: `${lighthouse.metrics.thirdPartyUsage.totalBlockingTime}ms`,
                    description: 'زمان بلاک شده توسط منابع شخص ثالث',
                    status: lighthouse.metrics.thirdPartyUsage.totalBlockingTime < 100 ? 'good' : lighthouse.metrics.thirdPartyUsage.totalBlockingTime < 200 ? 'warning' : 'poor',
                    context: { metrics: lighthouse.metrics }
                  })}
                  className="text-[#a63439] hover:text-[#8a2a2e] p-1 rounded-full hover:bg-red-50 transition-colors"
                >
                  <Brain className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}