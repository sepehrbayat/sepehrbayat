import React from 'react';
import { HelpCircle, Brain } from 'lucide-react';
import type { SEOAnalysis } from '../../../lib/seo/analyzer';

interface ContentMetricsProps {
  analysis: SEOAnalysis;
  onMetricClick: (metric: any) => void;
}

export default function ContentMetrics({ analysis, onMetricClick }: ContentMetricsProps) {
  return (
    <div>
      <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-[#a63439]" />
        تحلیل محتوا
      </h3>
      <div className="grid grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <h4 className="text-sm font-medium mb-4">آمار محتوا</h4>
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <span className="text-gray-600">تعداد کلمات</span>
                <span className="group relative inline-block">
                  <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                  <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                    تعداد کل کلمات در محتوای صفحه
                  </div>
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-medium">{analysis.content.wordCount}</span>
                <button
                  onClick={() => onMetricClick({
                    name: 'تعداد کلمات',
                    value: analysis.content.wordCount,
                    description: 'تعداد کل کلمات در محتوای صفحه',
                    status: analysis.content.wordCount >= 1000 ? 'good' : analysis.content.wordCount >= 500 ? 'warning' : 'poor',
                    context: { content: analysis.content }
                  })} 
                  className="brain-icon"
                >
                  <Brain className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <span className="text-gray-600">امتیاز خوانایی</span>
                <span className="group relative inline-block">
                  <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                  <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                    میزان سهولت خواندن و درک محتوا
                  </div>
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-medium">{analysis.content.readabilityScore}</span>
                <button
                  onClick={() => onMetricClick({
                    name: 'امتیاز خوانایی',
                    value: analysis.content.readabilityScore,
                    description: 'میزان سهولت خواندن و درک محتوا',
                    status: analysis.content.readabilityScore >= 70 ? 'good' : analysis.content.readabilityScore >= 50 ? 'warning' : 'poor',
                    context: { content: analysis.content }
                  })}
                  className="text-[#a63439] hover:text-[#8a2a2e] p-1 rounded-full hover:bg-red-50 transition-colors"
                >
                  <Brain className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <span className="text-gray-600">لینک‌های داخلی</span>
                <span className="group relative inline-block">
                  <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                  <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                    تعداد لینک‌های داخلی به صفحات دیگر سایت
                  </div>
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-medium">{analysis.content.internalLinks}</span>
                <button
                  onClick={() => onMetricClick({
                    name: 'لینک‌های داخلی',
                    value: analysis.content.internalLinks,
                    description: 'تعداد لینک‌های داخلی به صفحات دیگر سایت',
                    status: analysis.content.internalLinks >= 5 ? 'good' : analysis.content.internalLinks >= 2 ? 'warning' : 'poor',
                    context: { content: analysis.content }
                  })}
                  className="text-[#a63439] hover:text-[#8a2a2e] p-1 rounded-full hover:bg-red-50 transition-colors"
                >
                  <Brain className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <h4 className="text-sm font-medium mb-4">کلمات کلیدی پرتکرار</h4>
          <div className="space-y-3">
            {Object.entries(analysis.content.keywordDensity).map(([keyword, density]) => (
              <div key={keyword} className="flex items-center justify-between text-sm">
                <span className="text-gray-600">{keyword}</span>
                <div className="flex items-center gap-2">
                  <span className="font-medium">{density.toFixed(1)}%</span>
                  <button
                    onClick={() => onMetricClick({
                      name: `تراکم کلمه کلیدی "${keyword}"`,
                      value: `${density.toFixed(1)}%`,
                      description: 'درصد تکرار کلمه کلیدی در محتوا',
                      status: density >= 0.5 && density <= 2.5 ? 'good' : density > 2.5 ? 'warning' : 'poor',
                      context: { content: analysis.content }
                    })}
                    className="text-[#a63439] hover:text-[#8a2a2e] p-1 rounded-full hover:bg-red-50 transition-colors"
                  >
                    <Brain className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}