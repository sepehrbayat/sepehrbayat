import React from 'react';
import { HelpCircle, Brain, Zap, Database, Image as ImageIcon, Globe, Lock, Gauge } from 'lucide-react';
import type { LighthouseReport } from '../../../lib/lighthouse';
import { METRIC_THRESHOLDS } from '../../../lib/lighthouse/constants';

interface PerformanceMetricsProps {
  lighthouse?: LighthouseReport | null;
  device: 'desktop' | 'mobile';
  onMetricClick: (metric: any) => void;
}

export default function PerformanceMetrics({ lighthouse, device, onMetricClick }: PerformanceMetricsProps) {
  // Early return with loading state if no data
  if (!lighthouse?.metrics) {
    return (
      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="bg-gray-50 animate-pulse h-24 rounded-lg" />
        ))}
      </div>
    );
  }

  const { metrics } = lighthouse;

  const getStatusColor = (value: number, thresholds: { good: number; warning: number }) => {
    return value <= thresholds.good ? 'text-green-600' :
           value <= thresholds.warning ? 'text-yellow-600' :
           'text-red-600';
  };

  const getMetricStatus = (value: number, metric: keyof typeof METRIC_THRESHOLDS) => {
    return value <= METRIC_THRESHOLDS[metric].GOOD ? 'good' :
           value <= METRIC_THRESHOLDS[metric].WARNING ? 'warning' : 'poor';
  };

  return (
    <div>
      <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-[#a63439]" />
        متریک‌های عملکرد
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Core Performance Metrics */}
        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <h4 className="text-sm font-medium mb-4 flex items-center gap-2">
            <Gauge className="w-4 h-4 text-[#a63439]" />
            متریک‌های اصلی
          </h4>
          <div className="space-y-3">
            {Object.entries(metrics.mainThreadWork).map(([type, time]) => (
              <div key={type} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <span className="text-gray-600">{type}</span>
                  <span className="group relative inline-block">
                    <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                    <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                      {type === 'scriptEvaluation' ? 'زمان اجرای اسکریپت‌ها' :
                       type === 'styleLayout' ? 'زمان محاسبه استایل و لایه‌بندی' :
                       type === 'rendering' ? 'زمان رندر محتوا' :
                       type === 'painting' ? 'زمان نقاشی صفحه' : 'سایر عملیات'}
                    </div>
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-medium">{time}ms</span>
                  <button
                    onClick={() => onMetricClick({
                      name: type,
                      value: `${time}ms`,
                      description: `زمان صرف شده برای ${type}`,
                      status: time < 500 ? 'good' : time < 1000 ? 'warning' : 'poor',
                      context: {
                        metrics: metrics
                      }
                    })} 
                    className="brain-icon"
                  >
                    <Brain className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <h4 className="text-sm font-medium mb-4 flex items-center gap-2">
            <Zap className="w-4 h-4 text-[#a63439]" />
            بهینه‌سازی منابع
          </h4>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">فایل‌های جاوااسکریپت</span>
                <span className="text-sm font-medium">
                  {metrics.unusedJavaScript ? `${(metrics.unusedJavaScript / 1024).toFixed(1)} KB غیرفعال` : '-'}
                </span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-[#a63439] transition-all"
                  style={{
                    width: `${metrics.unusedJavaScript ? Math.min(100, (metrics.unusedJavaScript / 1024 / 10)) : 0}%`
                  }}
                />
              </div>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">استایل‌های CSS</span>
                <span className="text-sm font-medium">
                  {metrics.unusedCSS ? `${(metrics.unusedCSS / 1024).toFixed(1)} KB غیرفعال` : '-'}
                </span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-[#a63439] transition-all"
                  style={{
                    width: `${metrics.unusedCSS ? Math.min(100, (metrics.unusedCSS / 1024 / 5)) : 0}%`
                  }}
                />
              </div>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">تصاویر</span>
                <span className="text-sm font-medium">
                  {metrics.optimizedImages ? `${metrics.optimizedImages}% بهینه شده` : '-'}
                </span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-[#a63439] transition-all"
                  style={{
                    width: `${metrics.optimizedImages || 0}%`
                  }}
                />
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <h4 className="text-sm font-medium mb-4 flex items-center gap-2">
            <Globe className="w-4 h-4 text-[#a63439]" />
            شبکه و بارگذاری
          </h4>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">زمان پاسخ سرور</span>
              <div className="flex items-center gap-2">
                <span className={`text-sm font-medium ${getStatusColor(metrics.serverResponseTime || 0, { good: 100, warning: 200 })}`}>
                  {metrics.serverResponseTime || 0}ms
                </span>
                <button
                  onClick={() => onMetricClick({
                    name: 'زمان پاسخ سرور',
                    value: `${metrics.serverResponseTime || 0}ms`,
                    description: 'زمان پاسخگویی سرور به درخواست‌ها',
                    status: getMetricStatus(metrics.serverResponseTime || 0, 'TTFB'),
                    context: { metrics }
                  })}
                  className="brain-icon"
                >
                  <Brain className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">تأخیر شبکه</span>
              <div className="flex items-center gap-2">
                <span className={`text-sm font-medium ${getStatusColor(metrics.networkRtt || 0, { good: 50, warning: 100 })}`}>
                  {metrics.networkRtt || 0}ms
                </span>
                <button
                  onClick={() => onMetricClick({
                    name: 'تأخیر شبکه',
                    value: `${metrics.networkRtt || 0}ms`,
                    description: 'زمان رفت و برگشت درخواست‌های شبکه',
                    status: metrics.networkRtt <= 50 ? 'good' : metrics.networkRtt <= 100 ? 'warning' : 'poor',
                    context: { metrics }
                  })}
                  className="brain-icon"
                >
                  <Brain className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">حجم کل منابع</span>
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">
                  {((metrics.totalByteWeight || 0) / 1024 / 1024).toFixed(1)} MB
                </span>
                <button
                  onClick={() => onMetricClick({
                    name: 'حجم کل منابع',
                    value: `${((metrics.totalByteWeight || 0) / 1024 / 1024).toFixed(1)} MB`,
                    description: 'مجموع حجم تمام منابع صفحه',
                    status: metrics.totalByteWeight <= 1024 * 1024 ? 'good' : metrics.totalByteWeight <= 2048 * 1024 ? 'warning' : 'poor',
                    context: { metrics }
                  })}
                  className="brain-icon"
                >
                  <Brain className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <h4 className="text-sm font-medium mb-4 flex items-center gap-2">
            <Lock className="w-4 h-4 text-[#a63439]" />
            امنیت و پروتکل‌ها
          </h4>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">HTTPS</span>
              <span className={`text-sm font-medium ${metrics.security?.https ? 'text-green-600' : 'text-red-600'}`}>
                {metrics.security?.https ? 'فعال' : 'غیرفعال'}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">محتوای مختلط</span>
              <span className={`text-sm font-medium ${!metrics.security?.mixedContent ? 'text-green-600' : 'text-red-600'}`}>
                {!metrics.security?.mixedContent ? 'ندارد' : 'دارد'}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">گواهی SSL</span>
              <span className={`text-sm font-medium ${metrics.security?.certificate?.valid ? 'text-green-600' : 'text-red-600'}`}>
                {metrics.security?.certificate?.valid ? 'معتبر' : 'نامعتبر'}
              </span>
            </div>
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <h4 className="text-sm font-medium mb-4 flex items-center gap-2">
            <Database className="w-4 h-4 text-[#a63439]" />
            کش و فشرده‌سازی
          </h4>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">فشرده‌سازی Gzip/Brotli</span>
              <span className={`text-sm font-medium ${metrics.compressedResources ? 'text-green-600' : 'text-red-600'}`}>
                {metrics.compressedResources ? 'فعال' : 'غیرفعال'}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">کش مرورگر</span>
              <span className={`text-sm font-medium ${metrics.cacheHeaders ? 'text-green-600' : 'text-red-600'}`}>
                {metrics.cacheHeaders ? 'فعال' : 'غیرفعال'}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">TTL کش</span>
              <span className="text-sm font-medium">
                {metrics.staticCacheTtl ? `${Math.round(metrics.staticCacheTtl / 3600 / 24)} روز` : '-'}
              </span>
            </div>
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <h4 className="text-sm font-medium mb-4 flex items-center gap-2">
            <ImageIcon className="w-4 h-4 text-[#a63439]" />
            بهینه‌سازی تصاویر
          </h4>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">فرمت‌های نسل جدید</span>
              <span className="text-sm font-medium">
                {metrics.images?.nextGen ? `${metrics.images.nextGen}%` : '-'}
                {metrics.images?.webpEnabled && <span className="text-xs text-green-600 mr-2">(WebP)</span>}
                {metrics.images?.avifEnabled && <span className="text-xs text-green-600 mr-2">(AVIF)</span>}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">تصاویر ریسپانسیو</span>
              <span className="text-sm font-medium">
                {metrics.images?.responsive ? `${metrics.images.responsive}%` : '-'}
                {metrics.images?.sizesAttribute && <span className="text-xs text-green-600 mr-2">(sizes)</span>}
                {metrics.images?.srcsetAttribute && <span className="text-xs text-green-600 mr-2">(srcset)</span>}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Lazy Loading</span>
              <span className="text-sm font-medium">
                {metrics.images?.lazyLoaded ? `${metrics.images.lazyLoaded}%` : '-'}
                {metrics.images?.lazyLoadEnabled && <span className="text-xs text-green-600 mr-2">(فعال)</span>}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">حجم کل تصاویر</span>
              <span className="text-sm font-medium">
                {metrics.images?.totalBytes ? `${(metrics.images.totalBytes / 1024 / 1024).toFixed(1)} MB` : '-'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}