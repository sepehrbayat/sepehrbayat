import React from 'react';
import { Shield, Users, CheckCircle2, XCircle, Brain } from 'lucide-react';
import type { LighthouseReport } from '../../../lib/seo/lighthouse';

interface SecurityMetricsProps {
  lighthouse: LighthouseReport;
  performanceMetrics: {
    security: {
      score: number;
      features: {
        https: boolean;
        csp: boolean;
        hsts: boolean;
        xss: boolean;
      };
    };
    userExperience: {
      score: number;
    };
  };
  onMetricClick: (metric: any) => void;
}

export default function SecurityMetrics({ lighthouse, performanceMetrics, onMetricClick }: SecurityMetricsProps) {
  return (
    <div>
      <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-[#a63439]" />
        امنیت و دسترسی‌پذیری
      </h3>
      <div className="grid grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-[#a63439]" />
              <span className="font-medium">امنیت</span>
              <button
                onClick={() => onMetricClick({
                  name: 'امنیت',
                  value: `${performanceMetrics.security.score}%`,
                  description: 'امتیاز امنیت سایت',
                  status: performanceMetrics.security.score >= 90 ? 'good' : performanceMetrics.security.score >= 70 ? 'warning' : 'poor',
                  context: {
                    metrics: lighthouse.metrics,
                    device
                  }
                })} 
                className="brain-icon"
              >
                <Brain className="w-4 h-4" />
              </button>
            </div>
            <div className={`text-lg font-bold ${
              performanceMetrics.security.score >= 90 ? 'text-green-600' :
              performanceMetrics.security.score >= 70 ? 'text-blue-600' :
              performanceMetrics.security.score >= 50 ? 'text-yellow-600' : 'text-red-600'
            }`}>
              {performanceMetrics.security.score}%
            </div>
          </div>
          <div className="space-y-2">
            {Object.entries(performanceMetrics.security.features).map(([key, enabled]) => (
              <div key={key} className="flex items-center justify-between text-sm">
                <span className="text-gray-600">{key.toUpperCase()}</span>
                {enabled ? (
                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                ) : (
                  <XCircle className="w-4 h-4 text-red-500" />
                )}
              </div>
            ))}
          </div>
        </div>
        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-[#a63439]" />
              <span className="font-medium">تجربه کاربری</span>
              <button
                onClick={() => onMetricClick({
                  name: 'تجربه کاربری',
                  value: `${performanceMetrics.userExperience.score}%`,
                  description: 'امتیاز تجربه کاربری سایت',
                  status: performanceMetrics.userExperience.score >= 90 ? 'good' : performanceMetrics.userExperience.score >= 70 ? 'warning' : 'poor',
                  context: { accessibility: lighthouse.accessibility, bestPractices: lighthouse.bestPractices }
                })}
                className="text-[#a63439] hover:text-[#8a2a2e] p-1 rounded-full hover:bg-red-50 transition-colors"
              >
                <Brain className="w-4 h-4" />
              </button>
            </div>
            <div className={`text-lg font-bold ${
              performanceMetrics.userExperience.score >= 90 ? 'text-green-600' :
              performanceMetrics.userExperience.score >= 70 ? 'text-blue-600' :
              performanceMetrics.userExperience.score >= 50 ? 'text-yellow-600' : 'text-red-600'
            }`}>
              {performanceMetrics.userExperience.score}%
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">دسترسی‌پذیری</span>
              <span className="font-medium">{Math.round(lighthouse.accessibility)}%</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">بهترین شیوه‌ها</span>
              <span className="font-medium">{Math.round(lighthouse.bestPractices)}%</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">PWA</span>
              <span className="font-medium">{Math.round(lighthouse.progressiveWebApp)}%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}