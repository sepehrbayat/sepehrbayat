import React from 'react';
import type { LighthouseReport } from '../../../lib/seo/lighthouse';

interface ResourceMetricsProps {
  lighthouse: LighthouseReport;
}

export default function ResourceMetrics({ lighthouse }: ResourceMetricsProps) {
  return (
    <div>
      <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-[#a63439]" />
        منابع و عملکرد
      </h3>
      <div className="grid grid-cols-2 gap-6">
        <div className="bg-white rounded-lg p-6 border border-gray-100">
          <h4 className="text-sm font-medium mb-4">منابع صفحه</h4>
          <div className="space-y-3">
            {Object.entries(lighthouse.metrics.resourceSummary).map(([type, count]) => (
              <div key={type} className="flex items-center justify-between text-sm">
                <span className="text-gray-600">{type}</span>
                <span className="font-medium">{count}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-white rounded-lg p-6 border border-gray-100">
          <h4 className="text-sm font-medium mb-4">زمان‌بندی اجرا</h4>
          <div className="space-y-3">
            {Object.entries(lighthouse.metrics.mainThreadWork).map(([type, time]) => (
              <div key={type} className="flex items-center justify-between text-sm">
                <span className="text-gray-600">{type}</span>
                <span className="font-medium">{time}ms</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}