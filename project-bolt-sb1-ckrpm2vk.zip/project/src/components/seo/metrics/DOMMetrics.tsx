import React from 'react';
import { HelpCircle, Brain } from 'lucide-react';
import type { LighthouseReport } from '../../../lib/seo/lighthouse';

interface DOMMetricsProps {
  lighthouse: LighthouseReport;
  onMetricClick: (metric: any) => void;
}

export default function DOMMetrics({ lighthouse, onMetricClick }: DOMMetricsProps) {
  return (
    <div>
      <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-[#a63439]" />
        متریک‌های DOM
      </h3>
      <div className="grid grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">زمان بارگذاری DOM</span>
              <span className="group relative inline-block">
                <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                  زمان بارگذاری و پردازش اولیه DOM
                </div>
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-medium">{lighthouse.metrics.domContentLoaded}ms</span>
              <button
                onClick={() => onMetricClick({
                  name: 'زمان بارگذاری DOM',
                  value: `${lighthouse.metrics.domContentLoaded}ms`,
                  description: 'زمان بارگذاری و پردازش اولیه DOM',
                  status: lighthouse.metrics.domContentLoaded < 1000 ? 'good' : lighthouse.metrics.domContentLoaded < 2000 ? 'warning' : 'poor',
                  context: {
                    metrics: lighthouse.metrics
                  }
                })} 
                className="brain-icon"
              >
                <Brain className="w-4 h-4" />
              </button>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">اندازه DOM</span>
              <span className="group relative inline-block">
                <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                  تعداد کل المان‌های DOM
                </div>
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-medium">{lighthouse.metrics.domSize} المان</span>
              <button
                onClick={() => onMetricClick({
                  name: 'اندازه DOM',
                  value: `${lighthouse.metrics.domSize} المان`,
                  description: 'تعداد کل المان‌های DOM',
                  status: lighthouse.metrics.domSize < 800 ? 'good' : lighthouse.metrics.domSize < 1500 ? 'warning' : 'poor',
                  context: { metrics: lighthouse.metrics }
                })}
                className="text-[#a63439] hover:text-[#8a2a2e] p-1 rounded-full hover:bg-red-50 transition-colors"
              >
                <Brain className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-[#a63439]/5 to-gray-50 p-6 rounded-xl shadow-sm">
          <h4 className="text-sm font-medium mb-4">منابع صفحه</h4>
          <div className="space-y-3">
            {Object.entries(lighthouse.metrics.resourceSummary).map(([type, count]) => (
              <div key={type} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <span className="text-gray-600">{type}</span>
                  <span className="group relative inline-block">
                    <HelpCircle className="w-4 h-4 text-gray-400 cursor-help" />
                    <div className="opacity-0 bg-black text-white text-xs rounded-lg py-2 px-3 absolute z-10 bottom-full right-1/2 transform translate-x-1/2 mb-2 w-48 pointer-events-none group-hover:opacity-100 transition-opacity">
                      {type === 'total' ? 'تعداد کل منابع' :
                       type === 'js' ? 'تعداد فایل‌های جاوااسکریپت' :
                       type === 'css' ? 'تعداد فایل‌های CSS' :
                       type === 'images' ? 'تعداد تصاویر' :
                       type === 'fonts' ? 'تعداد فونت‌ها' : 'سایر منابع'}
                    </div>
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-medium">{count}</span>
                  <button
                    onClick={() => onMetricClick({
                      name: `تعداد ${type}`,
                      value: count,
                      description: `تعداد منابع از نوع ${type}`,
                      status: type === 'total' ? (count < 50 ? 'good' : count < 100 ? 'warning' : 'poor') :
                              type === 'js' ? (count < 15 ? 'good' : count < 30 ? 'warning' : 'poor') :
                              type === 'css' ? (count < 5 ? 'good' : count < 10 ? 'warning' : 'poor') :
                              type === 'images' ? (count < 20 ? 'good' : count < 40 ? 'warning' : 'poor') :
                              type === 'fonts' ? (count < 3 ? 'good' : count < 6 ? 'warning' : 'poor') : 'good',
                      context: { metrics: lighthouse.metrics }
                    })}
                    className="text-[#a63439] hover:text-[#8a2a2e] p-1 rounded-full hover:bg-red-50 transition-colors"
                  >
                    <Brain className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}