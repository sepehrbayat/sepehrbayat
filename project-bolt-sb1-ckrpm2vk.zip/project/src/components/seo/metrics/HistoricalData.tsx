import React from 'react';
import { Line } from 'react-chartjs-2';

interface HistoricalDataProps {
  data: Array<{
    date: string;
    performance: {
      desktop: number;
      mobile: number;
    };
    seo: {
      desktop: number;
      mobile: number;
    };
  }>;
  selectedDevice: 'desktop' | 'mobile';
}

export default function HistoricalData({ data, selectedDevice }: HistoricalDataProps) {
  if (data.length <= 1) return null;

  return (
    <div>
      <h3 className="text-lg font-medium mb-4 flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-[#a63439]" />
        روند تغییرات
      </h3>
      <div className="bg-white p-6 rounded-lg border border-gray-100">
        <Line
          data={{
            labels: data.map(d => new Date(d.date).toLocaleDateString('fa-IR')),
            datasets: [
              {
                label: 'عملکرد',
                data: data.map(d => d.performance[selectedDevice]),
                borderColor: '#a63439',
                backgroundColor: '#a63439',
                tension: 0.4
              },
              {
                label: 'سئو',
                data: data.map(d => d.seo[selectedDevice]),
                borderColor: '#4B5563',
                backgroundColor: '#4B5563',
                tension: 0.4
              }
            ]
          }}
          options={{
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                position: 'top' as const,
                align: 'end' as const,
                rtl: true,
                labels: {
                  usePointStyle: true,
                  padding: 20,
                  font: {
                    family: 'Vazirmatn'
                  }
                }
              }
            },
            scales: {
              y: {
                beginAtZero: true,
                max: 100,
                ticks: {
                  font: {
                    family: 'Vazirmatn'
                  }
                }
              },
              x: {
                ticks: {
                  font: {
                    family: 'Vazirmatn'
                  }
                }
              }
            }
          }}
        />
      </div>
    </div>
  );
}