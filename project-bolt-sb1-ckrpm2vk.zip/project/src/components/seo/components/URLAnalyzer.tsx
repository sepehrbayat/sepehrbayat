import React from 'react';
import { Search, Brain, AlertCircle } from 'lucide-react';
import URLInput from '../URLInput';
import DeviceTabs from '../DeviceTabs';
import HelpMessage from '../HelpMessage';
import OverallScores from '../metrics/OverallScores';
import CoreWebVitals from '../metrics/CoreWebVitals';
import PerformanceMetrics from '../metrics/PerformanceMetrics';
import SecurityMetrics from '../metrics/SecurityMetrics';
import MainThreadMetrics from '../metrics/MainThreadMetrics';
import ContentMetrics from '../metrics/ContentMetrics';
import MetaTagsMetrics from '../metrics/MetaTagsMetrics';
import DOMMetrics from '../metrics/DOMMetrics';
import HistoricalData from '../metrics/HistoricalData';
import AISuggestionPopup from '../AISuggestionPopup';
import type { SEOMetric } from '../types';

interface URLAnalyzerProps {
  url: string;
  onUrlChange: (url: string) => void;
  onAnalyze: () => void;
  isAnalyzing: boolean;
  error: string | null;
  currentAnalysis: any;
  currentLighthouse: any;
  selectedDevice: 'desktop' | 'mobile';
  onDeviceChange: (device: 'desktop' | 'mobile') => void;
  historicalData: any[];
  seoScore: any;
  performanceMetrics: any;
  onMetricClick: (metric: SEOMetric) => void;
  selectedMetric: SEOMetric | null;
  showSuggestions: boolean;
  suggestions: string[] | null;
  isLoadingSuggestions: boolean;
  onCloseSuggestions: () => void;
}

export default function URLAnalyzer({
  url,
  onUrlChange,
  onAnalyze,
  isAnalyzing,
  error,
  currentAnalysis,
  currentLighthouse,
  selectedDevice,
  onDeviceChange,
  historicalData,
  seoScore,
  performanceMetrics,
  onMetricClick,
  selectedMetric,
  showSuggestions,
  suggestions,
  isLoadingSuggestions,
  onCloseSuggestions
}: URLAnalyzerProps) {
  return (
    <div className="space-y-8">
      <div className="bg-white rounded-xl p-6 space-y-6">
        <URLInput
          url={url}
          onUrlChange={onUrlChange}
          onAnalyze={onAnalyze}
          isAnalyzing={isAnalyzing}
        />

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {selectedMetric && (
          <AISuggestionPopup
            isOpen={showSuggestions}
            onClose={onCloseSuggestions}
            metric={selectedMetric}
            suggestions={suggestions}
            isLoading={isLoadingSuggestions}
          />
        )}

        {currentAnalysis && currentLighthouse && (
          <div className="space-y-8">
            <HelpMessage />

            <DeviceTabs
              selectedDevice={selectedDevice}
              onDeviceChange={onDeviceChange}
            />

            <OverallScores
              seoScore={seoScore}
              lighthouse={currentLighthouse}
              onMetricClick={onMetricClick}
              analysis={currentAnalysis}
            />

            <CoreWebVitals
              lighthouse={currentLighthouse}
              device={selectedDevice}
              onMetricClick={onMetricClick}
            />

            <PerformanceMetrics
              lighthouse={currentLighthouse}
              device={selectedDevice}
              onMetricClick={onMetricClick}
            />

            <SecurityMetrics
              lighthouse={currentLighthouse}
              performanceMetrics={performanceMetrics}
              onMetricClick={onMetricClick}
            />

            <ContentMetrics
              analysis={currentAnalysis}
              onMetricClick={onMetricClick}
            />

            <MetaTagsMetrics
              analysis={currentAnalysis}
              onMetricClick={onMetricClick}
            />

            <MainThreadMetrics
              lighthouse={currentLighthouse}
              onMetricClick={onMetricClick}
            />

            <DOMMetrics
              lighthouse={currentLighthouse}
              onMetricClick={onMetricClick}
            />

            <HistoricalData
              data={historicalData}
              selectedDevice={selectedDevice}
            />
          </div>
        )}
      </div>
    </div>
  );
}