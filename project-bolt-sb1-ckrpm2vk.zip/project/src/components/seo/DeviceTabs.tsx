import React from 'react';
import { Monitor, Smartphone } from 'lucide-react';

interface DeviceTabsProps {
  selectedDevice: 'desktop' | 'mobile';
  onDeviceChange: (device: 'desktop' | 'mobile') => void;
}

export default function DeviceTabs({ selectedDevice, onDeviceChange }: DeviceTabsProps) {
  return (
    <div className="flex gap-2">
      <button
        onClick={() => onDeviceChange('desktop')}
        className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
          selectedDevice === 'desktop'
            ? 'bg-[#a63439] text-white'
            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
        }`}
      >
        <Monitor className="w-4 h-4" />
        <span>دسکتاپ</span>
      </button>
      <button
        onClick={() => onDeviceChange('mobile')}
        className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
          selectedDevice === 'mobile'
            ? 'bg-[#a63439] text-white'
            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
        }`}
      >
        <Smartphone className="w-4 h-4" />
        <span>موبایل</span>
      </button>
    </div>
  );
}