import React, { useState, useEffect } from 'react';
import { AlertCircle } from 'lucide-react';
import { trackActivity } from '../../lib/activity';
import type { LighthouseReport } from '../../lib/seo/lighthouse';
import type { SEOAnalysis } from '../../lib/seo/analyzer';
import HelpMessage from './HelpMessage';
import { analyzePage } from '../../lib/seo/analyzer';
import { runLighthouseAudit } from '../../lib/seo/lighthouse';
import AISuggestionPopup from './AISuggestionPopup';
import URLInput from './URLInput';
import DeviceTabs from './DeviceTabs';
import OverallScores from './metrics/OverallScores';
import CoreWebVitals from './metrics/CoreWebVitals';
import PerformanceMetrics from './metrics/PerformanceMetrics';
import SecurityMetrics from './metrics/SecurityMetrics';
import MainThreadMetrics from './metrics/MainThreadMetrics';
import ContentMetrics from './metrics/ContentMetrics';
import MetaTagsMetrics from './metrics/MetaTagsMetrics';
import DOMMetrics from './metrics/DOMMetrics';
import HistoricalData from './metrics/HistoricalData';
import { getAISuggestions } from '../../lib/seo/suggestions';

interface SEOScore {
  score: number;
  label: string;
  recommendations: string[];
}

export default function SEODashboard() {
  const [url, setUrl] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [desktopAnalysis, setDesktopAnalysis] = useState<SEOAnalysis | null>(null);
  const [mobileAnalysis, setMobileAnalysis] = useState<SEOAnalysis | null>(null);
  const [desktopLighthouse, setDesktopLighthouse] = useState<LighthouseReport | null>(null);
  const [mobileLighthouse, setMobileLighthouse] = useState<LighthouseReport | null>(null);
  const [selectedDevice, setSelectedDevice] = useState<'desktop' | 'mobile'>('desktop');
  const [historicalData, setHistoricalData] = useState<any[]>([]);
  const [seoScore, setSeoScore] = useState<SEOScore>({ score: 0, label: '', recommendations: [] });
  const [performanceMetrics, setPerformanceMetrics] = useState({
    security: { score: 0, features: { https: false, csp: false, hsts: false, xss: false } },
    userExperience: { score: 0 }
  });
  const [selectedMetric, setSelectedMetric] = useState<{
    name: string;
    value: string | number;
    description: string;
    status: 'good' | 'warning' | 'poor';
    context: Record<string, any>;
  } | null>(null);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [suggestions, setSuggestions] = useState<string[] | null>(null);
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);

  const currentAnalysis = selectedDevice === 'desktop' ? desktopAnalysis : mobileAnalysis;
  const currentLighthouse = selectedDevice === 'desktop' ? desktopLighthouse : mobileLighthouse;

  const handleDeviceChange = (device: 'desktop' | 'mobile') => {
    if (!desktopAnalysis || !mobileAnalysis) return;
    setSelectedDevice(device);
  };

  const handleMetricClick = async (metric: {
    name: string;
    value: string | number;
    description: string;
    status: 'good' | 'warning' | 'poor';
    context: Record<string, any>;
  }) => {
    setSelectedMetric(metric);
    setSuggestions(null);
    setShowSuggestions(true);
    setIsLoadingSuggestions(true);
    
    try {
      const newSuggestions = await getAISuggestions(metric);
      setSuggestions(newSuggestions);
    } catch (error) {
      console.error('Error getting suggestions:', error);
      setSuggestions(['خطا در دریافت پیشنهادات. لطفاً دوباره تلاش کنید.']);
    } finally {
      setIsLoadingSuggestions(false);
    }
  };

  const analyzeSEO = async () => {
    if (!url) {
      setError('لطفاً یک URL معتبر وارد کنید');
      return;
    }
    
    if (!url.startsWith('http')) {
      setError('آدرس باید با http یا https شروع شود');
      return;
    }

    try {
      // Validate URL format
      try {
        new URL(url);
      } catch {
        setError('آدرس وارد شده معتبر نیست');
        return;
      }
      
      setIsAnalyzing(true);
      setError(null);

      const [desktop, desktopLight, mobile, mobileLight] = await Promise.all([
        analyzePage(url, 'desktop'),
        runLighthouseAudit(url, 'desktop'),
        analyzePage(url, 'mobile'),
        runLighthouseAudit(url, 'mobile')
      ]);

      setDesktopAnalysis(desktop);
      setMobileAnalysis(mobile);
      setDesktopLighthouse(desktopLight);
      setMobileLighthouse(mobileLight);

      // Track SEO analysis activity
      await trackActivity(
        'seo_analysis',
        'تحلیل سئو سایت',
        `تحلیل سئو سایت ${url}`,
        {
          url,
          desktop: {
            analysis: desktop,
            lighthouse: desktopLight
          },
          mobile: {
            analysis: mobile,
            lighthouse: mobileLight
          }
        },
        {
          device: selectedDevice,
          timestamp: new Date().toISOString()
        }
      );
      
      // Calculate security and UX scores
      const securityFeatures = {
        https: url.startsWith('https'),
        csp: true, // Simplified for demo
        hsts: true, // Simplified for demo
        xss: true  // Simplified for demo
      };
      
      const securityScore = Object.values(securityFeatures).filter(Boolean).length * 25;
      const userExperienceScore = Math.round((desktopLight.accessibility + desktopLight.bestPractices) / 2);
      
      setPerformanceMetrics({
        security: { score: securityScore, features: securityFeatures },
        userExperience: { score: userExperienceScore }
      });
      
      // Add to historical data
      setHistoricalData(prev => [...prev, {
        date: new Date(),
        performance: {
          desktop: desktopLight.performance,
          mobile: mobileLight.performance
        },
        seo: {
          desktop: desktopLight.seo,
          mobile: mobileLight.seo
        },
        url: url
      }]);
    } catch (error) {
      let errorMessage = 'خطا در تحلیل SEO. لطفاً مجدداً تلاش کنید.';
      
      if (error instanceof Error) {
        if (error.message.includes('Failed to fetch page content')) {
          errorMessage = 'خطا در دسترسی به سایت. لطفاً از صحت آدرس اطمینان حاصل کنید.';
        } else if (error.message.includes('DOMParser not available')) {
          errorMessage = 'خطا در پردازش محتوای سایت';
        } else if (error.message.includes('Invalid URL')) {
          errorMessage = 'آدرس وارد شده معتبر نیست.';
        }
      }
      
      setError(errorMessage);
      console.error('SEO Analysis error:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  useEffect(() => {
    if (!currentAnalysis || !currentLighthouse) {
      setSeoScore({ score: 0, label: '', recommendations: [] });
      return;
    }

    let score = 0;
    const recommendations: string[] = [];

    // Meta Tags Score (20 points)
    if (currentAnalysis.metaTags.title) score += 5;
    else recommendations.push('عنوان صفحه را تنظیم کنید');
    
    if (currentAnalysis.metaTags.description) score += 5;
    else recommendations.push('توضیحات متا را اضافه کنید');
    
    if (currentAnalysis.metaTags.keywords) score += 5;
    else recommendations.push('کلمات کلیدی را تعریف کنید');
    
    if (Object.keys(currentAnalysis.metaTags.ogTags).length > 0) score += 5;
    else recommendations.push('تگ‌های Open Graph را اضافه کنید');

    // Content Score (30 points)
    if (currentAnalysis.content.wordCount > 300) score += 10;
    else recommendations.push('محتوای بیشتری اضافه کنید (حداقل 300 کلمه)');
    
    if (currentAnalysis.content.readabilityScore > 60) score += 10;
    else recommendations.push('خوانایی متن را بهبود دهید');
    
    if (currentAnalysis.content.internalLinks > 0) score += 10;
    else recommendations.push('لینک‌های داخلی اضافه کنید');

    // Technical Score (30 points)
    if (currentAnalysis.technical.hasRobotsTxt) score += 10;
    else recommendations.push('فایل robots.txt ایجاد کنید');
    
    if (currentAnalysis.technical.hasSitemap) score += 10;
    else recommendations.push('نقشه سایت XML ایجاد کنید');
    
    if (currentAnalysis.technical.isResponsive) score += 10;
    else recommendations.push('سایت را ریسپانسیو کنید');

    // Image Score (20 points)
    const altTextPercentage = (currentAnalysis.images.withAlt / currentAnalysis.images.total) * 100;
    if (altTextPercentage > 80) score += 20;
    else recommendations.push('برای تصاویر متن جایگزین اضافه کنید');

    let label = '';
    if (score >= 90) label = 'عالی';
    else if (score >= 70) label = 'خوب';
    else if (score >= 50) label = 'متوسط';
    else label = 'ضعیف';

    setSeoScore({ score, label, recommendations });
  }, [currentAnalysis, currentLighthouse, selectedDevice]);

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <h1 className="text-2xl font-medium mb-2">تحلیل سئو</h1>
          <p className="text-gray-600">وضعیت سئو سایت خود را بررسی کنید و پیشنهادات بهبود را دریافت کنید.</p>
        </div>

        <div className="bg-white rounded-xl p-6 space-y-6">
          <URLInput
            url={url}
            onUrlChange={setUrl}
            onAnalyze={analyzeSEO}
            isAnalyzing={isAnalyzing}
          />

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              <p>{error}</p>
            </div>
          )}

          {selectedMetric && (
            <AISuggestionPopup
              isOpen={showSuggestions}
              onClose={() => setShowSuggestions(false)}
              metric={selectedMetric}
              suggestions={suggestions}
              isLoading={isLoadingSuggestions}
            />
          )}

          {currentAnalysis && currentLighthouse && (
            <div className="space-y-8">
              <HelpMessage />

              <DeviceTabs
                selectedDevice={selectedDevice}
                onDeviceChange={handleDeviceChange}
              />

              <OverallScores
                seoScore={seoScore}
                lighthouse={currentLighthouse}
                onMetricClick={handleMetricClick}
                analysis={currentAnalysis}
              />

              <CoreWebVitals
                lighthouse={currentLighthouse}
                device={selectedDevice}
                onMetricClick={handleMetricClick}
              />

              <PerformanceMetrics
                lighthouse={currentLighthouse}
                device={selectedDevice}
                onMetricClick={handleMetricClick}
              />

              <SecurityMetrics
                lighthouse={currentLighthouse}
                performanceMetrics={performanceMetrics}
                onMetricClick={handleMetricClick}
              />

              <ContentMetrics
                analysis={currentAnalysis}
                onMetricClick={handleMetricClick}
              />

              <MetaTagsMetrics
                analysis={currentAnalysis}
                onMetricClick={handleMetricClick}
              />

              <MainThreadMetrics
                lighthouse={currentLighthouse}
                onMetricClick={handleMetricClick}
              />

              <DOMMetrics
                lighthouse={currentLighthouse}
                onMetricClick={handleMetricClick}
              />

              <HistoricalData
                data={historicalData}
                selectedDevice={selectedDevice}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}