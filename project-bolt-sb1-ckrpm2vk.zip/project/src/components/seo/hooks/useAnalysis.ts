import { useState, useCallback } from 'react';
import { analyzePage } from '../../../lib/seo/analyzer';
import { runLighthouseAudit } from '../../../lib/seo/lighthouse';
import type { SEOScore, PerformanceMetrics } from '../types';

export function useAnalysis() {
  const [url, setUrl] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [desktopAnalysis, setDesktopAnalysis] = useState<SEOAnalysis | null>(null);
  const [mobileAnalysis, setMobileAnalysis] = useState<SEOAnalysis | null>(null);
  const [desktopLighthouse, setDesktopLighthouse] = useState<LighthouseReport | null>(null);
  const [mobileLighthouse, setMobileLighthouse] = useState<LighthouseReport | null>(null);
  const [selectedDevice, setSelectedDevice] = useState<'desktop' | 'mobile'>('desktop');
  const [historicalData, setHistoricalData] = useState<any[]>([]);
  const [seoScore, setSeoScore] = useState<SEOScore>({ score: 0, label: '', recommendations: [] });
  const [performanceMetrics, setPerformanceMetrics] = useState<PerformanceMetrics>({
    security: { score: 0, features: { https: false, csp: false, hsts: false, xss: false } },
    userExperience: { score: 0 }
  });

  const analyzeSEO = useCallback(async () => {
    if (!url) {
      setError('لطفاً یک URL معتبر وارد کنید');
      return;
    }
    
    if (!url.startsWith('http')) {
      setError('آدرس باید با http یا https شروع شود');
      return;
    }

    try {
      setIsAnalyzing(true);
      setError(null);

      const [desktop, desktopLight, mobile, mobileLight] = await Promise.all([
        analyzePage(url, 'desktop'),
        runLighthouseAudit(url, 'desktop'),
        analyzePage(url, 'mobile'),
        runLighthouseAudit(url, 'mobile')
      ]);

      setDesktopAnalysis(desktop);
      setMobileAnalysis(mobile);
      setDesktopLighthouse(desktopLight);
      setMobileLighthouse(mobileLight);
      
      // Calculate security and UX scores
      const securityFeatures = {
        https: url.startsWith('https'),
        csp: true,
        hsts: true,
        xss: true
      };
      
      const securityScore = Object.values(securityFeatures).filter(Boolean).length * 25;
      const userExperienceScore = Math.round((desktopLight.accessibility + desktopLight.bestPractices) / 2);
      
      setPerformanceMetrics({
        security: { score: securityScore, features: securityFeatures },
        userExperience: { score: userExperienceScore }
      });
      
      // Add to historical data
      setHistoricalData(prev => [...prev, {
        date: new Date().toISOString(),
        performance: {
          desktop: desktopLight.performance,
          mobile: mobileLight.performance
        },
        seo: {
          desktop: desktopLight.seo,
          mobile: mobileLight.seo
        },
        url: url
      }]);

    } catch (error) {
      let errorMessage = 'خطا در تحلیل SEO. لطفاً مجدداً تلاش کنید.';
      
      if (error instanceof Error) {
        if (error.message.includes('Failed to fetch page content')) {
          errorMessage = 'خطا در دسترسی به سایت. لطفاً از صحت آدرس اطمینان حاصل کنید.';
        } else if (error.message.includes('DOMParser not available')) {
          errorMessage = 'خطا در پردازش محتوای سایت';
        } else if (error.message.includes('Invalid URL')) {
          errorMessage = 'آدرس وارد شده معتبر نیست.';
        }
      }
      
      setError(errorMessage);
      console.error('SEO Analysis error:', error);
    } finally {
      setIsAnalyzing(false);
    }
  }, [url]);

  return {
    url,
    setUrl,
    isAnalyzing,
    error,
    desktopAnalysis,
    mobileAnalysis,
    desktopLighthouse,
    mobileLighthouse,
    selectedDevice,
    setSelectedDevice,
    historicalData,
    seoScore,
    performanceMetrics,
    analyzeSEO
  };
}