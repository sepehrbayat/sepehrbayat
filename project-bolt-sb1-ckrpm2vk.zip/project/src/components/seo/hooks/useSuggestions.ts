import { useState } from 'react';
import { getAISuggestions } from '../../../lib/seo/suggestions';
import type { SEOMetric } from '../types';

export function useSuggestions() {
  const [selectedMetric, setSelectedMetric] = useState<SEOMetric | null>(null);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [suggestions, setSuggestions] = useState<string[] | null>(null);
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);

  const handleMetricClick = async (metric: SEOMetric) => {
    setSelectedMetric(metric);
    setSuggestions(null);
    setShowSuggestions(true);
    setIsLoadingSuggestions(true);
    
    try {
      const newSuggestions = await getAISuggestions(metric);
      setSuggestions(newSuggestions);
    } catch (error) {
      console.error('Error getting suggestions:', error);
      setSuggestions(['خطا در دریافت پیشنهادات. لطفاً دوباره تلاش کنید.']);
    } finally {
      setIsLoadingSuggestions(false);
    }
  };

  return {
    selectedMetric,
    showSuggestions,
    suggestions,
    isLoadingSuggestions,
    handleMetricClick,
    setShowSuggestions
  };
}