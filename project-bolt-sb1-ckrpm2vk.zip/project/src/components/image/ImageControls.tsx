import React from 'react';
import { Crown, Star, Settings2, Sliders, Sparkles, Palette, Layout, Camera } from 'lucide-react';

interface ImageControlsProps {
  onSettingsChange: (settings: any) => void;
  settings: {
    model: 'dall-e-2' | 'dall-e-3';
    width: string;
    height: string;
    quality: 'standard' | 'hd';
    style: 'vivid' | 'natural';
    mood: string;
    lighting: string;
    composition: string;
    perspective: string;
    colorScheme: string;
  };
}

export default function ImageControls({ onSettingsChange, settings }: ImageControlsProps) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <div className="col-span-2 space-y-4">
          <div className="flex items-center gap-2 mb-3">
            <Crown className="w-4 h-4 text-amber-600" />
            <h3 className="text-sm font-medium text-amber-900">تنظیمات اصلی</h3>
          </div>
          <div>
            <label className="block text-xs font-medium text-amber-800 mb-1.5">مدل هوش مصنوعی</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => onSettingsChange({ 
                  ...settings, 
                  model: 'هوش پیک سریع',
                  width: '1024',
                  height: '1024',
                  quality: 'standard'
                })}
                className={`p-3 rounded-xl border-2 transition-all ${
                  settings.model === 'هوش پیک سریع'
                    ? 'border-amber-500 bg-amber-50'
                    : 'border-amber-200 hover:border-amber-300'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-amber-900">هوش پیک سریع</span>
                  {settings.model === 'هوش پیک سریع' && (
                    <div className="w-2 h-2 rounded-full bg-amber-500" />
                  )}
                </div>
                <p className="text-xs text-amber-700">سریع و مقرون به صرفه</p>
              </button>
              <button
                onClick={() => onSettingsChange({
                  ...settings,
                  model: 'هوش پیک دقیق',
                  width: '1024',
                  height: '1024',
                  quality: 'standard'
                })}
                className={`p-3 rounded-xl border-2 transition-all ${
                  settings.model === 'هوش پیک دقیق'
                    ? 'border-amber-500 bg-amber-50'
                    : 'border-amber-200 hover:border-amber-300'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-amber-900">هوش پیک دقیق</span>
                  {settings.model === 'هوش پیک دقیق' && (
                    <div className="w-2 h-2 rounded-full bg-amber-500" />
                  )}
                </div>
                <p className="text-xs text-amber-700">کیفیت بالا و جزئیات دقیق</p>
              </button>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-3 mt-4">
            <div>
              <label className="block text-xs font-medium text-amber-800 mb-1.5">ابعاد تصویر</label>
              {settings.model === 'هوش پیک سریع' ? (
                <select
                  value={`${settings.width}x${settings.height}`}
                  onChange={(e) => {
                    const [width, height] = e.target.value.split('x');
                    onSettingsChange({ ...settings, width, height });
                  }}
                  className="w-full bg-white border border-amber-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                >
                  <option value="256x256">256×256</option>
                  <option value="512x512">512×512</option>
                  <option value="1024x1024">1024×1024</option>
                </select>
              ) : (
                <select
                  value={`${settings.width}x${settings.height}`}
                  onChange={(e) => {
                    const [width, height] = e.target.value.split('x');
                    onSettingsChange({ ...settings, width, height });
                  }}
                  className="w-full bg-white border border-amber-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                >
                  <option value="1024x1024">مربع (1024×1024)</option>
                  <option value="1024x1792">عمودی (1024×1792)</option>
                  <option value="1792x1024">افقی (1792×1024)</option>
                </select>
              )}
            </div>
            <div>
              <label className="block text-xs font-medium text-amber-800 mb-1.5">
                {settings.model === 'هوش پیک دقیق' ? 'کیفیت تصویر' : 'تعداد تصویر'}
              </label>
              {settings.model === 'هوش پیک دقیق' ? (
                <select
                  value={settings.quality}
                  onChange={(e) => onSettingsChange({ ...settings, quality: e.target.value })}
                  className="w-full bg-white border border-amber-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                >
                  <option value="standard">استاندارد</option>
                  <option value="hd">HD</option>
                </select>
              ) : (
                <select
                  value={settings.samples}
                  onChange={(e) => onSettingsChange({ ...settings, samples: e.target.value })}
                  className="w-full bg-white border border-amber-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                >
                  <option value="1">1 تصویر</option>
                  <option value="2">2 تصویر</option>
                  <option value="3">3 تصویر</option>
                  <option value="4">4 تصویر</option>
                </select>
              )}
            </div>
          </div>
          {settings.model === 'هوش پیک دقیق' && (
            <div className="mt-4">
              <label className="block text-xs font-medium text-amber-800 mb-1.5">سبک تصویر</label>
              <select
                value={settings.style}
                onChange={(e) => onSettingsChange({ ...settings, style: e.target.value })}
                className="w-full bg-white border border-amber-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
              >
                <option value="vivid">زنده و دراماتیک</option>
                <option value="natural">طبیعی</option>
              </select>
            </div>
          )}
        </div>

        <div className="col-span-2">
          <div className="flex items-center gap-2 mb-3">
            <Palette className="w-4 h-4 text-amber-600" />
            <h3 className="text-sm font-medium text-amber-900">تنظیمات هنری</h3>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-amber-800 mb-1.5">حس و حال</label>
              <select
                value={settings.mood}
                onChange={(e) => onSettingsChange({ ...settings, mood: e.target.value })}
                className="w-full bg-white border border-amber-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
              >
                <option value="dramatic">دراماتیک و پرشور</option>
                <option value="peaceful">آرام و دلنشین</option>
                <option value="energetic">پرانرژی و پویا</option>
                <option value="mysterious">مرموز و اسرارآمیز</option>
                <option value="romantic">رمانتیک و احساسی</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-amber-800 mb-1.5">طیف رنگی</label>
              <select
                value={settings.colorScheme}
                onChange={(e) => onSettingsChange({ ...settings, colorScheme: e.target.value })}
                className="w-full bg-white border border-amber-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
              >
                <option value="vibrant">رنگ‌های زنده و درخشان</option>
                <option value="muted">رنگ‌های ملایم و آرام</option>
                <option value="monochrome">تک‌رنگ (سیاه و سفید)</option>
                <option value="warm">رنگ‌های گرم</option>
                <option value="cool">رنگ‌های سرد</option>
              </select>
            </div>
          </div>
        </div>

        <div className="col-span-2">
          <div className="flex items-center gap-2 mb-3">
            <Layout className="w-4 h-4 text-amber-600" />
            <h3 className="text-sm font-medium text-amber-900">تنظیمات ترکیب‌بندی</h3>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-amber-800 mb-1.5">ترکیب‌بندی</label>
              <select
                value={settings.composition}
                onChange={(e) => onSettingsChange({ ...settings, composition: e.target.value })}
                className="w-full bg-white border border-amber-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
              >
                <option value="balanced">متعادل و هماهنگ</option>
                <option value="dynamic">پویا و پر جنب و جوش</option>
                <option value="minimal">ساده و مینیمال</option>
                <option value="detailed">پر جزئیات و پیچیده</option>
                <option value="abstract">انتزاعی و هنری</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-amber-800 mb-1.5">نورپردازی</label>
              <select
                value={settings.lighting}
                onChange={(e) => onSettingsChange({ ...settings, lighting: e.target.value })}
                className="w-full bg-white border border-amber-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
              >
                <option value="natural">نور طبیعی روز</option>
                <option value="studio">نور استودیویی حرفه‌ای</option>
                <option value="dramatic">نورپردازی دراماتیک</option>
                <option value="soft">نور نرم و ملایم</option>
                <option value="backlit">نور از پشت (کنتراست بالا)</option>
              </select>
            </div>
          </div>
        </div>

        <div className="col-span-2">
          <div className="flex items-center gap-2 mb-3">
            <Camera className="w-4 h-4 text-amber-600" />
            <h3 className="text-sm font-medium text-amber-900">تنظیمات دوربین</h3>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-amber-800 mb-1.5">زاویه دید</label>
              <select
                value={settings.perspective}
                onChange={(e) => onSettingsChange({ ...settings, perspective: e.target.value })}
                className="w-full bg-white border border-amber-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
              >
                <option value="front">نمای روبرو</option>
                <option value="side">نمای جانبی</option>
                <option value="aerial">نمای هوایی</option>
                <option value="closeup">نمای نزدیک</option>
                <option value="wide">نمای باز</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-r from-amber-50 to-amber-100 rounded-xl p-4 border border-amber-200">
        <div className="flex items-center gap-2 mb-3">
          <Star className="w-4 h-4 text-amber-600 fill-amber-600" />
          <h3 className="text-sm font-medium text-amber-900">ویژگی‌های پیشرفته DALL-E 3</h3>
        </div>
        <ul className="space-y-2">
          <li className="flex items-center gap-2 text-sm text-amber-800">
            <Sparkles className="w-4 h-4 text-amber-600" />
            <span>کیفیت HD برای جزئیات بیشتر</span>
          </li>
          <li className="flex items-center gap-2 text-sm text-amber-800">
            <Sparkles className="w-4 h-4 text-amber-600" />
            <span>سبک‌های زنده و طبیعی</span>
          </li>
          <li className="flex items-center gap-2 text-sm text-amber-800">
            <Sparkles className="w-4 h-4 text-amber-600" />
            <span>ابعاد بزرگتر تصویر</span>
          </li>
        </ul>
      </div>
    </div>
  );
}