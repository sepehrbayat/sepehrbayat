import React from 'react';
import { POPULAR_SYMBOLS } from '../../lib/trading/market/symbols';
import { Search, AlertCircle } from 'lucide-react';

interface SymbolSelectorProps {
  onSelect: (symbol: string) => void;
  selectedSymbol?: string;
  className?: string;
  error?: string | null;
  isLoading?: boolean;
}

export default function SymbolSelector({ onSelect, selectedSymbol, className = '', error, isLoading }: SymbolSelectorProps) {
  const [category, setCategory] = React.useState<'stocks' | 'crypto' | 'forex'>('stocks');
  const [searchQuery, setSearchQuery] = React.useState('');

  const filteredSymbols = React.useMemo(() => {
    let symbols = category === 'stocks' 
      ? POPULAR_SYMBOLS.stocks.us 
      : POPULAR_SYMBOLS[category];

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return symbols.filter(s => 
        s.symbol.toLowerCase().includes(query) || 
        s.name.toLowerCase().includes(query)
      );
    }
    return symbols;
  }, [category, searchQuery]);

  return (
    <div className={`space-y-4 ${className}`}>
      <div className="flex gap-2">
        <button
          onClick={() => setCategory('stocks')}
          className={`px-3 py-1 rounded-lg text-sm transition-colors ${
            category === 'stocks'
              ? 'bg-[#a63439] text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          سهام
        </button>
        <button
          onClick={() => setCategory('crypto')}
          className={`px-3 py-1 rounded-lg text-sm transition-colors ${
            category === 'crypto'
              ? 'bg-[#a63439] text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          رمزارز
        </button>
        <button
          onClick={() => setCategory('forex')}
          className={`px-3 py-1 rounded-lg text-sm transition-colors ${
            category === 'forex'
              ? 'bg-[#a63439] text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          فارکس
        </button>
      </div>

      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="جستجوی نماد..."
          className="w-full bg-gray-50 border border-gray-200 rounded-lg pr-10 pl-3 py-2"
        />
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-center gap-2 text-red-700 text-sm">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          <p>{error}</p>
        </div>
      )}

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
        {filteredSymbols.map((symbol) => (
          <button
            key={symbol.symbol}
            onClick={() => onSelect(symbol.symbol)}
            disabled={isLoading}
            className={`p-3 rounded-lg text-sm text-right transition-all hover:shadow-md ${
              selectedSymbol === symbol.symbol
                ? 'bg-[#a63439] text-white shadow-md scale-[1.02]'
                : 'bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed'
            }`}
          >
            <div className="font-medium mb-1">{symbol.symbol}</div>
            <div className={`text-xs ${
              selectedSymbol === symbol.symbol ? 'text-white/80' : 'text-gray-500'
            }`}>{symbol.name}</div>
            {isLoading && selectedSymbol === symbol.symbol && (
              <div className="mt-1 text-xs text-white/80">در حال بارگذاری...</div>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}