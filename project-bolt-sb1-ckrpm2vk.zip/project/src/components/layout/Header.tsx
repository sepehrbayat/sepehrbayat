import React, { useState, useRef, useEffect } from 'react';
import { Bell, Search, Settings, User, ChevronDown, MessageSquare, HelpCircle, LogOut, Loader2 } from 'lucide-react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../lib/auth/AuthContext';
import type { User as UserType } from '../../lib/auth/types';
import Breadcrumb from './Breadcrumb';

export default function Header() {
  const navigate = useNavigate();
  const location = useLocation();
  const { signOut, user } = useAuth();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const userMenuRef = useRef<HTMLDivElement>(null);
  const notificationsRef = useRef<HTMLDivElement>(null);
  
  // Get breadcrumb items based on current path
  const getBreadcrumbItems = () => {
    const paths = location.pathname.split('/').filter(Boolean);
    if (paths.length === 0) return [];
    
    const items = [];
    let currentPath = '';
    
    for (const path of paths) {
      currentPath += `/${path}`;
      const title = getTitleForPath(path);
      if (title) {
        items.push({
          title,
          path: currentPath
        });
      }
    }
    
    return items;
  };
  
  // Get human-readable title for path
  const getTitleForPath = (path: string): string => {
    const titles: Record<string, string> = {
      'ai': 'دستیارهای هوشمند',
      'language': 'دستیار زبان',
      'finance': 'دستیار مالی',
      'health': 'دستیار سلامت',
      'cooking': 'دستیار آشپزی',
      'shopping': 'دستیار خرید',
      'programming': 'دستیار برنامه‌نویسی',
      'decoration': 'دستیار دکوراسیون',
      'entertainment': 'دستیار سرگرمی',
      'travel': 'دستیار سفر',
      'student': 'دستیار دانشجو',
      'seo-tools': 'ابزارهای سئو',
      'content': 'تولید محتوا',
      'analytics': 'تحلیل',
      'interior': 'طراحی داخلی',
      'trading': 'معامله و ترید',
      'achievements': 'دستاوردها',
      'activity': 'فعالیت‌ها',
      'chat': 'گفتگو',
      'help': 'راهنما',
      'profile': 'پروفایل',
      'settings': 'تنظیمات'
    };
    return titles[path] || path;
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setShowUserMenu(false);
      }
      if (notificationsRef.current && !notificationsRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [userMenuRef, notificationsRef]);

  const handleMenuClick = (path: string) => {
    navigate(path);
    setShowUserMenu(false);
  };

  const handleLogout = async () => {
    try {
      setIsLoading(true);
      await signOut();
      navigate('/auth');
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <header className="bg-white px-3 sm:px-6 py-3 sm:py-4 flex flex-col gap-2 border-b border-gray-100 sticky top-0 z-50">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-6">
          <Link to="/" className="block">
            <img 
              src="http://hooshex.com/wp-content/uploads/2025/02/6019137301315174720-removebg-preview.png" 
              alt="Logo" 
              className="h-7 sm:h-10 md:h-12 transform hover:scale-105 transition-transform duration-300" 
            />
          </Link>
          {location.pathname !== '/' && (
            <Breadcrumb items={getBreadcrumbItems()} />
          )}
        </div>
        
        <div className="flex items-center gap-4">
          <div className="relative hidden md:block">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="جستجو..."
              className="w-48 lg:w-64 bg-gray-50 border border-gray-200 rounded-lg pr-9 pl-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#a63439] transition-all"
            />
          </div>

          <div className="relative" ref={notificationsRef}>
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="p-1.5 sm:p-2 md:p-2.5 hover:bg-gray-100 rounded-full relative hidden sm:block"
            >
              <Bell className="w-3 h-3 sm:w-4 sm:h-4 md:w-5 md:h-5 text-gray-600" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
            </button>
            
            {showNotifications && (
              <div className="absolute left-0 mt-2 w-64 sm:w-72 md:w-80 bg-white rounded-xl shadow-lg border border-gray-100 py-2 z-50">
                <div className="px-4 py-2 border-b border-gray-100">
                  <h3 className="text-sm font-medium">اعلان‌ها</h3>
                </div>
                <div className="max-h-64 overflow-y-auto">
                  <div className="px-4 py-3 hover:bg-gray-50 transition-colors">
                    <p className="text-sm">به هوشِکس خوش آمدید! 👋</p>
                    <span className="text-xs text-gray-500 mt-1 block">۱ دقیقه پیش</span>
                  </div>
                  <div className="px-4 py-3 hover:bg-gray-50 transition-colors">
                    <p className="text-sm">نسخه جدید هوش پیک منتشر شد</p>
                    <span className="text-xs text-gray-500 mt-1 block">۲ ساعت پیش</span>
                  </div>
                </div>
                <div className="px-4 py-2 border-t border-gray-100">
                  <button className="text-sm text-[#a63439] hover:text-[#8a2a2e] transition-colors">
                    مشاهده همه اعلان‌ها
                  </button>
                </div>
              </div>
            )}
          </div>

          <Link to="/chat" className="p-2 hover:bg-gray-100 rounded-full hidden sm:block">
            <MessageSquare className="w-3 h-3 sm:w-4 sm:h-4 md:w-5 md:h-5 text-gray-600" />
          </Link>

          <Link to="/help" className="p-2 hover:bg-gray-100 rounded-full hidden sm:block">
            <HelpCircle className="w-3 h-3 sm:w-4 sm:h-4 md:w-5 md:h-5 text-gray-600" />
          </Link>

          <div className="h-8 border-r border-gray-200 mx-2 hidden sm:block" />

          <div className="relative" ref={userMenuRef}>
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center gap-1 sm:gap-2 hover:bg-gray-50 rounded-lg py-1 px-1 sm:px-2 transition-colors group"
            >
              {user?.avatarUrl ? (
                <img 
                  src={user.avatarUrl} 
                  alt="avatar"
                  className="w-5 h-5 sm:w-7 sm:h-7 md:w-8 md:h-8 rounded-full object-cover border border-gray-200 group-hover:border-[#a63439] transition-colors"
                />
              ) : (
                <div className="w-5 h-5 sm:w-7 sm:h-7 md:w-8 md:h-8 rounded-full bg-[#a63439] text-white flex items-center justify-center text-[10px] sm:text-sm font-medium">
                  {user?.fullName?.[0]?.toUpperCase() || 'ک'}
                </div>
              )}
              <div className="hidden sm:block text-right">
                <div className="text-xs md:text-sm font-medium">{user?.fullName || 'کاربر هوشِکس'}</div>
                <div className="text-[10px] md:text-xs text-gray-500">کاربر پایه</div>
              </div>
              <ChevronDown className="w-4 h-4 text-gray-400 hidden sm:block" />
            </button>

            {showUserMenu && (
              <div className="absolute left-0 mt-2 w-48 sm:w-52 md:w-56 bg-white rounded-xl shadow-lg border border-gray-100 py-2 z-50 animate-fadeIn">
                <button 
                  onClick={() => handleMenuClick('/profile')}
                  className="w-full px-3 sm:px-4 py-2 text-right text-xs sm:text-sm hover:bg-gray-50 transition-colors flex items-center gap-2"
                >
                  <User className="w-4 h-4" />
                  <span>پروفایل</span>
                </button>
                <button 
                  onClick={() => handleMenuClick('/settings')}
                  className="w-full px-3 sm:px-4 py-2 text-right text-xs sm:text-sm hover:bg-gray-50 transition-colors flex items-center gap-2"
                >
                  <Settings className="w-4 h-4" />
                  <span>تنظیمات</span>
                </button>
                <div className="border-t border-gray-100 my-1" />
                <button 
                  onClick={handleLogout}
                  disabled={isLoading}
                  className="w-full px-3 sm:px-4 py-2 text-right text-xs sm:text-sm text-red-600 hover:bg-red-50 transition-colors flex items-center gap-2 disabled:opacity-50"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>در حال خروج...</span>
                    </>
                  ) : (
                    <>
                      <LogOut className="w-4 h-4" />
                      <span>خروج</span>
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}