// This component is no longer needed since we only support Persian
export default function LanguageSwitcher() { return null; }