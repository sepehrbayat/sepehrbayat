import React, { useRef, useEffect } from 'react';
import { Home, Search, PenTool, BarChart3, Brain, Sofa, TrendingUp, Trophy, History } from 'lucide-react';

interface MobileNavProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

export default function MobileNav({ activeSection, onSectionChange }: MobileNavProps) {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const navRef = useRef<HTMLElement>(null);

  // Add smooth scroll behavior
  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container) return;

    const handleScroll = () => {
      const scrollLeft = container.scrollLeft;
      const maxScroll = container.scrollWidth - container.clientWidth;
      
      // Add fade effect classes based on scroll position
      container.classList.toggle('fade-left', scrollLeft > 0);
      container.classList.toggle('fade-right', scrollLeft < maxScroll);
    };

    container.addEventListener('scroll', handleScroll);
    handleScroll(); // Initial check

    return () => container.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { id: 'dashboard', name: 'داشبورد', icon: Home },
    { id: 'seo-tools', name: 'سئو', icon: Search },
    { id: 'content', name: 'محتوا', icon: PenTool },
    { id: 'analytics', name: 'تحلیل', icon: BarChart3 },
    { id: 'ai', name: 'هوش مصنوعی', icon: Brain },
    { id: 'interior', name: 'طراحی', icon: Sofa },
    { id: 'trading', name: 'ترید', icon: TrendingUp },
    { id: 'achievements', name: 'دستاوردها', icon: Trophy },
    { id: 'activity', name: 'فعالیت‌ها', icon: History }
  ];

  return (
    <nav 
      ref={navRef}
      className="md:hidden fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-lg border-t border-gray-100 z-50 pb-safe shadow-[0_-8px_20px_-4px_rgba(0,0,0,0.1)] transition-all duration-300"
    >
      <div 
        ref={scrollContainerRef}
        className="flex overflow-x-auto scrollbar-none relative scroll-smooth"
        style={{
          WebkitOverflowScrolling: 'touch',
          scrollbarWidth: 'none',
          msOverflowStyle: 'none'
        }}
      >
        {/* Fade effect elements */}
        <div className="absolute left-0 top-0 bottom-0 w-12 bg-gradient-to-r from-white/80 to-transparent pointer-events-none opacity-0 transition-opacity duration-200 fade-left backdrop-blur-sm" />
        <div className="absolute right-0 top-0 bottom-0 w-12 bg-gradient-to-l from-white/80 to-transparent pointer-events-none opacity-0 transition-opacity duration-200 fade-right backdrop-blur-sm" />
        
        {/* Navigation items */}
        <div className="flex px-6 py-3 min-w-full justify-between">
          {menuItems.map(item => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => onSectionChange(item.id)}
                className={`relative flex flex-col items-center justify-center min-w-[64px] px-2 py-1 rounded-xl transition-all duration-300 ${
                  isActive
                    ? 'text-[#a63439] scale-110'
                    : 'text-gray-500 hover:text-[#a63439] active:scale-95'
                }`}
              >
                <div className={`relative ${isActive ? 'animate-bounce-subtle' : ''}`}>
                  <Icon className={`w-6 h-6 transition-all duration-300 ${
                    isActive ? 'transform -translate-y-1' : ''
                  }`} />
                  {isActive && (
                    <div className="absolute -inset-1 bg-[#a63439]/10 rounded-full animate-ping" />
                  )}
                </div>
                
                <span className={`text-xs font-medium mt-1 whitespace-nowrap transition-all duration-300 ${
                  isActive ? 'opacity-100' : 'opacity-70'
                }`}>
                  {item.name}
                </span>
                
                {isActive && (
                  <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-[#a63439]" />
                )}
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}