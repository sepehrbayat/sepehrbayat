import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom'; 
import { Home, Search, PenTool, BarChart3, Brain, Sofa, TrendingUp, Trophy, History, ChevronUp, ChevronDown, X, ChevronRight, Menu, ArrowRight } from 'lucide-react';

export type Section = 'dashboard' | 'seo-tools' | 'content' | 'analytics' | 'ai' | 'interior' | 'achievements' | 'trading' | 'activity';

interface SidebarProps {
  activeSection: Section;
  onSectionChange: (section: Section) => void;
}

export default function Sidebar({ activeSection, onSectionChange }: SidebarProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const [isExpanded, setIsExpanded] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const sidebarRef = useRef<HTMLElement>(null);
  const overlayRef = useRef<HTMLDivElement>(null);
  const [isAnimating, setIsAnimating] = useState(false);
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);
  const [touchY, setTouchY] = useState<number | null>(null);
  const minSwipeDistance = 50;

  // Update active section based on current path
  useEffect(() => {
    const path = location.pathname.substring(1).split('/')[0];
    if (location.pathname === '/') {
      onSectionChange('dashboard');
    } else if (path && path !== activeSection) {
      onSectionChange(path as Section);
    }
  }, [location.pathname, onSectionChange, activeSection]);

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (!mobile) {
        setIsExpanded(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Close expanded menu on route change in mobile
  useEffect(() => {
    if (isMobile) {
      setIsExpanded(false);
    }
  }, [location.pathname, isMobile]);

  // Handle click outside to close sidebar
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (isMobile && isExpanded && sidebarRef.current && !sidebarRef.current.contains(event.target as Node)) {
        setIsExpanded(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isMobile, isExpanded]);

  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
    setTouchY(e.targetTouches[0].clientY);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd || !touchY) return;
    
    const distanceX = touchStart - touchEnd;
    const distanceY = Math.abs(touchY - touchEnd);
    
    // Only handle horizontal swipes (ignore vertical scrolling)
    if (distanceY < 50) {
      const isLeftSwipe = distanceX > minSwipeDistance;
      const isRightSwipe = distanceX < -minSwipeDistance;
      
      if (isLeftSwipe && isExpanded) {
        handleClose();
      } else if (isRightSwipe && !isExpanded) {
        handleOpen();
      }
    }
  };

  const handleOpen = () => {
    setIsAnimating(true);
    setIsExpanded(true);
    setTimeout(() => setIsAnimating(false), 300);
  };

  const handleClose = () => {
    setIsAnimating(true);
    setIsExpanded(false);
    setTimeout(() => setIsAnimating(false), 300);
  };

  const handleSectionClick = (section: Section) => {
    // Always navigate to the appropriate route
    if (section === 'dashboard' && location.pathname !== '/') {
      navigate('/');
    } else if (section !== 'dashboard') {
      navigate(`/${section}`);
    }
    
    // Update active section and close mobile menu
    onSectionChange(section);
    setIsExpanded(false); // Close mobile menu
  };
    
  // Check if a section is currently active
  const isSectionActive = (section: string) => {
    if (section === 'dashboard') {
      return location.pathname === '/';
    }
    // For other sections, check if the current path starts with the section name
    return location.pathname.startsWith(`/${section}`);
  };

  const menuItems = [
    { id: 'dashboard', name: 'داشبورد', icon: Home },
    { id: 'seo-tools', name: 'ابزارهای سئو', icon: Search },
    { id: 'content', name: 'تولید محتوا', icon: PenTool },
    { id: 'analytics', name: 'تحلیل', icon: BarChart3 },
    { id: 'ai', name: 'هوش مصنوعی', icon: Brain },
    { id: 'interior', name: 'طراحی داخلی', icon: Sofa },
    { id: 'trading', name: 'معامله و ترید', icon: TrendingUp },
    { id: 'activity', name: 'فعالیت‌ها', icon: History },
    { id: 'achievements', name: 'دستاوردها', icon: Trophy }
  ];

  return (
    <aside 
      ref={sidebarRef}
      role="navigation"
      aria-label="منوی اصلی"
      className={`fixed ${
        isMobile 
          ? isExpanded
            ? 'top-0 right-0 w-[280px] h-screen bg-white translate-x-0'
            : 'top-0 right-0 w-[280px] h-screen bg-white translate-x-full'
          : 'top-0 right-0 h-screen w-20 bg-white'
      } transition-transform duration-300 ease-in-out z-[60] shadow-xl ${isAnimating ? 'will-change-transform' : ''}`}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
    >
      {/* Mobile Overlay */}
      {isMobile && isExpanded && (
        <div 
          ref={overlayRef}
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 animate-fadeIn" 
          onClick={handleClose}
          aria-hidden="true"
        />
      )}

      {/* Mobile Menu Header */}
      {isMobile && (
        <>
          {isExpanded && (
            <div className="sticky top-0 bg-white border-b border-gray-100 p-4 flex items-center justify-between">
              <h2 className="text-lg font-medium">منو</h2>
              <button
                onClick={handleClose}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                aria-label="بستن منو"
              >
                <X className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          )}
          {!isExpanded && (
            <button
              onClick={handleOpen}
              className="fixed bottom-8 right-6 bg-[#a63439] text-white p-4 rounded-2xl shadow-2xl hover:bg-[#8a2a2e] transition-all hover:scale-110 active:scale-95 z-[70] focus:outline-none focus:ring-2 focus:ring-[#a63439] focus:ring-offset-2 flex items-center gap-3"
              aria-label="باز کردن منو"
            >
              <Menu className="w-7 h-7" />
              <span className="text-base font-medium">منو</span>
              <div className="absolute -top-2 -right-2 w-3 h-3 bg-amber-500 rounded-full animate-pulse"></div>
            </button>
          )}
        </>
      )}

      {/* Main Navigation */}
      <nav className={`flex flex-col ${
        isMobile ? 'p-4 h-[calc(100%-60px)] overflow-y-auto scrollbar-thin scrollbar-thumb-gray-200 scrollbar-track-transparent' : 'items-center py-6'
      }`}>
        <div className="flex flex-col gap-3">
          {menuItems.map(item => {
          const Icon = item.icon;
          return (
            <button
              type="button"
              onClick={() => handleSectionClick(item.id as Section)}
              key={item.id}
              className={`relative flex items-center justify-center w-12 h-12 rounded-xl transition-all group focus:outline-none focus:ring-2 focus:ring-[#a63439] ${
                isSectionActive(item.id)
                  ? 'bg-[#a63439] text-white shadow-md'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
              onMouseEnter={() => setHoveredItem(item.id)}
              onMouseLeave={() => setHoveredItem(null)}
              aria-current={isSectionActive(item.id) ? 'page' : undefined}
            >
              <Icon className="w-6 h-6" />
              
              {/* Tooltip */}
              <div
                className={`absolute right-full mr-2 px-2 py-1 bg-gray-800 text-white text-sm rounded whitespace-nowrap opacity-0 pointer-events-none transition-opacity ${
                  hoveredItem === item.id ? 'opacity-100' : ''
                }`}
                style={{ transform: 'translateX(-4px)', zIndex: 80 }}
              >
                {item.name}
              </div>
            </button>
          );
        })}
        </div>
      </nav>
    </aside>
  );
}