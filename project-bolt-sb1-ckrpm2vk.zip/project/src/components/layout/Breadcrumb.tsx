import React from 'react';
import { ChevronLeft, Home } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface BreadcrumbProps {
  items: Array<{
    title: string;
    path?: string;
  }>;
}

export default function Breadcrumb({ items }: BreadcrumbProps) {
  const navigate = useNavigate();

  return (
    <nav className="flex items-center gap-2 text-sm">
      <button
        onClick={() => navigate('/')}
        className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors flex items-center gap-1.5 text-gray-600 hover:text-[#a63439]"
      >
        <Home className="w-4 h-4" />
        <span className="text-xs">داشبورد</span>
      </button>
      
      {items.map((item, index) => (
        <React.Fragment key={index}>
          <ChevronLeft className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
          {item.path ? (
            <button
              onClick={() => navigate(item.path)}
              className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors text-gray-600 hover:text-[#a63439] text-xs whitespace-nowrap"
            >
              {item.title}
            </button>
          ) : (
            <span className="p-1.5 text-gray-900 text-xs whitespace-nowrap">{item.title}</span>
          )}
        </React.Fragment>
      ))}
    </nav>
  );
}