import React from 'react';
import { TrendInsightsProps } from '../../../lib/analytics/trend/types';

export default function TrendInsights({ data, isEnglish }: TrendInsightsProps) {
  return (
    <div className="grid grid-cols-2 gap-4">
      <div className="bg-gray-50 rounded-lg p-4">
        <h3 className="text-sm font-medium mb-2">
          {isEnglish ? 'Trend Analysis' : 'تحلیل روند'}
        </h3>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">
              {isEnglish ? 'Trend Direction' : 'جهت روند'}
            </span>
            <span className="text-sm font-medium">{
              isEnglish ? data.trend : 
              data.trend === 'upward' ? 'صعودی' :
              data.trend === 'downward' ? 'نزولی' :
              data.trend === 'stable' ? 'ثابت' :
              data.trend === 'cyclical' ? 'نوسانی' :
              data.trend
            }</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">
              {isEnglish ? 'Confidence' : 'اطمینان'}
            </span>
            <span className="text-sm font-medium">{data.confidence}%</span>
          </div>
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg p-4">
        <h3 className="text-sm font-medium mb-2">
          {isEnglish ? 'Key Insights' : 'نکات کلیدی'}
        </h3>
        <div className="space-y-2">
          {data.insights.map((insight, index) => (
            <div key={index} className="text-sm">• {insight}</div>
          ))}
        </div>
      </div>
    </div>
  );
}