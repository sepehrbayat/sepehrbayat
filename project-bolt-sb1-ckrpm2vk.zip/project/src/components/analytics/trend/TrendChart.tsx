import React, { useRef } from 'react';
import { Line } from 'react-chartjs-2';
import { Download } from 'lucide-react';
import { TrendChartProps } from '../../../lib/analytics/trend/types';

export default function TrendChart({ data, onExport, isExporting }: TrendChartProps) {
  const chartRef = useRef<any>(null);

  return (
    <div className="bg-gray-50 rounded-lg p-4">
      <div className="flex justify-end gap-2 mb-4">
        <button
          onClick={() => onExport('png')}
          disabled={isExporting}
          className="bg-gray-100 text-gray-700 px-3 py-1 rounded-lg hover:bg-gray-200 transition-colors flex items-center gap-1 text-sm"
        >
          <Download className="w-4 h-4" />
          PNG
        </button>
        <button
          onClick={() => onExport('pdf')}
          disabled={isExporting}
          className="bg-gray-100 text-gray-700 px-3 py-1 rounded-lg hover:bg-gray-200 transition-colors flex items-center gap-1 text-sm"
        >
          <Download className="w-4 h-4" />
          PDF
        </button>
        <button
          onClick={() => onExport('excel')}
          disabled={isExporting}
          className="bg-gray-100 text-gray-700 px-3 py-1 rounded-lg hover:bg-gray-200 transition-colors flex items-center gap-1 text-sm"
        >
          <Download className="w-4 h-4" />
          Excel
        </button>
      </div>
      <div className="aspect-[16/9] w-full">
        <Line
          ref={chartRef}
          data={data}
          options={{
            responsive: true,
            plugins: {
              legend: {
                position: 'top',
                align: 'end',
                rtl: true,
                labels: {
                  usePointStyle: true,
                  padding: 20,
                  font: {
                    family: 'Vazirmatn'
                  }
                }
              }
            },
            scales: {
              y: {
                beginAtZero: true,
                ticks: {
                  font: {
                    family: 'Vazirmatn'
                  }
                }
              },
              x: {
                ticks: {
                  font: {
                    family: 'Vazirmatn'
                  }
                }
              }
            }
          }}
        />
      </div>
    </div>
  );
}