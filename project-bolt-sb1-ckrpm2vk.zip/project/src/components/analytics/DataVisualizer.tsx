import React, { useState, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { BarChart2, PieChart, LineChart, Upload, Download, Wand2, Brain, AlertCircle } from 'lucide-react';
import { Bar, Line, Pie } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement, Title, Tooltip, Legend } from 'chart.js';
import { openai, DEFAULT_MODEL } from '../../lib/openai';
import { exportChartAsImage, exportChartAsExcel, exportChartAsPDF } from '../../lib/analytics/export';
import { processFileData, cleanData } from '../../lib/analytics/processing';
import FileUploader from './FileUploader';
import { trackToolUsage } from '../../lib/activity/tracking';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

interface ChartData {
  labels: string[];
  datasets: {
    label: string;
    data: number[];
    backgroundColor?: string | string[];
    borderColor?: string;
    borderWidth?: number;
  }[];
}

export default function DataVisualizer() {
  const { t, i18n } = useTranslation();
  const isEnglish = i18n.language === 'en';
  const [data, setData] = useState<string>('');
  const [uploadedData, setUploadedData] = useState<any[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [chartType, setChartType] = useState<'bar' | 'line' | 'pie'>('bar');
  const [chartData, setChartData] = useState<ChartData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const chartRef = useRef<any>(null);
  const [isExporting, setIsExporting] = useState(false);

  const handleExport = async (format: 'png' | 'pdf' | 'excel') => {
    try {
      if (!chartData || !chartRef.current) {
        throw new Error(isEnglish ? 'No chart data available' : 'نموداری برای خروجی وجود ندارد');
      }

      setIsExporting(true);

      switch (format) {
        case 'png':
          const imageUrl = await exportChartAsImage(chartRef);
          const link = document.createElement('a');
          link.download = 'chart.png';
          link.href = imageUrl;
          link.click();
          break;

        case 'pdf':
          exportChartAsPDF(chartRef, 'Chart Analysis');
          break;

        case 'excel':
          exportChartAsExcel(chartData);
          break;
      }
    } catch (error) {
      console.error('Export error:', error);
      setError(error instanceof Error ? error.message : 
        isEnglish ? 'Error exporting chart' : 'خطا در تهیه خروجی');
    } finally {
      setIsExporting(false);
    }
  };

  const handleDataLoad = (loadedData: any[]) => {
    if (loadedData.length > 0) {
      // Convert data to CSV format
      const csvData = loadedData
        .map(row => Array.isArray(row) ? row.join(',') : Object.values(row).join(','))
        .join('\n');
      setData(csvData);
      setUploadedData(loadedData);
    }
  };

  const handleDataAnalysis = async () => {
    try {
      // Track analysis start
      await trackToolUsage(
        'data-visualizer',
        'تحلیل داده‌ها',
        'شروع تحلیل داده‌ها',
        {
          data,
          chartType
        }
      );

      if (!data.trim()) {
        setError(isEnglish ? 'Please enter data to analyze' : 'لطفاً داده‌ها را وارد کنید');
        setError(isEnglish ? 'Please enter data to analyze' : 'لطفاً داده‌ها را وارد کنید');
        return;
      }

      setIsAnalyzing(true);
      setError(null);
      setChartData(null);
      setChartData(null);

      // Validate and parse data
      let parsedData;
      try {
        let data2;
        if (uploadedData.length > 0) {
          // Process uploaded data
          data2 = await processFileData(uploadedData);
        } else {
          // Parse manually entered data
          const rows = data.trim().split('\n').map(line => 
            line.split(',').map(val => val.trim()));
          data2 = await processFileData(rows);
        }

        // Clean and validate the processed data
        const cleanedData = cleanData(data2);
        parsedData = cleanedData.rows;

        if (!Array.isArray(parsedData) || parsedData.length === 0) {
          setError(isEnglish ? 'Invalid data format' : 'فرمت داده نامعتبر است');
          return;
        }
      } catch (error) {
        setError(error instanceof Error ? error.message : 
          isEnglish ? 'Error processing data' : 'خطا در پردازش داده‌ها');
        setChartData(null);
        return;
      }

      // Prepare data for AI analysis
      const analysisData = {
        data: parsedData,
        chartType: chartType,
        language: isEnglish ? 'en' : 'fa',
        format: 'chart'
      };

      const response = await openai.chat.completions.create({
        model: DEFAULT_MODEL,
        temperature: 0.3,
        response_format: { type: "json_object" },
        messages: [
          {
            role: 'system',
            content: isEnglish ?
              `You are a data visualization expert. Please analyze the provided data and suggest the best visualization format. Return only a JSON object with no markdown formatting.

Please return the response in this JSON format:
{
  "data": {
    "labels": string[],
    "datasets": [{
      "label": string,
      "data": number[],
      "backgroundColor": string[],
      "borderColor": string,
      "borderWidth": number
    }]
  }
}` :
              `شما یک متخصص تجسم داده هستید. لطفاً داده‌های ارائه شده را تحلیل کرده و با توجه به نوع نمودار درخواستی، یک تجسم مناسب ایجاد کنید. فقط یک آبجکت JSON بدون فرمت مارک‌داون برگردانید.

لطفاً پاسخ را در قالب JSON با این ساختار برگردانید:
{
  "data": {
    "labels": ["برچسب 1", "برچسب 2"],
    "datasets": [{
      "label": "عنوان مجموعه داده",
      "data": [عدد 1, عدد 2],
      "backgroundColor": ["رنگ 1", "رنگ 2"],
      "borderColor": "رنگ حاشیه",
      "borderWidth": عدد
    }]
  }
}`
          },
          {
            role: 'user',
            content: JSON.stringify(analysisData)
          }
        ]
      });

      const content = response.choices[0]?.message?.content;
      if (!content) {
        throw new Error('پاسخی از سرور دریافت نشد');
      }

      let result;
      try {
        // Clean up any markdown formatting
        const jsonStr = content.replace(/^```json\n|\n```$/g, '').trim();
        result = JSON.parse(jsonStr);
      } catch (error) {
        console.error('JSON parse error:', error);
        throw new Error('خطا در پردازش نتایج تحلیل');
      }

      if (!result?.data?.labels || !Array.isArray(result.data.labels)) {
        throw new Error('فرمت داده‌های نمودار نامعتبر است');
      }
      
      setChartData(result.data);

      // Track successful analysis
      await trackToolUsage(
        'data-visualizer',
        'تحلیل موفق داده‌ها',
        'داده‌ها با موفقیت تحلیل شدند',
        {
          data,
          result,
          chartType
        }
      );

    } catch (error) {
      // Track error
      await trackToolUsage(
        'data-visualizer',
        'خطا در تحلیل داده‌ها',
        error instanceof Error ? error.message : 'خطا در تحلیل داده‌ها',
        { error: error }
      );
      console.error('Data analysis error:', error);
      setError(error instanceof Error ? error.message : 'خطا در تحلیل داده‌ها');
      setChartData(null);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl p-6 space-y-6">
        <div>
          <FileUploader onDataLoad={handleDataLoad} />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">
            {isEnglish ? 'Enter Your Data' : 'داده‌های خود را وارد کنید'}
          </label>
          <textarea
            value={data}
            onChange={(e) => setData(e.target.value)}
            className="w-full h-48 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 resize-none"
            placeholder={`ماه,فروش,هزینه,سود
فروردین,1200000,800000,400000
اردیبهشت,1500000,900000,600000
خرداد,1800000,1000000,800000
تیر,1600000,950000,650000
مرداد,2000000,1200000,800000
شهریور,2200000,1300000,900000`}
          />
        </div>

        <div className="flex gap-4">
          <button
            onClick={() => setChartType('bar')}
            className={`p-3 rounded-lg flex items-center gap-2 ${
              chartType === 'bar'
                ? 'bg-[#a63439] text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <BarChart2 className="w-5 h-5" />
            <span>{isEnglish ? 'Bar Chart' : 'نمودار میله‌ای'}</span>
          </button>
          <button
            onClick={() => setChartType('line')}
            className={`p-3 rounded-lg flex items-center gap-2 ${
              chartType === 'line'
                ? 'bg-[#a63439] text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <LineChart className="w-5 h-5" />
            <span>{isEnglish ? 'Line Chart' : 'نمودار خطی'}</span>
          </button>
          <button
            onClick={() => setChartType('pie')}
            className={`p-3 rounded-lg flex items-center gap-2 ${
              chartType === 'pie'
                ? 'bg-[#a63439] text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <PieChart className="w-5 h-5" />
            <span>{isEnglish ? 'Pie Chart' : 'نمودار دایره‌ای'}</span>
          </button>
        </div>

        <button
          onClick={handleDataAnalysis}
          disabled={isAnalyzing || !data.trim()}
          className="w-full bg-[#a63439] text-white p-4 rounded-lg flex items-center justify-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
        >
          {isAnalyzing ? (
            <>
              <Brain className="w-5 h-5 animate-pulse" />
              <span>{isEnglish ? 'Analyzing data...' : 'در حال تحلیل داده‌ها...'}</span>
            </>
          ) : (
            <>
              <Wand2 className="w-5 h-5" />
              <span>{isEnglish ? 'Analyze Data' : 'تحلیل داده‌ها'}</span>
            </>
          )}
        </button>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {chartData && (
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="flex justify-end gap-2 mb-4">
              <button
                onClick={() => handleExport('png')}
                disabled={isExporting}
                className="bg-gray-100 text-gray-700 px-3 py-1 rounded-lg hover:bg-gray-200 transition-colors flex items-center gap-1 text-sm"
              >
                <Download className="w-4 h-4" />
                PNG
              </button>
              <button
                onClick={() => handleExport('pdf')}
                disabled={isExporting}
                className="bg-gray-100 text-gray-700 px-3 py-1 rounded-lg hover:bg-gray-200 transition-colors flex items-center gap-1 text-sm"
              >
                <Download className="w-4 h-4" />
                PDF
              </button>
              <button
                onClick={() => handleExport('excel')}
                disabled={isExporting}
                className="bg-gray-100 text-gray-700 px-3 py-1 rounded-lg hover:bg-gray-200 transition-colors flex items-center gap-1 text-sm"
              >
                <Download className="w-4 h-4" />
                Excel
              </button>
            </div>
            <div className="aspect-[16/9] w-full">
              {chartType === 'bar' && <Bar ref={chartRef} data={chartData} />}
              {chartType === 'line' && <Line ref={chartRef} data={chartData} />}
              {chartType === 'pie' && <Pie ref={chartRef} data={chartData} />}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}