import React, { useState, useRef } from 'react';
import { Upload, X, FileSpreadsheet, FileText, AlertCircle, Loader2 } from 'lucide-react';
import * as XLSX from 'xlsx';
import Papa from 'papaparse';

interface FileUploaderProps {
  onDataLoad: (data: any[]) => void;
  maxSize?: number; // in MB
}

export default function FileUploader({ onDataLoad, maxSize = 10 }: FileUploaderProps) {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const supportedFormats = [
    { ext: '.xlsx, .xls', icon: FileSpreadsheet, label: 'فایل‌های اکسل' },
    { ext: '.csv', icon: FileText, label: 'فایل‌های CSV' },
    { ext: '.txt', icon: FileText, label: 'فایل‌های متنی' }
  ];

  const validateFile = (file: File) => {
    const validTypes = [
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'text/csv',
      'text/plain'
    ];
    
    if (!validTypes.includes(file.type)) {
      throw new Error('فرمت فایل پشتیبانی نمی‌شود');
    }

    if (file.size > maxSize * 1024 * 1024) {
      throw new Error(`حجم فایل نباید بیشتر از ${maxSize} مگابایت باشد`);
    }
  };

  const parseExcel = async (file: File): Promise<any[]> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = e.target?.result;
          const workbook = XLSX.read(data, { type: 'binary' });
          const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
          const jsonData = XLSX.utils.sheet_to_json(firstSheet, { header: 1 });
          resolve(jsonData);
        } catch (error) {
          reject(new Error('خطا در خواندن فایل اکسل'));
        }
      };
      reader.onerror = () => reject(new Error('خطا در خواندن فایل'));
      reader.readAsBinaryString(file);
    });
  };

  const parseCSV = async (file: File): Promise<any[]> => {
    return new Promise((resolve, reject) => {
      Papa.parse(file, {
        complete: (results) => resolve(results.data),
        error: () => reject(new Error('خطا در خواندن فایل CSV')),
        header: false
      });
    });
  };

  const parseTXT = async (file: File): Promise<any[]> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const text = e.target?.result as string;
          const rows = text.split('\n').map(row => 
            row.split(/[\t,;]/).map(cell => cell.trim())
          );
          resolve(rows);
        } catch (error) {
          reject(new Error('خطا در خواندن فایل متنی'));
        }
      };
      reader.onerror = () => reject(new Error('خطا در خواندن فایل'));
      reader.readAsText(file);
    });
  };

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (!selectedFile) return;

    try {
      setIsLoading(true);
      setError(null);
      validateFile(selectedFile);

      let data: any[];
      if (selectedFile.type.includes('excel') || selectedFile.name.match(/\.xlsx?$/i)) {
        data = await parseExcel(selectedFile);
      } else if (selectedFile.type === 'text/csv' || selectedFile.name.endsWith('.csv')) {
        data = await parseCSV(selectedFile);
      } else {
        data = await parseTXT(selectedFile);
      }

      // Validate data structure
      if (!Array.isArray(data) || data.length === 0) {
        throw new Error('فایل داده‌ای ندارد');
      }

      setFile(selectedFile);
      setPreview(data.slice(0, 5)); // Show first 5 rows
      onDataLoad(data);

    } catch (error) {
      console.error('File processing error:', error);
      setError(error instanceof Error ? error.message : 'خطا در پردازش فایل');
      if (fileInputRef.current) fileInputRef.current.value = '';
    } finally {
      setIsLoading(false);
    }
  };

  const handleRemove = () => {
    setFile(null);
    setPreview([]);
    setError(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    onDataLoad([]);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2 mb-2">
        {supportedFormats.map((format, index) => (
          <div key={index} className="flex items-center gap-1 text-sm text-gray-600">
            <format.icon className="w-4 h-4" />
            <span>{format.label}</span>
            <span className="text-gray-400">({format.ext})</span>
          </div>
        ))}
      </div>

      <label
        htmlFor="file-upload"
        className={`relative flex flex-col items-center justify-center gap-2 w-full bg-gray-50 border-2 border-dashed transition-all rounded-lg p-4 cursor-pointer hover:bg-gray-100 group ${
          isLoading ? 'border-yellow-400 animate-pulse' :
          file ? 'border-[#a63439]' : 'border-gray-200'
        } ${error ? 'border-red-300' : ''}`}
      >
        {file ? (
          <>
            <div className="flex items-center gap-3">
              <FileSpreadsheet className="w-6 h-6 text-[#a63439]" />
              <span className="font-medium">{file.name}</span>
              <span className="text-sm text-gray-500">
                ({(file.size / 1024 / 1024).toFixed(2)} MB)
              </span>
            </div>
            {preview.length > 0 && (
              <div className="w-full mt-4 overflow-x-auto">
                <table className="w-full text-sm">
                  <tbody>
                    {preview.map((row, i) => (
                      <tr key={i} className="border-b border-gray-100">
                        {Array.isArray(row) && row.map((cell, j) => (
                          <td key={j} className="py-1 px-2">{cell}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            <button
              onClick={(e) => {
                e.preventDefault();
                handleRemove();
              }}
              className="absolute top-2 left-2 p-1 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <X className="w-4 h-4" />
            </button>
          </>
        ) : (
          <div className="flex flex-col items-center gap-2">
            {isLoading ? (
              <Loader2 className="w-8 h-8 text-[#a63439] animate-spin" />
            ) : (
              <Upload className={`w-8 h-8 ${error ? 'text-red-500' : 'text-gray-400'}`} />
            )}
            <span className={`text-sm ${error ? 'text-red-600' : 'text-gray-600'}`}>
              {isLoading ? 'در حال پردازش فایل...' : 'برای آپلود فایل کلیک کنید یا فایل را اینجا رها کنید'}
            </span>
            <span className="text-xs text-gray-500">
              (حداکثر {maxSize} مگابایت)
            </span>
          </div>
        )}
      </label>
      <input
        ref={fileInputRef}
        id="file-upload"
        type="file"
        accept=".xlsx,.xls,.csv,.txt"
        onChange={handleFileChange}
        className="hidden"
      />

      {error && (
        <div className="flex items-center gap-2 text-sm text-red-600">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}
    </div>
  );
}