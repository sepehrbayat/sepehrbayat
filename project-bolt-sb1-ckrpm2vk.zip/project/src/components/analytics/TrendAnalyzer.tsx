import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { TrendingUp, Brain, AlertCircle, Wand2, FileText } from 'lucide-react';
import { Line } from 'react-chartjs-2';
import FileUploader from './FileUploader';
import regression from 'regression';
import { mean, standardDeviation, linearRegression } from 'simple-statistics';
import { openai } from '../../lib/openai';

interface TrendData {
  dates: string[];
  values: number[];
  predictions: number[];
  trend: string;
  confidence: number;
  insights: string[];
}

export default function TrendAnalyzer() {
  const { t, i18n } = useTranslation();
  const isEnglish = i18n.language === 'en';
  const [data, setData] = useState<string>('');
  const [uploadedData, setUploadedData] = useState<any[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [trendData, setTrendData] = useState<TrendData | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleDataLoad = (loadedData: any[]) => {
    if (loadedData.length > 0) {
      // Convert data to CSV format
      const csvData = loadedData
        .map(row => Array.isArray(row) ? row.join(',') : Object.values(row).join(','))
        .join('\n');
      setData(csvData);
      setUploadedData(loadedData);
    }
  };

  const analyzeTrend = async () => {
    try {
      if (!data.trim()) {
        throw new Error(isEnglish ? 'Please enter data to analyze' : 'لطفاً داده‌ها را وارد کنید');
      }

      setIsAnalyzing(true);
      setError(null);

      // Parse and validate data
      const rows = data.trim().split('\n').map(row => {
        const [date, valueStr] = row.split(',').map(s => s.trim());
        const value = parseFloat(valueStr);
        if (isNaN(value)) {
          throw new Error('مقادیر عددی نامعتبر هستند');
        }
        return { date, value };
      });

      const dates = rows.map(row => row.date);
      const values = rows.map(row => row.value);

      // Get AI analysis
      const response = await openai.chat.completions.create({
        model: 'gpt-4o',
        temperature: 0.3,
        max_tokens: 1000,
        messages: [
          {
            role: 'system',
            content: isEnglish ? 
              `You are a trend analysis expert. Please analyze the provided time series data and identify trends. Return ONLY a valid JSON object, no markdown formatting or code blocks.

Response format:
{
  "trend": "upward" | "downward" | "stable" | "cyclical",
  "confidence": number (0-100),
  "insights": [
    "insight 1",
    "insight 2",
    "insight 3"
  ]
}` :
              `شما یک متخصص تحلیل روند هستید. لطفاً داده‌های سری زمانی ارائه شده را تحلیل کنید. فقط یک آبجکت JSON برگردانید، بدون فرمت مارک‌داون یا بلوک کد.

قالب پاسخ:
{
  "trend": "صعودی" | "نزولی" | "ثابت" | "نوسانی",
  "confidence": عدد بین 0 تا 100,
  "insights": [
    "نکته کلیدی 1",
    "نکته کلیدی 2",
    "نکته کلیدی 3"
  ]
}`
          },
          {
            role: 'user',
            content: data
          }
        ]
      });

      const aiAnalysis = JSON.parse(response.choices[0]?.message?.content || '{}');
      
      // Validate required fields
      if (!aiAnalysis.trend || !aiAnalysis.confidence || !Array.isArray(aiAnalysis.insights)) {
        throw new Error(isEnglish ? 'Invalid analysis format' : 'قالب تحلیل نامعتبر است');
      }

      // Calculate trend line using regression
      const points = values.map((y, i) => [i, y]);
      const result = regression.linear(points as [number, number][]);
      const predictions = result.points.map(point => point[1]);

      // Calculate trend statistics
      const regressionStats = linearRegression(points);

      setTrendData({
        dates,
        values,
        predictions,
        trend: aiAnalysis.trend,
        confidence: aiAnalysis.confidence,
        insights: aiAnalysis.insights
      });

    } catch (error) {
      console.error('Trend analysis error:', error);
      setError(error instanceof Error ? error.message : 'Error analyzing trend');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl p-6 space-y-6">
        <div>
          <FileUploader onDataLoad={handleDataLoad} />
          <div className="mt-4 bg-gray-50 rounded-lg p-4">
            <h3 className="text-sm font-medium mb-2">راهنمای ورود داده‌ها</h3>
            <p className="text-sm text-gray-600 mb-2">
              داده‌های خود را در یکی از قالب‌های زیر وارد کنید:
            </p>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>• فایل اکسل (.xlsx, .xls) با دو ستون: تاریخ و مقدار</li>
              <li>• فایل CSV یا متنی با فرمت: تاریخ,مقدار در هر خط</li>
              <li>• وارد کردن مستقیم داده‌ها در کادر متنی با فرمت: تاریخ,مقدار (هر خط یک رکورد)</li>
            </ul>
            <p className="text-sm text-gray-600 mt-2">
              مثال:<br />
              1402/01/01,100<br />
              1402/01/02,120<br />
              1402/01/03,115
            </p>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">
            {isEnglish ? 'Enter Time Series Data' : 'داده‌های سری زمانی را وارد کنید'}
          </label>
          <textarea
            value={data}
            onChange={(e) => setData(e.target.value)}
            className="w-full h-32 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 resize-none"
            placeholder="1402/01/01,100&#10;1402/01/02,120&#10;1402/01/03,115"
          />
        </div>

        <button
          onClick={analyzeTrend}
          disabled={isAnalyzing || !data.trim()}
          className="w-full bg-blue-600 text-white p-4 rounded-lg flex items-center justify-center gap-2 hover:bg-blue-700 disabled:opacity-50"
        >
          {isAnalyzing ? (
            <>
              <Brain className="w-5 h-5 animate-pulse" />
              <span>{isEnglish ? 'Analyzing...' : 'در حال تحلیل...'}</span>
            </>
          ) : (
            <>
              <TrendingUp className="w-5 h-5" />
              <span>{isEnglish ? 'Analyze Trend' : 'تحلیل روند'}</span>
            </>
          )}
        </button>

        {error && (
          <div className="bg-red-50 text-red-600 p-4 rounded-lg flex items-center gap-2">
            <AlertCircle className="w-5 h-5" />
            <span>{error}</span>
          </div>
        )}

        {trendData && (
          <div className="space-y-6">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-medium mb-2">
                {isEnglish ? 'Analysis Results' : 'نتایج تحلیل'}
              </h3>
              <p>
                {isEnglish ? 'Trend: ' : 'روند: '}
                <span className="font-medium">{trendData.trend}</span>
              </p>
              <p>
                {isEnglish ? 'Confidence: ' : 'اطمینان: '}
                <span className="font-medium">{trendData.confidence}%</span>
              </p>
            </div>

            <div className="h-64">
              <Line
                data={{
                  labels: trendData.dates,
                  datasets: [
                    {
                      label: isEnglish ? 'Actual Values' : 'مقادیر واقعی',
                      data: trendData.values,
                      borderColor: 'rgb(59, 130, 246)',
                      backgroundColor: 'rgba(59, 130, 246, 0.1)',
                      fill: true
                    },
                    {
                      label: isEnglish ? 'Trend Line' : 'خط روند',
                      data: trendData.predictions,
                      borderColor: 'rgb(239, 68, 68)',
                      borderDash: [5, 5],
                      fill: false
                    }
                  ]
                }}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      position: 'top'
                    }
                  }
                }}
              />
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-medium mb-2">
                {isEnglish ? 'Insights' : 'بینش‌ها'}
              </h3>
              <ul className="space-y-2">
                {trendData.insights.map((insight, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <div className="w-5 h-5 mt-0.5 flex-shrink-0">
                      <FileText className="w-full h-full" />
                    </div>
                    <span>{insight}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}