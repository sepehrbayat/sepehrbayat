import React from 'react';
import { Tool } from '../../../types';
import ToolCard from './ToolCard';
import { getCategoryIcon } from './utils';

interface ToolSectionProps {
  category: string;
  tools: Tool[];
  onSelectTool: (toolId: string) => void;
}

const categoryTitles: Record<string, string> = {
  video: 'ابزارهای ویدئو',
  video: 'ابزارهای ویدیو',
  analytics: 'ابزارهای تحلیلی',
  trading: 'ابزارهای معاملاتی',
  content: 'ابزارهای تولید محتوا',
  seo: 'ابزارهای سئو',
  ai: 'دستیارهای هوشمند',
  interior: 'طراحی داخلی'
};

export default function ToolSection({ category, tools, onSelectTool }: ToolSectionProps) {
  const CategoryIcon = getCategoryIcon(category);
  const title = categoryTitles[category] || category;

  return (
    <div>
      <h2 className="text-lg font-medium mb-4 flex items-center gap-2">
        <CategoryIcon className="w-5 h-5 text-[#a63439]" />
        {title}
      </h2>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
        {tools.map(tool => (
          <ToolCard
            key={tool.id}
            tool={tool}
            onSelect={() => !tool.isLocked && onSelectTool(tool.id)}
          />
        ))}
      </div>
    </div>
  );
}