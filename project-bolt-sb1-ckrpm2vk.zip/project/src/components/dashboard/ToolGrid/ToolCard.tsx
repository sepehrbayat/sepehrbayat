import React from 'react';
import { useTranslation } from 'react-i18next';
import { Star, Crown } from 'lucide-react';
import { Tool } from '../../../types';

interface ToolCardProps {
  tool: Tool;
  onSelect: () => void;
}

export default function ToolCard({ tool, onSelect }: ToolCardProps) {
  const { t } = useTranslation();

  return (
    <div
      onClick={onSelect}
      className={`${tool.color} rounded-lg p-3 flex flex-col items-center justify-center aspect-square relative ${
        tool.id === 'content-pro' || tool.id === 'image' || tool.id === 'seo-pro' 
          ? 'shadow-[0_0_15px_rgba(245,158,11,0.3)] hover:shadow-[0_0_25px_rgba(245,158,11,0.5)]' 
          : ''
      } ${
        !tool.isLocked ? 'hover:scale-105 cursor-pointer' : 'opacity-60 cursor-not-allowed'
      } transition-all duration-300`}
    >
      {tool.id === 'content-pro' || tool.id === 'image' || tool.id === 'seo-pro' ? (
        <div className="relative">
          <Crown className="w-6 h-6 mb-2 text-amber-600" />
          <div className="absolute -top-1 -right-1">
            <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
          </div>
        </div>
      ) : (
        React.createElement(tool.icon, { className: 'w-6 h-6 mb-2 text-gray-700' })
      )}

      <span className={`text-xs font-medium text-center line-clamp-2 ${
        tool.id === 'content-pro' || tool.id === 'image' || tool.id === 'seo-pro'
          ? 'text-amber-800' 
          : 'text-gray-700'
      }`}>
        {tool.name}
      </span>

      {tool.isNew && !tool.isLocked && (
        <div className="absolute top-2 left-2 bg-[#a63439] text-white text-[10px] px-1.5 py-0.5 rounded-full">
          {t('common.new')}
        </div>
      )}

      {tool.isLocked && (
        <div className="absolute top-2 left-2 bg-gray-800 text-white text-[10px] px-1.5 py-0.5 rounded-full">
          {t('common.comingSoon')}
        </div>
      )}

      {(tool.id === 'content-pro' || tool.id === 'image' || tool.id === 'seo-pro') && (
        <div className="absolute top-2 left-2 bg-gradient-to-r from-amber-500 to-amber-600 text-white text-[10px] px-2 py-0.5 rounded-full flex items-center gap-1">
          <Star className="w-2.5 h-2.5 fill-current" />
          <span>PRO</span>
        </div>
      )}
    </div>
  );
}