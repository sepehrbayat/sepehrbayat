import { Tool } from '../../../types';
import { 
  BarChart2, FileText, Search, TrendingUp, Sofa, Brain,
  Globe, DollarSign, Heart, GraduationCap, ChefHat, Film,
  ShoppingBag, Code, Home, Film, Plane, Image, Video, BookOpen,
  Music, Ruler, Wand2, Building2, Mountain, PencilRuler, Star,
  Crown, Target, Activity, LineChart
} from 'lucide-react';

// Map category names to their icons
const categoryIcons = {
  video: Film,
  analytics: BarChart2,
  content: FileText,
  seo: Search,
  trading: TrendingUp,
  interior: Sofa,
  ai: Brain
};

// Get icon component for a category
export function getCategoryIcon(category: string) {
  return categoryIcons[category as keyof typeof categoryIcons] || Brain;
}

// Group tools by category
export function getToolsByCategory(): Record<string, Tool[]> {
  const tools: Tool[] = [
    // ابزارهای ویدئو
    {
      id: 'image-to-video',
      name: 'تبدیل تصویر به ویدئو',
      description: 'تبدیل تصاویر ثابت به ویدئوهای پویا',
      icon: Film,
      color: 'bg-rose-100',
      isNew: true,
      category: 'video'
    },


    // ابزارهای تحلیلی
    {
      id: 'data-visualizer',
      name: 'تجسم هوشمند داده‌ها',
      description: 'ساخت نمودارها و تجسم‌های زیبا با کمک هوش مصنوعی',
      icon: BarChart2,
      color: 'bg-blue-100',
      isNew: true,
      category: 'analytics'
    },
    {
      id: 'trend-analyzer',
      name: 'تحلیلگر روند هوشمند',
      description: 'تحلیل روندها و الگوهای موجود در داده‌ها',
      icon: TrendingUp,
      color: 'bg-green-100',
      isNew: true,
      category: 'analytics'
    },
    {
      id: 'performance-tracker',
      name: 'ردیاب عملکرد',
      description: 'پیگیری و تحلیل معیارهای عملکردی',
      icon: Target,
      color: 'bg-purple-100',
      isNew: true,
      category: 'analytics'
    },
    {
      id: 'smart-reports',
      name: 'گزارش‌های هوشمند',
      description: 'تولید گزارش‌های هوشمند با هوش مصنوعی',
      icon: Activity,
      color: 'bg-amber-100',
      isNew: true,
      isLocked: true,
      category: 'analytics'
    },

    // ابزارهای معاملاتی
    {
      id: 'technical-analyzer',
      name: 'تحلیلگر تکنیکال',
      description: 'تحلیل تکنیکال خودکار نمودارها با هوش مصنوعی',
      icon: LineChart,
      color: 'bg-blue-100',
      isNew: true,
      isLocked: true,
      category: 'trading'
    },
    {
      id: 'pattern-recognizer',
      name: 'تشخیص الگو',
      description: 'شناسایی خودکار الگوهای قیمتی و نموداری',
      icon: Brain,
      color: 'bg-purple-100',
      isNew: true,
      isLocked: true,
      category: 'trading'
    },
    {
      id: 'sentiment-analyzer',
      name: 'تحلیل سنتیمنت',
      description: 'تحلیل احساسات بازار و اخبار مرتبط',
      icon: BarChart2,
      color: 'bg-green-100',
      isNew: true,
      isLocked: true,
      category: 'trading'
    },
    {
      id: 'portfolio-optimizer',
      name: 'بهینه‌ساز سبد سهام',
      description: 'مدیریت و بهینه‌سازی هوشمند پورتفولیو',
      icon: Target,
      color: 'bg-amber-100',
      isNew: true,
      isLocked: true,
      category: 'trading'
    },

    // ابزارهای تولید محتوا
    {
      id: 'content-pro',
      name: 'تولید مقاله پرو',
      description: 'تولید محتوای حرفه‌ای با هوشِکس پرو',
      icon: Crown,
      color: 'bg-gradient-to-br from-amber-100 to-amber-50',
      isNew: true,
      category: 'content'
    },
    {
      id: 'content',
      name: 'تولید محتوا',
      description: 'تولید محتوای هوشمند با کمک هوش مصنوعی',
      icon: FileText,
      color: 'bg-emerald-100',
      isNew: true,
      category: 'content'
    },
    {
      id: 'reels-script',
      name: 'سناریو نویس ریلز',
      description: 'تولید سناریو برای ریلز و شورت',
      icon: Film,
      color: 'bg-pink-100',
      isNew: true,
      category: 'content'
    },
    {
      id: 'image',
      name: 'هوش پیک پرو',
      description: 'تولید تصویر حرفه‌ای با هوش مصنوعی',
      icon: Image,
      color: 'bg-purple-100',
      isNew: true,
      category: 'content'
    },
    {
      id: 'image-lite',
      name: 'هوش پیک لایت',
      description: 'تولید تصویر ساده با هوش مصنوعی',
      icon: Image,
      color: 'bg-indigo-100',
      isNew: true,
      category: 'content'
    },
    {
      id: 'music',
      name: 'هوش موزیک',
      description: 'تولید و ویرایش موسیقی',
      icon: Music,
      color: 'bg-purple-100',
      isNew: true,
      isLocked: true,
      category: 'content'
    },

    // ابزارهای سئو
    {
      id: 'seo-pro',
      name: 'تحلیل سئو پرو',
      description: 'تحلیل عمیق و پیشرفته سئو سایت با هوش مصنوعی',
      icon: Crown,
      color: 'bg-gradient-to-br from-amber-100 to-amber-50',
      isNew: true,
      category: 'seo'
    },
    {
      id: 'seo',
      name: 'تحلیل سئو',
      description: 'تحلیل جامع سئو سایت و دریافت پیشنهادات بهبود',
      icon: Search,
      color: 'bg-blue-100',
      isNew: true,
      category: 'seo'
    },
    {
      id: 'keyword-research',
      name: 'تحقیق کلمات کلیدی',
      description: 'پیدا کردن بهترین کلمات کلیدی برای محتوا',
      icon: Search,
      color: 'bg-purple-100',
      isNew: true,
      category: 'seo'
    },
    {
      id: 'content-optimizer',
      name: 'بهینه‌سازی محتوا',
      description: 'بهینه‌سازی محتوا برای کلمات کلیدی هدف',
      icon: FileText,
      color: 'bg-emerald-100',
      isNew: true,
      category: 'seo'
    },
    {
      id: 'competitor-analysis',
      name: 'تحلیل رقبا',
      description: 'بررسی و مقایسه سئو رقبا',
      icon: BarChart2,
      color: 'bg-orange-100',
      isNew: true,
      category: 'seo'
    },

    // دستیارهای هوشمند
    {
      id: 'student',
      name: 'دستیار دانشجو',
      description: 'کمک در امور تحصیلی و دانشگاهی',
      icon: BookOpen,
      color: 'bg-blue-100',
      isNew: true,
      category: 'ai'
    },
    {
      id: 'language',
      name: 'دستیار زبان',
      description: 'یادگیری و تمرین زبان‌های خارجی',
      icon: Globe,
      color: 'bg-blue-100',
      category: 'ai'
    },
    {
      id: 'finance',
      name: 'دستیار مالی',
      description: 'مشاوره مالی و سرمایه‌گذاری',
      icon: DollarSign,
      color: 'bg-yellow-100',
      category: 'ai'
    },
    {
      id: 'health',
      name: 'دستیار سلامت',
      description: 'مشاوره سلامت و تغذیه',
      icon: Heart,
      color: 'bg-green-100',
      category: 'ai'
    },
    {
      id: 'cooking',
      name: 'دستیار آشپزی',
      description: 'آموزش آشپزی و دستور پخت',
      icon: ChefHat,
      color: 'bg-red-100',
      category: 'ai'
    },
    {
      id: 'shopping',
      name: 'دستیار خرید',
      description: 'راهنمای خرید هوشمند',
      icon: ShoppingBag,
      color: 'bg-teal-100',
      category: 'ai'
    },
    {
      id: 'programming',
      name: 'دستیار برنامه‌نویسی',
      description: 'کمک در کدنویسی و دیباگ',
      icon: Code,
      color: 'bg-gray-100',
      category: 'ai'
    },
    {
      id: 'entertainment',
      name: 'دستیار سرگرمی',
      description: 'پیشنهاد فیلم و سرگرمی',
      icon: Film,
      color: 'bg-red-100',
      category: 'ai'
    },
    {
      id: 'travel',
      name: 'دستیار سفر',
      description: 'برنامه‌ریزی و راهنمای سفر',
      icon: Plane,
      color: 'bg-cyan-100',
      category: 'ai'
    },

    // ابزارهای طراحی داخلی
    {
      id: 'interior-designer',
      name: 'طراح داخلی هوشمند',
      description: 'طراحی خودکار دکوراسیون داخلی',
      icon: Sofa,
      color: 'bg-orange-100',
      isNew: true,
      isLocked: true,
      category: 'interior'
    },
    {
      id: 'floor-planner',
      name: 'نقشه‌کشی هوشمند',
      description: 'تبدیل تصویر به نقشه حرفه‌ای',
      icon: Ruler,
      color: 'bg-blue-100',
      isNew: true,
      isLocked: true,
      category: 'interior'
    },
    {
      id: 'room-decorator',
      name: 'دکوراتور اتاق',
      description: 'طراحی دکوراسیون اتاق',
      icon: Wand2,
      color: 'bg-purple-100',
      isNew: true,
      isLocked: true,
      category: 'interior'
    },
    {
      id: 'exterior-restorer',
      name: 'بازسازی نمای خارجی',
      description: 'بازسازی و بهبود نمای ساختمان',
      icon: Building2,
      color: 'bg-green-100',
      isNew: true,
      isLocked: true,
      category: 'interior'
    },
    {
      id: 'scenario-changer',
      name: 'تغییر محیط',
      description: 'تغییر محیط اطراف ساختمان',
      icon: Mountain,
      color: 'bg-yellow-100',
      isNew: true,
      isLocked: true,
      category: 'interior'
    },
    {
      id: 'sketch-renderer',
      name: 'رندر طرح اولیه',
      description: 'تبدیل طرح دستی به تصویر واقعی',
      icon: PencilRuler,
      color: 'bg-red-100',
      isNew: true,
      isLocked: true,
      category: 'interior'
    }
  ];

  // Group tools by category
  return tools.reduce((acc, tool) => {
    if (!acc[tool.category]) {
      acc[tool.category] = [];
    }
    acc[tool.category].push(tool);
    return acc;
  }, {} as Record<string, Tool[]>);
}