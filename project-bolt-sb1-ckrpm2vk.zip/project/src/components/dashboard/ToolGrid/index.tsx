import React, { useState, useEffect } from 'react';
import { Brain, Sparkles } from 'lucide-react';
import { Tool } from '../../../types';
import ToolSection from './ToolSection';
import { getToolsByCategory } from './utils';
import { renderSelectedTool } from './toolRenderer';

export default function ToolGrid() {
  const [selectedTool, setSelectedTool] = useState<string | null>(null);

  // Reset selectedTool when returning to grid
  useEffect(() => {
    setSelectedTool(null);
  }, []);

  // If a tool is selected, render its component
  if (selectedTool) {
    return renderSelectedTool(selectedTool);
  }

  // Get tools grouped by category
  const toolsByCategory = getToolsByCategory();

  return (
    <div className="space-y-8">
      <div className="relative overflow-hidden bg-gradient-to-br from-[#a63439]/5 via-white to-[#262e43]/5 rounded-2xl p-8 shadow-xl border border-[#a63439]/10 backdrop-blur-sm">
        {/* Decorative background elements */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(166,52,57,0.1)_0%,transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_80%,rgba(38,46,67,0.1)_0%,transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.8)_0%,transparent_70%)]" />
        
        <div className="relative flex items-center gap-6">
          <div className="relative group">
            <div className="absolute -inset-0.5 bg-gradient-to-r from-[#a63439] to-[#262e43] rounded-2xl blur opacity-50 group-hover:opacity-75 transition duration-1000 group-hover:duration-200 animate-tilt" />
            <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-br from-[#a63439] to-[#262e43] p-1">
              <div className="w-full h-full bg-white rounded-xl flex items-center justify-center">
                <Brain className="w-8 h-8 text-[#a63439]" />
              </div>
            </div>
            <div className="absolute -top-3 -right-3 animate-pulse">
              <div className="w-6 h-6 rounded-full bg-[#a63439] flex items-center justify-center">
                <Sparkles className="w-3 h-3 text-white" />
              </div>
            </div>
          </div>
          <div>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold bg-gradient-to-l from-[#a63439] via-[#8a2a2e] to-[#262e43] bg-clip-text text-transparent">
              ابزارهای هوشِکس
            </h2>
            <p className="text-base md:text-lg mt-2 text-gray-600">
              مجموعه ابزارهای هوشمند برای کمک به شما در زمینه‌های مختلف
            </p>
            <div className="flex items-center gap-3 mt-4">
              <div className="flex items-center gap-1.5 bg-[#a63439]/10 text-[#a63439] px-3 py-1 rounded-full text-sm">
                <Brain className="w-4 h-4" />
                <span>هوش مصنوعی پیشرفته</span>
              </div>
              <div className="flex items-center gap-1.5 bg-[#262e43]/10 text-[#262e43] px-3 py-1 rounded-full text-sm">
                <Sparkles className="w-4 h-4" />
                <span>ابزارهای حرفه‌ای</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-8">
        {Object.entries(toolsByCategory).map(([category, tools]) => (
          <ToolSection
            key={category}
            category={category}
            tools={tools}
            onSelectTool={setSelectedTool}
          />
        ))}
      </div>
    </div>
  );
}