import React from 'react';
import ImageToVideo from '../../../pages/ImageToVideo';
import DataVisualizer from '../../analytics/DataVisualizer';
import TrendAnalyzer from '../../analytics/TrendAnalyzer';
import PerformanceTracker from '../../analytics/PerformanceTracker';
import SmartReports from '../../analytics/SmartReports';
import AnalyticsTools from '../../../pages/AnalyticsTools';
import ContentPro from '../../../pages/ContentPro';
import ShoppingAI from '../../../pages/ShoppingAI';
import ImageAILite from '../../../pages/ImageAILite';
import LanguageAI from '../../../pages/LanguageAI';
import FinanceAI from '../../../pages/FinanceAI';
import TravelAI from '../../../pages/TravelAI';
import ImageAI from '../../../pages/ImageAI';
import ContentAI from '../../../pages/ContentAI';
import SEOAnalyzer from '../../../pages/SEOAnalyzer';
import HealthAI from '../../../pages/HealthAI';
import CookingAI from '../../../pages/CookingAI';
import ProgrammingAI from '../../../pages/ProgrammingAI';
import DecorationAI from '../../../pages/DecorationAI';
import EntertainmentAI from '../../../pages/EntertainmentAI';
import KeywordResearch from '../../seo/tools/KeywordResearch';
import InteriorDesigner from '../../../pages/interior/InteriorDesigner';
import FloorPlanner from '../../../pages/interior/FloorPlanner';
import RoomDecorator from '../../../pages/interior/RoomDecorator';
import ExteriorRestorer from '../../../pages/interior/ExteriorRestorer';
import ScenarioChanger from '../../../pages/interior/ScenarioChanger';
import SketchRenderer from '../../../pages/interior/SketchRenderer';
import ContentOptimizer from '../../seo/tools/ContentOptimizer';
import CompetitorAnalysis from '../../seo/tools/CompetitorAnalysis';
import MusicAI from '../../../pages/MusicAI';
import SEOProAnalyzer from '../../seo/SEOProAnalyzer';
import StudentAI from '../../../pages/StudentAI';
import TradingTools from '../../../pages/TradingTools';

// Map tool IDs to their components
const toolComponents: Record<string, React.ComponentType<any>> = {
  'image-to-video': ImageToVideo,
  'language': LanguageAI,
  'content-pro': ContentPro,
  'finance': FinanceAI,
  'health': HealthAI,
  'cooking': CookingAI,
  'shopping': ShoppingAI,
  'programming': ProgrammingAI,
  'decoration': DecorationAI,
  'entertainment': EntertainmentAI,
  'travel': TravelAI,
  'image': ImageAI,
  'image-lite': ImageAILite,
  'content': ContentAI,
  'seo': SEOAnalyzer,
  'seo-pro': SEOProAnalyzer,
  'keyword-research': KeywordResearch,
  'content-optimizer': ContentOptimizer,
  'competitor-analysis': CompetitorAnalysis,
  'student': StudentAI,
  'education': StudentAI,
  'interior-designer': InteriorDesigner,
  'floor-planner': FloorPlanner,
  'room-decorator': RoomDecorator,
  'exterior-restorer': ExteriorRestorer,
  'scenario-changer': ScenarioChanger,
  'sketch-renderer': SketchRenderer,
  'music': MusicAI
};

// Render the selected tool component
export function renderSelectedTool(toolId: string) {
  // Special cases for analytics tools
  if (['data-visualizer', 'trend-analyzer', 'performance-tracker', 'smart-reports'].includes(toolId)) {
    return <AnalyticsTools tool={toolId} />;
  }

  // Special cases for trading tools
  if (['technical-analyzer', 'pattern-recognizer', 'sentiment-analyzer', 'portfolio-optimizer'].includes(toolId)) {
    return <TradingTools tool={toolId} />;
  }

  // Render component from map
  const Component = toolComponents[toolId];
  if (Component) {
    return <Component />;
  }

  return null;
}