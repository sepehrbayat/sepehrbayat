import React from 'react';
import { Tool } from '../../types';
import * as Icons from 'lucide-react';

interface ToolCardProps {
  tool: Tool;
}

export default function ToolCard({ tool }: ToolCardProps) {
  const Icon = Icons[tool.icon as keyof typeof Icons];

  return (
    <div className="bg-[#efecee] rounded-xl p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
          tool.isNew ? 'bg-[#a63439] text-white' : 'bg-white text-[#262e43]'
        }`}>
          {Icon && <Icon className="w-6 h-6" />}
        </div>
        {tool.isNew && (
          <span className="bg-[#a63439] text-white text-xs px-2 py-1 rounded-full">
            جدید
          </span>
        )}
        {tool.isLocked && (
          <Icons.Lock className="w-5 h-5 text-[#262e43]" />
        )}
      </div>
      <h3 className="text-[#262e43] font-medium mb-1">{tool.name}</h3>
      <p className="text-sm text-gray-600">{tool.description}</p>
    </div>
  );
}