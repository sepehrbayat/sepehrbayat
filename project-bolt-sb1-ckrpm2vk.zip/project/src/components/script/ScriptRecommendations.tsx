import React from 'react';
import type { ScriptAnalysis } from './types';

interface ScriptRecommendationsProps {
  recommendations: ScriptAnalysis['recommendations'];
}

export default function ScriptRecommendations({ recommendations }: ScriptRecommendationsProps) {
  return (
    <div className="bg-white rounded-xl p-6">
      <h3 className="text-lg font-medium mb-4">پیشنهادات تکمیلی</h3>
      <div className="grid grid-cols-3 gap-4">
        <div>
          <h4 className="text-sm font-medium mb-2">نکات فنی</h4>
          <ul className="space-y-2">
            {recommendations.technical.map((rec, index) => (
              <li
                key={index}
                className="bg-gray-50 rounded-lg p-3 text-sm text-gray-600"
              >
                {rec}
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-medium mb-2">نکات خلاقانه</h4>
          <ul className="space-y-2">
            {recommendations.creative.map((rec, index) => (
              <li
                key={index}
                className="bg-gray-50 rounded-lg p-3 text-sm text-gray-600"
              >
                {rec}
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-medium mb-2">نکات تولید</h4>
          <ul className="space-y-2">
            {recommendations.production.map((rec, index) => (
              <li
                key={index}
                className="bg-gray-50 rounded-lg p-3 text-sm text-gray-600"
              >
                {rec}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}