import React from 'react';
import ChatInterface from './ChatInterface';

interface GenericChatBotProps {
  title: string;
  description: string;
  systemPrompt: string;
  suggestions: Array<{
    text: string;
    icon: any;
  }>;
}

const GenericChatBot: React.FC<GenericChatBotProps> = ({
  title,
  description,
  systemPrompt,
  suggestions
}) => {
  return (
    <div className="container mx-auto py-6 md:py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="text-2xl font-medium mb-2 bg-gradient-to-l from-[#a63439] to-[#262e43] bg-clip-text text-transparent">
            {title}
          </h1>
          <p className="text-gray-600 text-sm md:text-base">{description}</p>
        </div>
        <ChatInterface
          systemPrompt={systemPrompt}
          suggestions={suggestions}
        />
      </div>
    </div>
  );
};

export default GenericChatBot;