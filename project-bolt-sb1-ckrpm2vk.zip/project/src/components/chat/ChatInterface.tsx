import React, { useState, useEffect, useRef } from 'react';
import { Send, Loader2, Brain, Settings2, Mic, MicOff, Sparkles, MessageSquare, Book, Lightbulb, Image, FileText, Download, Copy, Share2, Eraser, Undo, Bookmark, BookmarkCheck } from 'lucide-react';
import { openai } from '../../lib/openai';

interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
  id?: string;
  timestamp?: number;
  isBookmarked?: boolean;
  attachments?: Array<{
    type: 'image' | 'file';
    url: string;
    name: string;
  }>;
  metadata?: {
    sources?: string[];
    confidence?: number;
    processingTime?: number;
  };
}

interface ChatInterfaceProps {
  systemPrompt: string;
  suggestions: Array<{
    text: string;
    icon: any;
  }>;
}

interface Preferences {
  responseStyle: 'concise' | 'detailed';
  includeExamples: boolean;
  useMarkdown: boolean;
  autoScroll: boolean;
  showTimestamps: boolean;
  enableSpeech: boolean;
}

export default function ChatInterface({ systemPrompt, suggestions }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [showPreferences, setShowPreferences] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(null);
  const [preferences, setPreferences] = useState<Preferences>({
    responseStyle: 'concise',
    includeExamples: true,
    useMarkdown: true,
    autoScroll: true,
    showTimestamps: true,
    enableSpeech: true
  });

  const handleKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter') {
      if (e.shiftKey) {
        // Allow new line with Shift+Enter
        return;
      }
      // Prevent default to avoid unwanted newline
      e.preventDefault();
      // Submit form if not empty and not loading
      if (input.trim() && !isLoading) {
        handleSubmit(e);
      }
    }
  };


  const toggleRecording = () => {
    if (!recognition || !preferences.enableSpeech) return;
    
    if (isRecording) {
      recognition.stop();
    } else {
      try {
        recognition.start();
        setIsRecording(true);
      } catch (error) {
        console.error('Speech recognition error:', error);
        setIsRecording(false);
      }
    }
  };
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [selectedMessages, setSelectedMessages] = useState<string[]>([]);
  const [showExport, setShowExport] = useState(false);
  const [messageHistory, setMessageHistory] = useState<Message[][]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);

  useEffect(() => {
    if (window.SpeechRecognition || window.webkitSpeechRecognition) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'fa-IR';

      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        setInput(transcript);
        setIsRecording(false);
      };

      recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setIsRecording(false);
      };

      recognition.onend = () => {
        setIsRecording(false);
      };

      setRecognition(recognition);
    }
  }, []);

  const scrollToBottom = () => {
    if (preferences.autoScroll) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleUndo = () => {
    if (historyIndex < messageHistory.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setMessages(messageHistory[historyIndex + 1]);
    }
  };

  const handleRedo = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setMessages(messageHistory[historyIndex - 1]);
    }
  };

  const handleClearChat = () => {
    setMessageHistory([...messageHistory, messages]);
    setHistoryIndex(-1);
    setMessages([]);
    setShowSuggestions(true);
  };

  const handleCopyMessages = () => {
    const selectedContent = messages
      .filter(m => selectedMessages.includes(m.id || ''))
      .map(m => `${m.role === 'user' ? 'شما' : 'هوشِکس'}: ${m.content}`)
      .join('\n\n');
    navigator.clipboard.writeText(selectedContent);
  };

  const handleExportChat = (format: 'text' | 'json' | 'html') => {
    const selectedMsgs = messages.filter(m => selectedMessages.includes(m.id || ''));
    let content = '';
    
    switch (format) {
      case 'text':
        content = selectedMsgs
          .map(m => `${m.role === 'user' ? 'شما' : 'هوشِکس'}: ${m.content}`)
          .join('\n\n');
        break;
      case 'json':
        content = JSON.stringify(selectedMsgs, null, 2);
        break;
      case 'html':
        content = `
          <html dir="rtl">
            <head>
              <meta charset="UTF-8">
              <style>
                body { font-family: system-ui; line-height: 1.5; }
                .message { margin: 1em 0; padding: 1em; border-radius: 0.5em; }
                .user { background: #f3f4f6; }
                .assistant { background: #e5e7eb; }
              </style>
            </head>
            <body>
              ${selectedMsgs.map(m => `
                <div class="message ${m.role}">
                  <strong>${m.role === 'user' ? 'شما' : 'هوشِکس'}</strong>
                  <p>${m.content}</p>
                  ${m.metadata?.sources ? `
                    <div class="sources">
                      <small>منابع:</small>
                      <ul>
                        ${m.metadata.sources.map(s => `<li>${s}</li>`).join('')}
                      </ul>
                    </div>
                  ` : ''}
                </div>
              `).join('')}
            </body>
          </html>
        `;
        break;
    }

    const blob = new Blob([content], { type: format === 'html' ? 'text/html' : 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `chat-export.${format}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleBookmarkMessage = (messageId: string) => {
    setMessages(messages.map(m => 
      m.id === messageId ? { ...m, isBookmarked: !m.isBookmarked } : m
    ));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const trimmedInput = input.trim();
      if (!trimmedInput || isLoading) {
        return;
      }

      const userMessage = { 
        role: 'user' as const, 
        content: trimmedInput,
        id: Math.random().toString(36).substr(2, 9),
        timestamp: Date.now()
      };
      
      setMessages(prev => [...prev, userMessage]);
      setMessageHistory([...messageHistory, messages]);
      setHistoryIndex(-1);
      setInput('');
      setIsLoading(true);

      const completion = await openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: systemPrompt + `\n\nدستورالعمل‌های پاسخ‌دهی:
${preferences.responseStyle === 'concise' ? `
1. پاسخ‌ها باید در یک یا دو پاراگراف کوتاه باشند
2. فقط مهمترین نکته را بیان کنید
3. از کلی‌گویی و توضیحات غیرضروری خودداری کنید
4. حداکثر 100 کلمه پاسخ دهید` : `
1. پاسخ‌ها باید کامل و جامع باشند
2. جزئیات مهم را توضیح دهید
3. از مفاهیم پیشرفته‌تر استفاده کنید
4. نکات تکمیلی را هم ذکر کنید`}

${preferences.includeExamples ? `
نحوه ارائه مثال‌ها:
1. فقط یک مثال کوتاه و کاربردی ارائه دهید
2. مثال باید مستقیماً مرتبط با سوال باشد
3. مثال را در یک خط توضیح دهید` : `
- از ارائه مثال خودداری کنید
- فقط در صورت درخواست مستقیم کاربر مثال بزنید`}`
          },
          ...messages,
          userMessage
        ]
      });

      const content = completion.choices[0]?.message?.content;
      if (!content) {
        throw new Error('پاسخی از سرور دریافت نشد');
      }

      const assistantMessage: Message = {
        role: 'assistant',
        content: completion.choices[0].message.content,
        id: Math.random().toString(36).substr(2, 9),
        timestamp: Date.now(),
        metadata: {
          processingTime: Date.now() - userMessage.timestamp,
          confidence: Math.random() * 20 + 80 // Simulated confidence score
        }
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Error:', error);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'متاسفانه خطایی رخ داد. لطفاً دوباره تلاش کنید.',
        id: Math.random().toString(36).substr(2, 9),
        timestamp: Date.now()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[600px] bg-white rounded-2xl shadow-sm">
      <div className="p-4 border-b">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-medium">تنظیمات گفتگو</h2>
            <p className="text-sm text-gray-500">شخصی‌سازی نحوه پاسخ‌دهی</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowExport(!showExport)}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              title="خروجی گرفتن"
            >
              <Download className="w-5 h-5 text-gray-500" />
            </button>
            <button
              onClick={() => setShowPreferences(!showPreferences)}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              title="تنظیمات"
            >
              <Settings2 className="w-5 h-5 text-gray-500" />
            </button>
          </div>
        </div>
        {showPreferences && (
          <div className="mt-4 p-4 bg-gray-50 rounded-lg space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">سبک پاسخ‌دهی</label>
              <div className="flex gap-2">
                <button
                  onClick={() => setPreferences(p => ({ ...p, responseStyle: 'concise' }))}
                  className={`px-3 py-1 rounded ${
                    preferences.responseStyle === 'concise'
                      ? 'bg-[#a63439] text-white'
                      : 'bg-gray-200'
                  }`}
                >
                  مختصر
                </button>
                <button
                  onClick={() => setPreferences(p => ({ ...p, responseStyle: 'detailed' }))}
                  className={`px-3 py-1 rounded ${
                    preferences.responseStyle === 'detailed'
                      ? 'bg-[#a63439] text-white'
                      : 'bg-gray-200'
                  }`}
                >
                  کامل
                </button>
              </div>
            </div>
            <div className="space-y-2">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={preferences.includeExamples}
                  onChange={(e) => setPreferences(p => ({ ...p, includeExamples: e.target.checked }))}
                  className="rounded text-[#a63439]"
                />
                <span className="text-sm">شامل مثال‌های کاربردی</span>
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={preferences.useMarkdown}
                  onChange={(e) => setPreferences(p => ({ ...p, useMarkdown: e.target.checked }))}
                  className="rounded text-[#a63439]"
                />
                <span className="text-sm">پشتیبانی از مارک‌داون</span>
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={preferences.autoScroll}
                  onChange={(e) => setPreferences(p => ({ ...p, autoScroll: e.target.checked }))}
                  className="rounded text-[#a63439]"
                />
                <span className="text-sm">اسکرول خودکار</span>
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={preferences.showTimestamps}
                  onChange={(e) => setPreferences(p => ({ ...p, showTimestamps: e.target.checked }))}
                  className="rounded text-[#a63439]"
                />
                <span className="text-sm">نمایش زمان پیام‌ها</span>
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={preferences.enableSpeech}
                  onChange={(e) => setPreferences(p => ({ ...p, enableSpeech: e.target.checked }))}
                  className="rounded text-[#a63439]"
                />
                <span className="text-sm">فعال‌سازی ورودی صوتی</span>
              </label>
            </div>
          </div>
        )}
        {showExport && selectedMessages.length > 0 && (
          <div className="mt-4 p-4 bg-gray-50 rounded-lg space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium">خروجی گرفتن از گفتگو</h3>
              <span className="text-xs text-gray-500">{selectedMessages.length} پیام انتخاب شده</span>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => handleExportChat('text')}
                className="flex-1 bg-gray-200 text-gray-700 px-3 py-1 rounded hover:bg-gray-300 transition-colors text-sm"
              >
                متن ساده
              </button>
              <button
                onClick={() => handleExportChat('html')}
                className="flex-1 bg-gray-200 text-gray-700 px-3 py-1 rounded hover:bg-gray-300 transition-colors text-sm"
              >
                HTML
              </button>
              <button
                onClick={() => handleExportChat('json')}
                className="flex-1 bg-gray-200 text-gray-700 px-3 py-1 rounded hover:bg-gray-300 transition-colors text-sm"
              >
                JSON
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="flex-1 overflow-y-auto space-y-4 mb-4 p-4">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-500 space-y-8">
            <div className="text-center">
              <Brain className="w-12 h-12 mx-auto mb-4 text-[#a63439] animate-bounce" />
              <p>سوال خود را بپرسید تا به شما کمک کنم</p>
            </div>
            {showSuggestions && (
              <div className="space-y-2 w-full max-w-md">
                <p className="text-center mb-4 flex items-center justify-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#a63439]" />
                  پیشنهادهای شروع مکالمه
                </p>
                {suggestions.map((suggestion, index) => {
                  const Icon = suggestion.icon;
                  return (
                    <button
                      key={index}
                      onClick={() => {
                        setInput(suggestion.text);
                        setShowSuggestions(false);
                      }}
                      className="w-full p-3 bg-white border border-gray-200 rounded-xl flex items-center gap-3 hover:bg-gray-50 hover:border-[#a63439] transition-all duration-300 hover:scale-102 group"
                    >
                      <Icon className="w-5 h-5 text-gray-400 group-hover:text-[#a63439]" />
                      <span className="text-gray-600 text-sm group-hover:text-[#a63439]">
                        {suggestion.text}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        ) : (
          messages.map((message, index) => (
            <div
              key={message.id || index}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'} animate-fadeIn`}
            >
              <div
                className={`relative max-w-[80%] rounded-2xl p-3 transition-all duration-300 hover:shadow-md group ${
                  message.role === 'user'
                    ? 'bg-[#a63439] text-white'
                    : 'bg-gray-100 text-gray-800'
                }`}
              >
                <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                  <input
                    type="checkbox"
                    checked={selectedMessages.includes(message.id || '')}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedMessages([...selectedMessages, message.id || '']);
                      } else {
                        setSelectedMessages(selectedMessages.filter(id => id !== message.id));
                      }
                    }}
                    className="rounded text-[#a63439]"
                  />
                </div>
                <div className="absolute top-2 left-2 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 z-10">
                  <button
                    onClick={() => handleBookmarkMessage(message.id || '')}
                    className="p-1.5 rounded-full hover:bg-gray-200/20 transition-colors"
                    title={message.isBookmarked ? 'حذف نشان' : 'نشان کردن'}
                  >
                    {message.isBookmarked ? (
                      <BookmarkCheck className="w-4 h-4" />
                    ) : (
                      <Bookmark className="w-4 h-4" />
                    )}
                  </button>
                  <button
                    onClick={() => navigator.clipboard.writeText(message.content)}
                    className="p-1.5 rounded-full hover:bg-gray-200/20 transition-colors"
                    title="کپی متن"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                </div>
                <div className="pt-6 pb-2">
                <p className="whitespace-pre-wrap">{message.content}</p>
                </div>
                {message.metadata && (
                  <div className="mt-2 pt-2 border-t border-gray-200/20 text-xs">
                    <div className="flex items-center gap-4 text-gray-500">
                      {preferences.showTimestamps && message.timestamp && (
                        <span>{new Date(message.timestamp).toLocaleTimeString('fa-IR')}</span>
                      )}
                      {message.metadata.processingTime && (
                        <span>زمان پردازش: {(message.metadata.processingTime / 1000).toFixed(1)} ثانیه</span>
                      )}
                      {message.metadata.confidence && (
                        <span>اطمینان: {message.metadata.confidence.toFixed(1)}%</span>
                      )}
                    </div>
                    {message.metadata.sources && message.metadata.sources.length > 0 && (
                      <div className="mt-2">
                        <p className="font-medium mb-1">منابع:</p>
                        <ul className="space-y-1">
                          {message.metadata.sources.map((source, i) => (
                            <li key={i}>{source}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))
        )}
        {isLoading && (
          <div className="flex items-center gap-3 text-gray-500 animate-pulse">
            <Brain className="w-5 h-5 text-[#a63439]" />
            <p>هوشِکس در حال فکر کردن...</p>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 border-t">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <button
              onClick={handleUndo}
              disabled={historyIndex >= messageHistory.length - 1}
              className="p-2 text-gray-500 hover:bg-gray-100 rounded-full transition-colors disabled:opacity-50"
              title="بازگشت"
            >
              <Undo className="w-4 h-4" />
            </button>
            <button
              onClick={handleClearChat}
              className="p-2 text-gray-500 hover:bg-gray-100 rounded-full transition-colors"
              title="پاک کردن گفتگو"
            >
              <Eraser className="w-4 h-4" />
            </button>
          </div>
          <div className="flex items-center gap-2">
            {selectedMessages.length > 0 && (
              <>
                <button
                  onClick={handleCopyMessages}
                  className="p-2 text-gray-500 hover:bg-gray-100 rounded-full transition-colors"
                  title="کپی پیام‌های انتخاب شده"
                >
                  <Copy className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setShowExport(true)}
                  className="p-2 text-gray-500 hover:bg-gray-100 rounded-full transition-colors"
                  title="خروجی گرفتن"
                >
                  <Share2 className="w-4 h-4" />
                </button>
              </>
            )}
          </div>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={toggleRecording}
            className={`p-2 rounded-xl transition-all duration-300 ${
              isRecording 
                ? 'bg-red-500 text-white animate-pulse' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
            title={recognition ? 'برای ضبط صدا کلیک کنید' : 'مرورگر شما از ضبط صدا پشتیبانی نمی‌کند'}
            disabled={!recognition}
          >
            {isRecording ? (
              <MicOff className="w-6 h-6" />
            ) : (
              <Mic className="w-6 h-6" />
            )}
          </button>
          <input
            type="text"
            value={input}
            onKeyPress={handleKeyPress}
            onChange={(e) => setInput(e.target.value)}
            placeholder={isLoading ? "در حال پردازش..." : "پیام خود را بنویسید..."}
            className="flex-1 bg-gray-100 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#a63439] transition-all"
            disabled={isLoading}
          />
          <button
            type="submit"
            onClick={handleSubmit}
            disabled={isLoading || !input.trim()}
            className="bg-[#a63439] text-white p-2 rounded-xl hover:bg-[#8a2a2e] transition-all disabled:opacity-50 hover:scale-105"
          >
            {isLoading ? (
              <Loader2 className="w-6 h-6 animate-spin" />
            ) : (
              <Send className="w-6 h-6" />
            )}
          </button>
        </div>
      </div>
    </div>
  );
}