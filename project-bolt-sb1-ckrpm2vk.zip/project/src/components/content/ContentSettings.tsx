import React from 'react';
import { Hash, FileText, Lock, Crown, Star } from 'lucide-react';
import { Hash, FileText, Lock, Crown, Star } from 'lucide-react';
import { Link } from 'react-router-dom';

export const toneOptions = [
  { id: 'formal', name: 'رسمی' },
  { id: 'casual', name: 'صمیمی' },
  { id: 'humorous', name: 'طنزآمیز' },
  { id: 'serious', name: 'جدی' }
];

export const audienceOptions = [
  { id: 'general', name: 'عمومی' },
  { id: 'professional', name: 'متخصصان' },
  { id: 'academic', name: 'دانشگاهی' },
  { id: 'business', name: 'کسب و کار' }
];

interface ContentSettingsProps {
  topic: string;
  targetKeyword: string;
  minWordCount: number;
  maxWordCount: number;
  selectedTone: string;
  selectedAudience: string;
  onTopicChange: (topic: string) => void;
  onKeywordChange: (keyword: string) => void;
  onMinWordCountChange: (count: number) => void;
  onMaxWordCountChange: (count: number) => void;
  contentLength: 'short' | 'medium' | 'long';
  onContentLengthChange: (length: 'short' | 'medium' | 'long') => void;
  onToneSelect: (tone: string) => void;
  onAudienceSelect: (audience: string) => void;
}

export default function ContentSettings({
  topic,
  targetKeyword,
  minWordCount,
  maxWordCount,
  selectedTone,
  selectedAudience,
  onTopicChange,
  onKeywordChange,
  onMinWordCountChange,
  onMaxWordCountChange,
  contentLength,
  onContentLengthChange,
  onToneSelect,
  onAudienceSelect
}: ContentSettingsProps) {
  const contentLengthOptions = [
    {
      id: 'short',
      name: 'کوتاه',
      description: 'حدود 500 تا 800 کلمه',
      icon: FileText
    },
    {
      id: 'medium',
      name: 'متوسط',
      description: 'حدود 1000 تا 1500 کلمه',
      icon: FileText
    },
    {
      id: 'long',
      name: 'بلند',
      description: 'حدود 2000 تا 3000 کلمه',
      icon: FileText
    }
  ];

  return (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium mb-2">طول محتوا</label>
        <p className="text-sm text-gray-500 mb-3">
          توجه: طول نهایی محتوا ممکن است برای حفظ کیفیت و انسجام متن، با مقادیر تقریبی زیر متفاوت باشد.
        </p>
        <div className="grid grid-cols-3 gap-4">
          {contentLengthOptions.map(option => (
            <button
              key={option.id}
              onClick={() => onContentLengthChange(option.id as 'short' | 'medium' | 'long')}
              className={`p-4 rounded-xl border transition-all ${
                contentLength === option.id
                  ? 'border-[#a63439] bg-[#a63439]/5'
                  : 'border-gray-200 hover:border-[#a63439] hover:bg-gray-50'
              }`}
            >
              <option.icon className={`w-6 h-6 mb-2 ${
                contentLength === option.id ? 'text-[#a63439]' : 'text-gray-400'
              }`} />
              <h3 className="text-sm font-medium mb-1">{option.name}</h3>
              <p className="text-xs text-gray-500">{option.description}</p>
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">موضوع محتوا</label>
        <textarea
          value={topic}
          onChange={(e) => onTopicChange(e.target.value)}
          className="w-full h-24 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 resize-none"
          placeholder="موضوع اصلی محتوا را وارد کنید..."
        />
      </div>

      <div className="grid grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium mb-2">کلمه کلیدی هدف</label>
          <div className="relative">
            <Hash className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={targetKeyword}
              onChange={(e) => onKeywordChange(e.target.value)}
              className="w-full bg-gray-50 border border-gray-200 rounded-lg px-9 py-2"
              placeholder="کلمه کلیدی اصلی برای سئو"
            />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">محدوده تعداد کلمات</label>
          <div className="flex items-center gap-2">
            <input
              type="number"
              min="500"
              max="5000"
              value={minWordCount}
              onChange={(e) => {
                const value = Math.max(500, Math.min(5000, parseInt(e.target.value) || 500));
                onMinWordCountChange(value);
              }}
              className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2"
              placeholder="حداقل"
            />
            <span className="text-gray-400">تا</span>
            <input
              type="number"
              min={minWordCount}
              max="5000"
              value={maxWordCount}
              onChange={(e) => {
                const value = Math.max(minWordCount, Math.min(5000, parseInt(e.target.value) || minWordCount));
                onMaxWordCountChange(value);
              }}
              className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2"
            />
          </div>
        </div>
      </div>

      <div className="relative">
        {/* Pro Feature Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-gray-100/80 to-gray-50/80 backdrop-blur-[1px] rounded-lg flex items-center justify-center">
          <div className="text-center">
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500/10 to-amber-600/10 px-3 py-1.5 rounded-full mb-3">
              <Lock className="w-4 h-4 text-amber-600" />
              <span className="text-sm text-amber-700">ویژه نسخه پرو</span>
            </div>
            <p className="text-sm text-gray-600 mb-3 px-4">
              برای دسترسی به تنظیمات پیشرفته لحن و مخاطب و افزایش کیفیت چشمگیر مقاله سئو شده، از نسخه پرو استفاده کنید
            </p>
            <Link
              to="/content-pro"
              className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 text-white px-4 py-2 rounded-lg text-sm hover:opacity-90 transition-all group shadow-[0_0_15px_rgba(245,158,11,0.3)] hover:shadow-[0_0_25px_rgba(245,158,11,0.5)]"
            >
              <Crown className="w-4 h-4" />
              <span>ارتقا به نسخه پرو</span>
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-6 opacity-50 pointer-events-none">
          <div>
            <label className="block text-sm font-medium mb-2 flex items-center gap-2">
              <span>لحن محتوا</span>
              <Lock className="w-4 h-4 text-amber-500" />
              <Lock className="w-4 h-4 text-amber-500" />
                  className="p-2 rounded-lg text-sm bg-gray-100/50 text-gray-500"
                  disabled
                >
                  {tone.name}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2 flex items-center gap-2">
              <span>مخاطب هدف</span>
              <Lock className="w-4 h-4 text-amber-500" />
              <Lock className="w-4 h-4 text-amber-500" />
                  className="p-2 rounded-lg text-sm bg-gray-100/50 text-gray-500"
                  disabled
                >
                  {audience.name}
                </button>
              ))}
            </div>
          </div>
        </div>
        
        {/* Pro Feature Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-gray-100/80 to-gray-50/80 backdrop-blur-[1px] rounded-lg flex items-center justify-center">
          <div className="text-center">
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500/10 to-amber-600/10 px-3 py-1.5 rounded-full mb-3">
              <Lock className="w-4 h-4 text-amber-600" />
              <span className="text-sm text-amber-700">ویژه نسخه پرو</span>
            </div>
            <p className="text-sm text-gray-600 mb-3 px-4">
              برای دسترسی به تنظیمات پیشرفته لحن و مخاطب و افزایش کیفیت چشمگیر مقاله سئو شده، از نسخه پرو استفاده کنید
            </p>
            <Link
              to="/content-pro"
              className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 text-white px-4 py-2 rounded-lg text-sm hover:opacity-90 transition-all group shadow-[0_0_15px_rgba(245,158,11,0.3)] hover:shadow-[0_0_25px_rgba(245,158,11,0.5)]"
            >
              <Crown className="w-4 h-4" />
              <span>ارتقا به نسخه پرو</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}