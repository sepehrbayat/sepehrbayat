import React from 'react';
import { Target, Sparkles, Lightbulb } from 'lucide-react';

export interface ContentStyle {
  id: string;
  name: string;
  description: string;
  icon: any;
  prompt: string;
}

export const contentStyles: ContentStyle[] = [
  {
    id: 'professional',
    name: 'حرفه‌ای و رسمی',
    description: 'مناسب برای مقالات تخصصی و محتوای کسب و کار',
    icon: Target,
    prompt: 'لحن رسمی و حرفه‌ای، استفاده از اصطلاحات تخصصی، ساختار منظم و منطقی'
  },
  {
    id: 'creative',
    name: 'خلاقانه و جذاب',
    description: 'مناسب برای محتوای سرگرم‌کننده و تعاملی',
    icon: Sparkles,
    prompt: 'لحن صمیمی و پویا، استفاده از تشبیه و استعاره، داستان‌سرایی جذاب'
  },
  {
    id: 'educational',
    name: 'آموزشی و توضیحی',
    description: 'مناسب برای آموزش مفاهیم و راهنماها',
    icon: Lightbulb,
    prompt: 'توضیحات گام به گام، مثال‌های کاربردی، زبان ساده و قابل فهم'
  }
];

interface ContentStylesProps {
  selectedStyle: string;
  onStyleSelect: (style: string) => void;
}

export default function ContentStyles({ selectedStyle, onStyleSelect }: ContentStylesProps) {
  return (
    <div>
      <label className="block text-sm font-medium mb-2">سبک محتوا</label>
      <div className="grid grid-cols-3 gap-4">
        {contentStyles.map(style => (
          <button
            key={style.id}
            onClick={() => onStyleSelect(style.id)}
            className={`p-4 rounded-xl border transition-all ${
              selectedStyle === style.id
                ? 'border-[#a63439] bg-[#a63439]/5'
                : 'border-gray-200 hover:border-[#a63439] hover:bg-gray-50'
            }`}
          >
            <style.icon className={`w-6 h-6 mx-auto mb-2 ${
              selectedStyle === style.id ? 'text-[#a63439]' : 'text-gray-400'
            }`} />
            <h3 className="text-sm font-medium mb-1">{style.name}</h3>
            <p className="text-xs text-gray-500">{style.description}</p>
          </button>
        ))}
      </div>
    </div>
  );
}