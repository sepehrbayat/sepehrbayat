import React from 'react';

interface TopicInputProps {
  topic: string;
  onChange: (topic: string) => void;
}

export default function TopicInput({ topic, onChange }: TopicInputProps) {
  return (
    <div>
      <label className="block text-sm font-medium mb-2">موضوع محتوا</label>
      <textarea
        value={topic}
        onChange={(e) => onChange(e.target.value)}
        className="w-full h-32 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 resize-none"
        placeholder="موضوع مورد نظر خود را وارد کنید..."
      />
    </div>
  );
}