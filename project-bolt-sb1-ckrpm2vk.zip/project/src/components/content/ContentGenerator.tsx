import React from 'react';
import { PenTool } from 'lucide-react';
import { trackToolUsage } from '../../lib/activity/tracking';

interface ContentGeneratorProps {
  isGenerating: boolean;
  disabled: boolean;
  onGenerate: () => void;
}

export default function ContentGenerator({ isGenerating, disabled, onGenerate }: ContentGeneratorProps) {
  const handleGenerate = async () => {
    try {
      // Track content generation start
      await trackToolUsage(
        'content-generator',
        'تولید محتوا',
        'شروع تولید محتوا',
        {
          topic,
          keywords,
          style,
          tone,
          audience
        }
      );

      const content = await generateContent({
        topic,
        keywords,
        style,
        tone,
        audience
      });

      // Track successful generation
      await trackToolUsage(
        'content-generator',
        'تولید موفق محتوا',
        'محتوا با موفقیت تولید شد',
        {
          topic,
          content,
          wordCount: content.length
        }
      );

      onGenerate(content);
    } catch (error) {
      // Track error
      await trackToolUsage(
        'content-generator',
        'خطا در تولید محتوا',
        error instanceof Error ? error.message : 'خطای ناشناخته',
        { error: error }
      );
      throw error;
    }
  };

  return (
    <button
      onClick={onGenerate}
      disabled={isGenerating || disabled}
      className={`w-full bg-[#a63439] text-white p-4 rounded-lg flex items-center justify-center gap-2 hover:bg-[#8a2a2e] transition-all ${
        isGenerating ? 'animate-pulse' : ''
      } disabled:opacity-50 disabled:cursor-not-allowed`}
    >
      <PenTool className="w-5 h-5" />
      {isGenerating ? 'در حال تولید محتوا...' : 'تولید محتوا'}
    </button>
  );
}