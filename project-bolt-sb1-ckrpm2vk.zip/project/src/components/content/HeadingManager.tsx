import React, { useState, useRef, useEffect } from 'react';
import { ListOrdered, Sparkles, Loader2, Brain, ChevronRight, Layers, X } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { isEnglishUI } from '../../lib/i18n/languageManager';
import { openaiPro } from '../../lib/openai';
import { LANGUAGE_CHANGE_EVENT, type LanguageChangeEvent } from '../../lib/i18n/languageManager';
import { suggestHeadings } from '../../lib/content/suggestions';

interface Heading {
  title: string;
  level: number;
  id: string;
  parentId?: string;
  children?: Heading[];
}

interface HeadingManagerProps {
  headings: Heading[];
  onAddHeading: (heading: Heading) => void;
  onRemoveHeading: (headingId: string) => void;
  disabled?: boolean;
  topic: string;
}

interface HeadingGroup {
  heading: Heading;
  children: Heading[];
}
export default function HeadingManager({
  headings,
  onAddHeading,
  onRemoveHeading,
  disabled,
  topic
}: HeadingManagerProps) {
  const { t } = useTranslation();
  const isEnglish = isEnglishUI();
  const [newHeading, setNewHeading] = useState('');
  const [selectedLevel, setSelectedLevel] = useState(2);
  const [isSuggestingHeadings, setIsSuggestingHeadings] = useState(false);
  const [suggestedHeadings, setSuggestedHeadings] = useState<Heading[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [loadingPhase, setLoadingPhase] = useState<{
    title: string;
    tips: string[];
    icon: any;
    color: string;
  } | null>(null);
  const [selectedHeading, setSelectedHeading] = useState<string | null>(null);
  const headingsContainerRef = useRef<HTMLDivElement>(null);
  const [tipIndex, setTipIndex] = useState(0);
  const [showSparkle, setShowSparkle] = useState(false);

  // Loading phases configuration
  const loadingPhases = {
    analysis: {
      title: 'در حال تحلیل ساختار...',
      tips: [
        'تحلیل موضوع و محتوای اصلی...',
        'شناسایی مفاهیم کلیدی...',
        'بررسی ارتباطات موضوعی...',
        'تحلیل ساختار محتوای مشابه...',
        'شناسایی الگوهای موفق...'
      ],
      icon: Brain,
      color: 'amber'
    },
    generation: {
      title: 'در حال تولید سرتیترها...',
      tips: [
        'ایجاد ساختار منطقی و منسجم...',
        'بهینه‌سازی برای موتورهای جستجو...',
        'اطمینان از پوشش کامل موضوع...',
        'بررسی توازن و تناسب سرتیترها...',
        'نهایی‌سازی ساختار پیشنهادی...'
      ],
      icon: Sparkles,
      color: 'amber'
    }
  };

  // Listen for language changes
  useEffect(() => {
    const handleLanguageChange = (event: LanguageChangeEvent) => {
      // Clear suggestions when language changes to prevent mixed language content
      setShowSuggestions(false);
      setSuggestedHeadings([]);
    };

    window.addEventListener(LANGUAGE_CHANGE_EVENT, handleLanguageChange as EventListener);
    return () => {
      window.removeEventListener(LANGUAGE_CHANGE_EVENT, handleLanguageChange as EventListener);
    };
  }, []);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (headingRef.current && !headingRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);
  
  // Group headings hierarchically
  const groupedHeadings = React.useMemo(() => {
    const groups: HeadingGroup[] = [];
    const h2Headings = headings.filter(h => h.level === 2);
    
    h2Headings.forEach(h2 => {
      const children = headings.filter(h => h.parentId === h2.id);
      groups.push({ heading: h2, children });
    });
    
    return groups;
  }, [headings]);

  const handleAddHeading = () => {
    if (newHeading.trim()) {
      onAddHeading({
        title: newHeading.trim(),
        level: selectedLevel,
        id: Math.random().toString(36).substr(2, 9),
        parentId: selectedHeading
      });
      setNewHeading('');
    }
  };

  // Loading animation effects
  useEffect(() => {
    if (isSuggestingHeadings) {
      // Rotate through tips
      const tipInterval = setInterval(() => {
        setTipIndex(prev => {
          const currentPhase = loadingPhase;
          if (!currentPhase) return 0;
          return (prev + 1) % currentPhase.tips.length;
        });
      }, 3000);

      // Show random sparkles
      const sparkleInterval = setInterval(() => {
        setShowSparkle(true);
        setTimeout(() => setShowSparkle(false), 500);
      }, 2000);

      return () => {
        clearInterval(tipInterval);
        clearInterval(sparkleInterval);
      };
    }
  }, [isSuggestingHeadings, loadingPhase]);

  const handleSuggestHeadings = async (parentId?: string) => {
    try {
      if (!topic?.trim()) {
        throw new Error(t('dashboard.tools.content.headings.error.noTopic'));
      }

      setIsSuggestingHeadings(true);
      setError(null);
      setSuggestedHeadings([]);
      setShowSuggestions(false);
      setLoadingPhase(loadingPhases.analysis);
      setLoadingProgress(25);

      const parentHeading = parentId ? headings.find(h => h.id === parentId) : null;
      const level = parentHeading ? parentHeading.level + 1 : 2;

      if (level > 4) {
        throw new Error(t('dashboard.tools.content.headings.error.maxLevel'));
      }

      const headingContext = parentHeading ? `${parentHeading.title} > ` : '';

      setLoadingPhase(loadingPhases.generation);
      setLoadingProgress(50);

      const suggestions = await suggestHeadings(
        parentId ? headings.find(h => h.id === parentId)?.title || '' : topic,
        parentId,
        parentId ? headings.find(h => h.id === parentId)?.level + 1 : 2,
        true, // Enable Pro features for ContentPro
        openaiPro // Pass the imported openaiPro client
      );
      
      setLoadingProgress(75);

      // Validate suggestions before showing
      if (!Array.isArray(suggestions) || suggestions.length === 0) {
        throw new Error(t('dashboard.tools.content.headings.error.noSuggestions'));
      }

      // Filter out any existing headings
      const filteredSuggestions = suggestions.filter(
        suggestion => !headings.some(h => h.title === suggestion.title)
      );

      if (filteredSuggestions.length === 0) {
        throw new Error('تمام پیشنهادات قبلاً اضافه شده‌اند');
      }

      setLoadingProgress(100);

      setSuggestedHeadings(suggestions);
      setShowSuggestions(true);

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : t('dashboard.tools.content.headings.error.general');
      console.error('Error suggesting headings:', { error, topic, parentId });
      setError(errorMessage);
      setSuggestedHeadings([]);
      setShowSuggestions(false);
    } finally {
      setIsSuggestingHeadings(false);
      setLoadingPhase(null);
      setLoadingProgress(0);
    }
  };

  return (
    <div ref={headingRef} className="space-y-4">
      <div className="flex gap-2 mb-3">
        <div className="relative flex-1 flex gap-2">
          <ListOrdered className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            value={newHeading}
            onChange={(e) => setNewHeading(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleAddHeading()}
            className="w-full bg-gray-50 border border-gray-200 rounded-lg px-9 py-2" 
            dir={isEnglish ? 'ltr' : 'rtl'}
            className="w-full bg-gray-50 border border-gray-200 rounded-lg px-9 py-2" 
            dir={isEnglish ? 'ltr' : 'rtl'}
            lang={isEnglish ? 'en' : 'fa'}
            placeholder="سرتیتر را وارد کنید..."
          />
          <select
            value={selectedLevel}
            onChange={(e) => setSelectedLevel(parseInt(e.target.value))}
            className="bg-gray-50 border border-gray-200 rounded-lg px-3 py-2"
          >
            <option value={2}>H2</option>
            <option value={3}>H3</option>
            <option value={4}>H4</option>
          </select>
          <button
            onClick={handleAddHeading}
            disabled={!newHeading.trim()}
            className="bg-[#a63439] text-white px-4 py-2 rounded-lg hover:bg-[#8a2a2e] transition-colors disabled:opacity-50"
          >
            <span>افزودن</span>
          </button>
        </div>
      </div>

      <button
        onClick={() => handleSuggestHeadings()}
        disabled={isSuggestingHeadings || disabled}
        className="w-full bg-gray-100 text-gray-700 px-3 py-2 rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
      >
        {isSuggestingHeadings ? (
          <Loader2 className="w-4 h-4 animate-spin" />
        ) : (
          <Sparkles className="w-4 h-4 text-[#a63439]" />
        )}
        <span>پیشنهاد سرتیترهای هوشمند</span>
      </button>

      {showSuggestions && suggestedHeadings.length > 0 && (
        <div className="mt-4 bg-gradient-to-br from-[#a63439]/5 to-white border border-[#a63439]/10 rounded-xl overflow-hidden shadow-lg">
          <div className="bg-[#a63439]/5 px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Brain className="w-4 h-4 text-[#a63439]" />
              <span className="font-medium">
                {selectedHeading 
                  ? `پیشنهاد زیرعنوان‌های H${selectedLevel}`
                  : 'پیشنهادهای هوشمند'}
              </span>
            </div>
            <button
              onClick={() => setShowSuggestions(false)}
              className="text-gray-500 hover:text-[#a63439] p-1 hover:bg-[#a63439]/10 rounded-full transition-all"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="p-4 space-y-3">
            {suggestedHeadings.map((heading) => (
              <button
                key={heading.id}
                onClick={() => {
                  onAddHeading(heading);
                  setSuggestedHeadings(prev => prev.filter(h => h.id !== heading.id));
                  if (suggestedHeadings.length === 1) {
                    setShowSuggestions(false);
                  }
                }}
                className="w-full bg-white rounded-lg p-3 hover:shadow-md transition-all group relative overflow-hidden text-right border border-transparent hover:border-[#a63439]/20"
              >
                <div className="absolute inset-y-0 right-0 w-1 bg-[#a63439]/10 group-hover:bg-[#a63439] transition-colors rounded-r-lg" />
                <div className="relative flex items-center gap-3 group-hover:translate-x-2 transition-transform">
                  <div className="w-8 h-8 rounded-lg bg-[#a63439]/10 flex items-center justify-center flex-shrink-0">
                    <Layers className="w-4 h-4 text-[#a63439]" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-medium text-[#a63439] bg-[#a63439]/10 px-2 py-0.5 rounded">
                        H{heading.level}
                      </span>
                      <span className="font-medium">{heading.title}</span>
                    </div>
                    <p className="text-xs text-gray-500">برای افزودن کلیک کنید</p>
                  </div>
                  <div className="absolute left-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <ChevronRight className="w-5 h-5 text-[#a63439]" />
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
      
      {isSuggestingHeadings && (
        <div className="mt-4 bg-white border border-gray-200 rounded-lg sm:rounded-xl p-4 sm:p-6 text-center space-y-4">
          <div className="relative w-[120px] h-[120px] mx-auto">
            <div className={`absolute inset-0 rounded-full bg-${loadingPhase?.color}-500/5 flex items-center justify-center`}>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className={`w-[80px] h-[80px] sm:w-[100px] sm:h-[100px] rounded-full border-4 border-${loadingPhase?.color}-500 border-t-transparent animate-spin`} />
              </div>
              <div className="absolute inset-0 flex items-center justify-center">
                {loadingPhase?.icon && (
                  <loadingPhase.icon className={`w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 text-${loadingPhase.color}-500`} />
                )}
                {showSparkle && (
                  <div className="absolute inset-0 flex items-center justify-center animate-ping">
                    <Sparkles className={`w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6 text-${loadingPhase?.color}-400`} />
                  </div>
                )}
              </div>
            </div>
          </div>
          <div>
            <p className="text-base sm:text-lg font-medium text-gray-800 mb-2">{loadingPhase?.title}</p>
            <div className="w-full max-w-md mx-auto bg-gray-200 rounded-full h-2.5">
              <div
                className={`bg-${loadingPhase?.color}-500 h-2.5 rounded-full transition-all duration-300`}
                style={{ width: `${loadingProgress}%` }}
              />
            </div>
            {loadingPhase && (
              <div className="mt-2 sm:mt-4 space-y-2">
                {loadingPhase.tips.map((tip, index) => (
                  <div
                    key={index}
                    className={`transition-all duration-300 ${
                      index === tipIndex ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
                    }`}
                    style={{
                      display: index === tipIndex ? 'block' : 'none'
                    }}
                  >
                    <p className="text-xs sm:text-sm text-gray-600">{tip}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {error && (
        <div className="mt-4 bg-red-50 border border-red-200 rounded-lg p-4 text-red-700 text-sm">
          {error}
        </div>
      )}

      {headings.length > 0 && (
        <div className="space-y-4" ref={headingsContainerRef}>
          {groupedHeadings.map(({ heading: h2, children }) => (
            <div key={h2.id} className="space-y-2">
              {/* H2 Heading */}
              <div
                id={`heading-${h2.id}`}
                className={`bg-white border-2 rounded-lg p-4 flex items-center justify-between transition-all group ${
                  selectedHeading === h2.id 
                    ? 'border-amber-500 shadow-lg' 
                    : 'border-gray-200 hover:shadow-md'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-[#a63439]/10 flex items-center justify-center">
                    <Layers className="w-4 h-4 text-[#a63439]" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-medium text-[#a63439] bg-[#a63439]/10 px-2 py-0.5 rounded">
                        H2
                      </span>
                      <span className="font-medium">{h2.title}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setSelectedHeading(h2.id);
                      setSelectedLevel(3);
                      handleSuggestHeadings(h2.id);
                    }}
                    className="text-[#a63439] hover:text-white bg-[#a63439]/10 hover:bg-[#a63439] p-2 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                  >
                    <Sparkles className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onRemoveHeading(h2.id)}
                    className="text-gray-400 hover:text-red-500 p-2 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
              
              {/* H3 Children */}
              {children.length > 0 && (
                <div className="mr-8 space-y-2 border-r-2 border-gray-100">
                  {children.map(h3 => (
                    <div
                      key={h3.id}
                      id={`heading-${h3.id}`}
                      className={`bg-white border-2 rounded-lg p-4 flex items-center justify-between transition-all group ${
                        selectedHeading === h3.id 
                          ? 'border-amber-500 shadow-lg' 
                          : 'border-gray-200 hover:shadow-md'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-[#a63439]/10 flex items-center justify-center">
                          <Layers className="w-4 h-4 text-[#a63439]" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs font-medium text-[#a63439] bg-[#a63439]/10 px-2 py-0.5 rounded">
                              H3
                            </span>
                            <span className="font-medium">{h3.title}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {h3.level < 4 && (
                          <button
                            onClick={() => {
                              setSelectedHeading(h3.id);
                              setSelectedLevel(4);
                              handleSuggestHeadings(h3.id);
                            }}
                            className="text-[#a63439] hover:text-white bg-[#a63439]/10 hover:bg-[#a63439] p-2 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                          >
                            <Sparkles className="w-4 h-4" />
                          </button>
                        )}
                        <button
                          onClick={() => onRemoveHeading(h3.id)}
                          className="text-gray-400 hover:text-red-500 p-2 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}