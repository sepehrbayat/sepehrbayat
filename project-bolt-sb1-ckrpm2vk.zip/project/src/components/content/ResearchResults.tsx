import React from 'react';
import { Search } from 'lucide-react';

interface SearchResult {
  title: string;
  content: string;
  url: string;
}

interface ResearchResultsProps {
  results: SearchResult[];
}

export default function ResearchResults({ results }: ResearchResultsProps) {
  if (results.length === 0) return null;

  return (
    <div className="bg-white rounded-xl p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-medium">نتایج تحقیق</h2>
        <div className="flex items-center gap-2 text-sm text-gray-500">
          <Search className="w-4 h-4" />
          <span>تحلیل هوشمند</span>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {results.map((result, index) => (
          <div 
            key={index} 
            className="bg-gradient-to-br from-gray-50 to-white border border-gray-100 rounded-lg p-4 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#a63439]/10 flex items-center justify-center flex-shrink-0">
                <Search className="w-4 h-4 text-[#a63439]" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-medium mb-2 line-clamp-1">{result.title}</h3>
                <p className="text-sm text-gray-600 mb-3 line-clamp-3">
                  {result.content}
                </p>
                <div className="flex items-center justify-between">
                  <a
                    href={result.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#a63439] text-sm hover:underline flex items-center gap-1"
                  >
                    مشاهده منبع
                    <svg
                      className="w-3 h-3"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                      />
                    </svg>
                  </a>
                  {result.metadata?.publishDate && (
                    <span className="text-xs text-gray-400">
                      {new Date(result.metadata.publishDate).toLocaleDateString('fa-IR')}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}