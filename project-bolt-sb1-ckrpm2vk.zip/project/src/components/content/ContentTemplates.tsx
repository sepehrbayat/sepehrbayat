import React from 'react';
import { GraduationCap, ShoppingBag, Newspaper, Layout } from 'lucide-react';

export interface ArticleTemplate {
  id: string;
  title: string;
  description: string;
  icon: any;
  minWords: number;
  maxWords: number;
  style: string;
  tone: string;
  audience: string;
}

export const articleTemplates: ArticleTemplate[] = [
  {
    id: 'how-to',
    title: 'مقاله آموزشی',
    description: 'آموزش گام به گام با جزئیات کامل',
    icon: GraduationCap,
    minWords: 1500,
    maxWords: 2500,
    style: 'educational',
    tone: 'formal',
    audience: 'general'
  },
  {
    id: 'product-review',
    title: 'بررسی محصول',
    description: 'معرفی و نقد تخصصی محصولات',
    icon: ShoppingBag,
    minWords: 1000,
    maxWords: 2000,
    style: 'professional',
    tone: 'serious',
    audience: 'general'
  },
  {
    id: 'news',
    title: 'مقاله خبری',
    description: 'پوشش خبری با تحلیل و بررسی',
    icon: Newspaper,
    minWords: 800,
    maxWords: 1500,
    style: 'professional',
    tone: 'formal',
    audience: 'general'
  },
  {
    id: 'comparison',
    title: 'مقاله مقایسه‌ای',
    description: 'مقایسه تخصصی و تحلیلی',
    icon: Layout,
    minWords: 1200,
    maxWords: 2200,
    style: 'professional',
    tone: 'serious',
    audience: 'professional'
  }
];

interface ContentTemplatesProps {
  selectedTemplate: string | null;
  onTemplateSelect: (template: ArticleTemplate) => void;
}

export default function ContentTemplates({ selectedTemplate, onTemplateSelect }: ContentTemplatesProps) {
  return (
    <div>
      <label className="block text-sm font-medium mb-2">قالب‌های پیشنهادی</label>
      <div className="grid grid-cols-4 gap-4">
        {articleTemplates.map(template => (
          <button
            key={template.id}
            onClick={() => onTemplateSelect(template)}
            className={`p-4 rounded-xl border transition-all text-right ${
              selectedTemplate === template.id
                ? 'border-[#a63439] bg-[#a63439]/5'
                : 'border-gray-200 hover:border-[#a63439] hover:bg-gray-50'
            }`}
          >
            <div className="flex items-center gap-3 mb-2">
              <template.icon className={`w-5 h-5 ${
                selectedTemplate === template.id ? 'text-[#a63439]' : 'text-gray-400'
              }`} />
              <h3 className="text-sm font-medium">{template.title}</h3>
            </div>
            <p className="text-xs text-gray-500 mb-2">{template.description}</p>
            <div className="text-xs text-gray-400">
              تعداد کلمات: {template.minWords} تا {template.maxWords}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}