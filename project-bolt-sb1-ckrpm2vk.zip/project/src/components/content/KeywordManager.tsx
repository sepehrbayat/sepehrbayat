import React, { useRef, useEffect, useState } from 'react';
import { Hash, Sparkles, Loader2, Brain, Star, ChevronRight } from 'lucide-react';
import { useTranslation, Trans } from 'react-i18next';
import { isEnglishUI } from '../../lib/i18n/languageManager';
import { LANGUAGE_CHANGE_EVENT, type LanguageChangeEvent } from '../../lib/i18n/languageManager'; 

interface KeywordManagerProps {
  keywords: string[];
  onAddKeyword: (keyword: string) => void;
  onRemoveKeyword: (keyword: string) => void;
  onSuggestKeywords: () => Promise<void>;
  suggestedKeywords: string[];
  isSuggestingKeywords: boolean;
  showSuggestions: boolean;
  onSelectSuggestion: (keyword: string) => void;
  onHideSuggestions: () => void;
  disabled?: boolean;
}

export default function KeywordManager({
  keywords,
  onAddKeyword,
  onRemoveKeyword,
  onSuggestKeywords,
  suggestedKeywords,
  isSuggestingKeywords,
  showSuggestions,
  onSelectSuggestion,
  onHideSuggestions,
  disabled
}: KeywordManagerProps) {
  const { t } = useTranslation();
  const isEnglish = isEnglishUI();
  const [newKeyword, setNewKeyword] = useState('');
  const keywordRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [loadingMessage, setLoadingMessage] = useState('');
  const [showLoadingOverlay, setShowLoadingOverlay] = useState(false);
  const [selectedKeyword, setSelectedKeyword] = useState<string | null>(null);
  
  // Listen for language changes
  useEffect(() => {
    const handleLanguageChange = (event: LanguageChangeEvent) => {
      // Clear suggestions when language changes to prevent mixed language content
      onHideSuggestions();
      // Reset input direction based on new language
      if (inputRef.current) {
        inputRef.current.dir = isEnglish ? 'ltr' : 'rtl';
      }
    };

    window.addEventListener(LANGUAGE_CHANGE_EVENT, handleLanguageChange as EventListener);
    return () => {
      window.removeEventListener(LANGUAGE_CHANGE_EVENT, handleLanguageChange as EventListener);
    };
  }, [onHideSuggestions]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (keywordRef.current && !keywordRef.current.contains(event.target as Node)) {
        onHideSuggestions();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [onHideSuggestions]);

  const handleAddKeyword = () => {
    if (newKeyword.trim()) {
      onAddKeyword(newKeyword.trim());
      setNewKeyword('');
    }
  };

  // Loading animation effect
  useEffect(() => {
    if (isSuggestingKeywords) {
      setShowLoadingOverlay(true);
      setLoadingProgress(0);
      setLoadingMessage('در حال تحلیل موضوع...');

      const messages = [
        'در حال تحلیل موضوع...',
        'جستجوی کلمات کلیدی پرکاربرد...',
        'بهینه‌سازی پیشنهادات...',
        'در حال نهایی‌سازی...'
      ];

      let currentMessage = 0;
      const messageInterval = setInterval(() => {
        currentMessage = (currentMessage + 1) % messages.length;
        setLoadingMessage(messages[currentMessage]);
      }, 3000);

      const progressInterval = setInterval(() => {
        setLoadingProgress(prev => {
          if (prev >= 95) {
            clearInterval(progressInterval);
            return prev;
          }
          return prev + 1;
        });
      }, 100);

      return () => {
        clearInterval(messageInterval);
        clearInterval(progressInterval);
        setShowLoadingOverlay(false);
      };
    }
  }, [isSuggestingKeywords]);

  return (
    <div>
      <label className="block text-sm font-medium mb-2">
        کلمات کلیدی
      </label>
      <div className="flex gap-2 mb-3">
        <div ref={keywordRef} className="relative flex-1 flex gap-2">
          <Hash className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            value={newKeyword}
            onChange={(e) => setNewKeyword(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleAddKeyword()}
            className="w-full bg-gray-50 border border-gray-200 rounded-lg px-9 py-2" 
            dir={isEnglish ? 'ltr' : 'rtl'}
            placeholder="کلمه کلیدی را وارد کنید..."
          />
          <button
            onClick={onSuggestKeywords}
            disabled={isSuggestingKeywords || disabled}
            className="bg-gray-100 text-gray-700 px-3 py-2 rounded-lg hover:bg-gray-200 transition-colors flex items-center gap-1 disabled:opacity-50"
          >
            {isSuggestingKeywords ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Sparkles className="w-4 h-4" />
            )}
            <span className="hidden sm:inline">
              پیشنهاد هوشمند
            </span>
          </button>
          {showSuggestions && suggestedKeywords.length > 0 && (
            <div className="absolute top-full right-0 mt-1 w-full bg-white border-2 border-amber-500 rounded-xl shadow-lg overflow-hidden z-10 animate-fadeIn">
              <div className="bg-gradient-to-br from-amber-50 to-white px-4 py-3 flex items-center justify-between border-b border-amber-100">
                <div className="flex items-center gap-2">
                  <Brain className="w-4 h-4 text-amber-600" />
                  <span className="font-medium text-amber-900">پیشنهادهای هوشمند</span>
                </div>
                <Star className="w-4 h-4 text-amber-500 fill-amber-500 animate-pulse" />
              </div>
              <div className="p-2 space-y-2">
                {suggestedKeywords.map((keyword, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      setSelectedKeyword(keyword);
                      setTimeout(() => {
                        onSelectSuggestion(keyword);
                        const updatedSuggestions = suggestedKeywords.filter(k => k !== keyword);
                        if (updatedSuggestions.length === 0) {
                          onHideSuggestions();
                        }
                        setSelectedKeyword(null);
                      }, 300);
                    }}
                    className={`w-full bg-white rounded-lg p-3 hover:shadow-md transition-all group relative overflow-hidden text-right border border-transparent hover:border-amber-200 ${
                      selectedKeyword === keyword ? 'scale-95 opacity-50' : ''
                    }`}
                  >
                    <div className="absolute inset-y-0 right-0 w-1 bg-amber-100 group-hover:bg-amber-500 transition-colors rounded-r-lg" />
                    <div className="relative flex items-center gap-3 group-hover:translate-x-2 transition-transform">
                      <div className="w-8 h-8 rounded-lg bg-amber-50 flex items-center justify-center flex-shrink-0">
                        <Sparkles className="w-4 h-4 text-amber-600" />
                      </div>
                      <div className="flex-1">
                        <span className="font-medium">{keyword}</span>
                        <p className="text-xs text-gray-500">برای افزودن کلیک کنید</p>
                      </div>
                      <div className="absolute left-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <ChevronRight className="w-5 h-5 text-amber-500" />
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
          
          {/* Loading Overlay */}
          {showLoadingOverlay && (
            <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 animate-fadeIn p-4">
              <div className="max-w-lg w-full">
                <div className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-6 md:p-8 relative overflow-hidden">
                  {/* Animated Background Pattern */}
                  <div className="absolute inset-0 opacity-5">
                    <div className="absolute inset-0 bg-gradient-to-br from-amber-500 to-amber-600" />
                    <div className="absolute inset-0" style={{
                      backgroundImage: 'radial-gradient(circle at 1px 1px, #000 1px, transparent 0)',
                      backgroundSize: '20px 20px sm:40px 40px',
                      animation: 'patternMove 20s linear infinite'
                    }} />
                  </div>

                  {/* Content */}
                  <div className="relative">
                    {/* Logo with Animated Effects */}
                    <div className="flex justify-center mb-4 sm:mb-6 md:mb-8">
                      <div className="relative">
                        <div className="w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 rounded-full bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center transform transition-transform hover:scale-105">
                          <Brain className="w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 text-white" />
                          <div className="absolute inset-0 flex items-center justify-center animate-ping">
                            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6 text-white" />
                          </div>
                        </div>
                        <div className="absolute -top-2 -right-2 animate-bounce">
                          <Star className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6 text-amber-400 fill-amber-400" />
                        </div>
                        {/* Animated Ring */}
                        <div className="absolute -inset-2 rounded-full border-4 border-transparent animate-spin-slow opacity-30" style={{
                          background: 'linear-gradient(white, white) padding-box, linear-gradient(to right, #f59e0b, #d97706) border-box'
                        }} />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
        <button
          onClick={handleAddKeyword}
          disabled={!newKeyword.trim()}
          className="bg-[#a63439] text-white px-4 py-2 rounded-lg hover:bg-[#8a2a2e] transition-colors disabled:opacity-50"
        >
          افزودن
        </button>
      </div>
      {keywords.length > 0 && (
        <div className="flex flex-wrap gap-2 transition-all">
          {keywords.map((keyword, index) => (
            <span
              key={index}
              className={`bg-gradient-to-br from-amber-50 to-white border border-amber-200 text-amber-900 px-3 py-1 rounded-full text-sm flex items-center gap-2 animate-fadeIn shadow-sm hover:shadow-md transition-all ${
                selectedKeyword === keyword ? 'scale-95 opacity-50' : ''
              }`}
            >
              {keyword}
              <button
                onClick={() => onRemoveKeyword(keyword)}
                className="text-amber-400 hover:text-red-500 transition-colors"
              >
                ×
              </button>
            </span>
          ))}
        </div>
      )}
    </div>
  );
}