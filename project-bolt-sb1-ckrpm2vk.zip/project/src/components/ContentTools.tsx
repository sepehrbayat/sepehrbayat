@@ .. @@
 import React, { useState } from 'react';
 import { useTranslation, Trans } from 'react-i18next';
 import { Tool } from '../types';
-import { Video, Image, FileText, Music, PenTool, Star, Crown } from 'lucide-react';
+import { Image, FileText, Music, PenTool, Star, Crown } from 'lucide-react';
 import ContentAI from './ContentAI';
 import ImageAI from './ImageAI';
 import ImageAILite from './ImageAILite';
@@ .. @@
     {
       id: 'reels-script',
       name: 'سناریو نویس ریلز',
       description: 'تولید سناریو برای ریلز و شورت',
-      icon: Video,
+      icon: FileText,
       color: 'bg-pink-100',
       isNew: true
     },