import React, { useState } from 'react';
import { Sparkles, AlertCircle, Brain } from 'lucide-react';
import ImageControls from '../image/ImageControls';
import { openai } from '../../lib/openai';
import ImageGenerationOverlay from './ImageGenerationOverlay';

interface ImageGeneratorProps {
  onImageGenerated: (imageUrl: string) => void;
  onError: (error: string) => void;
}

export default function ImageGenerator({ onImageGenerated, onError }: ImageGeneratorProps) {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationPhase, setGenerationPhase] = useState<'analysis' | 'generation' | 'enhancement' | null>(null);
  const [progressPercent, setProgressPercent] = useState(0);
  const [settings, setSettings] = useState({
    model: 'dall-e-3',
    width: '1024',
    height: '1024',
    quality: 'hd',
    style: 'vivid',
    mood: 'dramatic',
    lighting: 'studio',
    composition: 'balanced',
    perspective: 'front',
    colorScheme: 'vibrant'
  });

  const handleGenerate = async () => {
    try {
      if (!prompt.trim()) {
        throw new Error('لطفاً توضیحات تصویر را وارد کنید');
      }

      setIsGenerating(true);
      setGenerationPhase('analysis');
      setProgressPercent(0);

      // Simulate analysis progress
      const analysisInterval = setInterval(() => {
        setProgressPercent(prev => {
          if (prev >= 30) {
            clearInterval(analysisInterval);
            return prev;
          }
          return prev + 1;
        });
      }, 100);

      setGenerationPhase('generation');
      setProgressPercent(35);

      const response = await openai.images.generate({
        model: 'dall-e-3',
        prompt: `${prompt}, masterpiece, best quality, highly detailed, sharp focus, professional lighting, 8k uhd`,
        n: 1,
        size: '1024x1024',
        quality: 'standard',
        response_format: 'url'
      });

      setGenerationPhase('enhancement');
      setProgressPercent(75);

      const imageUrl = response.data[0]?.url;
      if (!imageUrl) {
        throw new Error('خطا در تولید تصویر');
      }

      setProgressPercent(100);
      onImageGenerated(imageUrl);

    } catch (error) {
      console.error('Error:', error);
      onError(error instanceof Error ? error.message : 'خطا در تولید تصویر');
    } finally {
      setIsGenerating(false);
      setGenerationPhase(null);
      setProgressPercent(0);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium mb-2">توضیحات تصویر</label>
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          className="w-full h-32 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 resize-none"
          placeholder="تصویر مورد نظر خود را توصیف کنید..."
        />
      </div>

      <ImageControls
        settings={settings}
        onSettingsChange={setSettings}
      />

      <button
        onClick={handleGenerate}
        disabled={isGenerating || !prompt.trim()}
        className="w-full bg-[#a63439] text-white p-4 rounded-lg flex items-center justify-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
      >
        {isGenerating ? (
          <>
            <Brain className="w-5 h-5 animate-pulse" />
            <span>در حال تولید تصویر...</span>
          </>
        ) : (
          <>
            <Sparkles className="w-5 h-5" />
            <span>تولید تصویر</span>
          </>
        )}
      </button>

      <ImageGenerationOverlay 
        isVisible={isGenerating}
        progress={progressPercent}
        phase={generationPhase}
      />
    </div>
  );
}