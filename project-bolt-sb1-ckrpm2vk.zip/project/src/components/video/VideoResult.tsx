import React from 'react';
import { Download, AlertCircle } from 'lucide-react';

interface VideoResultProps {
  videoUrl: string;
  onError: (error: string) => void;
}

export default function VideoResult({ videoUrl, onError }: VideoResultProps) {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium">ویدئوی تولید شده</h3>
      <div className="aspect-video bg-black rounded-lg overflow-hidden">
        <video
          src={videoUrl}
          controls
          className="w-full h-full"
          onError={() => onError('خطا در پخش ویدئو')}
        />
      </div>
      <a
        href={videoUrl}
        download="generated-video.mp4"
        className="inline-flex items-center gap-2 bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 transition-colors"
      >
        <Download className="w-4 h-4" />
        <span>دانلود ویدئو</span>
      </a>
    </div>
  );
}