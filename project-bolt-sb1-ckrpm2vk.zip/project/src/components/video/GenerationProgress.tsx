import React from 'react';
import { X } from 'lucide-react';

interface GenerationProgressProps {
  progress: string;
  generationId: string | null;
  onCancel: () => void;
}

export default function GenerationProgress({ progress, generationId, onCancel }: GenerationProgressProps) {
  return (
    <div className="flex items-center justify-between bg-[#a63439]/5 border border-[#a63439]/10 rounded-lg p-4">
      <div className="flex items-center gap-3">
        <div className="animate-spin rounded-full h-4 w-4 border-2 border-[#a63439] border-t-transparent" />
        <p className="text-gray-700">{progress}</p>
      </div>
      {generationId && (
        <button
          onClick={onCancel}
          className="text-gray-500 hover:text-[#a63439] p-1 hover:bg-[#a63439]/10 rounded-full transition-all"
          title="لغو پردازش"
        >
          <X className="w-4 h-4" />
        </button>
      )}
    </div>
  );
}