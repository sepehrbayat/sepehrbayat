import React from 'react';
import { Check, X } from 'lucide-react';

interface ImageConfirmationProps {
  imageUrl: string;
  onConfirm: () => void;
  onReject: () => void;
}

export default function ImageConfirmation({ imageUrl, onConfirm, onReject }: ImageConfirmationProps) {
  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-br from-[#a63439]/5 to-white border border-[#a63439]/10 rounded-lg p-6">
        <h3 className="text-sm font-medium mb-4 flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-[#a63439]" />
          تصویر تولید شده
        </h3>
        <div className="aspect-square relative rounded-lg overflow-hidden shadow-lg mb-6 transform hover:scale-[1.02] transition-transform duration-300">
          <img
            src={imageUrl}
            alt="تصویر تولید شده"
            className="w-full h-full object-cover"
          />
        </div>
        <p className="text-sm text-gray-600 mb-6">
          آیا از این تصویر برای تولید ویدئو استفاده شود؟
        </p>
        <div className="flex gap-3">
          <button
            onClick={onConfirm}
            className="flex-1 bg-[#a63439] text-white px-4 py-3 rounded-lg flex items-center justify-center gap-2 hover:bg-[#8a2a2e] transition-all transform hover:scale-[1.02] active:scale-[0.98] duration-200"
          >
            <Check className="w-4 h-4" />
            <span>تایید و ادامه</span>
          </button>
          <button
            onClick={onReject}
            className="flex-1 bg-gray-100 text-gray-700 px-4 py-3 rounded-lg flex items-center justify-center gap-2 hover:bg-gray-200 transition-all transform hover:scale-[1.02] active:scale-[0.98] duration-200"
          >
            <X className="w-4 h-4" />
            <span>تولید مجدد</span>
          </button>
        </div>
      </div>
    </div>
  );
}