import React, { useEffect, useState } from 'react';
import { Brain, Crown, Star, Sparkles, Camera, Palette, Layout } from 'lucide-react';

interface GenerationOverlayProps {
  isVisible: boolean;
  progress: number;
  phase: 'analysis' | 'generation' | 'enhancement' | null;
}

const phases = {
  analysis: {
    icon: Brain,
    title: 'در حال تحلیل توضیحات...',
    tips: [
      'تحلیل عمیق پرامپت ورودی...',
      'شناسایی عناصر کلیدی تصویر...',
      'بررسی جزئیات و ویژگی‌ها...',
      'تنظیم پارامترهای تولید...',
      'آماده‌سازی برای تولید تصویر...'
    ],
    color: 'from-amber-500 to-amber-600',
    bgColor: 'from-amber-50 to-transparent',
    borderColor: 'border-amber-100'
  },
  generation: {
    icon: Camera,
    title: 'در حال تولید تصویر...',
    tips: [
      'ساخت تصویر با DALL-E 3...',
      'اعمال تنظیمات انتخاب شده...',
      'بهینه‌سازی جزئیات تصویر...',
      'پردازش نهایی خروجی...',
      'آماده‌سازی برای نمایش...'
    ],
    color: 'from-amber-500 to-amber-600',
    bgColor: 'from-amber-50 to-transparent',
    borderColor: 'border-amber-100'
  },
  enhancement: {
    icon: Palette,
    title: 'در حال بهبود کیفیت...',
    tips: [
      'افزایش وضوح و جزئیات...',
      'بهینه‌سازی رنگ‌ها و کنتراست...',
      'اعمال افکت‌های حرفه‌ای...',
      'بهبود کیفیت نهایی...',
      'آماده‌سازی خروجی نهایی...'
    ],
    color: 'from-amber-500 to-amber-600',
    bgColor: 'from-amber-50 to-transparent',
    borderColor: 'border-amber-100'
  }
};

export default function GenerationOverlay({ isVisible, progress, phase }: GenerationOverlayProps) {
  const [tipIndex, setTipIndex] = useState(0);
  const [showSparkle, setShowSparkle] = useState(false);

  useEffect(() => {
    if (!isVisible) return;

    // Rotate through tips every 3 seconds
    const tipInterval = setInterval(() => {
      setTipIndex(prev => {
        const currentPhase = phase ? phases[phase] : phases.analysis;
        return (prev + 1) % currentPhase.tips.length;
      });
    }, 3000);

    // Show random sparkles
    const sparkleInterval = setInterval(() => {
      setShowSparkle(true);
      setTimeout(() => setShowSparkle(false), 500);
    }, 2000);

    return () => {
      clearInterval(tipInterval);
      clearInterval(sparkleInterval);
    };
  }, [isVisible, phase]);

  if (!isVisible) return null;

  const currentPhase = phase ? phases[phase] : phases.analysis;
  const PhaseIcon = currentPhase.icon;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 animate-fadeIn p-4">
      <div className="max-w-lg w-full">
        <div className="bg-white rounded-2xl p-8 relative overflow-hidden">
          {/* Animated Background Pattern */}
          <div className="absolute inset-0 opacity-5">
            <div className={`absolute inset-0 bg-gradient-to-br ${currentPhase.color}`} />
            <div className="absolute inset-0" style={{
              backgroundImage: 'radial-gradient(circle at 1px 1px, #000 1px, transparent 0)',
              backgroundSize: '40px 40px',
              animation: 'patternMove 20s linear infinite'
            }} />
          </div>

          {/* Content */}
          <div className="relative">
            {/* Logo with Animated Effects */}
            <div className="flex justify-center mb-8">
              <div className="relative">
                <div className={`w-24 h-24 rounded-full bg-gradient-to-br ${currentPhase.color} flex items-center justify-center transform transition-transform hover:scale-105`}>
                  <PhaseIcon className="w-12 h-12 text-white" />
                  {showSparkle && (
                    <div className="absolute inset-0 flex items-center justify-center animate-ping">
                      <Sparkles className="w-6 h-6 text-white" />
                    </div>
                  )}
                </div>
                <div className="absolute -top-2 -right-2 animate-bounce">
                  <Star className="w-6 h-6 text-amber-400 fill-amber-400" />
                </div>
                {/* Animated Ring */}
                <div className="absolute -inset-2 rounded-full border-4 border-transparent animate-spin-slow opacity-30" style={{
                  background: 'linear-gradient(white, white) padding-box, linear-gradient(to right, #f59e0b, #d97706) border-box'
                }} />
              </div>
            </div>

            {/* Progress Section */}
            <div className="text-center space-y-6">
              <h2 className="text-xl font-bold bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
                {currentPhase.title}
              </h2>
              <div className="relative w-full h-2 bg-gray-200 rounded-full overflow-hidden mb-4">
                <div 
                  className={`h-full bg-gradient-to-r ${currentPhase.color} transition-all duration-500 ease-out relative`}
                  style={{ width: `${progress}%` }}
                >
                  {/* Animated Pulse Effect */}
                  <div className="absolute inset-0 bg-white opacity-30 animate-pulse" />
                </div>
              </div>
              <p className="text-sm text-gray-500">{progress}% تکمیل شده</p>
            </div>

            {/* Animated Tips */}
            <div className="mt-8 space-y-4">
              {currentPhase.tips.map((tip, index) => (
                <div 
                  key={index}
                  className={`flex items-center gap-3 p-3 bg-gradient-to-l ${currentPhase.bgColor} border ${currentPhase.borderColor} rounded-xl transition-all duration-300 transform ${
                    index === tipIndex ? 'scale-105 shadow-md' : 'scale-100'
                  }`}
                  style={{
                    opacity: index === tipIndex ? 1 : 0.5,
                    transform: `translateX(${index === tipIndex ? '0' : '-10px'})`,
                  }}
                >
                  <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${currentPhase.color} flex items-center justify-center`}>
                    <PhaseIcon className="w-4 h-4 text-white" />
                  </div>
                  <p className="text-sm flex-1">{tip}</p>
                  {index === tipIndex && (
                    <Sparkles className={`w-4 h-4 text-${currentPhase.color.split('-')[1]}-500 animate-pulse`} />
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}