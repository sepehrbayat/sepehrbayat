import React from 'react';
import { Sparkles } from 'lucide-react';

interface VideoPromptProps {
  value: string;
  onChange: (value: string) => void;
}

export default function VideoPrompt({ value, onChange }: VideoPromptProps) {
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <label className="block text-sm font-medium">توضیحات ویدئو</label>
        <div className="flex items-center gap-1 text-sm text-[#a63439]">
          <Sparkles className="w-4 h-4" />
          <span>هر چه دقیق‌تر، نتیجه بهتر</span>
        </div>
      </div>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full h-32 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 resize-none focus:outline-none focus:ring-2 focus:ring-[#a63439] transition-all"
        placeholder="توضیحات دقیق برای نحوه حرکت و تغییرات در ویدئو را وارد کنید..."
      />
      <div className="mt-2 text-xs text-gray-500">
        مثال: حرکت آرام دوربین به سمت جلو، تغییر تدریجی نور از تاریک به روشن، چرخش ملایم حول سوژه اصلی
      </div>
    </div>
  );
}