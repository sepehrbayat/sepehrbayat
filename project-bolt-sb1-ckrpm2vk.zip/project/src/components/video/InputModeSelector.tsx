import React from 'react';
import { Upload, Sparkles } from 'lucide-react';

interface InputModeSelectorProps {
  selectedMode: 'upload' | 'generate' | null;
  onModeSelect: (mode: 'upload' | 'generate') => void;
}

export default function InputModeSelector({ selectedMode, onModeSelect }: InputModeSelectorProps) {
  return (
    <div>
      <label className="block text-sm font-medium mb-2">انتخاب روش ورودی</label>
      <div className="grid grid-cols-2 gap-4">
        <button
          onClick={() => onModeSelect('upload')}
          className={`p-6 rounded-xl text-right transition-all hover:shadow-lg hover:scale-[1.02] group relative ${
            selectedMode === 'upload'
              ? 'bg-[#a63439] text-white shadow-lg scale-[1.02]'
              : 'bg-gray-50 hover:bg-gray-100'
          }`}
        >
          <Upload className={`w-8 h-8 mb-4 ${
            selectedMode === 'upload' ? 'text-white' : 'text-gray-700'
          }`} />
          <h3 className="text-lg font-medium mb-2">آپلود تصویر موجود</h3>
          <p className={`text-sm ${
            selectedMode === 'upload' ? 'text-white/80' : 'text-gray-500'
          }`}>تصویر خود را آپلود کنید تا به یک ویدئوی پویا تبدیل شود</p>
        </button>

        <button
          onClick={() => onModeSelect('generate')}
          className={`p-6 rounded-xl text-right transition-all hover:shadow-lg hover:scale-[1.02] group relative ${
            selectedMode === 'generate'
              ? 'bg-[#a63439] text-white shadow-lg scale-[1.02]'
              : 'bg-gray-50 hover:bg-gray-100'
          }`}
        >
          <Sparkles className={`w-8 h-8 mb-4 ${
            selectedMode === 'generate' ? 'text-white' : 'text-gray-700'
          }`} />
          <h3 className="text-lg font-medium mb-2">تولید با هوش مصنوعی</h3>
          <p className={`text-sm ${
            selectedMode === 'generate' ? 'text-white/80' : 'text-gray-500'
          }`}>ابتدا تصویر را با هوش مصنوعی تولید کرده و سپس به ویدئو تبدیل می‌کنیم</p>
        </button>
      </div>
    </div>
  );
}