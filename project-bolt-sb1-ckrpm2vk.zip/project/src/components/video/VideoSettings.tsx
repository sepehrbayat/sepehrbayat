import React from 'react';
import { Film, Ratio as AspectRatio } from 'lucide-react';

interface VideoSettingsProps {
  duration: 5 | 10;
  orientation: 'landscape' | 'portrait';
  onDurationChange: (duration: 5 | 10) => void;
  onOrientationChange: (orientation: 'landscape' | 'portrait') => void;
}

export default function VideoSettings({
  duration,
  orientation,
  onDurationChange,
  onOrientationChange
}: VideoSettingsProps) {
  return (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium mb-2">مدت زمان ویدئو</label>
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => onDurationChange(5)}
            className={`p-4 rounded-lg text-sm transition-colors flex flex-col items-center gap-2 ${
              duration === 5
                ? 'bg-[#a63439] text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <Film className="w-5 h-5" />
            <span>5 ثانیه</span>
          </button>
          <button
            onClick={() => onDurationChange(10)}
            className={`p-4 rounded-lg text-sm transition-colors flex flex-col items-center gap-2 ${
              duration === 10
                ? 'bg-[#a63439] text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <Film className="w-5 h-5" />
            <span>10 ثانیه</span>
          </button>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">جهت ویدئو</label>
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => onOrientationChange('landscape')}
            className={`p-4 rounded-lg text-sm transition-colors flex flex-col items-center gap-2 ${
              orientation === 'landscape'
                ? 'bg-[#a63439] text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <AspectRatio className="w-5 h-5 rotate-90" />
            <span>افقی</span>
            <span className="text-xs opacity-75">1280×768</span>
          </button>
          <button
            onClick={() => onOrientationChange('portrait')}
            className={`p-4 rounded-lg text-sm transition-colors flex flex-col items-center gap-2 ${
              orientation === 'portrait'
                ? 'bg-[#a63439] text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <AspectRatio className="w-5 h-5" />
            <span>عمودی</span>
            <span className="text-xs opacity-75">768×1280</span>
          </button>
        </div>
      </div>
    </div>
  );
}