import React from 'react';
import { FileText } from 'lucide-react';
import { CONTENT_LENGTH_RANGES, STYLES, TONES, AUDIENCES } from '../constants';
import type { ContentSettings } from '../types';

interface ContentSettingsProps {
  settings: ContentSettings;
  onSettingsChange: (settings: ContentSettings) => void;
}

export default function ContentSettings({ settings, onSettingsChange }: ContentSettingsProps) {
  return (
    <div className="space-y-6">
      <div className="mb-8">
        <label className="block text-sm font-medium mb-2">طول محتوا</label>
        <p className="text-sm text-gray-500 mb-3">
          توجه: طول نهایی محتوا ممکن است برای حفظ کیفیت و انسجام متن، با مقادیر تقریبی زیر متفاوت باشد.
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {Object.entries(CONTENT_LENGTH_RANGES).map(([key, value]) => (
            <button
              key={key}
              onClick={() => onSettingsChange({ ...settings, contentLength: key as any })}
              className={`p-4 rounded-xl border transition-all ${
                settings.contentLength === key
                  ? 'border-[#a63439] bg-[#a63439]/5'
                  : 'border-gray-200 hover:border-[#a63439] hover:bg-gray-50'
              }`}
            >
              <FileText className={`w-6 h-6 mb-2 ${
                settings.contentLength === key ? 'text-[#a63439]' : 'text-gray-400'
              }`} />
              <h3 className="text-sm font-medium mb-1">
                {key === 'short' ? 'کوتاه' :
                 key === 'medium' ? 'متوسط' :
                 key === 'long' ? 'بلند' : 'سفارشی'}
              </h3>
              <p className="text-xs text-gray-500">
                {value.min} تا {value.max} کلمه
              </p>
            </button>
          ))}
        </div>
      </div>

      <div className="bg-gray-50 rounded-xl p-6 space-y-8">
        <h3 className="text-sm font-medium mb-6">تنظیمات نگارش</h3>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
          <div>
            <label className="block text-sm font-medium mb-4">سبک نگارش</label>
            <div className="bg-white rounded-lg p-2 shadow-sm">
              {STYLES.map(style => (
                <button
                  key={style.id}
                  onClick={() => onSettingsChange({ ...settings, style: style.id })}
                  className={`w-full p-3 rounded-lg text-right transition-all mb-2 last:mb-0 ${
                    settings.style === style.id
                      ? 'bg-[#a63439] text-white shadow-md'
                      : 'hover:bg-gray-50'
                  }`}
                >
                  <div className="font-medium">{style.name}</div>
                  <div className={`text-xs mt-1 ${settings.style === style.id ? 'text-white/80' : 'text-gray-500'}`}>
                    {style.description}
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-4">لحن محتوا</label>
            <div className="bg-white rounded-lg p-2 shadow-sm">
              {TONES.map(tone => (
                <button
                  key={tone.id}
                  onClick={() => onSettingsChange({ ...settings, tone: tone.id })}
                  className={`w-full p-3 rounded-lg text-center transition-all mb-2 last:mb-0 ${
                    settings.tone === tone.id
                      ? 'bg-[#a63439] text-white shadow-md'
                      : 'hover:bg-gray-50'
                  }`}
                >
                  <div className="font-medium">{tone.name}</div>
                  <div className={`text-xs mt-1 ${settings.tone === tone.id ? 'text-white/80' : 'text-gray-500'}`}>
                    {tone.id === 'formal' ? 'مناسب برای محتوای رسمی و تخصصی' :
                     tone.id === 'informal' ? 'مناسب برای محتوای عمومی و راحت' :
                     'مناسب برای محتوای تعاملی و گفتگومحور'}
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-4">مخاطب هدف</label>
            <div className="bg-white rounded-lg p-2 shadow-sm">
              {AUDIENCES.map(audience => (
                <button
                  key={audience.id}
                  onClick={() => onSettingsChange({ ...settings, audience: audience.id })}
                  className={`w-full p-3 rounded-lg text-center transition-all mb-2 last:mb-0 ${
                    settings.audience === audience.id
                      ? 'bg-[#a63439] text-white shadow-md'
                      : 'hover:bg-gray-50'
                  }`}
                >
                  <div className="font-medium">{audience.name}</div>
                  <div className={`text-xs mt-1 ${settings.audience === audience.id ? 'text-white/80' : 'text-gray-500'}`}>
                    {audience.id === 'general' ? 'مناسب برای مخاطبان عمومی' :
                     audience.id === 'expert' ? 'مناسب برای متخصصان و حرفه‌ای‌ها' :
                     'مناسب برای محیط‌های علمی و دانشگاهی'}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}