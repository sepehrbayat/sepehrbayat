import React, { useEffect, useState } from 'react';
import { Brain, Crown, Star, Sparkles, FileText, Search, PenTool } from 'lucide-react';

interface GenerationOverlayProps {
  isVisible: boolean;
  progress: number;
  phase: 'research' | 'analysis' | 'generation' | null;
}

const phases = {
  research: {
    icon: Search,
    title: 'در حال تحقیق و جمع‌آوری اطلاعات...',
    tips: [
      'در حال جستجوی هوشمند در بیش از 100 منبع معتبر...',
      'تحلیل عمیق محتوای مرتبط با موضوع شما...',
      'بررسی جدیدترین مقالات و تحقیقات در این حوزه...',
      'استخراج داده‌های کلیدی از منابع معتبر...',
      'شناسایی الگوهای موفق در محتوای مشابه...'
    ],
    color: 'from-amber-500 to-amber-600',
    bgColor: 'from-amber-50 to-transparent',
    borderColor: 'border-amber-100'
  },
  analysis: {
    icon: Brain,
    title: 'در حال تحلیل و پردازش محتوا...',
    tips: [
      'تحلیل هوشمند ساختار و سازماندهی محتوا...',
      'بهینه‌سازی پیشرفته برای موتورهای جستجو...',
      'شناسایی و استخراج مفاهیم کلیدی موضوع...',
      'تحلیل رقابتی محتوای مشابه در این حوزه...',
      'ایجاد ساختار منحصر به فرد برای محتوای شما...'
    ],
    color: 'from-amber-500 to-amber-600',
    bgColor: 'from-amber-50 to-transparent',
    borderColor: 'border-amber-100'
  },
  generation: {
    icon: PenTool,
    title: 'در حال نگارش محتوای نهایی...',
    tips: [
      'نگارش محتوای حرفه‌ای با هوش مصنوعی پیشرفته...',
      'بهینه‌سازی محتوا برای جذب مخاطب هدف...',
      'اعمال اصول پیشرفته سئو در محتوا...',
      'ویرایش و بازبینی هوشمند متن تولید شده...',
      'اطمینان از کیفیت و یکپارچگی محتوای نهایی...'
    ],
    color: 'from-amber-500 to-amber-600',
    bgColor: 'from-amber-50 to-transparent',
    borderColor: 'border-amber-100'
  }
};

export default function GenerationOverlay({ isVisible, progress, phase }: GenerationOverlayProps) {
  const [tipIndex, setTipIndex] = useState(0);
  const [showSparkle, setShowSparkle] = useState(false);

  useEffect(() => {
    if (!isVisible) return;

    // Rotate through tips every 10 seconds
    const tipInterval = setInterval(() => {
      setTipIndex(prev => {
        const currentPhase = phase ? phases[phase] : phases.research;
        return (prev + 1) % currentPhase.tips.length;
      });
    }, 10000);

    // Show random sparkles
    const sparkleInterval = setInterval(() => {
      setShowSparkle(true);
      setTimeout(() => setShowSparkle(false), 500);
    }, 2000);

    return () => {
      clearInterval(tipInterval);
      clearInterval(sparkleInterval);
    };
  }, [isVisible, phase]);

  if (!isVisible) return null;

  const currentPhase = phase ? phases[phase] : phases.research;
  const PhaseIcon = currentPhase.icon;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 animate-fadeIn p-4 sm:p-6">
      <div className="max-w-lg w-full">
        <div className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-6 md:p-8 relative overflow-hidden">
          {/* Animated Background Pattern */}
          <div className="absolute inset-0 opacity-5">
            <div className={`absolute inset-0 bg-gradient-to-br ${currentPhase.color}`} />
            <div className="absolute inset-0" style={{
              backgroundImage: 'radial-gradient(circle at 1px 1px, #000 1px, transparent 0)',
              backgroundSize: '20px 20px sm:40px 40px',
              animation: 'patternMove 20s linear infinite'
            }} />
          </div>

          {/* Content */}
          <div className="relative">
            {/* Logo with Animated Effects */}
            <div className="flex justify-center mb-4 sm:mb-6 md:mb-8">
              <div className="relative">
                <div className={`w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 rounded-full bg-gradient-to-br ${currentPhase.color} flex items-center justify-center transform transition-transform hover:scale-105`}>
                  <PhaseIcon className="w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 text-white" />
                  {showSparkle && (
                    <div className="absolute inset-0 flex items-center justify-center animate-ping">
                      <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6 text-white" />
                    </div>
                  )}
                </div>
                <div className="absolute -top-2 -right-2 animate-bounce">
                  <Star className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6 text-amber-400 fill-amber-400" />
                </div>
                {/* Animated Ring */}
                <div className="absolute -inset-2 rounded-full border-4 border-transparent animate-spin-slow opacity-30" style={{
                  background: `linear-gradient(white, white) padding-box, linear-gradient(to right, ${currentPhase.color}) border-box`
                }} />
              </div>
            </div>

            {/* Progress Section */}
            <div className="mb-4 sm:mb-6 md:mb-8 text-center">
              <h2 className="text-lg sm:text-xl font-bold mb-2 bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
                {currentPhase.title}
              </h2>
              <div className="relative w-full h-1.5 sm:h-2 bg-gray-100 rounded-full overflow-hidden mb-2 sm:mb-4">
                <div 
                  className={`h-full bg-gradient-to-r ${currentPhase.color} transition-all duration-500 ease-out relative`}
                  style={{ width: `${progress}%` }}
                >
                  {/* Animated Pulse Effect */}
                  <div className="absolute inset-0 bg-white opacity-30 animate-pulse" />
                </div>
              </div>
              <p className="text-xs sm:text-sm text-gray-500">{progress}% تکمیل شده</p>
            </div>

            {/* Animated Tips */}
            <div className="space-y-4">
              {currentPhase.tips.map((tip, index) => (
                <div 
                  key={index}
                  className={`flex items-center gap-2 sm:gap-3 p-2 sm:p-3 bg-gradient-to-l ${currentPhase.bgColor} border ${currentPhase.borderColor} rounded-lg sm:rounded-xl transition-all duration-300 transform ${
                    index === tipIndex ? 'scale-105 shadow-md' : 'scale-100'
                  }`}
                  style={{
                    opacity: index === tipIndex ? 1 : 0.5,
                    transform: `translateX(${index === tipIndex ? '0' : '-10px'})`,
                  }}
                >
                  <div className={`w-6 h-6 sm:w-8 sm:h-8 rounded-md sm:rounded-lg bg-gradient-to-br ${currentPhase.color} flex items-center justify-center`}>
                    <PhaseIcon className="w-4 h-4 text-white" />
                  </div>
                  <p className="text-sm flex-1">{tip}</p>
                  {index === tipIndex && (
                    <Sparkles className={`w-4 h-4 text-${currentPhase.color.split('-')[1]}-500 animate-pulse`} />
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}