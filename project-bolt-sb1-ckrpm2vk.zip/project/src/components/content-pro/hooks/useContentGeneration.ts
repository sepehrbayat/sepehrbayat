import { useState } from 'react';
import { generateContent } from '../../../lib/content/generator';
import { trackActivity } from '../../../lib/activity/tracking';
import type { ContentGenerationProps } from '../types';

export function useContentGeneration({ onProgress, onError, onSuccess }: ContentGenerationProps = {}) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generate = async (topic: string, keywords: string[], headings: any[]) => {
    try {
      setIsGenerating(true);
      setError(null);
      onProgress?.('در حال تحقیق و جمع‌آوری اطلاعات...');

      // Track generation start
      await trackActivity(
        'content_generation',
        'تولید مقاله پرو',
        'شروع تولید مقاله',
        {
          prompt: topic,
          metadata: {
            keywords,
            headings
          },
          output: null
        },
        { tool_id: 'content-pro' }
      );

      onProgress?.('در حال تحلیل و پردازش محتوا...');

      const content = await generateContent({
        topic,
        keywords,
        headings,
        isPro: true,
        contentLength: 'medium' // Default to medium length
      });

      onProgress?.('در حال نگارش محتوای نهایی...');

      // Track successful generation
      await trackActivity(
        'content_generation',
        'تولید موفق مقاله',
        'مقاله با موفقیت تولید شد',
        {
          prompt: topic,
          metadata: {
            wordCount: content.wordCount,
            keywords,
            headings,
            seoScore: content.seoScore,
            readabilityScore: content.readabilityScore
          },
          output: content.content
        },
        { tool_id: 'content-pro' }
      );

      onSuccess?.(content);
      return content;

    } catch (error) {
      // Track error
      await trackActivity(
        'content_generation',
        'خطا در تولید مقاله',
        error instanceof Error ? error.message : 'خطای ناشناخته',
        {
          prompt: topic,
          metadata: {
            error: error instanceof Error ? error.message : 'Unknown error',
            keywords,
            headings
          },
          output: null
        },
        { tool_id: 'content-pro' }
      );

      const errorMessage = error instanceof Error ? error.message : 'خطا در تولید محتوا';
      console.error('Content generation error:', error);
      setError(errorMessage);
      onError?.(errorMessage);
      throw error;
    } finally {
      setIsGenerating(false);
      onProgress?.('');
    }
  };

  return {
    isGenerating,
    error,
    generate,
    setError
  };
}