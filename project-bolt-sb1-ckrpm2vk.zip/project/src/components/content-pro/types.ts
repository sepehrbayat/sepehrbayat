import { ContentPlan } from '../../types';

export interface ContentSettings {
  contentLength: 'short' | 'medium' | 'long' | 'custom';
  minWords: number;
  maxWords: number;
  style: string;
  tone: string;
  audience: string;
}

export interface ContentGenerationProps {
  onProgress?: (message: string) => void;
  onError?: (error: string) => void;
  onSuccess?: (content: ContentPlan) => void;
}