export const CONTENT_LENGTH_RANGES = {
  short: { min: 500, max: 800 },
  medium: { min: 1000, max: 1500 },
  long: { min: 2000, max: 3000 }
} as const;

export const STYLES = [
  { id: 'professional', name: 'حرفه‌ای', description: 'سبک رسمی و تخصصی' },
  { id: 'casual', name: 'دوستانه', description: 'سبک صمیمی و غیررسمی' },
  { id: 'educational', name: 'آموزشی', description: 'سبک توضیحی و آموزشی' }
] as const;

export const TONES = [
  { id: 'formal', name: 'رسمی' },
  { id: 'informal', name: 'غیررسمی' },
  { id: 'conversational', name: 'محاوره‌ای' }
] as const;

export const AUDIENCES = [
  { id: 'general', name: 'عمومی' },
  { id: 'expert', name: 'متخصص' },
  { id: 'academic', name: 'دانشگاهی' }
] as const;