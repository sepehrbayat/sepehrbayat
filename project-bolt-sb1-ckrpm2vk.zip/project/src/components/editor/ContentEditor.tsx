import React from 'react';
import RichTextEditor from './RichTextEditor';
import { Search, Book, FileText } from 'lucide-react';

interface ContentEditorProps {
  title: string;
  description: string;
  keywords: string[];
  wordCount: number;
  seoScore: number;
  readabilityScore: number;
  content: string;
  metadata?: {
    topic: string;
    style: string;
    tone: string;
    audience: string;
    targetKeyword?: string;
  };
  onContentChange: (content: string) => void;
}

export default function ContentEditor({
  title,
  description,
  keywords,
  wordCount,
  seoScore,
  readabilityScore,
  content,
  metadata,
  onContentChange
}: ContentEditorProps) {
  return (
    <div className="bg-white rounded-xl p-6 space-y-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-medium">{title}</h2>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Search className="w-4 h-4 text-[#a63439]" />
            <span className="text-sm">امتیاز سئو: {seoScore}/100</span>
          </div>
          <div className="flex items-center gap-2">
            <Book className="w-4 h-4 text-[#a63439]" />
            <span className="text-sm">خوانایی: {readabilityScore}/100</span>
          </div>
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-[#a63439]" />
            <span className="text-sm">تعداد کلمات: {wordCount}</span>
          </div>
        </div>
      </div>

      <p className="text-gray-600 mb-4">{description}</p>
      
      {metadata && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
          <div className="bg-gray-50 p-3 rounded-lg">
            <span className="text-xs text-gray-500 block mb-1">سبک</span>
            <span className="text-sm font-medium">{metadata.style}</span>
          </div>
          <div className="bg-gray-50 p-3 rounded-lg">
            <span className="text-xs text-gray-500 block mb-1">لحن</span>
            <span className="text-sm font-medium">{metadata.tone}</span>
          </div>
          <div className="bg-gray-50 p-3 rounded-lg">
            <span className="text-xs text-gray-500 block mb-1">مخاطب</span>
            <span className="text-sm font-medium">{metadata.audience}</span>
          </div>
          {metadata.targetKeyword && (
            <div className="bg-gray-50 p-3 rounded-lg">
              <span className="text-xs text-gray-500 block mb-1">کلمه کلیدی</span>
              <span className="text-sm font-medium">{metadata.targetKeyword}</span>
            </div>
          )}
        </div>
      )}
      
      <div className="flex flex-wrap gap-2 mb-6">
        {keywords.map((keyword, index) => (
          <span
            key={index}
            className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm"
          >
            {keyword}
          </span>
        ))}
      </div>

      <RichTextEditor
        content={content}
        onChange={onContentChange}
        placeholder="محتوای مقاله..."
      />
    </div>
  );
}