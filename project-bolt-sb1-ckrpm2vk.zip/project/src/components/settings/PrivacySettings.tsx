import React, { useState } from 'react';
import { Shield, Eye, Lock, Activity } from 'lucide-react';

interface PrivacySetting {
  id: string;
  title: string;
  description: string;
  enabled: boolean;
  icon: any;
}

export default function PrivacySettings() {
  const [settings, setSettings] = useState<PrivacySetting[]>([
    {
      id: 'activity',
      title: 'فعالیت‌های من',
      description: 'نمایش فعالیت‌های من به سایر کاربران',
      enabled: true,
      icon: Activity
    },
    {
      id: 'profile',
      title: 'پروفایل عمومی',
      description: 'نمایش اطلاعات پروفایل به صورت عمومی',
      enabled: false,
      icon: Eye
    },
    {
      id: '2fa',
      title: 'تایید دو مرحله‌ای',
      description: 'فعال‌سازی تایید دو مرحله‌ای برای امنیت بیشتر',
      enabled: false,
      icon: Lock
    }
  ]);

  const handleToggle = (id: string) => {
    setSettings(prev => prev.map(setting => {
      if (setting.id === id) {
        return {
          ...setting,
          enabled: !setting.enabled
        };
      }
      return setting;
    }));
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-medium mb-1">تنظیمات حریم خصوصی</h2>
        <p className="text-sm text-gray-500">حریم خصوصی و امنیت حساب خود را مدیریت کنید</p>
      </div>

      <div className="space-y-4">
        {settings.map(setting => (
          <div key={setting.id} className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#a63439]/10 flex items-center justify-center flex-shrink-0">
                <setting.icon className="w-4 h-4 text-[#a63439]" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium">{setting.title}</h3>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={setting.enabled}
                      onChange={() => handleToggle(setting.id)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-[#a63439]/20 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#a63439]"></div>
                  </label>
                </div>
                <p className="text-sm text-gray-500 mt-1">{setting.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-[#a63439]/5 rounded-lg p-4 mt-6">
        <div className="flex items-center gap-3 mb-3">
          <Shield className="w-5 h-5 text-[#a63439]" />
          <h3 className="font-medium">حریم خصوصی و امنیت</h3>
        </div>
        <p className="text-sm text-gray-600">
          ما به حریم خصوصی شما اهمیت می‌دهیم. اطلاعات شما به صورت رمزنگاری شده ذخیره می‌شود و تنها با اجازه شما به اشتراک گذاشته می‌شود.
        </p>
      </div>
    </div>
  );
}