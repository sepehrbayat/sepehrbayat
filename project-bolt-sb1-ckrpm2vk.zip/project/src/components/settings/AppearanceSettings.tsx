import React, { useState, useEffect } from 'react';
import { Moon, Sun, Globe } from 'lucide-react';
import { getUserSettings, updateUserSettings } from '../../lib/settings';
import { AlertCircle, Loader2 } from 'lucide-react';

export default function AppearanceSettings() {
  const [theme, setTheme] = useState<'light' | 'dark' | 'system'>('light');
  const [language, setLanguage] = useState<'fa' | 'en'>('fa');
  const [fontSize, setFontSize] = useState<'sm' | 'md' | 'lg'>('md');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      setIsLoading(true);
      const settings = await getUserSettings();
      if (settings) {
        setTheme(settings.theme);
        setLanguage(settings.language);
        setFontSize(settings.fontSize);
      }
    } catch (error) {
      setError(error instanceof Error ? error.message : 'خطا در دریافت تنظیمات');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      setIsSaving(true);
      setError(null);
      await updateUserSettings({
        theme,
        language,
        fontSize
      });
    } catch (error) {
      setError(error instanceof Error ? error.message : 'خطا در ذخیره تنظیمات');
    } finally {
      setIsSaving(false);
    }
  };

  const themes = [
    { id: 'light', name: 'روشن', icon: Sun },
    { id: 'dark', name: 'تیره', icon: Moon },
    { id: 'system', name: 'سیستم', icon: Moon }
  ];

  const fontSizes = [
    { id: 'sm', name: 'کوچک' },
    { id: 'md', name: 'متوسط' },
    { id: 'lg', name: 'بزرگ' }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-medium mb-1">تنظیمات ظاهری</h2>
        <p className="text-sm text-gray-500">ظاهر و زبان برنامه را شخصی‌سازی کنید</p>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <p>{error}</p>
        </div>
      )}

      <div className="space-y-6">
        <div>
          <h3 className="text-sm font-medium mb-3">تم برنامه</h3>
          <div className="grid grid-cols-3 gap-3">
            {themes.map(t => (
              <button
                key={t.id}
                onClick={() => setTheme(t.id as typeof theme)}
                className={`p-3 rounded-lg text-sm transition-colors flex items-center justify-center gap-2 ${
                  theme === t.id
                    ? 'bg-[#a63439] text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <t.icon className="w-4 h-4" />
                <span>{t.name}</span>
              </button>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-sm font-medium mb-3">زبان برنامه</h3>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => setLanguage('fa')}
              className={`p-3 rounded-lg text-sm transition-colors flex items-center justify-center gap-2 ${
                language === 'fa'
                  ? 'bg-[#a63439] text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <Globe className="w-4 h-4" />
              <span>فارسی</span>
            </button>
            <button
              onClick={() => setLanguage('en')}
              className={`p-3 rounded-lg text-sm transition-colors flex items-center justify-center gap-2 ${
                language === 'en'
                  ? 'bg-[#a63439] text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <Globe className="w-4 h-4" />
              <span>English</span>
            </button>
          </div>
        </div>

        <div>
          <h3 className="text-sm font-medium mb-3">اندازه متن</h3>
          <div className="grid grid-cols-3 gap-3">
            {fontSizes.map(size => (
              <button
                key={size.id}
                onClick={() => setFontSize(size.id as typeof fontSize)}
                className={`p-3 rounded-lg text-sm transition-colors ${
                  fontSize === size.id
                    ? 'bg-[#a63439] text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {size.name}
              </button>
            ))}
          </div>
        </div>
      </div>
      
      <button
        onClick={handleSave}
        disabled={isSaving}
        className="mt-6 bg-[#a63439] text-white px-6 py-2 rounded-lg flex items-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
      >
        {isSaving ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>در حال ذخیره...</span>
          </>
        ) : (
          <span>ذخیره تغییرات</span>
        )}
      </button>
    </div>
  );
}