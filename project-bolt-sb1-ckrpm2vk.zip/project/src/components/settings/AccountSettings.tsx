import React, { useState } from 'react';
import { Key, Trash2, Download, AlertCircle, Loader2 } from 'lucide-react';
import { useAuth } from '../../lib/auth/AuthContext'; 
import { supabase } from '../../lib/supabase';
import { deleteAccount, exportUserData } from '../../lib/settings';

export default function AccountSettings() {
  const { user } = useAuth();
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleChangePassword = async () => {
    try {
      setIsChangingPassword(true);
      setError(null);
      
      const { error } = await supabase.auth.updateUser({
        password: 'new-password' // TODO: Get from form input
      });

      if (error) throw error;

    } catch (error) {
      setError(error instanceof Error ? error.message : 'خطا در تغییر رمز عبور');
    } finally {
      setIsChangingPassword(false);
    }
  };

  const handleExportData = async () => {
    try {
      setIsExporting(true);
      setError(null);
      
      const blob = await exportUserData();
      
      // Create download link
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `hooshex-data-${new Date().toISOString()}.json`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

    } catch (error) {
      setError(error instanceof Error ? error.message : 'خطا در خروجی گرفتن از اطلاعات');
    } finally {
      setIsExporting(false);
    }
  };

  const handleDeleteAccount = async () => {
    try {
      setIsDeleting(true);
      setError(null);
      
      await deleteAccount();
      navigate('/auth');

    } catch (error) {
      setError(error instanceof Error ? error.message : 'خطا در حذف حساب کاربری');
    } finally {
      setIsDeleting(false);
      setShowDeleteConfirm(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-medium mb-1">تنظیمات حساب کاربری</h2>
        <p className="text-sm text-gray-500">تنظیمات امنیتی و مدیریت حساب کاربری</p>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <p>{error}</p>
        </div>
      )}

      <div className="space-y-4">
        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#a63439]/10 flex items-center justify-center">
                <Key className="w-4 h-4 text-[#a63439]" />
              </div>
              <div>
                <h3 className="font-medium">تغییر رمز عبور</h3>
                <p className="text-sm text-gray-500">رمز عبور حساب کاربری خود را تغییر دهید</p>
              </div>
            </div>
            <button
              onClick={handleChangePassword}
              disabled={isChangingPassword}
              className="bg-[#a63439] text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
            >
              {isChangingPassword ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>در حال تغییر...</span>
                </>
              ) : (
                <span>تغییر رمز عبور</span>
              )}
            </button>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#a63439]/10 flex items-center justify-center">
                <Download className="w-4 h-4 text-[#a63439]" />
              </div>
              <div>
                <h3 className="font-medium">خروجی گرفتن از اطلاعات</h3>
                <p className="text-sm text-gray-500">دریافت نسخه پشتیبان از اطلاعات حساب کاربری</p>
              </div>
            </div>
            <button
              onClick={handleExportData}
              disabled={isExporting}
              className="bg-[#a63439] text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
            >
              {isExporting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>در حال آماده‌سازی...</span>
                </>
              ) : (
                <span>دریافت خروجی</span>
              )}
            </button>
          </div>
        </div>

        <div className="bg-red-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-red-100 flex items-center justify-center">
                <Trash2 className="w-4 h-4 text-red-600" />
              </div>
              <div>
                <h3 className="font-medium text-red-600">حذف حساب کاربری</h3>
                <p className="text-sm text-red-500">این عملیات غیرقابل بازگشت است</p>
              </div>
            </div>
            {showDeleteConfirm ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="px-3 py-1.5 rounded-lg text-sm bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors"
                >
                  انصراف
                </button>
                <button
                  onClick={handleDeleteAccount}
                  disabled={isDeleting}
                  className="bg-red-600 text-white px-3 py-1.5 rounded-lg text-sm flex items-center gap-2 hover:bg-red-700 transition-colors disabled:opacity-50"
                >
                  {isDeleting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>در حال حذف...</span>
                    </>
                  ) : (
                    <span>تایید حذف</span>
                  )}
                </button>
              </div>
            ) : (
              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="text-red-600 hover:text-red-700 px-4 py-2 rounded-lg text-sm transition-colors"
              >
                حذف حساب
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}