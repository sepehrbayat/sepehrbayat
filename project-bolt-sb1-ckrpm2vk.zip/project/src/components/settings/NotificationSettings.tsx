import React, { useState } from 'react';
import { Bell, Mail, MessageSquare, Star } from 'lucide-react';

interface NotificationSetting {
  id: string;
  title: string;
  description: string;
  email: boolean;
  push: boolean;
  icon: any;
}

export default function NotificationSettings() {
  const [settings, setSettings] = useState<NotificationSetting[]>([
    {
      id: 'updates',
      title: 'به‌روزرسانی‌ها',
      description: 'اطلاع‌رسانی درباره ویژگی‌های جدید و به‌روزرسانی‌ها',
      email: true,
      push: true,
      icon: Bell
    },
    {
      id: 'messages',
      title: 'پیام‌ها',
      description: 'دریافت پیام‌های جدید از پشتیبانی',
      email: true,
      push: true,
      icon: MessageSquare
    },
    {
      id: 'marketing',
      title: 'پیشنهادات ویژه',
      description: 'اطلاع از تخفیف‌ها و پیشنهادات ویژه',
      email: false,
      push: false,
      icon: Star
    }
  ]);

  const handleToggle = (id: string, type: 'email' | 'push') => {
    setSettings(prev => prev.map(setting => {
      if (setting.id === id) {
        return {
          ...setting,
          [type]: !setting[type]
        };
      }
      return setting;
    }));
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-medium mb-1">تنظیمات اعلان‌ها</h2>
        <p className="text-sm text-gray-500">نحوه دریافت اعلان‌ها را مدیریت کنید</p>
      </div>

      <div className="space-y-4">
        {settings.map(setting => (
          <div key={setting.id} className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-start gap-3 mb-4">
              <div className="w-8 h-8 rounded-lg bg-[#a63439]/10 flex items-center justify-center flex-shrink-0">
                <setting.icon className="w-4 h-4 text-[#a63439]" />
              </div>
              <div>
                <h3 className="font-medium">{setting.title}</h3>
                <p className="text-sm text-gray-500">{setting.description}</p>
              </div>
            </div>
            <div className="flex items-center gap-6">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={setting.email}
                  onChange={() => handleToggle(setting.id, 'email')}
                  className="rounded text-[#a63439] focus:ring-[#a63439]"
                />
                <span className="text-sm">ایمیل</span>
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={setting.push}
                  onChange={() => handleToggle(setting.id, 'push')}
                  className="rounded text-[#a63439] focus:ring-[#a63439]"
                />
                <span className="text-sm">اعلان مرورگر</span>
              </label>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}