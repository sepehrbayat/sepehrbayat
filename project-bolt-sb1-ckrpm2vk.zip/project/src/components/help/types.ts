export interface HelpLink {
  title: string;
  url: string;
}

export interface HelpItem {
  title: string;
  content: React.ReactNode;
  links?: HelpLink[];
}