import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import type { HelpItem } from './types';

interface HelpCategoryProps {
  title: string;
  description: string;
  icon: any;
  items: HelpItem[];
}

export default function HelpCategory({ title, description, icon: Icon, items }: HelpCategoryProps) {
  const [expandedItem, setExpandedItem] = useState<number | null>(null);

  return (
    <div className="bg-white rounded-xl p-6 space-y-4">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-[#a63439]/10 flex items-center justify-center">
          <Icon className="w-5 h-5 text-[#a63439]" />
        </div>
        <div>
          <h2 className="font-medium">{title}</h2>
          <p className="text-sm text-gray-500">{description}</p>
        </div>
      </div>
      <div className="space-y-2">
        {items.map((item, index) => (
          <div key={index} className="border border-gray-100 rounded-lg overflow-hidden">
            <button
              onClick={() => setExpandedItem(expandedItem === index ? null : index)}
              className="w-full text-right p-3 text-sm hover:bg-gray-50 transition-colors flex items-center justify-between"
            >
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-[#a63439]" />
                {item.title}
              </div>
              {expandedItem === index ? (
                <ChevronUp className="w-4 h-4 text-gray-400" />
              ) : (
                <ChevronDown className="w-4 h-4 text-gray-400" />
              )}
            </button>
            {expandedItem === index && (
              <div className="p-4 bg-gray-50 border-t border-gray-100 animate-fadeIn">
                <div className="prose prose-sm max-w-none">
                  {item.content}
                </div>
                {item.links && item.links.length > 0 && (
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <h4 className="text-sm font-medium mb-2">لینک‌های مرتبط:</h4>
                    <div className="space-y-1">
                      {item.links.map((link, linkIndex) => (
                        <a
                          key={linkIndex}
                          href={link.url}
                          className="text-[#a63439] hover:text-[#8a2a2e] text-sm block"
                        >
                          {link.title}
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}