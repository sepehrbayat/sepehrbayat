import React from 'react';
import { HelpCircle } from 'lucide-react';

interface HelpHeaderProps {
  title: string;
  description: string;
}

export default function HelpHeader({ title, description }: HelpHeaderProps) {
  return (
    <div className="flex items-center gap-3 mb-4">
      <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#a63439] to-[#262e43] flex items-center justify-center">
        <HelpCircle className="w-5 h-5 text-white" />
      </div>
      <div>
        <h1 className="text-2xl font-medium mb-1">{title}</h1>
        <p className="text-gray-600">{description}</p>
      </div>
    </div>
  );
}