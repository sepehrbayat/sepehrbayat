import React from 'react';
import { Brain, MessageSquare } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function SmartAssistant() {
  const navigate = useNavigate();

  return (
    <div className="bg-[#a63439]/5 border border-[#a63439]/10 rounded-xl p-6">
      <div className="flex items-center gap-4 mb-4">
        <Brain className="w-6 h-6 text-[#a63439]" />
        <h2 className="text-lg font-medium">دستیار هوشمند</h2>
      </div>
      <p className="text-gray-700 mb-4">
        می‌توانید سوالات خود را از دستیار هوشمند هوشِکس بپرسید. دستیار ما آماده کمک به شما در تمامی زمینه‌هاست.
      </p>
      <button
        onClick={() => navigate('/chat')}
        className="bg-[#a63439] text-white px-6 py-3 rounded-lg flex items-center gap-2 hover:bg-[#8a2a2e] transition-all"
      >
        <MessageSquare className="w-5 h-5" />
        <span>گفتگو با دستیار هوشمند</span>
      </button>
    </div>
  );
}