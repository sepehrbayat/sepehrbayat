import React from 'react';
import type { HelpItem } from '../components/help/types';

export const toolsHelp: HelpItem[] = [
  {
    title: 'تولید محتوا با هوش مصنوعی',
    content: (
      <div className="space-y-2">
        <p>
          با استفاده از ابزار تولید محتوای هوشِکس می‌توانید به سرعت محتوای با کیفیت و بهینه برای سئو تولید کنید.
          این ابزار از پیشرفته‌ترین مدل‌های هوش مصنوعی برای تولید محتوا استفاده می‌کند.
        </p>
        <ul className="list-disc list-inside space-y-1">
          <li>انتخاب موضوع و کلمات کلیدی</li>
          <li>تنظیم سبک و لحن محتوا</li>
          <li>تولید خودکار ساختار مقاله</li>
          <li>بهینه‌سازی برای موتورهای جستجو</li>
        </ul>
      </div>
    ),
    links: [
      { title: 'آموزش تولید محتوا', url: '/blog/content-generation' },
      { title: 'نکات سئو در تولید محتوا', url: '/blog/seo-tips' }
    ]
  },
  {
    title: 'تحلیل سئو سایت',
    content: (
      <div className="space-y-2">
        <p>
          ابزار تحلیل سئو هوشِکس به شما کمک می‌کند تا وضعیت سئو سایت خود را بررسی کرده و نقاط ضعف و قوت آن را شناسایی کنید.
        </p>
        <ul className="list-disc list-inside space-y-1">
          <li>تحلیل جامع فاکتورهای سئو</li>
          <li>بررسی سرعت و عملکرد سایت</li>
          <li>تحلیل محتوا و کلمات کلیدی</li>
          <li>پیشنهادات بهبود سئو</li>
        </ul>
      </div>
    ),
    links: [
      { title: 'راهنمای تحلیل سئو', url: '/blog/seo-analysis' }
    ]
  }
];

export const faqHelp: HelpItem[] = [
  {
    title: 'چگونه شروع کنم؟',
    content: (
      <div className="space-y-2">
        <p>
          برای شروع کار با هوشِکس، مراحل زیر را دنبال کنید:
        </p>
        <ol className="list-decimal list-inside space-y-1">
          <li>ثبت‌نام و ایجاد حساب کاربری</li>
          <li>تکمیل اطلاعات پروفایل</li>
          <li>انتخاب ابزار مورد نظر</li>
          <li>شروع استفاده از امکانات</li>
        </ol>
      </div>
    )
  },
  {
    title: 'هزینه استفاده چقدر است؟',
    content: (
      <div className="space-y-2">
        <p>
          هوشِکس دارای پلن‌های مختلف متناسب با نیاز شماست:
        </p>
        <ul className="list-disc list-inside space-y-1">
          <li>پلن رایگان: دسترسی به امکانات پایه</li>
          <li>پلن حرفه‌ای: دسترسی به تمام ابزارها</li>
          <li>پلن سازمانی: مناسب برای تیم‌ها</li>
        </ul>
      </div>
    ),
    links: [
      { title: 'مقایسه پلن‌ها', url: '/pricing' }
    ]
  }
];

export const supportHelp: HelpItem[] = [
  {
    title: 'تماس با پشتیبانی',
    content: (
      <div className="space-y-2">
        <p>
          تیم پشتیبانی هوشِکس به صورت 24/7 آماده پاسخگویی به سوالات شماست.
          راه‌های ارتباطی:
        </p>
        <ul className="list-disc list-inside space-y-1">
          <li>چت آنلاین</li>
          <li>تیکت پشتیبانی</li>
          <li>ایمیل: support@hooshex.com</li>
        </ul>
      </div>
    )
  },
  {
    title: 'گزارش مشکل',
    content: (
      <div className="space-y-2">
        <p>
          در صورت مشاهده هرگونه مشکل فنی، می‌توانید از طریق فرم گزارش مشکل،
          جزئیات را با تیم فنی ما در میان بگذارید.
        </p>
        <button className="text-[#a63439] hover:text-[#8a2a2e] font-medium">
          ارسال گزارش مشکل
        </button>
      </div>
    )
  }
];