import type { ImageGenerationConfig } from './types';

export const DEFAULT_CONFIG: ImageGenerationConfig = {
  maxConcurrentRequests: 3,
  requestTimeout: 30000, // 30 seconds
  maxRetries: 10,
  initialRetryDelay: 1000, // 1 second
  maxRetryDelay: 30000, // 30 seconds
  maxTotalWaitTime: 300000, // 5 minutes
  jitterFactor: 0.1 // 10% jitter
};

export const ERROR_CODES = {
  TIMEOUT: 'TIMEOUT',
  NETWORK: 'NETWORK',
  API: 'API',
  VALIDATION: 'VALIDATION',
  TRANSLATION: 'TRANSLATION',
  UNKNOWN: 'UNKNOWN'
} as const;

export const ERROR_MESSAGES = {
  [ERROR_CODES.TIMEOUT]: 'زمان درخواست به پایان رسید',
  [ERROR_CODES.NETWORK]: 'خطا در ارتباط با سرور',
  [ERROR_CODES.API]: 'خطا در سرویس تولید تصویر',
  [ERROR_CODES.VALIDATION]: 'پارامترهای ورودی نامعتبر هستند',
  [ERROR_CODES.TRANSLATION]: 'خطا در ترجمه متن',
  [ERROR_CODES.UNKNOWN]: 'خطای ناشناخته'
} as const;