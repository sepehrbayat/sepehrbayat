import { DEFAULT_CONFIG } from './config';
import { isRetryableError } from './errors';
import type { ImageGenerationConfig } from './types';

function calculateDelay(attempt: number, config: ImageGenerationConfig): number {
  const baseDelay = Math.min(
    config.initialRetryDelay * Math.pow(2, attempt - 1),
    config.maxRetryDelay
  );
  
  // Add jitter to prevent thundering herd
  const jitter = baseDelay * config.jitterFactor * (Math.random() * 2 - 1);
  return Math.max(0, baseDelay + jitter);
}

export async function withRetry<T>(
  operation: () => Promise<T>,
  config: Partial<ImageGenerationConfig> = {}
): Promise<T> {
  const finalConfig = { ...DEFAULT_CONFIG, ...config };
  const startTime = Date.now();
  let lastError: Error | null = null;

  for (let attempt = 1; attempt <= finalConfig.maxRetries; attempt++) {
    try {
      // Check if we've exceeded maxTotalWaitTime
      if (Date.now() - startTime > finalConfig.maxTotalWaitTime) {
        throw new Error('زمان کل عملیات به پایان رسید');
      }

      // Add timeout to the operation
      const timeoutPromise = new Promise<never>((_, reject) => {
        setTimeout(() => reject(new Error('TIMEOUT')), finalConfig.requestTimeout);
      });

      const result = await Promise.race([operation(), timeoutPromise]);
      return result;

    } catch (error: any) {
      lastError = error;
      
      // Don't retry if error is not retryable or we're out of attempts
      if (!isRetryableError(error) || attempt === finalConfig.maxRetries) {
        break;
      }

      // Calculate and apply delay with jitter
      const delay = calculateDelay(attempt, finalConfig);
      await new Promise(resolve => setTimeout(resolve, delay));
      
      console.warn(`Retry attempt ${attempt} after ${delay}ms delay:`, error);
    }
  }

  throw lastError || new Error('خطای ناشناخته در عملیات');
}