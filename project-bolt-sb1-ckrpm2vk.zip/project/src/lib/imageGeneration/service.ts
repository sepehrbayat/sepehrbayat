import { DEFAULT_CONFIG, ERROR_CODES } from './config';
import { ImageGenerationException, RetryableError } from './errors';
import { withRetry } from './retry';
import { requestQueue } from './queue';
import { openai } from '../openai';
import type { 
  ImageGenerationConfig,
  ImageGenerationOptions,
  ImageGenerationResult,
  ImageGenerationProgress
} from './types';

const OPENAI_API_KEY = import.meta.env.VITE_OPENAI_API_KEY;

// DALL-E size options
const DALLE_SIZES = {
  'dall-e-2': ['256x256', '512x512', '1024x1024'],
  'dall-e-3': ['1024x1024', '1024x1792', '1792x1024']
} as const;

// Validate API key is configured
if (!OPENAI_API_KEY) {
  console.error('Missing OPENAI_API_KEY environment variable');
}

export interface GenerateImageParams {
  prompt: string;
  width?: string;
  height?: string;
  isPro?: boolean;
  quality?: 'standard' | 'hd';
  style?: 'vivid' | 'natural';
  mood?: string;
  lighting?: string;
  composition?: string;
  perspective?: string;
  colorScheme?: string;
  negativePrompt?: string;
}

export async function generateImage(params: GenerateImageParams) {
  // Determine model and size
  const model = params.isPro ? "dall-e-3" : "dall-e-2";
  const size = `${params.width}x${params.height}`;

  // Validate size based on model
  if (!DALLE_SIZES[model].includes(size)) {
    throw new Error(
      params.isPro 
        ? 'برای DALL-E 3 فقط سایزهای 1024x1024، 1024x1792 و 1792x1024 مجاز هستند'
        : 'برای DALL-E 2 فقط سایزهای 256x256، 512x512 و 1024x1024 مجاز هستند'
    );
  }

  // Enhance prompt with selected settings
  let enhancedPrompt = params.prompt;
  
  if (params.mood) {
    enhancedPrompt += `, ${params.mood} mood`;
  }
  
  if (params.lighting) {
    enhancedPrompt += `, ${params.lighting} lighting`;
  }
  
  if (params.composition) {
    enhancedPrompt += `, ${params.composition} composition`;
  }
  
  if (params.perspective) {
    enhancedPrompt += `, ${params.perspective} view`;
  }
  
  if (params.colorScheme) {
    enhancedPrompt += `, ${params.colorScheme} color scheme`;
  }

  // Add quality keywords
  enhancedPrompt += `, masterpiece, best quality, highly detailed, sharp focus, professional lighting, 8k uhd`;
  const response = await fetch("https://api.openai.com/v1/images/generations", {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${OPENAI_API_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model,
      prompt: enhancedPrompt,
      negative_prompt: params.negativePrompt,
      n: params.isPro ? 1 : Math.min(parseInt(params.samples || "1"), 10),
      size: `${params.width}x${params.height}`,
      ...(params.isPro && {
        quality: params.quality || "standard",
        style: params.style || "vivid"
      })
    })
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error?.error?.message || 'Failed to generate image');
  }

  const data = await response.json();
  
  if (!data?.data?.[0]?.url) {
    throw new Error('No image URL in response');
  }

  return {
    status: 'success',
    output: [data.data[0].url]
  };
}

export class ImageGenerationService {
  private config: ImageGenerationConfig;

  constructor(config: Partial<ImageGenerationConfig> = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  async generateImage(options: ImageGenerationOptions): Promise<ImageGenerationResult> {
    const startTime = Date.now();
    let retryCount = 0;
    try {
      // Validate input
      this.validateInput(options);

      // Update progress
      this.updateProgress(options, 'pending', 0);

      // Translate prompt if needed
      const translatedPrompt = await this.translatePrompt(options.prompt);
      
      // Queue the request
      const result = await requestQueue.add(async () => {
        try {
          // Update progress
          this.updateProgress(options, 'processing', 25);

          // Generate image with retries
          const imageUrl = await withRetry(
            async () => {
              retryCount++;
              return await this.makeImageRequest(translatedPrompt, options);
            },
            {
              maxRetries: this.config.maxRetries,
              timeout: this.config.requestTimeout
            }
          );

          // Validate response
          if (!imageUrl) {
            throw new Error('پاسخی از سرور دریافت نشد');
          }

          // Update progress
          this.updateProgress(options, 'completed', 100);

          return {
            url: imageUrl,
            metadata: {
              generationTime: Date.now() - startTime,
              retryCount
            }
          };

        } catch (error) {
          // Update progress with error
          this.updateProgress(options, 'failed', 0, this.normalizeError(error));
          throw error;
        }
      });

      return result;

    } catch (error) {
      const normalizedError = this.normalizeError(error);
      throw new ImageGenerationException(
        normalizedError.code as keyof typeof ERROR_CODES,
        normalizedError.message,
        normalizedError.details,
        normalizedError.retryable
      );
    }
  }

  private validateInput(options: ImageGenerationOptions) {
    if (!options.prompt?.trim()) {
      throw new ImageGenerationException(ERROR_CODES.VALIDATION, 'پرامپت نمی‌تواند خالی باشد');
    }

    if (options.width && (options.width < 64 || options.width > 1024)) {
      throw new ImageGenerationException(ERROR_CODES.VALIDATION, 'عرض تصویر باید بین 64 و 1024 پیکسل باشد');
    }

    if (options.height && (options.height < 64 || options.height > 1024)) {
      throw new ImageGenerationException(ERROR_CODES.VALIDATION, 'ارتفاع تصویر باید بین 64 و 1024 پیکسل باشد');
    }
  }

  private async translatePrompt(prompt: string): Promise<string> {
    try {
      const response = await openai.chat.completions.create({
        model: DEFAULT_MODEL,
        messages: [
          {
            role: 'system',
            content: `You are an expert in translating image prompts from Persian to English. Your task:

1. Translation Approach:
   - Precise translation of core concepts
   - Preservation of artistic intent
   - Enhancement of visual descriptions

2. Technical Details:
   - Professional photography terms
   - Artistic style descriptors
   - Composition keywords
   - Lighting terminology
   - Material and texture details

IMPORTANT: Return ONLY the translated text, without any explanations or additional text.`
          },
          {
            role: 'user',
            content: prompt.trim()
          }
        ]
      });

      const translatedText = response.choices[0]?.message?.content;
      if (!translatedText) {
        throw new RetryableError(ERROR_CODES.TRANSLATION);
      }

      return translatedText;

    } catch (error) {
      throw new RetryableError(
        ERROR_CODES.TRANSLATION,
        'خطا در ترجمه پرامپت',
        { originalError: error }
      );
    }
  }

  private async makeImageRequest(
    prompt: string,
    options: ImageGenerationOptions
  ): Promise<string> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.config.requestTimeout);

    // Determine model and size
    const model = options.isPro ? "dall-e-3" : "dall-e-2";
    const size = `${options.width || 1024}x${options.height || 1024}`;

    // Validate size based on model
    if (!DALLE_SIZES[model].includes(size)) {
      throw new Error(
        options.isPro 
          ? 'برای DALL-E 3 فقط سایزهای 1024x1024، 1024x1792 و 1792x1024 مجاز هستند'
          : 'برای DALL-E 2 فقط سایزهای 256x256، 512x512 و 1024x1024 مجاز هستند'
      );
    }

    // Add quality keywords to the prompt
    const enhancedPrompt = `${prompt}, masterpiece, best quality, highly detailed, sharp focus, 8k uhd, professional lighting`;

    try {
      const response = await fetch("https://api.openai.com/v1/images/generations", {
        method: 'POST',
        signal: controller.signal,
        headers: {
          'Authorization': `Bearer ${OPENAI_API_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model,
          prompt: enhancedPrompt,
          n: options.isPro ? 1 : Math.min(parseInt(options.samples || "1"), 10),
          size: `${options.width || 1024}x${options.height || 1024}`,
          ...(options.isPro ? {
            quality: options.quality || "standard",
            style: options.style || "vivid"
          } : {})
        })
      });

      if (!response.ok) {
        // Handle specific error cases
        if (response.status === 429) {
          throw new RetryableError(ERROR_CODES.API, 'محدودیت تعداد درخواست. لطفاً کمی صبر کنید');
        }
        if (response.status >= 500) {
          throw new RetryableError(ERROR_CODES.API, 'خطای سرور. لطفاً دوباره تلاش کنید');
        }
        if (response.status === 401) {
          throw new ImageGenerationException(ERROR_CODES.API, 'خطای احراز هویت API');
        }
        throw new RetryableError(ERROR_CODES.API, 'خطا در ارتباط با سرور');
      }

      const data = await response.json();
      
      if (!data || !data.data || !Array.isArray(data.data)) {
        const errorMessage = data?.error?.message || 'خطا در تولید تصویر';
        throw new RetryableError(ERROR_CODES.API, errorMessage);
      }

      if (data.data.length === 0) {
        throw new RetryableError(ERROR_CODES.API, 'خطا در دریافت تصویر');
      }

      return data.data[0].url;

    } catch (error) {
      if (error.name === 'AbortError') {
        throw new RetryableError(ERROR_CODES.TIMEOUT, 'زمان درخواست به پایان رسید');
      }

      // Convert fetch errors to retryable errors
      if (error instanceof TypeError && error.message.includes('fetch')) {
        throw new RetryableError(ERROR_CODES.NETWORK, 'خطا در ارتباط با سرور');
      }
      throw error;
    } finally {
      clearTimeout(timeout);
    }
  }

  private updateProgress(
    options: ImageGenerationOptions,
    status: ImageGenerationProgress['status'],
    progress: number,
    error?: ImageGenerationProgress['error']
  ) {
    if (options.onProgress && options.scene) {
      options.onProgress({
        sceneId: options.scene.id,
        status,
        progress,
        error
      });
    }
  }

  private normalizeError(error: any): ImageGenerationError {
    if (error instanceof ImageGenerationException) {
      return error.toJSON();
    }

    // Network errors
    if (error instanceof TypeError && error.message.includes('fetch')) {
      return {
        code: ERROR_CODES.NETWORK,
        message: 'خطا در ارتباط با سرور',
        details: error,
        retryable: true
      };
    }

    // Timeout errors
    if (error.message === 'TIMEOUT') {
      return {
        code: ERROR_CODES.TIMEOUT,
        message: 'زمان درخواست به پایان رسید',
        details: error,
        retryable: true
      };
    }

    return {
      code: ERROR_CODES.UNKNOWN,
      message: error?.message || 'خطای ناشناخته',
      details: error,
      retryable: false
    };
  }
}

// Create and export singleton instance
export const imageService = new ImageGenerationService();