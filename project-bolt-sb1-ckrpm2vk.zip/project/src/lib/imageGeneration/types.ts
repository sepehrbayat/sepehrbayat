import type { ScriptScene } from '../../components/script/types';

export interface ImageGenerationConfig {
  maxConcurrentRequests: number;
  requestTimeout: number;
  maxRetries: number;
  initialRetryDelay: number;
  maxRetryDelay: number;
  maxTotalWaitTime: number;
  jitterFactor: number;
}

export interface ImageGenerationResult {
  url: string;
  metadata?: {
    generationTime: number;
    retryCount: number;
    error?: string;
  };
}

export interface ImageGenerationError {
  code: string;
  message: string;
  details?: any;
  retryable: boolean;
}

export interface ImageGenerationProgress {
  sceneId: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  progress: number;
  error?: ImageGenerationError;
}

export interface ImageGenerationOptions {
  prompt: string;
  width?: number;
  height?: number;
  negativePrompt?: string;
  isPro?: boolean;
  quality?: 'standard' | 'hd';
  style?: 'vivid' | 'natural';
  samples?: string;
  quality?: 'standard' | 'hd';
  style?: 'vivid' | 'natural';
  scene?: ScriptScene;
  onProgress?: (progress: ImageGenerationProgress) => void;
}

export interface VideoGenerationOptions {
  prompt: string;
  width?: number;
  height?: number;
}

export interface VideoGenerationResponse {
  status: 'success' | 'processing' | 'failed';
  output?: string[];
  error?: {
    message: string;
    code: string;
  };
  message?: string;
  id?: string;
  meta?: Record<string, any>;
}