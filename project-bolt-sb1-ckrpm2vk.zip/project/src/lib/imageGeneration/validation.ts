import { ValidationError } from '../errors';
import { validatePrompt, validateDimensions, validateRetryOptions } from '../validation';
import type { ImageGenerationOptions } from './types';

export function validateImageGenerationOptions(options: ImageGenerationOptions): void {
  // Validate required fields
  validatePrompt(options.prompt);
  
  // Validate dimensions if provided
  validateDimensions(options.width, options.height);
  
  // Validate retry options if provided
  validateRetryOptions(options.maxRetries, options.timeout);
  
  // Validate negative prompt if provided
  if (options.negativePrompt && options.negativePrompt.length > 500) {
    throw new ValidationError('طول پرامپت منفی نباید بیشتر از 500 کاراکتر باشد');
  }
  
  // Validate scene if provided
  if (options.scene) {
    if (!options.scene.id) {
      throw new ValidationError('شناسه صحنه الزامی است');
    }
    
    if (!options.scene.title?.trim()) {
      throw new ValidationError('عنوان صحنه الزامی است');
    }
  }
}