import { ValidationError } from './errors';

// Common validation functions
export function validatePrompt(prompt: string): void {
  if (!prompt?.trim()) {
    throw new ValidationError('پرامپت نمی‌تواند خالی باشد');
  }
  
  if (prompt.length > 1000) {
    throw new ValidationError('طول پرامپت نباید بیشتر از 1000 کاراکتر باشد');
  }
}

export function validateDimensions(width?: number, height?: number): void {
  if (width && (width < 64 || width > 1024 || width % 8 !== 0)) {
    throw new ValidationError('عرض تصویر باید بین 64 و 1024 پیکسل و مضربی از 8 باشد');
  }

  if (height && (height < 64 || height > 1024 || height % 8 !== 0)) {
    throw new ValidationError('ارتفاع تصویر باید بین 64 و 1024 پیکسل و مضربی از 8 باشد');
  }
}

export function validateSceneDescription(description: string): void {
  if (!description?.trim()) {
    throw new ValidationError('توضیحات صحنه نمی‌تواند خالی باشد');
  }
  
  if (description.length > 2000) {
    throw new ValidationError('طول توضیحات صحنه نباید بیشتر از 2000 کاراکتر باشد');
  }
}

export function validateScriptIdea(idea: string): void {
  if (!idea?.trim()) {
    throw new ValidationError('ایده سناریو نمی‌تواند خالی باشد');
  }
  
  if (idea.length > 3000) {
    throw new ValidationError('طول ایده نباید بیشتر از 3000 کاراکتر باشد');
  }
}

export function validateRetryOptions(maxRetries?: number, timeout?: number): void {
  if (maxRetries !== undefined && (maxRetries < 0 || !Number.isInteger(maxRetries))) {
    throw new ValidationError('تعداد تلاش‌های مجدد باید عدد صحیح مثبت باشد');
  }

  if (timeout !== undefined && (timeout < 1000 || !Number.isInteger(timeout))) {
    throw new ValidationError('مهلت زمانی باید حداقل 1000 میلی‌ثانیه باشد');
  }
}

export function sanitizeText(text: string): string {
  return text
    .trim()
    .replace(/[\u200B-\u200D\uFEFF]/g, '') // Remove zero-width characters
    .replace(/[\u064B-\u065F]/g, '')  // Remove Arabic diacritics
    .replace(/\s+/g, ' '); // Normalize whitespace
}

export function validatePlatform(platform: string): void {
  const validPlatforms = ['instagram', 'youtube'];
  if (!validPlatforms.includes(platform)) {
    throw new ValidationError('پلتفرم انتخاب شده معتبر نیست');
  }
}

export function validateStyle(style: string): void {
  const validStyles = [
    'podcast', 'mystery', 'hook', 'trend', 'storytelling',
    'tutorial', 'vlog', 'review', 'challenge', 'behindTheScenes'
  ];
  if (!validStyles.includes(style)) {
    throw new ValidationError('سبک انتخاب شده معتبر نیست');
  }
}

export function validateGenre(genre: string): void {
  const validGenres = ['drama', 'comedy', 'action', 'documentary', 'educational', 'commercial'];
  if (!validGenres.includes(genre)) {
    throw new ValidationError('ژانر انتخاب شده معتبر نیست');
  }
}

export function validateDuration(duration: string, platform: string): void {
  const validDurations = {
    instagram: ['reels', 'short'],
    youtube: ['short', 'medium', 'long']
  };
  
  if (!validDurations[platform]?.includes(duration)) {
    throw new ValidationError('مدت زمان انتخاب شده برای این پلتفرم معتبر نیست');
  }
}