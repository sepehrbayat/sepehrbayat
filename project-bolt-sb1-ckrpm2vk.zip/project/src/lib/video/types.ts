export interface GenerateResponse {
  status: 'SUCCEEDED' | 'RUNNING' | 'FAILED' | 'PENDING' | 'CANCELLED' | 'THROTTLED';
  output?: string[];
  id?: string;
  fetch_result?: string;
  eta?: number;
  // For HTTP errors (4xx/5xx)
  error?: {
    message: string;
    field?: string;
    reason?: string;
  };
  // For task failures
  failure?: string;
  failureCode?: string;
  progress?: number;
  message?: string;
}

export interface TaskResponse {
  id: string;
  status: 'SUCCEEDED' | 'RUNNING' | 'FAILED' | 'PENDING' | 'CANCELLED' | 'THROTTLED';
  createdAt: string;
  output?: string[];
  failure?: string;
  failureCode?: string;
  progress?: number;
  eta?: number;
  message?: string;
}

export interface ImageToVideoOptions {
  image: string;
  promptText?: string;
  duration?: 5 | 10; // Only allow 5 or 10 seconds
  ratio?: '1280:768' | '768:1280'; // Restrict to valid ratios
  seed?: number;
}