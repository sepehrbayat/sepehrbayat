import { ValidationError } from '../errors';

interface ImageToVideoOptions {
  image?: string;
  prompt?: string;
  duration: 5 | 10;
  orientation: 'landscape' | 'portrait';
}

interface GenerateResponse {
  status: 'success' | 'processing' | 'failed';
  output?: string[];
  fetch_result?: string;
  eta?: number;
  error?: {
    message: string;
    code: string;
  };
}

const RUNWAY_API_KEY = import.meta.env.VITE_RUNWAY_API_KEY;
const RUNWAY_API_URL = "https://api.runwayml.com/v1";

if (!RUNWAY_API_KEY) {
  console.error('Missing RUNWAY_API_KEY environment variable');
}

export async function generateVideo(options: ImageToVideoOptions): Promise<GenerateResponse> {
  try {
    const dimensions = options.orientation === 'landscape' ? 
      { width: 1280, height: 768 } : 
      { width: 768, height: 1280 };

    const response = await fetch(`${RUNWAY_API_URL}/inference`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RUNWAY_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'text-to-video',
        prompt: options.prompt?.trim() || '',
        negative_prompt: "bad quality, blurry, distorted",
        num_frames: options.duration * 30, // Convert seconds to frames at 30fps
        fps: 30,
        cfg_scale: 7.5,
        motion_bucket_id: 127,
        model_version: "2",
        seed: -1
      })
    });

    if (!response.ok) {
      if (response.status === 429) {
        throw new Error('محدودیت تعداد درخواست. لطفاً کمی صبر کنید');
      }
      if (response.status === 401) {
        throw new Error('خطای احراز هویت API. لطفاً با پشتیبانی تماس بگیرید');
      }
      throw new Error(`خطای ${response.status}: ${await response.text()}`);
    }

    const data = await response.json();
    
    // Handle processing status
    if (data.status === 'processing') {
      return {
        status: 'processing',
        fetch_result: `${RUNWAY_API_URL}/generations/${data.id}`,
        eta: data.eta || 60,
        message: data.message || 'در حال پردازش...'
      };
    }

    // Handle success with output
    if (data.status === 'success') {
      return {
        status: 'success',
        output: [data.output.url]
      };
    }

    throw new Error('خطا در دریافت خروجی از سرور');

  } catch (error) {
    console.error('Video generation error:', error);
    throw error;
  }
}

export async function getTaskStatus(taskId: string): Promise<GenerateResponse> {
  try {
    const response = await fetch(`${RUNWAY_API_URL}/generations/${taskId}`, {
      headers: {
        'Authorization': `Bearer ${RUNWAY_API_KEY}`
      }
    });

    if (!response.ok) {
      throw new Error(`خطای ${response.status}: ${await response.text()}`);
    }

    const data = await response.json();
    
    if (data.status === 'success') {
      return {
        status: 'success',
        output: [data.output.url]
      };
    }

    if (data.status === 'failed') {
      throw new Error(data.error?.message || 'خطا در تولید ویدئو');
    }

    return {
      status: 'processing',
      eta: data.eta || 60,
      message: data.message || 'در حال پردازش...'
    };

  } catch (error) {
    console.error('Task status error:', error);
    throw error;
  }
}

export async function cancelTask(taskId: string): Promise<void> {
  try {
    const response = await fetch(`${RUNWAY_API_URL}/generations/${taskId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${RUNWAY_API_KEY}`
      }
    });

    if (!response.ok) {
      throw new Error(`خطای ${response.status}: ${await response.text()}`);
    }

  } catch (error) {
    console.error('Task cancellation error:', error);
    throw error;
  }
}