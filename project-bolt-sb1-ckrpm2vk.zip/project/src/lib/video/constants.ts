export const ERROR_CODES = {
  TIMEOUT: 'زمان درخواست به پایان رسید',
  NETWORK: 'خطا در ارتباط با سرور',
  API: 'خطا در سرویس تولید ویدئو',
  VALIDATION: 'پارامترهای ورودی نامعتبر هستند',
  UNKNOWN: 'خطای ناشناخته'
} as const;

export const POLL_CONFIG = {
  maxAttempts: 120, // 20 minutes with 10s interval
  baseInterval: 10000, // 10 seconds
  maxInterval: 30000, // 30 seconds
  timeout: 1200000, // 20 minutes
  retryAttempts: 3,
  baseRetryDelay: 5000 // 5 seconds
} as const;

export const VIDEO_CONFIG = {
  maxRetries: 3,
  requestTimeout: 60000, // 60 seconds
  maxConcurrentRequests: 3,
  maxFileSize: 100 * 1024 * 1024, // 100MB
  supportedFormats: ['video/mp4', 'video/webm', 'video/quicktime'],
  maxDuration: 300, // 5 minutes
  dimensions: {
    min: 128,
    max: 1024,
    step: 64
  },
  fps: {
    min: 1,
    max: 60,
    default: 30
  }
} as const;