import { ValidationError } from '../errors';
import type { GenerateResponse, ImageToVideoOptions } from './types';

const RUNWAY_API_KEY = import.meta.env.VITE_RUNWAY_API_KEY;
const RUNWAY_API_URL = "https://api.dev.runwayml.com/v1";

if (!RUNWAY_API_KEY) {
  console.error('Missing RUNWAY_API_KEY environment variable');
}

export async function generateVideo(options: ImageToVideoOptions): Promise<GenerateResponse> {
  try {
    // Validate seed if provided
    if (options.seed && (options.seed < 0 || options.seed > 4294967295)) {
      throw new Error('Seed must be between 0 and 4294967295');
    }

    // Validate duration
    if (options.duration && ![5, 10].includes(options.duration)) {
      throw new Error('Duration must be 5 or 10 seconds');
    }

    // Validate ratio
    if (options.ratio && !['1280:768', '768:1280'].includes(options.ratio)) {
      throw new Error('Invalid ratio');
    }

    const response = await fetch(`${RUNWAY_API_URL}/v1/image_to_video`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RUNWAY_API_KEY}`,
        'Content-Type': 'application/json',
        'X-Runway-Version': '2024-11-06'
      },
      body: JSON.stringify({
        promptImage: [{
          uri: options.image,
          position: "first"
        }],
        model: 'gen3a_turbo',
        promptText: options.promptText?.trim(),
        duration: options.duration || 10,
        ratio: options.ratio || '1280:768',
        watermark: false,
        seed: options.seed
      })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      
      if (response.status === 429) {
        throw new Error('محدودیت تعداد درخواست. لطفاً کمی صبر کنید');
      }
      if (response.status === 401) {
        throw new Error('خطای احراز هویت API. لطفاً با پشتیبانی تماس بگیرید');
      }
      throw new Error(
        errorData.error?.message || 
        `Error ${response.status}: ${errorData.error?.reason}`
      );
    }

    const data = await response.json();
    
    switch(data.status) {
      case 'SUCCEEDED':
        return {
          status: 'SUCCEEDED',
          output: Array.isArray(data.output) ? data.output : [data.output]
        };
      
      case 'PENDING':
      case 'RUNNING':
      case 'THROTTLED':
        return {
          status: data.status,
          fetch_result: `${RUNWAY_API_URL}/v1/tasks/${data.id}`,
          id: data.id,
          eta: data.eta || 60,
          progress: data.progress,
          message: data.message
        };
        
      case 'FAILED':
        throw new Error(data.failure || 'Generation failed');
        
      case 'CANCELLED':
        throw new Error('Task cancelled');
        
      default:
        throw new Error('Unknown status');
    }

  } catch (error) {
    console.error('Video generation error:', error);
    throw error;
  }
}

export async function getTaskStatus(taskId: string): Promise<GenerateResponse> {
  try {
    const response = await fetch(`${RUNWAY_API_URL}/v1/tasks/${taskId}`, {
      headers: {
        'Authorization': `Bearer ${RUNWAY_API_KEY}`,
        'Content-Type': 'application/json',
        'X-Runway-Version': '2024-11-06'
      }
    });

    if (!response.ok) {
      if (response.status === 404) {
        throw new Error('درخواست مورد نظر یافت نشد یا منقضی شده است');
      }
      throw new Error(`خطای ${response.status}: ${await response.text()}`);
    }

    const data = await response.json();

    switch(data.status) {
      case 'SUCCEEDED':
        return {
          status: 'SUCCEEDED',
          output: Array.isArray(data.output) ? data.output : [data.output]
        };
        
      case 'FAILED':
        throw new Error(data.failure || 'Generation failed');
        
      case 'RUNNING':
        return {
          status: 'RUNNING',
          progress: data.progress,
          eta: data.eta,
          message: data.message
        };
        
      case 'THROTTLED':
        return {
          status: 'THROTTLED',
          eta: data.eta,
          message: data.message
        };
        
      case 'PENDING':
        return {
          status: 'PENDING',
          message: data.message
        };
        
      case 'CANCELLED':
        throw new Error('Task cancelled');
        
      default:
        throw new Error('Unknown status');
    }

  } catch (error) {
    console.error('Generation status error:', error);
    throw error;
  }
}

export async function cancelTask(taskId: string): Promise<void> {
  try {
    const response = await fetch(`${RUNWAY_API_URL}/v1/tasks/${taskId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${RUNWAY_API_KEY}`,
        'Content-Type': 'application/json',
        'X-Runway-Version': '2024-11-06'
      }
    });

    if (!response.ok && response.status !== 404) {
      throw new Error(`خطای ${response.status}: ${await response.text()}`);
    }

  } catch (error) {
    console.error('Task cancellation error:', error);
    throw error;
  }
}