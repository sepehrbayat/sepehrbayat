// Re-export all video-related functionality
export * from './types';
export * from './service';
export * from './imageToVideo';

// Export singleton instance
export { generateVideo, getTaskStatus, cancelTask } from './service';