import { VideoGenerationError } from './errors';
import { VIDEO_CONFIG } from './constants';
import type { ImageToVideoOptions } from './types';

export function validateVideoOptions(options: ImageToVideoOptions): void {
  // Validate required fields
  if (!options.image?.trim()) {
    throw new VideoGenerationError('VALIDATION', 'تصویر نمی‌تواند خالی باشد');
  }

  // Validate duration
  if (options.duration && ![5, 10].includes(options.duration)) {
    throw new VideoGenerationError('VALIDATION', 'مدت زمان باید 5 یا 10 ثانیه باشد');
  }

  // Validate ratio
  if (options.ratio && !['1280:768', '768:1280'].includes(options.ratio)) {
    throw new VideoGenerationError('VALIDATION', 'نسبت تصویر نامعتبر است');
  }

  // Validate seed
  if (options.seed !== undefined) {
    if (!Number.isInteger(options.seed) || options.seed < 0 || options.seed > 4294967295) {
      throw new VideoGenerationError('VALIDATION', 'مقدار seed باید بین 0 و 4294967295 باشد');
    }
  }
}