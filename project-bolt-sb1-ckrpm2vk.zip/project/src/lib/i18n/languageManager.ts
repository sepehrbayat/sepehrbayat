import i18n from './index';
import type { 
  SupportedLanguage,
  TranslationOptions,
  TranslationStatus,
  LocalizedError,
  LanguagePreferences
} from './types';

// Language direction constant
export const LANGUAGE_DIRECTION = 'rtl';

// Event name constant
export const LANGUAGE_CHANGE_EVENT = 'languageChanged';

// Language change event type
export interface LanguageChangeEvent extends CustomEvent {
  detail: { language: SupportedLanguage };
}

// Error messages
const ERROR_MESSAGES: Record<string, LocalizedError> = {
  TRANSLATION_FAILED: {
    code: 'TRANSLATION_FAILED',
    messages: {
      fa: 'خطا در ترجمه متن'
    }
  },
  INVALID_LANGUAGE: {
    code: 'INVALID_LANGUAGE',
    messages: {
      fa: 'زبان انتخاب شده نامعتبر است'
    }
  },
  CONTENT_EMPTY: {
    code: 'CONTENT_EMPTY',
    messages: {
      fa: 'محتوا نمی‌تواند خالی باشد'
    }
  }
};

// Language utilities
export const getCurrentLanguage = (): SupportedLanguage => {
  return 'fa';
};

export const isEnglishUI = (): boolean => false;

export const getLanguagePreferences = (): LanguagePreferences => {
  return {
    primary: 'fa',
    fallback: 'fa',
    direction: 'rtl',
    dateFormat: 'jYYYY/jMM/jDD',
    numberFormat: 'fa-IR'
  };
};

// Error handling
export const getLocalizedErrorMessage = (errorCode: string): string => {
  const error = ERROR_MESSAGES[errorCode];
  if (!error) {
    return ERROR_MESSAGES.TRANSLATION_FAILED.messages[getCurrentLanguage()];
  }
  return error.messages[getCurrentLanguage()];
};

// Translation status management
export const createTranslationStatus = (targetLanguage: SupportedLanguage, source: string): TranslationStatus => ({
  isTranslating: false,
  progress: 0,
  error: null,
  targetLanguage,
  source,
  timestamp: Date.now()
});

// Content formatting
export const preserveFormatting = (content: string, options: TranslationOptions): string => {
  if (!options.preserveFormatting) return content;

  let preservedContent = content;

  if (options.htmlTags) {
    // Preserve HTML tags
    preservedContent = preservedContent.replace(/(<[^>]+>)/g, match => `__HTML_${btoa(match)}__`);
  }

  if (options.markdownFormatting) {
    // Preserve Markdown formatting
    preservedContent = preservedContent
      .replace(/(\*\*|__)(.*?)\1/g, match => `__MD_BOLD_${btoa(match)}__`)
      .replace(/(\*|_)(.*?)\1/g, match => `__MD_ITALIC_${btoa(match)}__`)
      .replace(/```[\s\S]*?```/g, match => `__MD_CODE_${btoa(match)}__`);
  }

  return preservedContent;
};

export const restoreFormatting = (content: string, options: TranslationOptions): string => {
  if (!options.preserveFormatting) return content;

  let restoredContent = content;

  if (options.htmlTags) {
    // Restore HTML tags
    restoredContent = restoredContent.replace(/__HTML_([A-Za-z0-9+/=]+)__/g, (_, encoded) => atob(encoded));
  }

  if (options.markdownFormatting) {
    // Restore Markdown formatting
    restoredContent = restoredContent
      .replace(/__MD_BOLD_([A-Za-z0-9+/=]+)__/g, (_, encoded) => atob(encoded))
      .replace(/__MD_ITALIC_([A-Za-z0-9+/=]+)__/g, (_, encoded) => atob(encoded))
      .replace(/__MD_CODE_([A-Za-z0-9+/=]+)__/g, (_, encoded) => atob(encoded));
  }

  return restoredContent;
};

// Language switching
export const switchLanguage = async (language: SupportedLanguage): Promise<void> => {
  if (!SUPPORTED_LANGUAGES.includes(language)) {
    throw new Error(getLocalizedErrorMessage('INVALID_LANGUAGE'));
  }

  // Update language state
  await i18n.changeLanguage(language);
  
  // Update document attributes
  document.documentElement.dir = 'rtl';
  document.documentElement.lang = language;
  
  // Dispatch language change event
  window.dispatchEvent(
    new CustomEvent(LANGUAGE_CHANGE_EVENT, { 
      detail: { language },
      bubbles: true 
    })
  );

  // Clear any cached suggestions to prevent mixed language content
  window.dispatchEvent(new CustomEvent('clearSuggestions'));
};