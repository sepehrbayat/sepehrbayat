// Supported languages
export const SUPPORTED_LANGUAGES = ['fa'] as const;
export type SupportedLanguage = typeof SUPPORTED_LANGUAGES[number];

// Translation options
export interface TranslationOptions {
  preserveFormatting?: boolean;
  context?: string;
  htmlTags?: boolean;
  markdownFormatting?: boolean;
}

// Translation status
export interface TranslationStatus {
  isTranslating: boolean;
  progress: number;
  error: string | null;
  targetLanguage: SupportedLanguage;
  source: string;
  timestamp: number;
}

// Error types
export interface LocalizedError {
  code: string;
  messages: {
    fa: string;
  };
}

// Content types
export interface LocalizedContent {
  key: string;
  values: Record<SupportedLanguage, string>;
  context?: string;
  metadata?: Record<string, unknown>;
}

// Language preferences
export interface LanguagePreferences {
  primary: SupportedLanguage;
  fallback: SupportedLanguage;
  direction: 'ltr' | 'rtl';
  dateFormat: string;
  numberFormat: string;
}