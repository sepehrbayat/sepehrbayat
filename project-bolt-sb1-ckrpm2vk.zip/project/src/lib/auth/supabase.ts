import { supabase } from '../supabase';
import { ValidationError } from '../errors';
import { isValidIranianPhone } from '../utils';
import { generateRandomCode } from '../utils';
import { sendOTPEmail } from './otp';
import { Provider, AuthResponse as SupabaseAuthResponse, AuthError } from '@supabase/supabase-js';

export interface AuthResponse {
  user: any;
  session: any;
  error?: string;
}

// Constants for rate limiting and verification
const MAX_ATTEMPTS = 3;
const CODE_EXPIRY = 5 * 60 * 1000; // 5 minutes
const RATE_LIMIT_WINDOW = 60 * 1000; // 1 minute
const MAX_REQUESTS_PER_WINDOW = 3;

export type SocialProvider = 'google' | 'github' | 'twitter' | 'facebook' | 'discord' | 'linkedin';

const OAUTH_PROVIDERS = {
  google: {
    name: 'Google',
    icon: 'google.svg'
  },
  github: {
    name: 'GitHub',
    icon: 'github.svg'
  },
  twitter: {
    name: 'Twitter',
    icon: 'twitter.svg'
  },
  facebook: {
    name: 'Facebook',
    icon: 'facebook.svg'
  },
  discord: {
    name: 'Discord',
    icon: 'discord.svg'
  },
  linkedin: {
    name: 'LinkedIn',
    icon: 'linkedin.svg'
  }
} as const;

interface SignUpData {
  email?: string;
  phone?: string;
  password?: string;
  fullName: string;
  companyName?: string;
  nationalId?: string;
  address?: string;
  postalCode?: string;
}

export async function signUp({ email, phone, password, ...userData }: SignUpData): Promise<AuthResponse> {
  try {
    let signUpData: any = {
      options: {
        data: {
          ...userData,
          email_confirmed: false,
          phone_confirmed: false
        }
      }
    };

    if (email && password) {
      // Email signup
      if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
        throw new ValidationError('ایمیل نامعتبر است');
      }
      if (password.length < 8) {
        throw new ValidationError('رمز عبور باید حداقل 8 کاراکتر باشد');
      }
      signUpData = {
        ...signUpData,
        email,
        password,
        options: {
          ...signUpData.options,
          emailRedirectTo: `${window.location.origin}/auth/callback`
        }
      };
    } else if (phone) {
      // Phone signup
      const formattedPhone = phone.trim().replace(/\D/g, '');
      if (!isValidIranianPhone(formattedPhone)) {
        throw new ValidationError('شماره موبایل نامعتبر است');
      }
      signUpData = {
        ...signUpData,
        phone: `+98${formattedPhone.substring(1)}`
      };
    } else {
      throw new ValidationError('ایمیل یا شماره موبایل الزامی است');
    }

    const { data, error } = await supabase.auth.signUp(signUpData);

    if (error) {
      if (error.message.includes('already exists')) {
        throw new ValidationError('این حساب کاربری قبلاً ثبت شده است');
      }
      throw error;
    }

    return { user: data.user, session: data.session };

  } catch (error) {
    console.error('Sign up error:', error);
    throw error instanceof ValidationError ? error : new ValidationError('خطا در ثبت‌نام');
  }
}

export async function signInWithPhone(phoneNumber: string): Promise<AuthResponse> {
  try {
    // Validate phone number
    const formattedPhone = phoneNumber.trim().replace(/\D/g, '');
    if (!isValidIranianPhone(formattedPhone)) {
      throw new ValidationError('شماره موبایل وارد شده معتبر نیست');
    }

    // Check rate limiting
    const { data: recentAttempts, error: countError } = await supabase
      .from('verification_codes')
      .select('created_at')
      .eq('phone_number', formattedPhone)
      .gte('created_at', new Date(Date.now() - RATE_LIMIT_WINDOW).toISOString());

    if (countError) throw countError;
    
    if (recentAttempts && recentAttempts.length >= MAX_REQUESTS_PER_WINDOW) {
      throw new ValidationError('تعداد درخواست‌ها بیش از حد مجاز است. لطفاً کمی صبر کنید');
    }

    const { data, error } = await supabase.auth.signInWithOtp({
      phone: `+98${formattedPhone.substring(1)}`,
      options: {
        channel: 'sms'
      }
    });

    if (error) {
      if (error.message.includes('rate limit')) {
        throw new ValidationError('تعداد درخواست‌ها بیش از حد مجاز است. لطفاً کمی صبر کنید');
      }
      throw new ValidationError(error.message);
    }

    return { user: data.user, session: data.session };

  } catch (error) {
    console.error('Phone sign in error:', error);
    throw error instanceof ValidationError ? error : new ValidationError('خطا در ارسال کد تایید');
  }
}

export async function verifyOtp(phoneNumber: string, token: string): Promise<AuthResponse> {
  try {
    const formattedPhone = phoneNumber.trim().replace(/\D/g, '');
    if (!isValidIranianPhone(formattedPhone)) {
      throw new ValidationError('شماره موبایل نامعتبر است');
    }

    // Get verification code from database
    const { data: storedCode, error: dbError } = await supabase
      .from('verification_codes')
      .select('*')
      .eq('phone_number', formattedPhone)
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (dbError || !storedCode) {
      throw new ValidationError('کد تایید منقضی شده است. لطفاً دوباره درخواست کد کنید');
    }

    // Check attempts
    if (storedCode.attempts >= MAX_ATTEMPTS) {
      // Delete expired code
      await supabase
        .from('verification_codes')
        .delete()
        .eq('phone_number', formattedPhone);
        
      throw new ValidationError('تعداد تلاش‌های مجاز به پایان رسید. لطفاً دوباره درخواست کد کنید');
    }

    // Check expiration
    if (new Date(storedCode.expires_at) < new Date()) {
      // Delete expired code
      await supabase
        .from('verification_codes')
        .delete()
        .eq('phone_number', formattedPhone);
        
      throw new ValidationError('کد تایید منقضی شده است. لطفاً دوباره درخواست کد کنید');
    }

    // Increment attempts
    await supabase
      .from('verification_codes')
      .update({ attempts: storedCode.attempts + 1 })
      .eq('id', storedCode.id);

    const { data, error } = await supabase.auth.verifyOtp({
      phone: `+98${formattedPhone.substring(1)}`,
      token,
      type: 'sms'
    });

    if (error) {
      if (error.message.includes('Invalid token')) {
        throw new ValidationError('کد تایید نامعتبر است');
      }
      if (error.message.includes('Token expired')) {
        throw new ValidationError('کد تایید منقضی شده است');
      }
      throw new ValidationError(error.message);
    }

    // Delete used code
    await supabase
      .from('verification_codes')
      .delete()
      .eq('phone_number', formattedPhone);

    return { user: data.user, session: data.session };

  } catch (error) {
    console.error('OTP verification error:', error);
    throw error instanceof ValidationError ? error : new ValidationError('خطا در تایید کد');
  }
}

export async function signInWithSocial(provider: SocialProvider) {
  try {    
    // Check if online
    if (!navigator.onLine) {
      throw new Error('اتصال اینترنت برقرار نیست. لطفاً اتصال خود را بررسی کنید');
    }

    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: provider as Provider,
      options: {
        redirectTo: 'https://auth.hooshex.com/auth/v1/callback',
        queryParams: provider === 'google' ? {
          access_type: 'offline',
          prompt: 'consent',
          scope: 'email profile openid'
        } : undefined
      }
    });

    if (error) {
      if (error.message.includes('provider is not enabled')) {
        throw new Error('ورود با گوگل در حال حاضر فعال نیست. لطفاً از روش دیگری استفاده کنید');
      } else if (error.message.includes('popup_closed_by_user')) {
        throw new Error('پنجره ورود با گوگل بسته شد');
      } else if (error.message.includes('popup_blocked')) {
        throw new Error('لطفاً پاپ‌آپ مرورگر را فعال کنید');
      } else if (error.message.includes('network')) {
        throw new Error('خطا در ارتباط با سرور. لطفاً اتصال اینترنت خود را بررسی کنید');
      } else if (error.message.includes('redirect_uri_mismatch')) {
        throw new Error('خطای پیکربندی. لطفاً با پشتیبانی تماس بگیرید');
        throw new Error('زمان درخواست به پایان رسید. لطفاً دوباره تلاش کنید');
      } else if (error.message.includes('access_denied')) {
        throw new Error('دسترسی به حساب گوگل رد شد');
      } else if (error.message.includes('invalid_request')) {
        throw new Error('درخواست نامعتبر. لطفاً صفحه را رفرش کنید');
      } else if (error.message.includes('invalid_client')) {
        throw new Error('خطای پیکربندی. لطفاً با پشتیبانی تماس بگیرید');
      } else if (error.message.includes('network')) {
        throw new Error('خطا در ارتباط با سرور. لطفاً اتصال اینترنت خود را بررسی کنید');
      } else if (error.message.includes('timeout')) {
      }
      throw error;
    }

    return data;
  } catch (error) {
    console.error('Google sign in error:', error);
    throw error instanceof Error ? error : new Error('خطا در ورود با گوگل');
  }
}

export async function signInWithEmail(email: string, password: string) {
  // Validate email format
  if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
    throw new ValidationError('ایمیل نامعتبر است');
  }

  // Validate password strength
  if (password.length < 8) {
    throw new ValidationError('رمز عبور باید حداقل 8 کاراکتر باشد');
  }

  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  });

  if (error) {
    if (error.message.includes('Invalid login credentials')) {
      throw new ValidationError('ایمیل یا رمز عبور اشتباه است');
    }
    if (error.message.includes('Email not confirmed')) {
      throw new ValidationError('لطفاً ایمیل خود را تایید کنید');
    }
    throw error;
  }

  return data;
}

export async function signUpWithEmail(email: string, password: string) {
  try {
    // Validate email format
    if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
      throw new ValidationError('لطفاً یک ایمیل معتبر وارد کنید');
    }

    // Validate password strength
    if (password.length < 8) {
      throw new ValidationError('رمز عبور باید حداقل 8 کاراکتر باشد و شامل حروف و اعداد باشد');
    }

    // Check rate limiting
    const { data: recentAttempts, error: countError } = await supabase
      .from('email_otp_codes_v9')
      .select('created_at')
      .eq('email', email)
      .gte('created_at', new Date(Date.now() - RATE_LIMIT_WINDOW).toISOString());

    if (countError) throw countError;
    
    if (recentAttempts && recentAttempts.length >= MAX_REQUESTS_PER_WINDOW) {
      throw new ValidationError('تعداد درخواست‌ها بیش از حد مجاز است. لطفاً کمی صبر کنید');
    }

    // Sign up with Supabase
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/verify`,
        data: {
          email_confirmed: false
        }
      }
    });

    if (error) {
      if (error.message.includes('already exists')) {
        throw new ValidationError('این ایمیل قبلاً ثبت شده است');
      }
      throw error;
    }

    // Generate OTP code
    const otpCode = generateRandomCode(6);

    // Store OTP in database with expiry
    const { error: otpError } = await supabase
      .from('email_otp_codes_v9')
      .insert({
        email,
        code: otpCode,
        expires_at: new Date(Date.now() + CODE_EXPIRY).toISOString(),
        attempts: 0
      });

    if (otpError) throw otpError;

    // Return success without error message to avoid confusion
    return data;

  } catch (error) {
    console.error('Email signup error:', error);
    throw error instanceof ValidationError ? error : new ValidationError('خطا در ثبت‌نام');
  }
}

export async function verifyOTP(email: string, token: string): Promise<boolean> {
  try {
    if (!email || !token) {
      throw new ValidationError('ایمیل و کد تایید الزامی هستند');
    }

    if (!token.match(/^\d{6}$/)) {
      throw new ValidationError('کد تایید باید 6 رقمی باشد');
    }

    // Get verification token
    const { data: tokenData, error: tokenError } = await supabase
      .from('email_otp_codes_v9')
      .select('*')
      .eq('email', email)
      .eq('code', token)
      .order('created_at', { ascending: false })
      .single();

    if (tokenError || !tokenData) {
      throw new ValidationError('کد تایید نامعتبر است یا منقضی شده است');
    }

    // Check expiration
    if (new Date(tokenData.expires_at) < new Date()) {
      // Delete expired token
      await supabase
        .from('email_otp_codes')
        .delete()
        .eq('id', tokenData.id);
      throw new ValidationError('کد تایید منقضی شده است');
    }

    // Check attempts
    if (tokenData.attempts >= MAX_ATTEMPTS) {
      // Delete expired token
      await supabase
        .from('email_otp_codes')
        .delete()
        .eq('id', tokenData.id);
      throw new ValidationError('تعداد تلاش‌های مجاز به پایان رسید');
    }

    // Update attempts
    await supabase
      .from('email_otp_codes_v9')
      .update({ attempts: tokenData.attempts + 1 })
      .eq('id', tokenData.id);

    // Verify token
    if (tokenData.code !== token) {
      const remainingAttempts = MAX_ATTEMPTS - (tokenData.attempts + 1);
      throw new ValidationError(`کد تایید نادرست است. ${remainingAttempts} تلاش دیگر باقی مانده است`);
    }

    // Update user metadata
    const { error: updateError } = await supabase.auth.updateUser({
      data: { email_confirmed: true }
    });

    if (updateError) throw updateError;

    // Delete used token
    await supabase
      .from('email_otp_codes_v9')
      .delete()
      .eq('id', tokenData.id);

    return true;

  } catch (error) {
    console.error('OTP verification error:', error);
    throw error instanceof ValidationError ? error : new ValidationError('خطا در تایید کد');
  }
}

export async function signOut() {
  try {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
    
    // Clear any local storage or state
    localStorage.removeItem('supabase.auth.token');
    
  } catch (error) {
    console.error('Sign out error:', error);
    throw new Error('خطا در خروج از حساب کاربری');
  }
}

export async function resetPassword(email: string) {
  if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
    throw new ValidationError('ایمیل نامعتبر است');
  }

  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${window.location.origin}/auth/reset-password`
  });

  if (error) {
    if (error.message.includes('not found')) {
      throw new ValidationError('این ایمیل در سیستم ثبت نشده است');
    }
    throw error;
  }
}

export async function updatePassword(newPassword: string) {
  if (newPassword.length < 8) {
    throw new ValidationError('رمز عبور باید حداقل 8 کاراکتر باشد');
  }

  const { error } = await supabase.auth.updateUser({
    password: newPassword
  });

  if (error) {
    if (error.message.includes('weak password')) {
      throw new ValidationError('رمز عبور انتخابی ضعیف است');
    }
    throw error;
  }
}

export async function getCurrentUser() {
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error) {
    console.error('Get user error:', error);
    throw new Error('خطا در دریافت اطلاعات کاربر');
  }
  return user;
}

export async function onAuthStateChange(callback: (event: string, session: any) => void) {
  const { data: { subscription } } = supabase.auth.onAuthStateChange(callback);
  return subscription;
}

export async function signInWithMagicLink(email: string): Promise<void> {
  try {
    if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
      throw new ValidationError('ایمیل نامعتبر است');
    }

    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/verify`,
        data: {
          email_confirmed: false
        }
      }
    });

    if (error) throw error;

  } catch (error) {
    console.error('Magic link error:', error);
    throw error instanceof ValidationError ? error : new ValidationError('خطا در ارسال لینک ورود');
  }
}

export async function refreshSession(): Promise<SupabaseAuthResponse> {
  try {
    const { data, error } = await supabase.auth.refreshSession();
    if (error) throw error;
    // Create verification token
    const { error: tokenError } = await supabase
      .from('email_otp_codes_v9')
      .insert({
        email,
        token: Math.random().toString(36).substring(2, 15),
        expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
      });

    if (tokenError) throw tokenError;

    return data;
  } catch (error) {
    console.error('Session refresh error:', error);
    throw new Error('خطا در بروزرسانی نشست کاربری');
  }
}

export async function updateProfile(updates: Partial<Omit<SignUpData, 'password'>>) {
  try {
    const { error } = await supabase.auth.updateUser({
      data: updates
    });

    if (error) throw error;

  } catch (error) {
    console.error('Profile update error:', error);
    throw new Error('خطا در بروزرسانی پروفایل');
  }
}

export { OAUTH_PROVIDERS };