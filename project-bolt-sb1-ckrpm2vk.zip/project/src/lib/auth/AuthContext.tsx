import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '../supabase';
import type { User } from './types';

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  error: string | null;
  isAuthenticated: boolean;
  signOut: () => Promise<void>;
  updateUser: (data: Partial<User>) => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoading: true,
  error: null,
  isAuthenticated: false,
  signOut: async () => {}
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session }, error }) => {
      if (error) {
        setError(error.message);
      } else if (session?.user) {
        setUser({
          id: session.user.id,
          phoneNumber: session.user.phone || '',
          email: session.user.email || '',
          fullName: session.user.user_metadata?.full_name || '',
          companyName: session.user.user_metadata?.company_name,
          nationalId: session.user.user_metadata?.national_id || '',
          address: session.user.user_metadata?.address || '',
          postalCode: session.user.user_metadata?.postal_code || '',
          avatarUrl: session.user.user_metadata?.avatar_url,
          isEmailVerified: session.user.email_confirmed || false,
          lastLogin: session.user.last_sign_in_at,
          createdAt: session.user.created_at,
          updatedAt: session.user.updated_at
        });
        setIsAuthenticated(true);
      }
      setIsLoading(false);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        setUser({
          id: session.user.id,
          phoneNumber: session.user.phone || '',
          email: session.user.email || '',
          fullName: session.user.user_metadata?.full_name || '',
          companyName: session.user.user_metadata?.company_name,
          nationalId: session.user.user_metadata?.national_id || '',
          address: session.user.user_metadata?.address || '',
          postalCode: session.user.user_metadata?.postal_code || '',
          avatarUrl: session.user.user_metadata?.avatar_url,
          isEmailVerified: session.user.email_confirmed || false,
          lastLogin: session.user.last_sign_in_at,
          createdAt: session.user.created_at,
          updatedAt: session.user.updated_at
        });
        setIsAuthenticated(true);
      } else {
        setUser(null);
        setIsAuthenticated(false);
      }
      setIsLoading(false);
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const signOut = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      setUser(null);
      setIsAuthenticated(false);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'خطا در خروج از حساب کاربری');
    }
  };

  const updateUser = async (data: Partial<User>) => {
    try {
      const { error } = await supabase.auth.updateUser({
        data: {
          ...data,
          updated_at: new Date().toISOString()
        }
      });
      if (error) throw error;
      setUser(prev => prev ? { ...prev, ...data } : null);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'خطا در بروزرسانی اطلاعات کاربر');
    }
  };
  return (
    <AuthContext.Provider value={{ user, isLoading, error, isAuthenticated, signOut, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}