import { supabase } from '../supabase';
import { ValidationError } from '../errors';

const OTP_EXPIRY = 10 * 60 * 1000; // 10 minutes
const MAX_ATTEMPTS = 3;
const RATE_LIMIT_WINDOW = 60 * 1000; // 1 minute
const MAX_REQUESTS_PER_WINDOW = 3;

/**
 * Generates a random 6-digit OTP code
 */
function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

/**
 * Sends OTP verification email
 */
export async function sendOTPEmail(email: string): Promise<void> {
  try {
    // Validate email format
    if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
      throw new ValidationError('ایمیل نامعتبر است');
    }

    // Check rate limiting
    const { data: recentAttempts, error: countError } = await supabase
      .from('email_otp_codes_v9')
      .select('created_at')
      .eq('email', email)
      .gte('created_at', new Date(Date.now() - RATE_LIMIT_WINDOW).toISOString());

    if (countError) throw countError;
    
    if (recentAttempts && recentAttempts.length >= MAX_REQUESTS_PER_WINDOW) {
      throw new ValidationError('تعداد درخواست‌ها بیش از حد مجاز است. لطفاً کمی صبر کنید');
    }

    // Generate OTP code
    const code = generateOTP();

    // Store OTP in database
    const { error: insertError } = await supabase
      .from('email_otp_codes_v9')
      .insert({
        email,
        code,
        expires_at: new Date(Date.now() + OTP_EXPIRY).toISOString()
      });

    if (insertError) throw insertError;

    // Send email using Supabase's email service
    const { error: emailError } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/auth/verify`,
      data: {
        type: 'otp',
        code
      }
    });

    if (emailError) throw emailError;

  } catch (error) {
    console.error('OTP email error:', error);
    throw error instanceof ValidationError ? error : new ValidationError('خطا در ارسال کد تایید');
  }
}

/**
 * Verifies OTP code
 */
export async function verifyOTP(email: string, code: string): Promise<boolean> {
  try {
    // Validate email format
    if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
      throw new ValidationError('ایمیل نامعتبر است');
    }

    // Validate code format
    if (!code.match(/^\d{6}$/)) {
      throw new ValidationError('کد تایید باید 6 رقمی باشد');
    }

    // Get OTP from database
    const { data: otpData, error: otpError } = await supabase
      .from('email_otp_codes_v9')
      .select('*')
      .eq('email', email)
      .eq('code', code)
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (otpError || !otpData) {
      throw new ValidationError('کد تایید نامعتبر است یا منقضی شده است');
    }

    // Check expiration
    if (new Date(otpData.expires_at) < new Date()) {
      // Delete expired code
      await supabase
        .from('email_otp_codes_v9')
        .delete()
        .eq('id', otpData.id);
        
      throw new ValidationError('کد تایید منقضی شده است');
    }

    // Check attempts
    if (otpData.attempts >= MAX_ATTEMPTS) {
      // Delete expired code
      await supabase
        .from('email_otp_codes_v9')
        .delete()
        .eq('id', otpData.id);
        
      throw new ValidationError('تعداد تلاش‌های مجاز به پایان رسید');
    }

    // Increment attempts
    await supabase
      .from('email_otp_codes_v9')
      .update({ attempts: otpData.attempts + 1 })
      .eq('id', otpData.id);

    // Verify code
    if (otpData.code !== code) {
      const remainingAttempts = MAX_ATTEMPTS - (otpData.attempts + 1);
      if (remainingAttempts <= 0) {
        // Delete expired code if no attempts remain
        await supabase
          .from('email_otp_codes_v9')
          .delete()
          .eq('id', otpData.id);
      }
      throw new ValidationError('کد تایید نادرست است');
    }

    // Update user metadata
    const { error: updateError } = await supabase.auth.updateUser({
      data: { email_confirmed: true }
    });

    if (updateError) throw updateError;

    // Delete used code
    await supabase
      .from('email_otp_codes_v9')
      .delete()
      .eq('id', otpData.id);

    return true;

  } catch (error) {
    console.error('OTP verification error:', error);
    throw error instanceof ValidationError ? error : new ValidationError('خطا در تایید کد');
  }
}