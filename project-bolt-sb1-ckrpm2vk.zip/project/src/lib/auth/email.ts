import { supabase } from '../supabase';
import { ValidationError } from '../errors';

const TOKEN_EXPIRY = 24 * 60 * 60 * 1000; // 24 hours
const MAX_ATTEMPTS = 3;

export async function signUpWithEmailVerification(email: string, password: string) {
  try {
    // Validate email format
    if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
      throw new ValidationError('ایمیل نامعتبر است');
    }

    // Validate password strength
    if (password.length < 8) {
      throw new ValidationError('رمز عبور باید حداقل 8 کاراکتر باشد');
    }

    // Sign up with Supabase
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/verify`,
        data: {
          email_confirmed: false
        }
      }
    });

    if (error) {
      if (error.message.includes('already exists')) {
        throw new ValidationError('این ایمیل قبلاً ثبت شده است');
      }
      throw error;
    }

    // Create verification token
    const { error: tokenError } = await supabase
      .from('email_verification_tokens_v3')
      .insert({
        email,
        token: Math.random().toString(36).substring(2, 15),
        expires_at: new Date(Date.now() + TOKEN_EXPIRY).toISOString()
      });

    if (tokenError) throw tokenError;

    return data;

  } catch (error) {
    console.error('Email signup error:', error);
    throw error instanceof ValidationError ? error : new ValidationError('خطا در ثبت‌نام');
  }
}

export async function verifyEmail(email: string, token: string) {
  try {
    // Get verification token
    const { data: tokenData, error: tokenError } = await supabase
      .from('email_verification_tokens_v3')
      .select('*')
      .eq('email', email)
      .eq('token', token)
      .single();

    if (tokenError || !tokenData) {
      throw new ValidationError('توکن تایید نامعتبر است');
    }

    // Check expiration
    if (new Date(tokenData.expires_at) < new Date()) {
      throw new ValidationError('توکن تایید منقضی شده است');
    }

    // Check attempts
    if (tokenData.attempts >= MAX_ATTEMPTS) {
      throw new ValidationError('تعداد تلاش‌های مجاز به پایان رسید');
    }

    // Update user metadata
    const { error: updateError } = await supabase.auth.updateUser({
      data: { email_confirmed: true }
    });

    if (updateError) throw updateError;

    // Delete used token
    await supabase
      .from('email_verification_tokens_v3')
      .delete()
      .eq('id', tokenData.id);

    return true;

  } catch (error) {
    console.error('Email verification error:', error);
    throw error instanceof ValidationError ? error : new ValidationError('خطا در تایید ایمیل');
  }
}