import { ValidationError } from '../errors';
import { isValidIranianPhone } from '../utils';
import { supabase } from '../supabase';
import { generateRandomCode } from '../utils';

const API_KEY = 'OWU0YmU1ZDMtNzNjYS00YjA5LWJhZjUtZTRkYmJlYjE0ODc3M2VjOGQ5Mzk3MGQ5MjFmZWE0YzcxMzBlMWRmNDhiOTE=';
const API_URL = 'https://api2.ippanel.com/api/v1';

// Constants
const MAX_ATTEMPTS = 3;
const CODE_EXPIRY = 5 * 60 * 1000; // 5 minutes
const RATE_LIMIT_WINDOW = 60 * 1000; // 1 minute
const MAX_REQUESTS_PER_WINDOW = 3;

// Pattern code for verification messages
const VERIFICATION_PATTERN = 'v5gfde'; // Replace with your actual pattern code from IPPanel dashboard

export interface SendVerificationCodeParams {
  phoneNumber: string;
  code: string;
}

export interface VerifyCodeParams {
  phoneNumber: string;
  code: string;
}

export async function sendVerificationCode({ phoneNumber, code }: SendVerificationCodeParams) {
  try {
    // Validate phone number
    const formattedPhone = phoneNumber.trim().replace(/\D/g, '');
    if (!isValidIranianPhone(formattedPhone)) {
      throw new ValidationError('شماره موبایل وارد شده معتبر نیست');
    }
    
    // Validate code format
    if (!code || !/^\d{6}$/.test(code.toString())) {
      throw new ValidationError('کد تایید باید 6 رقمی باشد');
    }

    // Check rate limiting
    const { data: recentAttempts, error: countError } = await supabase
      .from('verification_codes')
      .select('created_at')
      .eq('phone_number', formattedPhone)
      .gte('created_at', new Date(Date.now() - RATE_LIMIT_WINDOW).toISOString());

    if (countError) throw countError;
    
    if (recentAttempts && recentAttempts.length >= MAX_REQUESTS_PER_WINDOW) {
      throw new ValidationError('تعداد درخواست‌ها بیش از حد مجاز است. لطفاً کمی صبر کنید');
    }
    
    // Store verification code in Supabase
    const { error: dbError } = await supabase
      .from('verification_codes')
      .insert({
        phone_number: formattedPhone,
        code,
        expires_at: new Date(Date.now() + CODE_EXPIRY).toISOString(),
        attempts: 0
      });
    
    if (dbError) throw dbError;

    const response = await fetch(`${API_URL}/sms/pattern/normal/send`, {
      method: 'POST',
      headers: {
        'Authorization': `AccessKey ${API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        pattern_code: VERIFICATION_PATTERN,
        sender: "+983000505",
        recipient: formattedPhone,
        values: {
          verification_code: code // Use the exact variable name defined in your pattern
        }
      })
    });

    const data = await response.json().catch(() => ({}));

    // Handle API errors
    if (!response.ok || data.status === 'error' || data.error_message) {
      if (response.status === 401) {
        throw new ValidationError('خطای احراز هویت. لطفاً با پشتیبانی تماس بگیرید');
      }
      if (response.status === 429) {
        throw new ValidationError('تعداد درخواست‌ها بیش از حد مجاز است. لطفاً کمی صبر کنید');
      }
      if (response.status === 422 || response.status === 400) {
        const errorMessage = data.error_message || data.message || 'خطا در الگوی پیامک';
        console.error('IPPanel API Error:', {
          status: response.status,
          data,
          pattern: VERIFICATION_PATTERN,
          recipient: formattedPhone
        });
        throw new ValidationError(
          errorMessage.includes('pattern') || errorMessage.includes('template') 
            ? 'کد الگو نامعتبر است. لطفاً با پشتیبانی تماس بگیرید'
            : 'پارامترهای ارسالی نامعتبر هستند'
        );
      }
      
      throw new ValidationError(
        data.error_message || 
        data.errorMessage || 
        'خطا در ارسال کد تایید. لطفاً دوباره تلاش کنید'
      );
    }
    
    return data;

  } catch (error) {
    console.error('Error sending verification code:', error);
    
    // Handle specific API errors
    if (error instanceof Error) {
      if (error.message.includes('rate limit')) {
        throw new ValidationError('تعداد درخواست‌ها بیش از حد مجاز است. لطفاً کمی صبر کنید');
      }
      if (error.message.includes('invalid recipient')) {
        throw new ValidationError('شماره موبایل نامعتبر است');
      }
      if (error.message.includes('insufficient credit')) {
        throw new ValidationError('اعتبار حساب کافی نیست');
      }
      if (error.message.includes('Unauthorized') || error.message.includes('invalid token')) {
        throw new ValidationError('خطای احراز هویت. لطفاً دوباره تلاش کنید');
      }
      throw new ValidationError(error.message);
    }
    
    throw new ValidationError('خطا در ارسال کد تایید. لطفاً دوباره تلاش کنید');
  }
}

export async function verifyCode({ phoneNumber, code }: VerifyCodeParams): Promise<boolean> {
  try {
    // Validate phone number format
    const formattedPhone = phoneNumber.trim().replace(/\D/g, '');
    if (!isValidIranianPhone(formattedPhone)) {
      throw new ValidationError('شماره موبایل وارد شده معتبر نیست');
    }

    // Validate code format
    const formattedCode = code.toString().trim().replace(/\D/g, '');
    if (!formattedCode || !/^\d{6}$/.test(formattedCode)) {
      throw new ValidationError('کد تایید باید 6 رقمی باشد');
    }

    // Get verification code from Supabase
    const { data: storedCode, error: dbError } = await supabase
      .from('verification_codes')
      .select('*')
      .eq('phone_number', formattedPhone)
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (dbError || !storedCode) {
      throw new ValidationError('کد تایید منقضی شده است. لطفاً دوباره درخواست کد کنید');
    }

    // Check attempts
    if (storedCode.attempts >= MAX_ATTEMPTS) {
      // Delete expired code
      await supabase
        .from('verification_codes')
        .delete()
        .eq('phone_number', formattedPhone);
        
      throw new ValidationError('تعداد تلاش‌های مجاز به پایان رسید. لطفاً دوباره درخواست کد کنید');
    }

    // Check expiration
    if (new Date(storedCode.expires_at) < new Date()) {
      // Delete expired code
      await supabase
        .from('verification_codes')
        .delete()
        .eq('phone_number', formattedPhone);
        
      throw new ValidationError('کد تایید منقضی شده است. لطفاً دوباره درخواست کد کنید');
    }

    // Increment attempts
    await supabase
      .from('verification_codes')
      .update({ attempts: storedCode.attempts + 1 })
      .eq('id', storedCode.id);

    if (storedCode.code !== formattedCode) {
      const remainingAttempts = MAX_ATTEMPTS - (storedCode.attempts + 1);
      throw new ValidationError(`کد تایید اشتباه است. ${remainingAttempts} تلاش دیگر باقی مانده است`);
    }

    // Delete used code
    await supabase
      .from('verification_codes')
      .delete()
      .eq('phone_number', formattedPhone);

    return true;

  } catch (error) {
    throw error instanceof ValidationError ? error : new ValidationError('خطا در تایید کد. لطفاً دوباره تلاش کنید');
  }
}

/**
 * Check remaining credit
 */
export async function checkCredit(): Promise<number> {
  try {
    const response = await fetch(`${API_URL}/sms/accounting/credit/show`, {
      headers: {
        'Authorization': API_KEY
      }
    });

    if (!response.ok) {
      throw new Error('خطا در دریافت اعتبار');
    }

    const data = await response.json();
    return data.data.credit;

  } catch (error) {
    console.error('Error checking credit:', error);
    throw new Error('خطا در دریافت اعتبار');
  }
}

/**
 * Check message delivery status
 */
export async function checkDeliveryStatus(messageId: string): Promise<string> {
  try {
    const response = await fetch(`${API_URL}/sms/message/show-recipient/message-id/${messageId}`, {
      headers: {
        'Authorization': API_KEY
      }
    });

    if (!response.ok) {
      throw new Error('خطا در دریافت وضعیت پیامک');
    }

    const data = await response.json();
    return data.data.status;

  } catch (error) {
    console.error('Error checking delivery status:', error);
    throw error instanceof Error ? error : new Error('خطا در دریافت وضعیت پیامک');
  }
}

export { generateRandomCode as generateVerificationCode };