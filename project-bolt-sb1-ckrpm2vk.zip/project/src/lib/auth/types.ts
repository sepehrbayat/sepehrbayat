export interface User {
  id: string;
  phoneNumber: string;
  email: string;
  fullName: string;
  companyName?: string;
  nationalId: string;
  address: string;
  postalCode: string;
  avatarUrl?: string;
  isEmailVerified: boolean;
  lastLogin?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}