/**
 * Generates a random numeric code of specified length
 */
export function generateRandomCode(length: number = 6): string {
  const min = Math.pow(10, length - 1);
  const max = Math.pow(10, length) - 1;
  return Math.floor(min + Math.random() * (max - min + 1)).toString();
}

/**
 * Formats a phone number to standard format
 */
export function formatPhoneNumber(phone: string): string {
  return phone.replace(/\D/g, '').replace(/^0/, '');
}

/**
 * Validates an Iranian phone number
 */
export function isValidIranianPhone(phone: string): boolean {
  return /^09\d{9}$/.test(phone);
}