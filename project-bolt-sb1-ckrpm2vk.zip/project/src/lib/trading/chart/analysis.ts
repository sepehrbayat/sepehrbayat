import { openai } from '../../openai';
import { ChartData, ChartAnalysis } from './types';

/**
 * Analyzes selected chart region using AI
 */
export async function analyzePatterns(data: ChartData[]): Promise<ChartAnalysis> {
  try {
    const response = await openai.chat.completions.create({
      model: 'ModelsLab/Mixtral-8x7B-Instruct',
      temperature: 0.3,
      messages: [
        {
          role: 'system',
          content: `شما یک تحلیلگر تکنیکال حرفه‌ای هستید. لطفاً ناحیه انتخاب شده از نمودار را تحلیل کنید.

لطفاً خروجی را در قالب JSON با این ساختار برگردانید:
{
  "patterns": [{
    "name": "نام الگو",
    "probability": درصد احتمال,
    "target": قیمت هدف,
    "stopLoss": حد ضرر
  }],
  "trend": {
    "direction": "up" | "down" | "sideways",
    "strength": درصد قدرت روند,
    "support": [سطوح حمایت],
    "resistance": [سطوح مقاومت]
  },
  "indicators": [{
    "name": "نام اندیکاتور",
    "value": مقدار عددی,
    "signal": "buy" | "sell" | "neutral"
  }],
  "recommendations": ["پیشنهاد 1", "پیشنهاد 2"],
  "insights": ["بینش 1", "بینش 2"]
}`
        },
        {
          role: 'user',
          content: JSON.stringify(data)
        }
      ]
    });

    const analysis = JSON.parse(response.choices[0]?.message?.content || '{}');
    return analysis;

  } catch (error) {
    console.error('Chart analysis error:', error);
    throw error instanceof Error ? error : new Error('خطا در تحلیل نمودار');
  }
}

/**
 * Calculates technical indicators for the selected range
 */
export function calculateIndicators(data: ChartData[]) {
  const closes = data.map(d => d.close);
  const highs = data.map(d => d.high);
  const lows = data.map(d => d.low);
  
  // Calculate moving averages
  const sma20 = calculateSMA(closes, 20);
  const ema20 = calculateEMA(closes, 20);
  
  // Calculate RSI
  const rsi = calculateRSI(closes);
  
  // Calculate support and resistance levels
  const levels = findSupportResistance(highs, lows);
  
  return {
    sma20,
    ema20,
    rsi,
    ...levels
  };
}

/**
 * Finds support and resistance levels
 */
function findSupportResistance(highs: number[], lows: number[]) {
  const maxHigh = Math.max(...highs);
  const minLow = Math.min(...lows);
  
  // Find local extremes
  const supports: number[] = [];
  const resistances: number[] = [];
  
  for (let i = 1; i < lows.length - 1; i++) {
    // Support level
    if (lows[i] < lows[i-1] && lows[i] < lows[i+1]) {
      supports.push(lows[i]);
    }
    // Resistance level
    if (highs[i] > highs[i-1] && highs[i] > highs[i+1]) {
      resistances.push(highs[i]);
    }
  }
  
  return {
    supports: [...new Set(supports)].sort((a, b) => a - b),
    resistances: [...new Set(resistances)].sort((a, b) => a - b)
  };
}

/**
 * Calculates Simple Moving Average
 */
function calculateSMA(data: number[], period: number): number[] {
  const sma = [];
  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      sma.push(null);
      continue;
    }
    const sum = data.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
    sma.push(sum / period);
  }
  return sma;
}

/**
 * Calculates Exponential Moving Average
 */
function calculateEMA(data: number[], period: number): number[] {
  const ema = [];
  const multiplier = 2 / (period + 1);
  
  // First EMA uses SMA as initial value
  const smaFirst = data.slice(0, period).reduce((a, b) => a + b, 0) / period;
  ema.push(smaFirst);
  
  for (let i = 1; i < data.length; i++) {
    const value = data[i] * multiplier + ema[i - 1] * (1 - multiplier);
    ema.push(value);
  }
  
  return ema;
}

/**
 * Calculates Relative Strength Index
 */
function calculateRSI(data: number[], period: number = 14): number[] {
  const rsi = [];
  let gains = [];
  let losses = [];
  
  // Calculate price changes
  for (let i = 1; i < data.length; i++) {
    const change = data[i] - data[i - 1];
    gains.push(change > 0 ? change : 0);
    losses.push(change < 0 ? -change : 0);
  }
  
  // Calculate initial averages
  let avgGain = gains.slice(0, period).reduce((a, b) => a + b, 0) / period;
  let avgLoss = losses.slice(0, period).reduce((a, b) => a + b, 0) / period;
  
  // Calculate RSI values
  for (let i = 0; i < data.length; i++) {
    if (i < period) {
      rsi.push(null);
      continue;
    }
    
    const rs = avgGain / avgLoss;
    rsi.push(100 - (100 / (1 + rs)));
    
    // Update averages
    if (i < data.length - 1) {
      avgGain = ((avgGain * (period - 1)) + gains[i]) / period;
      avgLoss = ((avgLoss * (period - 1)) + losses[i]) / period;
    }
  }
  
  return rsi;
}