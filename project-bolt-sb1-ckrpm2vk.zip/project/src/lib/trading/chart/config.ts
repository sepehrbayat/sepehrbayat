export const CHART_CONFIG = {
  // Z-index layers
  zIndex: {
    container: 1,
    chart: 2,
    selection: 3,
    tooltip: 4
  },

  // Interaction settings
  interaction: {
    minScale: 0.1,
    maxScale: 10,
    wheelZoomRate: 0.1,
    pinchZoomRate: 0.1,
    panSensitivity: 1,
    doubleTapDelay: 300
  },

  // Selection overlay
  selection: {
    fillColor: 'rgba(76, 175, 80, 0.1)',
    strokeColor: 'rgba(76, 175, 80, 0.5)',
    strokeWidth: 1,
    markerRadius: 4,
    markerFillColor: '#4CAF50',
    markerStrokeColor: '#fff',
    markerStrokeWidth: 2
  },

  // Debug settings
  debug: {
    logEvents: true,
    logCoordinates: true,
    logSelectionState: true,
    logInteractions: true
  }
} as const;