import { useState, useEffect, useCallback } from 'react';
import { ChartData } from '../types';
import { marketService } from '../../market/service';

export function useChartData(symbol: string | undefined) {
  const [data, setData] = useState<ChartData[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadData = useCallback(async () => {
    if (!symbol) return;
    
    try {
      setIsLoading(true);
      setError(null);
      const historicalData = await marketService.fetchHistoricalData(symbol);
      setData(historicalData);
    } catch (error) {
      console.error('Error loading data:', error);
      setError(error instanceof Error ? error.message : 'خطا در دریافت داده‌ها');
    } finally {
      setIsLoading(false);
    }
  }, [symbol]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  return { data, isLoading, error, refreshData: loadData };
}