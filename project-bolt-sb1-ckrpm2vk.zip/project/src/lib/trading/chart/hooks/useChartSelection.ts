import { useState, useRef, useCallback } from 'react';
import { IChartApi } from 'lightweight-charts';
import { ChartData } from '../types';
import { analyzePatterns } from '../analysis';
import { SelectionMarker } from '../components/SelectionMarker';
import { SelectionRange } from '../components/SelectionRange';

export function useChartSelection(
  chart: IChartApi | null,
  data: ChartData[],
  onAnalyze?: (analysis: any) => void,
  isEnabled: boolean = true
) {
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [selectionGuide, setSelectionGuide] = useState<string | null>(null);
  const [selectedRange, setSelectedRange] = useState<{ start: number; end: number } | null>(null);
  
  const selectionStartRef = useRef<number | null>(null);
  const startMarkerRef = useRef<SelectionMarker | null>(null);
  const endMarkerRef = useRef<SelectionMarker | null>(null);
  const rangeRef = useRef<SelectionRange | null>(null);
  const isInitializedRef = useRef(false);

  // Reset selection state when chart changes
  useEffect(() => {
    if (chart && !isInitializedRef.current) {
      isInitializedRef.current = true;
    } else if (!chart) {
      isInitializedRef.current = false;
      clearSelection();
    }
  }, [chart]);

  const startSelection = useCallback(() => {
    if (!chart || !isEnabled || !isInitializedRef.current) return;
    
    setIsSelectionMode(true);
    selectionStartRef.current = null;
    setSelectionGuide('نقطه شروع محدوده را انتخاب کنید');
    
    // Initialize selection range
    if (!rangeRef.current) {
      rangeRef.current = new SelectionRange(chart);
    }
  }, [chart, isEnabled]);

  const handleClick = useCallback((time: number) => {
    if (!isSelectionMode || !chart || !isInitializedRef.current) return;

    if (selectionStartRef.current === null) {
      // Start selection
      selectionStartRef.current = time;
      
      // Create start marker
      startMarkerRef.current = new SelectionMarker({
        chart,
        data,
        time,
        isStart: true
      });
      startMarkerRef.current.draw();
      
      setSelectionGuide('حالا نقطه پایان را انتخاب کنید');
    } else {
      // End selection
      const start = Math.min(selectionStartRef.current, time);
      const end = Math.max(selectionStartRef.current, time);

      if (start === end) {
        // Invalid selection - clean up
        startMarkerRef.current?.remove();
        startMarkerRef.current = null;
        selectionStartRef.current = null;
        setSelectionGuide(null);
        return;
      }

      // Create end marker
      endMarkerRef.current = new SelectionMarker({
        chart,
        data,
        time,
        isStart: false
      });
      endMarkerRef.current.draw();

      // Draw selection range
      rangeRef.current?.draw(data, start, end);
      
      // Get selected data
      const selectedData = data.filter(d => {
        const time = typeof d.time === 'string' 
          ? new Date(d.time).getTime() / 1000 
          : d.time;
        return time >= start && time <= end;
      });

      // Analyze selected range
      if (selectedData.length > 0 && onAnalyze) {
        analyzePatterns(selectedData).then(analysis => {
          onAnalyze(analysis);
        }).catch(error => {
          console.error('Error analyzing selection:', error);
        });
      }

      setSelectedRange({ start, end });
      
      // Reset selection mode
      setIsSelectionMode(false);
      selectionStartRef.current = null;
      setSelectionGuide(null);
    }
  }, [isSelectionMode, chart, data, onAnalyze]);

  const clearSelection = useCallback(() => {
    // Clean up selection components
    startMarkerRef.current?.remove();
    endMarkerRef.current?.remove();
    rangeRef.current?.remove();
    
    // Reset refs
    startMarkerRef.current = null;
    endMarkerRef.current = null;
    selectionStartRef.current = null;
    rangeRef.current = null;
    
    // Reset state
    setSelectedRange(null);
    setSelectionGuide(null);
    setIsSelectionMode(false);
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      clearSelection();
    };
  }, []);

  return {
    isSelectionMode,
    selectionGuide,
    selectedRange,
    startSelection,
    handleClick,
    clearSelection
  };
}