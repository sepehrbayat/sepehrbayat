import { useRef, useCallback, useEffect } from 'react';
import { MARKET_CONFIG } from '../../market/config';
import { ChartData } from '../types';

interface UseWebSocketProps {
  symbol?: string;
  isOnline: boolean;
  onError?: (error: string) => void;
  onDataUpdate?: (data: ChartData) => void;
}

export function useWebSocket({ symbol, isOnline, onError, onDataUpdate }: UseWebSocketProps) {
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectAttemptRef = useRef(0);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();
  const isConnectingRef = useRef(false);
  const heartbeatIntervalRef = useRef<NodeJS.Timeout>();
  const lastPongRef = useRef<number>(Date.now());
  const connectionTimeoutRef = useRef<NodeJS.Timeout>();

  const connect = useCallback(() => {
    if (!isOnline) {
      onError?.('اتصال اینترنت برقرار نیست. لطفاً اتصال خود را بررسی کنید');
      isConnectingRef.current = false;
      return;
    }

    if (!symbol) {
      isConnectingRef.current = false;
      return;
    }

    // Prevent multiple connection attempts
    if (isConnectingRef.current) return;
    isConnectingRef.current = true;

    // Clean up existing connection
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }

    // Clear existing intervals/timeouts
    [reconnectTimeoutRef, heartbeatIntervalRef, connectionTimeoutRef].forEach(ref => {
      if (ref.current) {
        clearTimeout(ref.current);
        ref.current = null;
      }
    });

    try {
      const ws = new WebSocket(`${MARKET_CONFIG.eodHistorical.wsUrl}${symbol}?api_token=${MARKET_CONFIG.eodHistorical.apiKey}`);

      connectionTimeoutRef.current = setTimeout(() => {
        if (ws.readyState !== WebSocket.OPEN) {
          ws.close();
          throw new Error('زمان اتصال به پایان رسید');
        }
      }, MARKET_CONFIG.websocket.connectionTimeout);

      ws.onopen = () => {
        console.log('WebSocket connected');
        clearTimeout(connectionTimeoutRef.current);
        clearTimeout(reconnectTimeoutRef.current);
        connectionTimeoutRef.current = null;
        reconnectTimeoutRef.current = null;
        isConnectingRef.current = false;
        reconnectAttemptRef.current = 0;
        lastPongRef.current = Date.now();

        // Start heartbeat
        heartbeatIntervalRef.current = setInterval(() => {
          if (ws.readyState === WebSocket.OPEN) {
            // Check if we've received a pong recently
            if (Date.now() - lastPongRef.current > MARKET_CONFIG.websocket.heartbeatInterval * 2) {
              console.warn('No heartbeat response - reconnecting');
              ws.close();
              return;
            }
            ws.send(JSON.stringify({ type: 'ping' }));
          }
        }, MARKET_CONFIG.websocket.heartbeatInterval);

        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({
            action: 'subscribe',
            symbols: [symbol]
          }));
        }
      };

      ws.onclose = () => {
        console.log('WebSocket closed');
        isConnectingRef.current = false;
        wsRef.current = null;

        // Clear all intervals/timeouts
        [connectionTimeoutRef, heartbeatIntervalRef].forEach(ref => {
          if (ref.current) {
            clearTimeout(ref.current);
            ref.current = null;
          }
        });

        const shouldReconnect = 
          reconnectAttemptRef.current < MARKET_CONFIG.websocket.reconnectAttempts &&
          isOnline;

        if (shouldReconnect) {
          const baseDelay = Math.min(
            MARKET_CONFIG.websocket.baseBackoffDelay * Math.pow(2, reconnectAttemptRef.current),
            MARKET_CONFIG.websocket.maxBackoffDelay
          );
          const jitter = baseDelay * MARKET_CONFIG.websocket.jitterFactor * (Math.random() * 2 - 1);
          const delay = baseDelay + jitter;

          console.log(`Reconnecting in ${delay}ms (attempt ${reconnectAttemptRef.current + 1}/${MARKET_CONFIG.websocket.reconnectAttempts})`);
          
          // Clear any existing reconnect timeout
          if (reconnectTimeoutRef.current) {
            clearTimeout(reconnectTimeoutRef.current);
          }

          reconnectTimeoutRef.current = setTimeout(() => {
            reconnectAttemptRef.current++;
            connect();
          }, delay);
        } else {
          wsRef.current = null;
          isConnectingRef.current = false;
          reconnectAttemptRef.current = 0;
          const errorMessage = !isOnline 
            ? 'اتصال اینترنت قطع شده است'
            : 'تعداد تلاش‌های مجدد به حداکثر رسید. لطفاً صفحه را رفرش کنید';
          onError?.(errorMessage);
        }
      };

      ws.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);

          // Handle heartbeat responses
          if (message.type === 'pong' || message.type === 'heartbeat') {
            lastPongRef.current = Date.now();
            return;
          }

          if (message.type === 'trade' || message.type === 'quote') {
            onDataUpdate?.({
              time: message.data.t,
              open: message.data.p,
              high: message.data.p,
              low: message.data.p,
              close: message.data.p,
              volume: message.data.v || 0
            });
          }
        } catch (error) {
          console.error('WebSocket message error:', error);
        }
      };

      ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        clearTimeout(connectionTimeoutRef.current);
        clearTimeout(reconnectTimeoutRef.current);
        isConnectingRef.current = false;
        ws.close();
      };

      wsRef.current = ws;

    } catch (error) {
      console.error('WebSocket connection error:', error);
      isConnectingRef.current = false;
      if (error instanceof Error) {
        onError?.(error.message);
      } else {
        onError?.('خطا در برقراری ارتباط با سرور');
      }
    }
  }, [symbol, isOnline, onError, onDataUpdate]);

  useEffect(() => {
    connect();
    return () => {
      // Clear connection state
      isConnectingRef.current = false;
      reconnectAttemptRef.current = 0;

      // Close WebSocket if open
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }

      // Clear all intervals/timeouts
      [reconnectTimeoutRef, heartbeatIntervalRef, connectionTimeoutRef].forEach(ref => {
        if (ref.current) {
          clearTimeout(ref.current);
          ref.current = null;
        }
      });
    };
  }, [connect]);

  return {
    isConnected: wsRef.current?.readyState === WebSocket.OPEN,
    reconnect: connect
  };
}