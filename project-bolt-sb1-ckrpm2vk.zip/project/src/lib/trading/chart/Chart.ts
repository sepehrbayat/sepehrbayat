import { createChart, IChartApi, ISeriesApi, LineStyle, CrosshairMode } from 'lightweight-charts';
import { ChartData, ChartOptions, DrawingTool, ChartSelection } from './types';

export class TradingChart {
  private chart: IChartApi;
  private candlestickSeries: ISeriesApi<"Candlestick">;
  private volumeSeries: ISeriesApi<"Histogram">;
  private indicators: Map<string, ISeriesApi<"Line">>;
  private drawings: Map<string, ISeriesApi<"Line">>;
  private selection: ChartSelection | null = null;

  constructor(options: ChartOptions) {
    if (!options.container) {
      throw new Error('Container element is required');
    }
    
    // Get container dimensions
    const width = options.container.clientWidth;
    const height = options.container.clientHeight;
    
    if (width === 0 || height === 0) {
      throw new Error('Container must have non-zero dimensions');
    }

    // Create chart instance
    this.chart = createChart(options.container, {
      width,
      height,
      layout: {
        background: { color: options.theme === 'dark' ? '#1a1a1a' : '#ffffff' },
        textColor: options.theme === 'dark' ? '#d1d4dc' : '#131722',
      },
      grid: {
        vertLines: { visible: options.grid },
        horzLines: { visible: options.grid },
      },
      crosshair: {
        mode: options.crosshair ? CrosshairMode.Normal : CrosshairMode.Magnet,
      },
      rightPriceScale: {
        borderColor: options.theme === 'dark' ? '#4c525e' : '#e1e3e7',
      },
      timeScale: {
        borderColor: options.theme === 'dark' ? '#4c525e' : '#e1e3e7',
        timeVisible: true,
        secondsVisible: false,
      },
    });

    // Add candlestick series
    this.candlestickSeries = this.chart.addCandlestickSeries({
      upColor: '#26a69a',
      downColor: '#ef5350',
      borderVisible: false,
      wickUpColor: '#26a69a',
      wickDownColor: '#ef5350',
    });

    // Add volume series
    this.volumeSeries = this.chart.addHistogramSeries({
      color: '#26a69a',
      priceFormat: {
        type: 'volume',
      },
      priceScaleId: '', // Set as an overlay
    });

    // Initialize maps
    this.indicators = new Map<string, ISeriesApi<"Line">>();
    this.drawings = new Map<string, ISeriesApi<"Line">>();

    // Initialize event handlers
    this.initializeEventHandlers();
  }

  public getIndicators(): string[] {
    return Array.from(this.indicators.keys());
  }

  private initializeEventHandlers() {
    // Handle selection
    let selecting = false;
    let selectionStart: number | null = null;

    this.chart.subscribeClick((param) => {
      if (!selecting) {
        selecting = true;
        selectionStart = param.time as number;
      } else {
        selecting = false;
        const selectionEnd = param.time as number;
        this.handleSelection(selectionStart!, selectionEnd);
      }
    });

    // Handle crosshair move
    this.chart.subscribeCrosshairMove((param) => {
      if (selecting && selectionStart !== null) {
        this.updateSelectionPreview(selectionStart, param.time as number);
      }
    });
  }

  private handleSelection(from: number, to: number) {
    // Get data in selected range
    const data = this.candlestickSeries.data();
    const selectedData = data.filter(d => {
      const time = typeof d.time === 'number' ? d.time : new Date(d.time).getTime();
      return time >= from && time <= to;
    });

    if (selectedData.length === 0) return;

    // Calculate range statistics
    const high = Math.max(...selectedData.map(d => d.high));
    const low = Math.min(...selectedData.map(d => d.low));

    this.selection = {
      from,
      to,
      high,
      low,
      patterns: [],
      indicators: []
    };

    // Highlight selection
    this.drawSelectionBox();
  }

  private drawSelectionBox() {
    if (!this.selection) return;

    const { from, to, high, low } = this.selection;

    // Draw rectangle around selection
    const selectionSeries = this.chart.addLineSeries({
      color: 'rgba(76, 175, 80, 0.2)',
      lineWidth: 1,
      lineStyle: LineStyle.Dotted,
    });

    selectionSeries.setData([
      { time: from, value: high },
      { time: to, value: high },
      { time: to, value: low },
      { time: from, value: low },
      { time: from, value: high },
    ]);
  }

  private updateSelectionPreview(from: number, to: number) {
    // Update visual selection preview while dragging
    this.drawSelectionBox();
  }

  public setData(data: ChartData[]) {
    // Set candlestick data
    this.candlestickSeries.setData(data);

    // Set volume data
    this.volumeSeries.setData(
      data.map(d => ({
        time: d.time,
        value: d.volume,
        color: d.close >= d.open ? '#26a69a' : '#ef5350'
      }))
    );
  }

  public addIndicator(name: string, data: { time: string; value: number }[]) {
    // Remove existing indicator if any
    this.removeIndicator(name);
    
    if (!this.chart) {
      throw new Error('Chart not initialized');
    }

    const series = this.chart.addLineSeries({
      color: this.getIndicatorColor(name),
      lineWidth: 2,
      title: name,
    });

    series.setData(data.filter(d => d.value !== null));
    this.indicators.set(name, series);
  }

  public removeIndicator(name: string) {
    const series = this.indicators.get(name);
    if (series) {
      try {
        this.chart.removeSeries(series);
      } catch (error) {
        console.warn(`Error removing indicator ${name}:`, error);
      } finally {
        this.indicators.delete(name);
      }
    }
  }

  public addDrawing(tool: DrawingTool) {
    const series = this.chart.addLineSeries({
      color: tool.color,
      lineWidth: tool.width,
      lineStyle: this.getLineStyle(tool.style),
    });

    const id = `drawing-${Date.now()}`;
    this.drawings.set(id, series);
    return id;
  }

  public removeDrawing(id: string) {
    const series = this.drawings.get(id);
    if (series) {
      this.chart.removeSeries(series);
      this.drawings.delete(id);
    }
  }

  private getIndicatorColor(name: string): string {
    const colors: Record<string, string> = {
      'SMA': '#2196F3',
      'EMA': '#9C27B0',
      'RSI': '#FF9800',
      'MACD': '#4CAF50',
      'Bollinger': '#E91E63'
    };
    return colors[name] || '#787B86';
  }

  private getLineStyle(style: string): LineStyle {
    const styles: Record<string, LineStyle> = {
      'solid': LineStyle.Solid,
      'dotted': LineStyle.Dotted,
      'dashed': LineStyle.Dashed
    };
    return styles[style] || LineStyle.Solid;
  }

  public resize() {
    if (this.chart) {
      const container = this.chart.chartElement.parentElement;
      if (container) {
        const { clientWidth, clientHeight } = container;
        if (clientWidth > 0 && clientHeight > 0) {
          this.chart.applyOptions({
            width: clientWidth,
            height: clientHeight
          });
          this.chart.timeScale().fitContent();
        }
      }
    }
  }

  public destroy() {
    this.chart.remove();
  }
}