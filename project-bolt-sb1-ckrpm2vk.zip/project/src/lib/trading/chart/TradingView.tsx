import React, { useRef, useState, useEffect } from 'react';
import { Brain, Settings2, Download, AlertCircle } from 'lucide-react';
import { createChart, CrosshairMode } from 'lightweight-charts';
import { ChartData, ChartOptions, ChartAnalysis } from './types';
import { CHART_COLORS, CHART_CONFIG, INDICATOR_COLORS } from './constants';
import { useChartData } from './hooks/useChartData';
import { useChartSelection } from './hooks/useChartSelection';
import { useWebSocket } from './hooks/useWebSocket';
import { calculateSMA, calculateEMA, calculateRSI, calculateMACD, calculateBollingerBands } from './indicators';

interface TradingViewProps {
  data: ChartData[];
  options?: Partial<ChartOptions>;
  onAnalyze?: (analysis: ChartAnalysis) => void;
  onError?: (error: string) => void;
  className?: string;
  symbol?: string;
}

export default function TradingView({
  data: initialData,
  options,
  onAnalyze,
  onError,
  symbol,
  className = ''
}: TradingViewProps) {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<ReturnType<typeof createChart> | null>(null);
  const candlestickSeriesRef = useRef<any>(null);
  const [isInitialized, setIsInitialized] = useState(false);
  const initializationAttemptedRef = useRef(false);
  const indicatorSeriesRef = useRef<Map<string, any>>(new Map());
  const [showSettings, setShowSettings] = useState(false);
  const [selectedIndicators, setSelectedIndicators] = useState<string[]>(['SMA', 'RSI']);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [chartInstance, setChartInstance] = useState<ReturnType<typeof createChart> | null>(null);
  const { data, isLoading, error: dataError } = useChartData(symbol);

  // Initialize selection hook with memoized chart instance
  const memoizedChartInstance = React.useMemo(() => chartInstance, [chartInstance]);
  const {
    isSelectionMode,
    selectionGuide,
    selectedRange,
    startSelection,
    handleClick,
    clearSelection
  } = useChartSelection(memoizedChartInstance, data || [], onAnalyze, isInitialized);

  const { isConnected } = useWebSocket({
    symbol,
    isOnline,
    onError,
    onDataUpdate: (update) => {
      if (candlestickSeriesRef.current) {
        candlestickSeriesRef.current.update(update);
      }
    }
  });

  useEffect(() => {
    if (!chartContainerRef.current || initializationAttemptedRef.current) return;
    
    initializationAttemptedRef.current = true;
    
    setIsInitialized(false);

    const cleanup = () => {
      if (chartRef.current) {
        try {
          // Clear indicators
          indicatorSeriesRef.current.forEach(series => {
            try {
              chartRef.current?.removeSeries(series);
            } catch (error) {
              console.warn('Error removing indicator series:', error);
            }
          });
          indicatorSeriesRef.current.clear();

          // Clear candlestick series
          if (candlestickSeriesRef.current) {
            chartRef.current.removeSeries(candlestickSeriesRef.current);
            candlestickSeriesRef.current = null;
          }

          // Remove chart
          chartRef.current.remove();
          chartRef.current = null;
          setChartInstance(null);
          initializationAttemptedRef.current = false;
          setIsInitialized(false);
        } catch (error) {
          console.warn('Chart cleanup error:', error);
          // Reset state even if cleanup fails
          chartRef.current = null;
          setChartInstance(null);
          initializationAttemptedRef.current = false;
          setIsInitialized(false);
        }
      }
    };

    cleanup();

    try {
      // Create new chart instance
      const newChart = createChart(chartContainerRef.current, {
        width: chartContainerRef.current.clientWidth,
        height: CHART_CONFIG.height,
        layout: {
          background: { color: CHART_COLORS.background },
          textColor: CHART_COLORS.text,
        },
        grid: {
          vertLines: { color: CHART_COLORS.grid },
          horzLines: { color: CHART_COLORS.grid },
        },
        crosshair: {
          mode: CrosshairMode.Normal,
        },
        rightPriceScale: {
          borderColor: CHART_COLORS.grid,
        },
        timeScale: {
          borderColor: CHART_COLORS.grid,
          timeVisible: true,
          secondsVisible: false,
        },
      });

      // Store chart references
      chartRef.current = newChart; // Keep ref for internal use
      setChartInstance(newChart); // Update state for selection hook
      setIsInitialized(true);

      const candlestickSeries = newChart.addCandlestickSeries({
        upColor: CHART_COLORS.upColor,
        downColor: CHART_COLORS.downColor,
        borderVisible: false,
        wickUpColor: CHART_COLORS.upColor,
        wickDownColor: CHART_COLORS.downColor,
      });

      candlestickSeriesRef.current = candlestickSeries;

      if (data?.length > 0) {
        candlestickSeries.setData(data);
        newChart.timeScale().fitContent();
      }

      const clickHandler = (param: any) => {
        if (!chartRef.current) return;
        
        console.log('Chart click:', param);
        if (param.time) {
          const clickTime = typeof param.time === 'string'
            ? new Date(param.time).getTime() / 1000
            : param.time;
          console.log('Processed click time:', clickTime);
          handleClick(clickTime);
        }
      };

      // Subscribe to click events
      const unsubscribeClick = newChart.subscribeClick(clickHandler);

      const handleResize = () => {
        if (chartRef.current && chartContainerRef.current) {
          chartRef.current.applyOptions({
            width: chartContainerRef.current.clientWidth,
          });
        }
      };

      window.addEventListener('resize', handleResize);

      return () => {
        // Cleanup in specific order
        window.removeEventListener('resize', handleResize);
        unsubscribeClick(); // Always unsubscribe
        clearSelection?.(); // Clear selection before chart cleanup
        cleanup();
      };
    } catch (error) {
      console.error('Chart initialization error:', error);
      onError?.(error instanceof Error ? error.message : 'Error initializing chart');
      cleanup();
    }
  }, [data?.length]);

  // Update data
  useEffect(() => {
    if (isInitialized && chartRef.current && candlestickSeriesRef.current && data?.length > 0) {
      // Batch updates to prevent flickering
      requestAnimationFrame(() => {
        try {
          candlestickSeriesRef.current.setData(data);
          chartRef.current?.timeScale().fitContent();
        } catch (error) {
          console.error('Error updating chart data:', error);
          if (error instanceof Error && error.message === 'Object is disposed') {
            setIsInitialized(false);
            // Reset chart state
            chartRef.current = null;
            candlestickSeriesRef.current = null;
            initializationAttemptedRef.current = false;
            setChartInstance(null);
            setIsInitialized(false);
          }
          onError?.(error instanceof Error ? error.message : 'Error updating chart');
        }
      });
    }
  }, [data, isInitialized]);

  // Update indicators
  React.useEffect(() => {
    if (!isInitialized || !chartRef.current || !data?.length) return;
    
    try {
      // Remove existing indicators
      indicatorSeriesRef.current.forEach(series => {
        try {
          chartRef.current?.removeSeries(series);
        } catch (error) {
          if (error instanceof Error && !error.message.includes('disposed')) {
            console.warn('Error removing indicator series:', error);
          }
        }
      });
      indicatorSeriesRef.current.clear();

      // Add selected indicators
      selectedIndicators.forEach(indicator => {
        const prices = data.map(d => d.close);
        let indicatorData;

        switch (indicator) {
          case 'SMA':
            indicatorData = calculateSMA(prices, 20);
            break;
          case 'EMA':
            indicatorData = calculateEMA(prices, 20);
            break;
          case 'RSI':
            indicatorData = calculateRSI(prices);
            break;
          case 'MACD':
            const macd = calculateMACD(prices);
            indicatorData = macd.macd;
            break;
          case 'Bollinger':
            const bb = calculateBollingerBands(prices);
            indicatorData = bb.middle;
            break;
        }

        if (indicatorData && chartRef.current) {
          const series = chartRef.current.addLineSeries({
            color: INDICATOR_COLORS[indicator as keyof typeof INDICATOR_COLORS],
            lineWidth: 2,
            title: indicator,
          });

          series.setData(
            indicatorData.map((value, i) => ({
              time: data[i].time,
              value: value || 0
            }))
          );

          // Store series reference
          indicatorSeriesRef.current.set(indicator, series);
        }
      });
    } catch (error) {
      console.error('Error updating indicators:', error);
      if (error instanceof Error) {
        onError?.(error.message);
        if (error.message.includes('disposed')) {
          setIsInitialized(false);
          chartRef.current = null;
          candlestickSeriesRef.current = null;
        }
      }
    }
  }, [selectedIndicators, data, isInitialized]);

  // Monitor network status
  React.useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleExport = (format: 'png' | 'csv') => {
    if (!chartContainerRef.current) return;

    if (format === 'png') {
      const canvas = chartContainerRef.current.querySelector('canvas');
      if (!canvas) return;

      const link = document.createElement('a');
      link.download = 'chart.png';
      link.href = canvas.toDataURL('image/png');
      link.click();
    } else {
      const csv = data.map(d => 
        `${d.time},${d.open},${d.high},${d.low},${d.close},${d.volume}`
      ).join('\n');
      
      const blob = new Blob([csv], { type: 'text/csv' });
      const link = document.createElement('a');
      link.download = 'chart-data.csv';
      link.href = URL.createObjectURL(blob);
      link.click();
    }
  };

  return (
    <div className={`bg-white rounded-xl p-6 space-y-6 ${className}`}>
      {!isOnline && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 flex items-center gap-3 text-yellow-700 mb-4">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <p>اتصال اینترنت برقرار نیست. لطفاً اتصال خود را بررسی کنید</p>
        </div>
      )}

      {selectionGuide && (
        <div className="bg-[#a63439]/5 border border-[#a63439]/10 rounded-lg p-4 flex items-center gap-3 text-[#a63439] mb-4 animate-fadeIn">
          <Brain className="w-5 h-5 flex-shrink-0" />
          <p>{selectionGuide}</p>
        </div>
      )}

      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setShowSettings(!showSettings)}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <Settings2 className="w-5 h-5 text-gray-500" />
          </button>
          <div className="flex gap-2">
            <button
              onClick={() => handleExport('png')}
              className="bg-gray-100 text-gray-700 px-3 py-1 rounded-lg hover:bg-gray-200 transition-colors flex items-center gap-1 text-sm"
            >
              <Download className="w-4 h-4" />
              PNG
            </button>
            <button
              onClick={() => handleExport('csv')}
              className="bg-gray-100 text-gray-700 px-3 py-1 rounded-lg hover:bg-gray-200 transition-colors flex items-center gap-1 text-sm"
            >
              <Download className="w-4 h-4" />
              CSV
            </button>
          </div>
        </div>
        {onAnalyze && (
          <button
            onClick={startSelection}
            disabled={!data.length || isSelectionMode}
            className="bg-[#a63439] text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
          >
            <Brain className="w-4 h-4" />
            <span>انتخاب محدوده تحلیل</span>
          </button>
        )}
        {selectedRange && (
          <button
            onClick={clearSelection}
            className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-gray-200 transition-all"
          >
            <span>پاک کردن انتخاب</span>
          </button>
        )}
      </div>

      {showSettings && (
        <div className="mb-6 p-4 bg-gray-50 rounded-lg space-y-4">
          <h3 className="text-sm font-medium mb-2">اندیکاتورها</h3>
          <div className="flex flex-wrap gap-2">
            {['SMA', 'EMA', 'RSI', 'MACD', 'Bollinger'].map(indicator => (
              <label key={indicator} className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={selectedIndicators.includes(indicator)}
                  onChange={(e) => {
                    if (e.target.checked) {
                      setSelectedIndicators([...selectedIndicators, indicator]);
                    } else {
                      setSelectedIndicators(selectedIndicators.filter(i => i !== indicator));
                    }
                  }}
                  className="rounded text-[#a63439]"
                />
                <span className="text-sm">{indicator}</span>
              </label>
            ))}
          </div>
        </div>
      )}

      <div className="relative w-full" style={{ minHeight: '500px' }}>
        {/* Main chart container */}
        <div 
          ref={chartContainerRef} 
          className="absolute inset-0 bg-white border border-gray-100 rounded-lg overflow-hidden"
          style={{ zIndex: CHART_CONFIG.zIndex.chart }}
        />
        
        {/* Selection overlay */}
        <div 
          className="absolute inset-0 pointer-events-none"
          style={{ zIndex: CHART_CONFIG.zIndex.selection }}
        >
          {isSelectionMode && (
            <div className="absolute inset-0 bg-black/5 cursor-crosshair" />
          )}
        </div>

        {/* Tooltips layer */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{ zIndex: CHART_CONFIG.zIndex.tooltip }}
        />
      </div>

      {isLoading && (
        <div className="absolute inset-0 bg-white/50 backdrop-blur-sm flex items-center justify-center z-10">
          <div className="flex items-center gap-3">
            <div className="w-5 h-5 border-2 border-[#a63439] border-t-transparent rounded-full animate-spin" />
            <span className="text-gray-600">در حال بارگذاری نمودار...</span>
          </div>
        </div>
      )}

      {dataError && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700 mt-4">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <p>{dataError}</p>
        </div>
      )}
    </div>
  );
}