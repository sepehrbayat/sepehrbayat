export const CHART_COLORS = {
  upColor: '#26a69a',
  downColor: '#ef5350',
  selectionStart: '#4CAF50',
  selectionEnd: '#f44336',
  selectionRange: 'rgba(76, 175, 80, 0.2)',
  grid: '#f0f0f0',
  background: '#ffffff',
  text: '#333333'
} as const;

export const CHART_CONFIG = {
  height: 500,
  margins: {
    top: 0.1,
    bottom: 0.1
  },
  animation: {
    duration: 300,
    easing: 'easeInOutCubic'
  }
} as const;

export const INDICATOR_COLORS = {
  SMA: '#2196F3',
  EMA: '#9C27B0',
  RSI: '#FF9800',
  MACD: '#4CAF50',
  Bollinger: '#E91E63'
} as const;