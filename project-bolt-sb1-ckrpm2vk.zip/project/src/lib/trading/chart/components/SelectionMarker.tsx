import React from 'react';
import { IChartApi, ISeriesApi } from 'lightweight-charts';
import { ChartData } from '../types';

interface SelectionMarkerProps {
  chart: IChartApi | null;
  data: ChartData[];
  time: number;
  isStart: boolean;
  onRemove?: () => void;
}

export class SelectionMarker {
  private markerSeries: ISeriesApi<'Line'> | null = null;

  constructor(private props: SelectionMarkerProps) {}

  draw() {
    const { chart, data, time, isStart } = this.props;
    if (!chart) return;

    // Find the price at the selected time
    const point = data.find(d => {
      const dataTime = typeof d.time === 'string' 
        ? new Date(d.time).getTime() / 1000
        : d.time;
      return dataTime === time;
    });
    
    if (!point) return;
    
    // Remove existing marker
    this.remove();
    
    // Create new marker series
    this.markerSeries = chart.addLineSeries({
      color: isStart ? '#4CAF50' : '#f44336',
      lineWidth: 2,
      lastValueVisible: false,
      priceLineVisible: false,
    });
    
    // Draw vertical line marker with animation
    const markerHeight = (point.high - point.low) * 0.1;
    this.markerSeries.setData([
      { time, value: point.high + markerHeight },
      { time, value: point.low - markerHeight }
    ]);
  }

  remove() {
    if (this.markerSeries && this.props.chart) {
      try {
        this.props.chart.removeSeries(this.markerSeries);
        this.markerSeries = null;
        this.props.onRemove?.();
      } catch (error) {
        console.warn('Error removing marker series:', error);
      }
    }
  }

  getSeries() {
    return this.markerSeries;
  }
}