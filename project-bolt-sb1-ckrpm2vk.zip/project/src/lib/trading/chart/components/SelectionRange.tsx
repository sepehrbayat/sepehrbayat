import { IChartApi, ISeriesApi } from 'lightweight-charts';
import { ChartData } from '../types';

export class SelectionRange {
  private rangeSeries: ISeriesApi<'Line'> | null = null;

  constructor(private chart: IChartApi | null) {}

  draw(data: ChartData[], start: number, end: number) {
    if (!this.chart) return;
    
    // Debug logging
    if (CHART_CONFIG.debug.logSelectionState) {
      console.log('Drawing selection range:', { start, end });
    }
    
    // Ensure start and end are different
    if (start === end) return;
    
    // Remove previous selection series
    this.remove();
    
    // Get price range for selection
    const selectedData = data.filter(d => {
      const time = typeof d.time === 'string' 
        ? new Date(d.time).getTime() / 1000 
        : d.time;
      return time >= start && time <= end;
    });
    
    if (selectedData.length === 0) return;
    
    const high = Math.max(...selectedData.map(d => d.high));
    const low = Math.min(...selectedData.map(d => d.low));
    
    // Add new selection markers with improved options
    this.rangeSeries = this.chart.addLineSeries({
      color: CHART_CONFIG.selection.fillColor,
      lineWidth: CHART_CONFIG.selection.strokeWidth,
      lineStyle: 2, // Dotted
      priceLineVisible: false,
      lastValueVisible: false,
      crosshairMarkerVisible: false,
      zIndex: -1,
      autoscaleInfoProvider: () => ({
        priceRange: {
          minValue: low,
          maxValue: high
        }
      })
    });
    
    // Draw selection box with animation
    const selectionPoints = [
      { time: start, value: high },
      { time: end, value: high },
      { time: end, value: low },
      { time: start, value: low }
    ];
    
    // Sort points by time to ensure ascending order
    selectionPoints.sort((a, b) => a.time - b.time);
    
    this.rangeSeries.setData([
      ...selectionPoints,
      { time: selectionPoints[0].time, value: selectionPoints[0].value } // Close the box
    ]);
  }

  remove() {
    if (this.rangeSeries && this.chart) {
      try {
        this.chart.removeSeries(this.rangeSeries);
        this.rangeSeries = null;
      } catch (error) {
        console.warn('Error removing selection range:', error);
      }
    }
  }

  getSeries() {
    return this.rangeSeries;
  }
}