export interface ChartData {
  time: string | number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface ChartOptions {
  container: HTMLElement;
  timeframe: string;
  indicators: string[];
  theme: 'light' | 'dark';
  grid: boolean;
  crosshair: boolean;
}

export interface ChartAnalysis {
  patterns: Array<{
    name: string;
    probability: number;
    target: number;
    stopLoss: number;
  }>;
  trend: {
    direction: 'up' | 'down' | 'sideways';
    strength: number;
    support: number[];
    resistance: number[];
  };
  indicators: Array<{
    name: string;
    value: number;
    signal: 'buy' | 'sell' | 'neutral';
  }>;
  recommendations: string[];
  insights: string[];
}

export interface SelectionState {
  start: number | null;
  end: number | null;
  isSelecting: boolean;
  guide: string | null;
}