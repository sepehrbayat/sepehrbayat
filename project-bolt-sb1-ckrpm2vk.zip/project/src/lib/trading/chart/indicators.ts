/**
 * Technical Indicators
 */

// Simple Moving Average (SMA)
export function calculateSMA(data: number[], period: number): number[] {
  const sma = [];
  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      sma.push(null);
      continue;
    }
    const sum = data.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
    sma.push(sum / period);
  }
  return sma;
}

// Exponential Moving Average (EMA)
export function calculateEMA(data: number[], period: number): number[] {
  const ema = [];
  const multiplier = 2 / (period + 1);

  // First EMA uses SMA as initial value
  const smaFirst = data.slice(0, period).reduce((a, b) => a + b, 0) / period;
  ema.push(smaFirst);

  for (let i = 1; i < data.length; i++) {
    const value = data[i] * multiplier + ema[i - 1] * (1 - multiplier);
    ema.push(value);
  }

  return ema;
}

// Relative Strength Index (RSI)
export function calculateRSI(data: number[], period: number = 14): number[] {
  const rsi = [];
  let gains = [];
  let losses = [];

  // Calculate price changes
  for (let i = 1; i < data.length; i++) {
    const change = data[i] - data[i - 1];
    gains.push(change > 0 ? change : 0);
    losses.push(change < 0 ? -change : 0);
  }

  // Calculate initial averages
  let avgGain = gains.slice(0, period).reduce((a, b) => a + b, 0) / period;
  let avgLoss = losses.slice(0, period).reduce((a, b) => a + b, 0) / period;

  // Calculate RSI values
  for (let i = 0; i < data.length; i++) {
    if (i < period) {
      rsi.push(null);
      continue;
    }

    const rs = avgGain / avgLoss;
    rsi.push(100 - (100 / (1 + rs)));

    // Update averages
    if (i < data.length - 1) {
      avgGain = ((avgGain * (period - 1)) + gains[i]) / period;
      avgLoss = ((avgLoss * (period - 1)) + losses[i]) / period;
    }
  }

  return rsi;
}

// Moving Average Convergence Divergence (MACD)
export function calculateMACD(
  data: number[],
  fastPeriod: number = 12,
  slowPeriod: number = 26,
  signalPeriod: number = 9
): { macd: number[]; signal: number[]; histogram: number[] } {
  const fastEMA = calculateEMA(data, fastPeriod);
  const slowEMA = calculateEMA(data, slowPeriod);
  
  // Calculate MACD line
  const macdLine = fastEMA.map((fast, i) => fast - slowEMA[i]);
  
  // Calculate Signal line (9-day EMA of MACD line)
  const signalLine = calculateEMA(macdLine, signalPeriod);
  
  // Calculate Histogram
  const histogram = macdLine.map((macd, i) => macd - signalLine[i]);

  return {
    macd: macdLine,
    signal: signalLine,
    histogram
  };
}

// Bollinger Bands
export function calculateBollingerBands(
  data: number[],
  period: number = 20,
  stdDev: number = 2
): { upper: number[]; middle: number[]; lower: number[] } {
  const middle = calculateSMA(data, period);
  const upper = [];
  const lower = [];

  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      upper.push(null);
      lower.push(null);
      continue;
    }

    const slice = data.slice(i - period + 1, i + 1);
    const avg = middle[i];
    const std = Math.sqrt(
      slice.reduce((sum, val) => sum + Math.pow(val - avg, 2), 0) / period
    );

    upper.push(avg + (stdDev * std));
    lower.push(avg - (stdDev * std));
  }

  return { upper, middle, lower };
}

// Average True Range (ATR)
export function calculateATR(
  high: number[],
  low: number[],
  close: number[],
  period: number = 14
): number[] {
  const tr = [0]; // True Range
  const atr = []; // Average True Range

  // Calculate True Range
  for (let i = 1; i < close.length; i++) {
    const trueHigh = Math.max(high[i], close[i - 1]);
    const trueLow = Math.min(low[i], close[i - 1]);
    tr.push(trueHigh - trueLow);
  }

  // Calculate ATR
  let sum = tr.slice(0, period).reduce((a, b) => a + b, 0);
  atr.push(sum / period);

  for (let i = period; i < tr.length; i++) {
    atr.push(((atr[i - period] * (period - 1)) + tr[i]) / period);
  }

  return atr;
}