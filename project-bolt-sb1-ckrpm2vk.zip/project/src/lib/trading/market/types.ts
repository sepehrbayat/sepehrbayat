export interface MarketDataConfig {
  apiKey: string;
  baseUrl: string;
  wsUrl: string;
  requestTimeout: number;
  reconnectDelay: number;
  maxRetries: number;
}

export interface MarketSymbol {
  symbol: string;
  name: string;
  type: 'stock' | 'crypto' | 'forex';
  exchange?: string;
}

export interface MarketQuote {
  symbol: string;
  price: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  timestamp: number;
}

export interface WebSocketMessage {
  type: 'trade' | 'quote' | 'bar' | 'status';
  data: {
    s?: string;  // Symbol
    p?: number;  // Price
    v?: number;  // Volume
    t?: number;  // Timestamp
    dp?: boolean; // Dark pool flag
    ms?: string;  // Market status
    a?: number;  // Ask price (forex)
    b?: number;  // Bid price (forex)
    dc?: number; // Daily change %
    dd?: number; // Daily difference
    q?: number;  // Quantity (crypto)
  };
}

export interface SubscriptionOptions {
  symbol: string;
  interval?: string;
  depth?: number;
}

export type MessageHandler = (message: WebSocketMessage) => void;