import { useState, useEffect } from 'react';
import { MarketQuote, WebSocketMessage } from './types';
import { marketService } from './service';

/**
 * Hook for real-time market data
 */
export function useMarketData(symbol: string, interval: string = '1m') {
  const [data, setData] = useState<MarketQuote[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;

    const loadHistoricalData = async () => {
      try {
        setIsLoading(true);
        setError(null);

        const historicalData = await marketService.fetchHistoricalData(symbol, interval);
        if (mounted) {
          setData(historicalData);
        }

      } catch (error) {
        console.error('Error loading historical data:', error);
        if (mounted) {
          setError(error instanceof Error ? error.message : 'خطا در دریافت داده‌ها');
        }
      } finally {
        if (mounted) {
          setIsLoading(false);
        }
      }
    };

    const handleUpdate = (message: WebSocketMessage) => {
      if (!mounted) return;

      if (message.type === 'trade' || message.type === 'quote') {
        setData(prev => {
          const quote = message.data as MarketQuote;
          const lastQuote = prev[prev.length - 1];

          // Update last bar if within same interval
          if (lastQuote && isWithinInterval(quote.timestamp, lastQuote.timestamp, interval)) {
            const updatedQuotes = [...prev];
            updatedQuotes[updatedQuotes.length - 1] = {
              ...lastQuote,
              high: Math.max(lastQuote.high, quote.price),
              low: Math.min(lastQuote.low, quote.price),
              close: quote.price,
              volume: lastQuote.volume + quote.volume
            };
            return updatedQuotes;
          }

          // Add new bar
          return [...prev, {
            symbol: quote.symbol,
            timestamp: quote.timestamp,
            open: quote.price,
            high: quote.price,
            low: quote.price,
            close: quote.price,
            volume: quote.volume,
            price: quote.price
          }];
        });
      }
    };

    // Load historical data and subscribe to updates
    loadHistoricalData();
    marketService.subscribe({ symbol, interval }, handleUpdate);

    return () => {
      mounted = false;
      marketService.unsubscribe(symbol, handleUpdate);
    };
  }, [symbol, interval]);

  return { data, isLoading, error };
}

/**
 * Checks if timestamp is within the same interval
 */
function isWithinInterval(t1: number, t2: number, interval: string): boolean {
  const diff = Math.abs(t1 - t2);
  const intervals: Record<string, number> = {
    '1m': 60 * 1000,
    '5m': 5 * 60 * 1000,
    '15m': 15 * 60 * 1000,
    '30m': 30 * 60 * 1000,
    '1h': 60 * 60 * 1000,
    '4h': 4 * 60 * 60 * 1000,
    '1d': 24 * 60 * 60 * 1000
  };
  return diff < (intervals[interval] || intervals['1m']);
}