export const MARKET_CONFIG = {
  // EOD Historical Data API configuration
  eodHistorical: {
    apiKey: '67cb042e97be55.83901871', 
    baseUrl: 'https://eodhd.com/api',
    wsUrl: 'wss://ws.eodhistoricaldata.com/ws/us/',
    requestTimeout: 10000,
    reconnectDelay: 1000,
    maxRetries: 3
  },

  // Intervals for data fetching
  intervals: {
    '1m': '1min',
    '5m': '5min',
    '15m': '15min',
    '30m': '30min',
    '1h': '1h',
    '4h': '4h',
    '1d': '1d'
  },

  // Rate limiting
  rateLimit: {
    requests: 5,
    perSecond: 1,
    burstRequests: 10
  },

  // WebSocket configuration
  websocket: {
    reconnectAttempts: 5,
    heartbeatInterval: 15000,
    connectionTimeout: 15000,
    maxBackoffDelay: 30000,
    baseBackoffDelay: 2000,
    jitterFactor: 0.1
  }
} as const;