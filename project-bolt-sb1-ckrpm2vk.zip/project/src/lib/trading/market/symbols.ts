// Popular trading symbols by category
export const POPULAR_SYMBOLS = {
  stocks: {
    us: [
      { symbol: 'AAPL', name: 'Apple Inc.' },
      { symbol: 'MSFT', name: 'Microsoft Corporation' },
      { symbol: 'GOOGL', name: 'Alphabet Inc.' },
      { symbol: 'AMZN', name: 'Amazon.com Inc.' },
      { symbol: 'META', name: 'Meta Platforms Inc.' },
      { symbol: 'TSLA', name: 'Tesla Inc.' },
      { symbol: 'NVDA', name: 'NVIDIA Corporation' },
      { symbol: 'JPM', name: 'JPMorgan Chase & Co.' }
    ]
  },
  crypto: [
    { symbol: 'BTC-USD', name: 'Bitcoin' },
    { symbol: 'ETH-USD', name: 'Ethereum' },
    { symbol: 'BNB-USD', name: 'Binance Coin' },
    { symbol: 'XRP-USD', name: 'Ripple' },
    { symbol: 'ADA-USD', name: 'Cardano' },
    { symbol: 'SOL-USD', name: 'Solana' },
    { symbol: 'DOT-USD', name: 'Polkadot' },
    { symbol: 'DOGE-USD', name: 'Dogecoin' }
  ],
  forex: [
    { symbol: 'EURUSD', name: 'EUR/USD' },
    { symbol: 'GBPUSD', name: 'GBP/USD' },
    { symbol: 'USDJPY', name: 'USD/JPY' },
    { symbol: 'AUDUSD', name: 'AUD/USD' },
    { symbol: 'USDCAD', name: 'USD/CAD' },
    { symbol: 'USDCHF', name: 'USD/CHF' },
    { symbol: 'NZDUSD', name: 'NZD/USD' },
    { symbol: 'EURGBP', name: 'EUR/GBP' }
  ]
} as const;