import { MarketDataConfig, MarketQuote, WebSocketMessage, SubscriptionOptions, MessageHandler } from './types';
import { MARKET_CONFIG } from './config';

export class MarketDataService {
  private config: MarketDataConfig;
  private ws: WebSocket | null = null;
  private subscribers = new Map<string, Set<MessageHandler>>();
  private isOnline = navigator.onLine;
  private isConnecting = false;
  private isReconnecting = false;
  private reconnectAttempts = 0;
  private heartbeatInterval: NodeJS.Timeout | null = null;
  private connectionTimeout: NodeJS.Timeout | null = null;
  private retryTimeout: NodeJS.Timeout | null = null;

  constructor(config: Partial<MarketDataConfig> = {}) {
    this.config = {
      ...MARKET_CONFIG.eodHistorical,
      ...config
    };
    
    // Listen for online/offline events
    window.addEventListener('online', this.handleOnlineStatus);
    window.addEventListener('offline', this.handleOnlineStatus);
  }

  private handleOnlineStatus = () => {
    this.isOnline = navigator.onLine;
    if (this.isOnline) {
      // Attempt to reconnect when back online
      this.connectWebSocket();
    } else {
      // Close connection when offline
      this.ws?.close();
    }
  };

  /**
   * Fetches historical data from EOD Historical Data
   */
  async fetchHistoricalData(symbol: string, interval: string = '1d'): Promise<MarketQuote[]> {
    try {
      // Check network connectivity first
      if (!this.isOnline) {
        throw new Error('اتصال اینترنت برقرار نیست. لطفاً اتصال خود را بررسی کنید');
      }

      if (!symbol.trim()) {
        throw new Error('لطفاً یک نماد معتبر انتخاب کنید');
      }

      // Add delay between requests to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 1000));

      const response = await fetch(
        `${this.config.baseUrl}/eod/${symbol}?api_token=${this.config.apiKey}&interval=${interval}&fmt=json&period=30d`,
        {
          headers: {
            'Accept': 'application/json',
            'User-Agent': 'Mozilla/5.0'
          },
          signal: AbortSignal.timeout(this.config.requestTimeout)
        }
      );

      if (!response.ok) {
        if (response.status === 401) {
          throw new Error('خطای احراز هویت API. لطفاً با پشتیبانی تماس بگیرید');
        }
        if (response.status === 429) {
          throw new Error('محدودیت تعداد درخواست. لطفاً چند دقیقه صبر کنید');
        }
        if (response.status === 404) {
          throw new Error(`نماد ${symbol} در سیستم یافت نشد. لطفاً نماد دیگری را انتخاب کنید`);
        }
        throw new Error('خطا در دریافت داده‌های تاریخی');
      }

      const data = await response.json();
      
      if (!Array.isArray(data) || data.length === 0) {
        throw new Error('داده‌ای برای نماد مورد نظر یافت نشد. لطفاً نماد دیگری را انتخاب کنید');
      }

      // Format EOD Historical Data response
      return data.map((item: any) => ({
        symbol,
        time: item.date,
        open: item.open,
        high: item.high,
        low: item.low,
        close: item.close,
        volume: item.volume,
        price: item.close
      }));

    } catch (error) {
      console.error('Error fetching historical data:', error);
      
      if (error instanceof Error) {
        if (error.name === 'AbortError') {
          throw new Error('زمان درخواست به پایان رسید. لطفاً دوباره تلاش کنید');
        }
        if (error.message.includes('Failed to fetch')) {
          throw new Error('خطا در ارتباط با سرور. لطفاً اتصال اینترنت خود را بررسی کنید');
        }
        throw error;
      }
      
      // Generic error message for unknown errors
      throw new Error('خطا در دریافت اطلاعات. لطفاً دوباره تلاش کنید');
    }
  }

  /**
   * Establishes WebSocket connection
   */
  private connectWebSocket() {
    if (this.ws?.readyState === WebSocket.OPEN || this.isConnecting || this.isReconnecting) return;
    
    this.isConnecting = true;
    
    // Set connection timeout
    this.connectionTimeout = setTimeout(() => {
      if (this.ws?.readyState !== WebSocket.OPEN) {
        console.log('Connection timeout, closing socket');
        this.ws?.close();
        this.isConnecting = false;
        this.handleReconnect();
      }
    }, this.config.requestTimeout);

    try {
      this.ws = new WebSocket(`${this.config.wsUrl}${this.config.apiKey}`);

      this.ws.onopen = () => {
        console.log('WebSocket connected');
        this.isConnecting = false;
        this.isReconnecting = false;
        this.reconnectAttempts = 0;
        this.startHeartbeat();
      
        if (this.connectionTimeout) {
          clearTimeout(this.connectionTimeout);
          this.connectionTimeout = null;
        }

        // Resubscribe all active subscriptions
        this.subscribers.forEach((handlers, symbol) => {
          if (this.ws?.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({
              action: 'subscribe-trades',
              symbols: [symbol]
            }));
          }
        });
      };

      this.ws.onclose = () => {
        console.log('WebSocket closed');
        this.isConnecting = false;
        this.stopHeartbeat();
        this.handleReconnect();
      };

      this.ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        this.isConnecting = false;
        if (this.connectionTimeout) {
          clearTimeout(this.connectionTimeout);
          this.connectionTimeout = null;
        }
        // Notify subscribers of error
        this.subscribers.forEach(subscribers => {
          subscribers.forEach(handler => 
            handler({ type: 'status', data: { status: 'error', message: 'خطا در ارتباط با سرور' } })
          );
        });
      };

      this.ws.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data) as WebSocketMessage;
          this.handleMessage(message);
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      };
    } catch (error) {
      console.error('Error creating WebSocket:', error);
      this.isConnecting = false;
      this.handleReconnect();
    }
  }

  /**
   * Handles WebSocket reconnection
   */
  private handleReconnect() {
    if (this.isReconnecting) return;
    
    if (this.reconnectAttempts >= MARKET_CONFIG.websocket.reconnectAttempts) {
      console.error('Max reconnection attempts reached');
      this.subscribers.forEach(subscribers => {
        subscribers.forEach(handler => 
          handler({ type: 'status', data: { status: 'disconnected' } })
        );
      });
      return;
    }

    this.isReconnecting = true;
    this.reconnectAttempts++;
    const baseDelay = this.config.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1);
    const jitter = Math.random() * 1000; // Add random jitter
    const delay = Math.min(baseDelay + jitter, 30000); // Cap at 30 seconds
    
    console.log(`Reconnecting in ${delay}ms (attempt ${this.reconnectAttempts})`);
    
    if (this.retryTimeout) {
      clearTimeout(this.retryTimeout);
    }
    
    this.retryTimeout = setTimeout(() => {
      this.isReconnecting = false;
      this.connectWebSocket();
    }, delay);
  }

  private cleanup() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }
    if (this.connectionTimeout) {
      clearTimeout(this.connectionTimeout);
      this.connectionTimeout = null;
    }
    if (this.retryTimeout) {
      clearTimeout(this.retryTimeout);
      this.retryTimeout = null;
    }
    this.isConnecting = false;
    this.isReconnecting = false;
    this.reconnectAttempts = 0;
  }

  /**
   * Starts WebSocket heartbeat
   */
  private startHeartbeat() {
    this.stopHeartbeat();
    this.heartbeatInterval = setInterval(() => {
      if (this.ws?.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify({ type: 'ping' }));
      }
    }, MARKET_CONFIG.websocket.heartbeatInterval);
  }

  /**
   * Stops WebSocket heartbeat
   */
  private stopHeartbeat() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }
  }

  /**
   * Handles incoming WebSocket messages
   */
  private handleMessage(message: WebSocketMessage) {
    const symbol = message.data?.s; // EOD uses 's' for symbol
    if (!symbol) return;

    // Format message based on data type
    let formattedMessage: WebSocketMessage;

    // Handle US stock trades
    if (message.data?.p !== undefined) {
      formattedMessage = {
        type: 'trade',
        data: {
          symbol: message.data.s,
          price: message.data.p,
          volume: message.data.v || 0,
          timestamp: message.data.t,
          darkPool: message.data.dp || false,
          marketStatus: message.data.ms
        }
      };
    }
    // Handle forex quotes  
    else if (message.data?.a !== undefined) {
      formattedMessage = {
        type: 'quote',
        data: {
          symbol: message.data.s,
          ask: message.data.a,
          bid: message.data.b,
          dailyChange: message.data.dc,
          dailyDiff: message.data.dd,
          timestamp: message.data.t
        }
      };
    }
    // Handle crypto trades
    else if (message.data?.q !== undefined) {
      formattedMessage = {
        type: 'trade',
        data: {
          symbol: message.data.s,
          price: message.data.p,
          quantity: message.data.q,
          dailyChange: message.data.dc,
          dailyDiff: message.data.dd,
          timestamp: message.data.t
        }
      };
    }
    else {
      return; // Ignore unrecognized message formats
    }

    const subscribers = this.subscribers.get(symbol);
    if (subscribers) {
      subscribers.forEach(handler => handler(formattedMessage));
    }
  }

  /**
   * Subscribes to real-time updates
   */
  subscribe(options: SubscriptionOptions, handler: MessageHandler) {
    const { symbol } = options;

    // Initialize connection if needed
    this.connectWebSocket();

    // Add subscriber
    if (!this.subscribers.has(symbol)) {
      this.subscribers.set(symbol, new Set());
    }
    this.subscribers.get(symbol)!.add(handler);

    // Send subscription message
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        action: 'subscribe-trades',
        symbols: [symbol],
        ...options
      }));
    }
  }

  /**
   * Unsubscribes from updates
   */
  unsubscribe(symbol: string, handler: MessageHandler) {
    const subscribers = this.subscribers.get(symbol);
    if (subscribers) {
      subscribers.delete(handler);
      if (subscribers.size === 0) {
        this.subscribers.delete(symbol);
        if (this.ws?.readyState === WebSocket.OPEN) {
          this.ws.send(JSON.stringify({
            action: 'unsubscribe-trades',
            symbol
          }));
        }
      }
    }
  }

  /**
   * Closes WebSocket connection
   */
  disconnect() {
    this.stopHeartbeat();
    this.cleanup();
    // Remove event listeners
    window.removeEventListener('online', this.handleOnlineStatus);
    window.removeEventListener('offline', this.handleOnlineStatus);
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.subscribers.clear();
  }
}

// Create and export singleton instance
export const marketService = new MarketDataService({ apiKey: '67cb042e97be55.83901871' });