export interface PatternData {
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface PatternMatch {
  pattern: string;
  startIndex: number;
  endIndex: number;
  confidence: number;
  description: string;
  prediction: {
    direction: 'bullish' | 'bearish' | 'neutral';
    target: number;
    stopLoss: number;
    probability: number;
  };
}

export interface PatternAnalysis {
  patterns: PatternMatch[];
  statistics: {
    totalPatterns: number;
    reliability: number;
    averageReturn: number;
    successRate: number;
  };
  recommendations: string[];
  insights: string[];
}

export interface ChartAnnotation {
  type: 'pattern' | 'support' | 'resistance' | 'trendline';
  points: Array<{x: number; y: number}>;
  label: string;
  color: string;
}

export interface PatternVisualization {
  data: PatternData[];
  annotations: ChartAnnotation[];
  indicators: Array<{
    name: string;
    values: number[];
    color: string;
  }>;
}