import { PatternData, PatternMatch, PatternAnalysis } from './types';
import { openai } from '../../openai';

/**
 * Analyzes price data to detect technical patterns
 */
export async function analyzePatterns(data: PatternData[]): Promise<PatternAnalysis> {
  try {
    // Prepare data for AI analysis
    const priceData = data.map(d => ({
      time: d.time,
      open: d.open,
      high: d.high,
      low: d.low,
      close: d.close,
      volume: d.volume
    }));

    // Get AI analysis
    const response = await openai.chat.completions.create({
      model: 'ModelsLab/Mixtral-8x7B-Instruct',
      temperature: 0.3,
      messages: [
        {
          role: 'system',
          content: `شما یک متخصص تحلیل تکنیکال و تشخیص الگوهای نموداری هستید. لطفاً داده‌های قیمت را تحلیل کرده و الگوهای معتبر را شناسایی کنید.

لطفاً خروجی را در قالب JSON با این ساختار برگردانید:
{
  "patterns": [{
    "pattern": "نام الگو",
    "startIndex": شماره شروع الگو,
    "endIndex": شماره پایان الگو,
    "confidence": درصد اطمینان,
    "description": "توضیحات الگو",
    "prediction": {
      "direction": "bullish" | "bearish" | "neutral",
      "target": قیمت هدف,
      "stopLoss": حد ضرر,
      "probability": احتمال موفقیت
    }
  }],
  "statistics": {
    "totalPatterns": تعداد کل الگوها,
    "reliability": درصد اعتبار,
    "averageReturn": بازدهی متوسط,
    "successRate": نرخ موفقیت
  },
  "recommendations": ["پیشنهاد 1", "پیشنهاد 2"],
  "insights": ["بینش 1", "بینش 2"]
}`
        },
        {
          role: 'user',
          content: JSON.stringify(priceData)
        }
      ]
    });

    const analysis = JSON.parse(response.choices[0]?.message?.content || '{}');
    return analysis;

  } catch (error) {
    console.error('Pattern analysis error:', error);
    throw error instanceof Error ? error : new Error('خطا در تحلیل الگوها');
  }
}

/**
 * Calculates pattern reliability statistics
 */
export function calculatePatternStats(patterns: PatternMatch[], data: PatternData[]): {
  reliability: number;
  averageReturn: number;
  successRate: number;
} {
  let successfulPatterns = 0;
  let totalReturn = 0;

  patterns.forEach(pattern => {
    const entryPrice = data[pattern.endIndex].close;
    const nextTenCandles = data.slice(pattern.endIndex + 1, pattern.endIndex + 11);
    
    if (nextTenCandles.length > 0) {
      const maxPrice = Math.max(...nextTenCandles.map(d => d.high));
      const minPrice = Math.min(...nextTenCandles.map(d => d.low));
      
      if (pattern.prediction.direction === 'bullish') {
        const success = maxPrice >= pattern.prediction.target;
        if (success) successfulPatterns++;
        totalReturn += ((maxPrice - entryPrice) / entryPrice) * 100;
      } else if (pattern.prediction.direction === 'bearish') {
        const success = minPrice <= pattern.prediction.target;
        if (success) successfulPatterns++;
        totalReturn += ((entryPrice - minPrice) / entryPrice) * 100;
      }
    }
  });

  return {
    reliability: patterns.length > 0 ? (successfulPatterns / patterns.length) * 100 : 0,
    averageReturn: patterns.length > 0 ? totalReturn / patterns.length : 0,
    successRate: patterns.length > 0 ? (successfulPatterns / patterns.length) * 100 : 0
  };
}