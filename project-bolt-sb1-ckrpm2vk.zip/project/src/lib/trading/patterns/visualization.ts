import { PatternData, PatternMatch, ChartAnnotation, PatternVisualization } from './types';

/**
 * Creates chart annotations for identified patterns
 */
export function createPatternAnnotations(
  data: PatternData[],
  patterns: PatternMatch[]
): ChartAnnotation[] {
  return patterns.map(pattern => {
    const startPoint = {
      x: pattern.startIndex,
      y: data[pattern.startIndex].low
    };
    
    const endPoint = {
      x: pattern.endIndex,
      y: data[pattern.endIndex].high
    };

    const color = pattern.prediction.direction === 'bullish' ? '#10b981' :
                 pattern.prediction.direction === 'bearish' ? '#ef4444' :
                 '#6b7280';

    return {
      type: 'pattern',
      points: [startPoint, endPoint],
      label: pattern.pattern,
      color
    };
  });
}

/**
 * Prepares data for chart visualization
 */
export function prepareVisualization(
  data: PatternData[],
  patterns: PatternMatch[]
): PatternVisualization {
  // Create pattern annotations
  const annotations = createPatternAnnotations(data, patterns);

  // Calculate technical indicators
  const closes = data.map(d => d.close);
  
  // 20-period SMA
  const sma20 = calculateSMA(closes, 20);
  
  // 50-period SMA
  const sma50 = calculateSMA(closes, 50);
  
  // RSI
  const rsi = calculateRSI(closes);

  return {
    data,
    annotations,
    indicators: [
      {
        name: 'SMA20',
        values: sma20,
        color: '#3b82f6'
      },
      {
        name: 'SMA50',
        values: sma50,
        color: '#8b5cf6'
      },
      {
        name: 'RSI',
        values: rsi,
        color: '#ef4444'
      }
    ]
  };
}

/**
 * Calculates Simple Moving Average
 */
function calculateSMA(data: number[], period: number): number[] {
  const sma = [];
  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      sma.push(null);
      continue;
    }
    const sum = data.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
    sma.push(sum / period);
  }
  return sma;
}

/**
 * Calculates Relative Strength Index
 */
function calculateRSI(data: number[], period: number = 14): number[] {
  const rsi = [];
  let gains = [];
  let losses = [];

  // Calculate price changes
  for (let i = 1; i < data.length; i++) {
    const change = data[i] - data[i - 1];
    gains.push(change > 0 ? change : 0);
    losses.push(change < 0 ? -change : 0);
  }

  // Calculate initial averages
  let avgGain = gains.slice(0, period).reduce((a, b) => a + b, 0) / period;
  let avgLoss = losses.slice(0, period).reduce((a, b) => a + b, 0) / period;

  // Calculate RSI values
  for (let i = 0; i < data.length; i++) {
    if (i < period) {
      rsi.push(null);
      continue;
    }

    const rs = avgGain / avgLoss;
    rsi.push(100 - (100 / (1 + rs)));

    // Update averages
    if (i < data.length - 1) {
      avgGain = ((avgGain * (period - 1)) + gains[i]) / period;
      avgLoss = ((avgLoss * (period - 1)) + losses[i]) / period;
    }
  }

  return rsi;
}