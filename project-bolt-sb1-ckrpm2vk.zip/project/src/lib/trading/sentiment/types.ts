export interface NewsItem {
  title: string;
  content: string;
  source: string;
  url: string;
  publishDate: string;
  sentiment: {
    score: number;  // -1 to 1
    label: 'positive' | 'negative' | 'neutral';
    confidence: number;
  };
}

export interface SocialMediaPost {
  platform: string;
  content: string;
  author: string;
  timestamp: string;
  engagement: {
    likes: number;
    shares: number;
    comments: number;
  };
  sentiment: {
    score: number;
    label: 'positive' | 'negative' | 'neutral';
    confidence: number;
  };
}

export interface MarketSentiment {
  overall: {
    score: number;
    label: 'bullish' | 'bearish' | 'neutral';
    confidence: number;
  };
  news: {
    score: number;
    items: NewsItem[];
    topKeywords: string[];
  };
  social: {
    score: number;
    posts: SocialMediaPost[];
    trending: string[];
  };
  technical: {
    score: number;
    indicators: {
      name: string;
      value: number;
      signal: 'buy' | 'sell' | 'neutral';
    }[];
  };
  recommendations: string[];
  insights: string[];
}

export interface SentimentAnalysisOptions {
  timeframe: string;
  sources: string[];
  keywords: string[];
  language: 'en' | 'fa';
}