import { openai } from '../../openai';
import { MarketSentiment, NewsItem, SentimentAnalysisOptions } from './types';

/**
 * Analyzes market sentiment from multiple sources
 */
export async function analyzeSentiment(
  text: string,
  options: SentimentAnalysisOptions
): Promise<MarketSentiment> {
  try {
    const response = await openai.chat.completions.create({
      model: 'ModelsLab/Mixtral-8x7B-Instruct',
      temperature: 0.3,
      messages: [
        {
          role: 'system',
          content: `شما یک متخصص تحلیل سنتیمنت بازار هستید. لطفاً متن‌ها و اخبار را تحلیل کرده و احساسات بازار را شناسایی کنید.

لطفاً خروجی را در قالب JSON با این ساختار برگردانید:
{
  "overall": {
    "score": عدد بین -1 تا 1,
    "label": "bullish" | "bearish" | "neutral",
    "confidence": درصد اطمینان
  },
  "news": {
    "score": عدد بین -1 تا 1,
    "items": [{
      "title": "عنوان خبر",
      "content": "متن خبر",
      "source": "منبع خبر",
      "url": "لینک خبر",
      "publishDate": "تاریخ انتشار",
      "sentiment": {
        "score": عدد بین -1 تا 1,
        "label": "positive" | "negative" | "neutral",
        "confidence": درصد اطمینان
      }
    }],
    "topKeywords": ["کلیدواژه 1", "کلیدواژه 2"]
  },
  "social": {
    "score": عدد بین -1 تا 1,
    "posts": [{
      "platform": "نام پلتفرم",
      "content": "متن پست",
      "author": "نویسنده",
      "timestamp": "زمان انتشار",
      "engagement": {
        "likes": تعداد لایک,
        "shares": تعداد اشتراک,
        "comments": تعداد نظرات
      },
      "sentiment": {
        "score": عدد بین -1 تا 1,
        "label": "positive" | "negative" | "neutral",
        "confidence": درصد اطمینان
      }
    }],
    "trending": ["ترند 1", "ترند 2"]
  },
  "technical": {
    "score": عدد بین -1 تا 1,
    "indicators": [{
      "name": "نام اندیکاتور",
      "value": مقدار عددی,
      "signal": "buy" | "sell" | "neutral"
    }]
  },
  "recommendations": ["پیشنهاد 1", "پیشنهاد 2"],
  "insights": ["بینش 1", "بینش 2"]
}`
        },
        {
          role: 'user',
          content: `لطفاً این متن را تحلیل کنید. بازه زمانی: ${options.timeframe}
منابع: ${options.sources.join(', ')}
کلمات کلیدی: ${options.keywords.join(', ')}

متن:
${text}`
        }
      ]
    });

    const analysis = JSON.parse(response.choices[0]?.message?.content || '{}');
    return analysis;

  } catch (error) {
    console.error('Sentiment analysis error:', error);
    throw error instanceof Error ? error : new Error('خطا در تحلیل سنتیمنت');
  }
}

/**
 * Calculates weighted sentiment score
 */
export function calculateWeightedSentiment(
  news: NewsItem[],
  weights: { recency: number; reliability: number; impact: number }
): number {
  let totalScore = 0;
  let totalWeight = 0;

  news.forEach(item => {
    // Calculate recency weight (more recent = higher weight)
    const daysSincePublish = (Date.now() - new Date(item.publishDate).getTime()) / (1000 * 60 * 60 * 24);
    const recencyWeight = Math.exp(-daysSincePublish / 7); // Exponential decay over a week

    // Calculate source reliability weight
    const reliabilityWeight = getSourceReliability(item.source);

    // Calculate impact weight based on content
    const impactWeight = calculateImpactWeight(item.content);

    // Calculate total weight for this item
    const itemWeight = (
      weights.recency * recencyWeight +
      weights.reliability * reliabilityWeight +
      weights.impact * impactWeight
    );

    totalScore += item.sentiment.score * itemWeight;
    totalWeight += itemWeight;
  });

  return totalWeight > 0 ? totalScore / totalWeight : 0;
}

/**
 * Gets reliability score for news source
 */
function getSourceReliability(source: string): number {
  const reliabilityScores: Record<string, number> = {
    'Reuters': 0.9,
    'Bloomberg': 0.9,
    'Financial Times': 0.85,
    'Wall Street Journal': 0.85,
    'CNBC': 0.8,
    // Add more sources as needed
  };

  return reliabilityScores[source] || 0.5; // Default reliability for unknown sources
}

/**
 * Calculates impact weight based on content
 */
function calculateImpactWeight(content: string): number {
  // High-impact keywords and their weights
  const impactKeywords = {
    'breaking': 1.5,
    'urgent': 1.5,
    'alert': 1.3,
    'just in': 1.3,
    'exclusive': 1.2,
    'report': 1.1,
    // Add more keywords as needed
  };

  let maxWeight = 1.0;
  Object.entries(impactKeywords).forEach(([keyword, weight]) => {
    if (content.toLowerCase().includes(keyword)) {
      maxWeight = Math.max(maxWeight, weight);
    }
  });

  return maxWeight;
}