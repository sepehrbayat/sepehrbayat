export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      verification_codes: {
        Row: {
          id: string
          phone_number: string
          code: string
          expires_at: string
          created_at: string
          attempts: number
        }
        Insert: {
          id?: string
          phone_number: string
          code: string
          expires_at: string
          created_at?: string
          attempts?: number
        }
        Update: {
          id?: string
          phone_number?: string
          code?: string
          expires_at?: string
          created_at?: string
          attempts?: number
        }
      }
    }
  }
}