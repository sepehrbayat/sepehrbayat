export const INTERIOR_CONFIG = {
  maxRetries: 3, // Maximum number of retry attempts
  requestTimeout: 30000, // 30 seconds
  maxConcurrentRequests: 3,
  baseRetryDelay: 2000, // Base delay for exponential backoff (2 seconds)
  maxRetryDelay: 20000, // Maximum delay between retries (20 seconds)
  rateLimitDelay: 20000, // Delay after rate limit (20 seconds)
  jitterFactor: 0.1, // 10% random jitter to prevent thundering herd
  defaultStrength: 0.99,
  defaultGuidanceScale: 8,
  defaultInferenceSteps: 51,
  maxImageSize: 10 * 1024 * 1024, // 10MB
  minImageDimension: 256,
  maxImageDimension: 2048
} as const;

export const ERROR_CODES = {
  TIMEOUT: 'TIMEOUT',
  NETWORK: 'NETWORK',
  API: 'API',
  VALIDATION: 'VALIDATION',
  TRANSLATION: 'TRANSLATION',
  UNKNOWN: 'UNKNOWN'
} as const;

export const ERROR_MESSAGES = {
  [ERROR_CODES.TIMEOUT]: 'زمان درخواست به پایان رسید',
  [ERROR_CODES.NETWORK]: 'خطا در ارتباط با سرور',
  [ERROR_CODES.API]: 'خطا در سرویس طراحی داخلی',
  [ERROR_CODES.VALIDATION]: 'پارامترهای ورودی نامعتبر هستند',
  [ERROR_CODES.TRANSLATION]: 'خطا در ترجمه متن',
  [ERROR_CODES.UNKNOWN]: 'خطای ناشناخته'
} as const;

export const POLL_CONFIG = {
  maxAttempts: 30,     // Maximum number of polling attempts (5 minutes)
  baseInterval: 10000, // Base interval between polls (10 seconds)
  maxInterval: 30000,  // Maximum interval between polls (30 seconds)
  timeout: 300000,     // Overall timeout (5 minutes)
  retryAttempts: 3,    // Maximum retry attempts for failed requests
  baseRetryDelay: 5000 // Base delay between retries (5 seconds)
} as const;