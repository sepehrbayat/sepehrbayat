import { InteriorDesignError } from './errors';
import { INTERIOR_CONFIG } from './constants';
import type { InteriorDesignOptions } from './types';

export function validateInteriorDesignOptions(options: InteriorDesignOptions): void {
  // Validate required fields
  if (!options.image?.trim()) {
    throw new InteriorDesignError('VALIDATION', 'تصویر نمی‌تواند خالی باشد');
  }

  if (!options.prompt?.trim()) {
    throw new InteriorDesignError('VALIDATION', 'توضیحات نمی‌تواند خالی باشد');
  }

  // Validate style if provided
  if (options.style && !['modern', 'classic', 'minimal', 'industrial', 'scandinavian'].includes(options.style)) {
    throw new InteriorDesignError('VALIDATION', 'سبک انتخاب شده معتبر نیست');
  }

  // Validate numeric parameters
  if (options.strength !== undefined) {
    if (typeof options.strength !== 'number' || options.strength < 0 || options.strength > 1) {
      throw new InteriorDesignError('VALIDATION', 'مقدار strength باید بین 0 و 1 باشد');
    }
  }

  if (options.guidanceScale !== undefined) {
    if (typeof options.guidanceScale !== 'number' || options.guidanceScale < 1 || options.guidanceScale > 20) {
      throw new InteriorDesignError('VALIDATION', 'مقدار guidance scale باید بین 1 و 20 باشد');
    }
  }

  if (options.numInferenceSteps !== undefined) {
    if (!Number.isInteger(options.numInferenceSteps) || options.numInferenceSteps < 1 || options.numInferenceSteps > 100) {
      throw new InteriorDesignError('VALIDATION', 'تعداد مراحل باید عدد صحیح بین 1 و 100 باشد');
    }
  }

  if (options.seed !== undefined && !Number.isInteger(options.seed)) {
    throw new InteriorDesignError('VALIDATION', 'seed باید عدد صحیح باشد');
  }
}

export function validateImageDimensions(width: number, height: number): void {
  if (width < INTERIOR_CONFIG.minImageDimension || height < INTERIOR_CONFIG.minImageDimension) {
    throw new InteriorDesignError(
      'VALIDATION',
      `ابعاد تصویر باید حداقل ${INTERIOR_CONFIG.minImageDimension}x${INTERIOR_CONFIG.minImageDimension} پیکسل باشد`
    );
  }

  if (width > INTERIOR_CONFIG.maxImageDimension || height > INTERIOR_CONFIG.maxImageDimension) {
    throw new InteriorDesignError(
      'VALIDATION',
      `ابعاد تصویر نباید بیشتر از ${INTERIOR_CONFIG.maxImageDimension}x${INTERIOR_CONFIG.maxImageDimension} پیکسل باشد`
    );
  }
}

export function validateImageSize(size: number): void {
  if (size > INTERIOR_CONFIG.maxImageSize) {
    throw new InteriorDesignError(
      'VALIDATION',
      `حجم تصویر نباید بیشتر از ${INTERIOR_CONFIG.maxImageSize / (1024 * 1024)} مگابایت باشد`
    );
  }
}