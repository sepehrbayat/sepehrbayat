import { openai } from '../openai';
import { InteriorDesignError, RetryableError, isRetryableError } from './errors';
import { validateInteriorDesignOptions } from './validation';
import { INTERIOR_CONFIG, POLL_CONFIG } from './constants';
import type { InteriorDesignOptions, InteriorDesignResponse, InteriorDesignProgress } from './types';

export class InteriorDesignService {
  private config = INTERIOR_CONFIG;
  private pollConfig = POLL_CONFIG;

  private getRetryDelay(attempt: number): number {
    // Calculate base delay with exponential backoff
    const baseDelay = Math.min(
      this.config.baseRetryDelay * Math.pow(2, attempt),
      this.config.maxRetryDelay
    );
    
    // Add jitter to prevent thundering herd
    const jitter = baseDelay * this.config.jitterFactor * (Math.random() * 2 - 1);
    return Math.max(0, baseDelay + jitter);
  }

  private createErrorResponse(
    status: number,
    code: string,
    message: string,
    retryAttempt: number,
    options?: InteriorDesignOptions,
    waitTime?: number
  ): ErrorResponse {
    return {
      status,
      code,
      message,
      retryAttempt,
      timestamp: new Date().toISOString(),
      waitTime,
      requestDetails: options ? {
        prompt: options.prompt,
        style: options.style,
        timestamp: new Date().toISOString()
      } : undefined
    };
  }

  private async makeRequest(options: InteriorDesignOptions, retryCount: number = 0): Promise<InteriorDesignResponse> {
    try {
      // Check if we've exceeded max retries
      if (retryCount >= this.config.maxRetries) {
        throw new InteriorDesignError('API', 'تعداد تلاش‌های مجدد به حداکثر رسید. لطفاً چند دقیقه صبر کنید');
      }

      // If we've already retried too many times, wait longer
      if (retryCount > 0) {
        const delay = this.getRetryDelay(retryCount);
        console.log(`Retry attempt ${retryCount}/${this.config.maxRetries}, waiting ${delay}ms`);
        await new Promise(resolve => setTimeout(resolve, delay));
      }

      // Log request details for debugging
      console.log('Making interior design request:', {
        retryCount,
        timestamp: new Date().toISOString(),
        options: {
          ...options,
          image: 'REDACTED' // Don't log image data
        }
      });

      // Add exponential backoff delay with jitter for retries
      if (retryCount > 0) {
        const delay = Math.min(1000 * Math.pow(2, retryCount - 1), 10000);
        const jitter = Math.random() * 1000;
        await new Promise(resolve => setTimeout(resolve, delay + jitter));
      }

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), this.config.requestTimeout);

      try {
        const response = await fetch("https://modelslab.com/api/v6/interior/make", {
          method: 'POST',
          cache: 'no-store',
          signal: controller.signal,
          headers: {
            'Content-Type': 'application/json',
            'key': "DIT0j1BOjKT9OSLc5d2dnHYpTqrNjhXVxGba5toE6Z5pWJiVM2uDbYdHpr2r"
          },
          body: JSON.stringify({
            key: "DIT0j1BOjKT9OSLc5d2dnHYpTqrNjhXVxGba5toE6Z5pWJiVM2uDbYdHpr2r",
            init_image: options.image,
            prompt: options.prompt,
            negative_prompt: "bad quality, low quality, blurry",
            seed: options.seed || Math.floor(Math.random() * 2147483647),
            guidance_scale: options.guidanceScale || this.config.defaultGuidanceScale,
            strength: options.strength || this.config.defaultStrength,
            num_inference_steps: options.numInferenceSteps || this.config.defaultInferenceSteps,
            base64: false,
            temp: false
          })
        });

        // Log raw response for debugging
        const responseText = await response.text();
        console.log('ModelsLab Raw Response:', {
          status: response.status,
          statusText: response.statusText,
          responseText: responseText.slice(0, 1000) // Log first 1000 chars only
        });

        if (!response.ok) {
          if (response.status === 429) {
            const retryAfter = response.headers.get('Retry-After');
            const waitTime = retryAfter ? parseInt(retryAfter) * 1000 : this.config.rateLimitDelay;
            const nextAttempt = retryCount + 1;
            
            const errorResponse = this.createErrorResponse(
              429,
              'RATE_LIMIT',
              `محدودیت تعداد درخواست. تلاش مجدد در ${Math.round(waitTime / 1000)} ثانیه (تلاش ${nextAttempt}/${this.config.maxRetries})`,
              retryCount,
              options,
              waitTime
            );
            
            console.warn('Rate limit hit:', errorResponse);
            
            await new Promise(resolve => setTimeout(resolve, waitTime));
            return this.makeRequest(options, nextAttempt);
          }
          
          if (response.status >= 500) {
            const errorResponse = this.createErrorResponse(
              response.status,
              'SERVER_ERROR',
              'خطای سرور. لطفاً دوباره تلاش کنید',
              retryCount,
              options
            );
            console.error('Server error:', errorResponse);
            throw new RetryableError('API', errorResponse.message, errorResponse);
          }
          
          if (response.status === 401) {
            const errorResponse = this.createErrorResponse(
              401,
              'AUTH_ERROR',
              'خطای احراز هویت API. لطفاً با پشتیبانی تماس بگیرید',
              retryCount,
              options
            );
            console.error('Auth error:', errorResponse);
            throw new InteriorDesignError('API', errorResponse.message, errorResponse);
          }
          
          const errorResponse = this.createErrorResponse(
            response.status,
            'API_ERROR',
            'خطا در ارتباط با سرور. لطفاً دوباره تلاش کنید',
            retryCount,
            options
          );
          console.error('API error:', errorResponse);
          throw new RetryableError('API', errorResponse.message, errorResponse);
        }

        let data;
        try {
          data = JSON.parse(responseText);
          
          // Handle rate limit in response body
          if (data.message?.toLowerCase().includes('try again') || 
              data.error?.message?.toLowerCase().includes('try again')) {
            const nextAttempt = retryCount + 1;
            const errorResponse = this.createErrorResponse(
              429,
              'RATE_LIMIT_BODY',
              `محدودیت سرور. تلاش مجدد در ${Math.round(this.config.rateLimitDelay / 1000)} ثانیه (تلاش ${nextAttempt}/${this.config.maxRetries})`,
              retryCount,
              options,
              this.config.rateLimitDelay
            );
            console.warn('Rate limit in response body:', errorResponse);
            await new Promise(resolve => setTimeout(resolve, this.config.rateLimitDelay));
            return this.makeRequest(options, nextAttempt);
          }

        } catch (parseError) {
          console.error('JSON parse error:', parseError);
          throw new RetryableError('API', 'خطا در پردازش پاسخ سرور');
        }

        // Log parsed response
        console.log('ModelsLab Parsed Response:', {
          status: data?.status,
          hasOutput: Boolean(data?.output?.length || data?.future_links?.length || data?.proxy_links?.length),
          message: data?.message,
          error: data?.error
        });

        // Validate response structure
        if (!data || typeof data !== 'object') {
          throw new RetryableError('API', 'پاسخ نامعتبر از سرور');
        }

        // Check for error in response
        if (data.error) {
          throw new RetryableError('API', data.error.message || 'خطا در پردازش درخواست');
        }

        // Handle processing status with fetch_result
        if (data.status === 'processing' && data.fetch_result) {
          return {
            status: data.status,
            fetch_result: data.fetch_result,
            eta: data.eta || 60,
            tip: data.tip || `در حال پردازش تصویر... (تلاش ${retryCount + 1}/${this.config.maxRetries})`,
            id: data.id,
            output: data.output || [],
            future_links: data.future_links || [],
            meta: data.meta || {}
          };
        }

        // Handle success with output
        if (data.status === 'success') {
          if (Array.isArray(data.future_links) && data.future_links.length > 0) {
            return data.future_links;
          }
          if (Array.isArray(data.output) && data.output.length > 0) {
            return data.output;
          }
          if (Array.isArray(data.proxy_links) && data.proxy_links.length > 0) {
            return data.proxy_links;
          }
        }

        throw new RetryableError('API', data.message || 'خطا در دریافت خروجی از سرور');

      } catch (error) {
        if (error.name === 'AbortError') {
          const errorResponse = this.createErrorResponse(
            408,
            'TIMEOUT',
            'زمان درخواست به پایان رسید. لطفاً دوباره تلاش کنید',
            retryCount,
            options
          );
          console.error('Request timeout:', errorResponse);
          throw new RetryableError('TIMEOUT', errorResponse.message, errorResponse);
        }
        throw error;
      } finally {
        clearTimeout(timeout);
      }
    } catch (error) {
      if (isRetryableError(error) && retryCount < this.config.maxRetries) {
        return this.makeRequest(options, retryCount + 1);
      }
      throw error;
    }
  }

  async generateDesign(options: InteriorDesignOptions): Promise<string[]> {
    try {
      console.log('Starting design generation:', {
        hasImage: Boolean(options.image),
        promptLength: options.prompt?.length,
        timestamp: new Date().toISOString()
      });

      // Validate input options
      validateInteriorDesignOptions(options);

      // First translate the prompt to English
      const translatedPrompt = await this.translatePrompt(options.prompt);

      // Add quality keywords
      const enhancedPrompt = this.enhancePrompt(translatedPrompt, options.style);

      // Make request with enhanced prompt
      const data = await this.makeRequest({
        ...options,
        prompt: enhancedPrompt,
        seed: Math.floor(Math.random() * 2147483647)
      });

      // Log response data
      console.log('Design generation response:', {
        status: data.status,
        hasOutput: Boolean(data.output?.length),
        hasFutureLinks: Boolean(data.future_links?.length),
        timestamp: new Date().toISOString()
      });

      // Handle processing status
      if (data.status === 'processing' && data.fetch_result) {
        return await this.pollResult(data.fetch_result);
      } else if (data.status === 'success' && data.future_links?.length > 0) {
        return data.future_links;
      } else if (data.status === 'success' && data.output?.length > 0) {
        return data.output;
      } else if (data.status === 'success' && data.proxy_links?.length > 0) {
        return data.proxy_links;
      }

      throw new RetryableError('API', 'خطا در دریافت خروجی از سرور');

    } catch (error) {
      console.error('Interior design error:', error);
      
      if (error instanceof InteriorDesignError || error instanceof RetryableError) {
        throw error;
      }

      // Add more context to unknown errors
      const errorDetails = {
        originalError: error,
        timestamp: new Date().toISOString(),
        requestOptions: {
          ...options,
          image: 'REDACTED' // Don't log image data
        }
      };

      throw new InteriorDesignError(
        'UNKNOWN',
        error instanceof Error ? error.message : 'خطا در طراحی داخلی',
        errorDetails
      );
    }
  }

  private async translatePrompt(prompt: string): Promise<string> {
    try {
      const response = await openai.chat.completions.create({
        model: 'ModelsLab/Mixtral-8x7B-Instruct',
        messages: [
          {
            role: 'system',
            content: `You are an expert in translating interior design prompts from Persian to English. Your task:

1. Translation Approach:
   - Precise translation of design elements
   - Use professional interior design terminology
   - Preserve style and mood descriptions
   - Maintain material and color specifications

2. Technical Details:
   - Furniture and fixture terms
   - Material and finish names
   - Color schemes
   - Lighting terminology
   - Layout descriptions

3. Quality Focus:
   - Professional design language
   - Clear specifications
   - Accurate measurements
   - Style consistency

IMPORTANT: Return ONLY the translated text, without any explanations or additional text.`
          },
          {
            role: 'user',
            content: prompt.trim()
          }
        ]
      });

      const translatedText = response.choices[0]?.message?.content;
      if (!translatedText) {
        throw new RetryableError('TRANSLATION', 'خطا در ترجمه متن');
      }

      return translatedText;

    } catch (error) {
      console.error('Translation error:', error);
      throw new RetryableError(
        'TRANSLATION',
        'خطا در ترجمه متن',
        { originalError: error }
      );
    }
  }

  private enhancePrompt(prompt: string, style?: string): string {
    const styleKeywords = {
      modern: 'modern interior design, contemporary furniture, clean lines',
      classic: 'classic interior design, traditional furniture, elegant details',
      minimal: 'minimalist design, simple furniture, clean spaces',
      industrial: 'industrial style, raw materials, exposed elements',
      scandinavian: 'scandinavian design, light colors, natural materials'
    };

    return `${prompt}, ${style ? styleKeywords[style] : ''}, interior design, architectural visualization, interior rendering, masterpiece, best quality, highly detailed, sharp focus, professional lighting, 8k uhd, realistic textures, photorealistic, cinematic`.trim();
  }

  private async pollResult(url: string): Promise<string[]> {
    let attempts = 0;
    const startTime = Date.now();
    const maxAttempts = this.pollConfig.maxAttempts;
    let lastError: Error | null = null;

    while (attempts < maxAttempts) {
      try {
        // Check timeout
        if (Date.now() - startTime > this.pollConfig.timeout) {
          throw new InteriorDesignError('TIMEOUT', 'زمان انتظار به پایان رسید. لطفاً دوباره تلاش کنید');
        }

        // Add delay between attempts
        if (attempts > 0) {
          const delay = Math.min(
            this.pollConfig.baseInterval * Math.pow(1.5, attempts), // Reduced exponential factor
            this.pollConfig.maxInterval
          );
          await new Promise(resolve => setTimeout(resolve, delay));
        }

        const response = await fetch(url, {
          cache: 'no-store',
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'key': "DIT0j1BOjKT9OSLc5d2dnHYpTqrNjhXVxGba5toE6Z5pWJiVM2uDbYdHpr2r"
          }
        });

        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        // Log raw poll response
        const responseText = await response.text();
        console.log('ModelsLab Poll Response:', {
          status: response.status,
          statusText: response.statusText,
          responseText: responseText.slice(0, 1000) // Log first 1000 chars only
        });

        let data: InteriorDesignResponse;
        try {
          data = JSON.parse(responseText);
        } catch (error) {
          throw new RetryableError('API', 'خطا در پردازش پاسخ سرور');
        }

        // Handle success with output
        if (data.status === 'success') {
          if (Array.isArray(data.future_links) && data.future_links.length > 0) {
            return data.future_links;
          }
          if (Array.isArray(data.output) && data.output.length > 0) {
            return data.output;
          }
          if (Array.isArray(data.proxy_links) && data.proxy_links.length > 0) {
            return data.proxy_links;
          }
        }

        // Handle explicit failure
        if (data.status === 'failed' || data.error) {
          throw new Error(data.error?.message || data.message || 'خطا در تولید تصویر');
        }

        // Continue polling if still processing
        if (data.status === 'processing') {
          attempts++;
          const remainingAttempts = maxAttempts - attempts;
          console.log('Still processing:', {
            attempt: attempts,
            remaining: remainingAttempts,
            eta: data.eta,
            tip: data.tip,
            message: data.message
          });
          
          if (remainingAttempts <= 5) {
            console.warn(`Only ${remainingAttempts} polling attempts remaining`);
          }
          
          continue;
        }

        // If we get here, the response is invalid
        throw new RetryableError('API', 'پاسخ نامعتبر از سرور');

      } catch (error) {
        lastError = error;
        const remainingAttempts = maxAttempts - attempts - 1;
        
        if (remainingAttempts <= 0) {
          throw new InteriorDesignError(
            'TIMEOUT',
            'زمان انتظار به پایان رسید. لطفاً با پارامترهای متفاوت دوباره تلاش کنید'
          );
        }
        
        console.warn(`Polling attempt ${attempts + 1}/${maxAttempts} failed:`, error);
        attempts++;
      }
    }

    throw lastError || new InteriorDesignError(
      'TIMEOUT',
      'زمان انتظار به پایان رسید. لطفاً دوباره تلاش کنید'
    );
  }
}

// Create and export singleton instance
export const interiorService = new InteriorDesignService();

// Re-export types and errors
export * from './types';
export * from './errors';