export interface InteriorDesignOptions {
  image: string;
  prompt: string;
  style?: 'modern' | 'classic' | 'minimal' | 'industrial' | 'scandinavian';
  strength?: number;
  guidanceScale?: number;
  numInferenceSteps?: number;
  seed?: number;
}

export interface ErrorResponse {
  status: number;
  code: string;
  message: string;
  retryAttempt: number;
  timestamp: string;
  waitTime?: number;
  requestDetails?: {
    prompt?: string;
    style?: string;
    timestamp: string;
  };
}

export interface InteriorDesignResponse {
  status: 'success' | 'processing' | 'failed';
  output?: string[];
  fetch_result?: string;
  eta?: number;
  tip?: string;
  error?: {
    message: string;
    code?: string;
  };
  meta?: {
    prompt: string;
    style: string;
    seed: number;
    guidance_scale: number;
    strength: number;
    num_inference_steps: number;
  };
}

export interface InteriorDesignProgress {
  status: 'pending' | 'processing' | 'completed' | 'failed';
  progress: number;
  message: string;
  error?: {
    code: string;
    message: string;
  };
}

export interface InteriorDesignError {
  code: string;
  message: string;
  details?: any;
  retryable: boolean;
}