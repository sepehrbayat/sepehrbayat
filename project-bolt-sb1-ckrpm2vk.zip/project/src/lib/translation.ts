import { openai } from './openai';
import { 
  isEnglishUI, 
  getLocalizedErrorMessage, 
  preserveFormatting, 
  restoreFormatting 
} from './i18n/languageManager';
import type { TranslationOptions } from './i18n/types';

export { TranslationOptions };

// Translation functions
export async function translateToEnglish(text: string, options: TranslationOptions = {}): Promise<string> {
  try {
    // Preserve formatting if needed
    const processedText = preserveFormatting(text, options);

    const response = await openai.chat.completions.create({
      model: 'ModelsLab/Mixtral-8x7B-Instruct',
      temperature: 0.3,
      messages: [
        {
          role: 'system',
          content: `You are an expert translator specializing in technical and content-related translations from Persian to English. Your task:

1. Translation Approach:
   - Precise translation of core concepts
   - Preservation of technical terminology
   - Maintain professional tone
   - Keep SEO-friendly structure

2. Technical Details:
   - Preserve formatting markers
   - Maintain keyword density
   - Keep heading structures
   - Respect content hierarchy
   ${options.preserveFormatting ? '- Preserve all HTML/Markdown formatting' : ''}
   ${options.context ? `Context: ${options.context}` : ''}

IMPORTANT: Return ONLY the translated text, without any explanations or additional text.`
        },
        {
          role: 'user',
          content: processedText.trim()
        }
      ]
    });

    const translatedText = response.choices?.[0]?.message?.content;
    if (!translatedText) {
      throw new Error(getLocalizedErrorMessage('TRANSLATION_FAILED'));
    }

    // Restore formatting if needed
    return restoreFormatting(translatedText, options);

  } catch (error) {
    console.error('Translation error:', error);
    throw error instanceof Error ? error : new Error(getLocalizedErrorMessage('TRANSLATION_ERROR'));
  }
}

export async function translateToFarsi(text: string, options: TranslationOptions = {}): Promise<string> {
  try {
    // Preserve formatting if needed
    const processedText = preserveFormatting(text, options);

    const response = await openai.chat.completions.create({
      model: 'ModelsLab/Mixtral-8x7B-Instruct',
      temperature: 0.3,
      messages: [
        {
          role: 'system',
          content: `You are an expert translator specializing in technical and content-related translations from English to Persian. Your task:

1. Translation Approach:
   - Natural and fluent Persian
   - Preserve technical accuracy
   - Maintain professional tone
   - Keep SEO-friendly structure

2. Technical Details:
   - Use proper Persian typography
   - Maintain keyword relevance
   - Keep heading hierarchy
   - Respect content structure

IMPORTANT: Return ONLY the translated text in Persian, without any explanations or additional text.`
        },
        {
          role: 'user',
          content: processedText.trim()
        }
      ]
    });

    const translatedText = response.choices?.[0]?.message?.content;
    if (!translatedText) {
      throw new Error(isEnglishUI() ? 'Translation failed' : 'خطا در ترجمه متن');
    }

    // Restore formatting if needed
    return restoreFormatting(translatedText, options);

  } catch (error) {
    console.error('Translation error:', error);
    throw error instanceof Error ? error : new Error(
      isEnglishUI() ? 'Error translating text' : 'خطا در ترجمه متن'
    );
  }
}