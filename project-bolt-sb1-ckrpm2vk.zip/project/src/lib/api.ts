import { GenerateResponse } from './types';

const API_KEY = "DIT0j1BOjKT9OSLc5d2dnHYpTqrNjhXVxGba5toE6Z5pWJiVM2uDbYdHpr2r";
const API_TIMEOUT = 30000; // 30 seconds

interface APIResponse {
  status: 'success' | 'processing' | 'failed';
  output?: string[];
  future_links?: string[];
  fetch_result?: string;
  eta?: number;
  error?: {
    message: string;
  };
}

function validateResponse(data: any): APIResponse {
  if (!data || typeof data !== 'object') {
    throw new Error('پاسخ نامعتبر از سرور');
  }

  // Validate status
  if (!['success', 'processing', 'failed'].includes(data.status)) {
    throw new Error('وضعیت نامعتبر از سرور');
  }

  // Check for error
  if (data.status === 'failed' || data.error) {
    throw new Error(data.error?.message || 'خطا در پردازش درخواست');
  }

  return data as APIResponse;
}

export async function makeRequest(prompt: string, image: string) {
  try {
    // Add timeout to the request
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), API_TIMEOUT);

    try {
      const response = await fetch("https://modelslab.com/api/v6/interior/make", {
        method: 'POST',
        signal: controller.signal,
        headers: {
          'Content-Type': 'application/json',
          'key': API_KEY
        },
        body: JSON.stringify({
          key: API_KEY,
          init_image: image,
          prompt: prompt,
          negative_prompt: "bad quality",
          seed: 0,
          guidance_scale: 8,
          strength: 0.99,
          num_inference_steps: 51,
          base64: false,
          temp: false,
          scale_down: 6,
          webhook: null,
          track_id: null
        })
      });

      // Log raw response for debugging
      const responseText = await response.text();
      console.log('ModelsLab Raw Response:', {
        status: response.status,
        statusText: response.statusText,
        responseText: responseText.slice(0, 1000), // Log first 1000 chars only
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      let data: GenerateResponse;
      let retryCount = 0;
      const maxRetries = 2;

      try {
        while (retryCount <= maxRetries) {
          try {
            data = JSON.parse(responseText);
            break;
          } catch (parseError) {
            retryCount++;
            if (retryCount > maxRetries) {
              throw parseError;
            }
            // Wait before retrying
            await new Promise(resolve => setTimeout(resolve, 1000 * retryCount));
          }
        }
      } catch (error) {
        console.error('JSON parse error:', error);
        throw new Error('خطا در پردازش پاسخ سرور');
      }
      
      const validatedData = validateResponse(data);

      // Log validated response
      console.log('ModelsLab Validated Response:', {
        status: validatedData.status,
        hasOutput: Boolean(validatedData.output?.length || validatedData.future_links?.length),
        hasFutureLinks: Boolean(validatedData.future_links?.length),
      });

      if (validatedData.status === 'processing' && validatedData.fetch_result) {
        return {
          status: 'processing',
          fetch_result: data.fetch_result,
          eta: data.eta || 60,
          message: data.message || 'در حال پردازش...'
        };
      }

      // Handle success with future_links
      if (validatedData.future_links?.length > 0) {
        return {
          status: 'success',
          output: validatedData.future_links
        };
      }

      if (validatedData.output?.length > 0 || validatedData.proxy_links?.length > 0) {
        return {
          status: 'success', 
          output: validatedData.output || validatedData.proxy_links || []
        };
      }

      // If we get here with success status but no output, it's an error
      if (validatedData.status === 'success') {
        throw new Error('خطا در دریافت خروجی');
      }

      throw new Error('خطا در دریافت خروجی');

    } catch (error) {
      if (error.name === 'AbortError') {
        throw new Error('زمان درخواست به پایان رسید');
      }
      if (error.message.includes('JSON')) {
        throw new Error('خطا در پردازش پاسخ سرور');
      }
      if (error.message.includes('network')) {
        throw new Error('خطا در ارتباط با سرور. لطفاً اتصال اینترنت خود را بررسی کنید');
      }
      if (error.message.includes('rate limit')) {
        throw new Error('محدودیت تعداد درخواست. لطفاً چند دقیقه صبر کنید');
      }
      if (error.message.includes('HTTP error') || error.message.includes('Failed to fetch')) {
        throw new Error('خطا در ارتباط با سرور. لطفاً دوباره تلاش کنید');
      }
      throw error;
    } finally {
      clearTimeout(timeout);
    }

  } catch (error: any) {
    console.error('API request failed:', error);
    console.error('Error details:', { name: error?.name, message: error?.message, stack: error?.stack });
    throw error;
  }
}

// Polling function for processing status
export async function pollResult(url: string, maxAttempts = 30): Promise<string[]> {
  const response = await fetch(url, {
    cache: 'no-store',
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      'key': API_KEY
    }
  });

  if (!response.ok || response.status === 204 || response.status === 404) {
    throw new Error('خطا در دریافت نتیجه');
  }

  // Log raw poll response
  const responseText = await response.text();
  console.log('ModelsLab Poll Response:', {
    status: response.status,
    statusText: response.statusText,
    responseText: responseText.slice(0, 1000), // Log first 1000 chars only
  });

  let data;
  try {
    data = JSON.parse(responseText);
  } catch (error) {
    throw new Error('خطا در پردازش پاسخ سرور');
  }

  // Validate poll response
  const validatedData = validateResponse(data);

  if (validatedData.status === 'success' && (validatedData.output?.length || validatedData.future_links?.length || validatedData.proxy_links?.length)) {
    return validatedData.output || validatedData.future_links || [];
  }

  throw new Error('در حال پردازش...');
}