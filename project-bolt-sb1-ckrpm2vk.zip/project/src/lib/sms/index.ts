import { supabase } from '../supabase';

// Pattern codes for different message types
const PATTERNS = {
  VERIFICATION: 'verification', // Default verification pattern
  WELCOME: 'welcome',          // Welcome message pattern
  ALERT: 'alert'              // Alert message pattern
} as const;

interface SendSMSParams {
  recipient: string;
  message: string;
  sender: string;
  type: 'normal' | 'pattern' | 'bank' | 'district';
  pattern?: keyof typeof PATTERNS;
  description?: {
    summary?: string;
    count_recipient?: string;
  };
}

interface SMSMessage {
  id: string;
  user_id: string;
  recipient: string;
  message: string;
  sender: string;
  message_id?: string;
  status: 'pending' | 'sent' | 'delivered' | 'failed';
  type: string;
  created_at: string;
  updated_at: string;
}

const API_KEY = "DIT0j1BOjKT9OSLc5d2dnHYpTqrNjhXVxGba5toE6Z5pWJiVM2uDbYdHpr2r";
const API_URL = "https://api2.ippanel.com/api/v1";

export async function sendSMS({ recipient, message, sender, type, description }: SendSMSParams): Promise<SMSMessage> {
  try {
    // First create the message record in Supabase
    const { data: user } = await supabase.auth.getUser();
    if (!user?.user?.id) {
      throw new Error('کاربر احراز هویت نشده است');
    }

    const { data: messageRecord, error: dbError } = await supabase
      .from('sms_messages')
      .insert({
        user_id: user.user.id,
        recipient,
        message,
        sender,
        type,
        status: 'pending'
      })
      .select()
      .single();

    if (dbError) throw dbError;
    if (!messageRecord) throw new Error('خطا در ثبت پیام');

    // Send SMS via API
    let endpoint = '';
    let body = {};

    switch (type) {
      case 'normal':
        endpoint = '/sms/send/webservice/single';
        body = {
          recipient: [recipient],
          sender,
          message
        };
        break;

      case 'pattern':
        endpoint = '/sms/pattern/normal/send';
        body = {
          pattern_code: PATTERNS[pattern || 'VERIFICATION'],
          sender,
          recipient,
          values: {
            code: message // For verification patterns, message is the code
          },
          is_template_message: true
        };
        break;

      case 'bank':
        endpoint = '/sms/post-code-bank/send-overall';
        body = {
          meta: [{
            post_code: parseInt(recipient),
            gender: 1,
            from_age: 1300,
            to_age: 1400
          }],
          sender,
          message,
          description
        };
        break;

      case 'district':
        endpoint = '/sms/district-bank/send';
        body = {
          sender,
          message,
          area_ids: [parseInt(recipient)],
          description
        };
        break;
    }

    const response = await fetch(`${API_URL}${endpoint}`, {
      method: 'POST',
      headers: {
        'Authorization': API_KEY,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    });

    const apiResponse = await response.json();

    if (!response.ok) {
      // Handle specific API errors
      if (response.status === 422 && apiResponse.error_message?.code) {
        throw new Error('کد الگو نامعتبر است. لطفاً با پشتیبانی تماس بگیرید');
      }
      if (response.status === 401) {
        throw new Error('خطای احراز هویت. لطفاً با پشتیبانی تماس بگیرید');
      }
      if (response.status === 429) {
        throw new Error('تعداد درخواست‌ها بیش از حد مجاز است. لطفاً کمی صبر کنید');
      }
      
      throw new Error(apiResponse.errorMessage || 'خطا در ارسال پیامک');
    }

    // Update message record with API response
    const { data: updatedMessage, error: updateError } = await supabase
      .from('sms_messages')
      .update({
        message_id: apiResponse.data.message_id,
        status: 'sent'
      })
      .eq('id', messageRecord.id)
      .select()
      .single();

    if (updateError) throw updateError;
    if (!updatedMessage) throw new Error('خطا در بروزرسانی وضعیت پیام');

    return updatedMessage;

  } catch (error) {
    console.error('SMS send error:', error);
    throw error instanceof Error ? error : new Error('خطا در ارسال پیامک');
  }
}

export async function checkMessageStatus(messageId: string): Promise<string> {
  try {
    const response = await fetch(`${API_URL}/sms/message/show-recipient/message-id/${messageId}`, {
      headers: {
        'Authorization': API_KEY
      }
    });

    if (!response.ok) {
      throw new Error('خطا در دریافت وضعیت پیامک');
    }

    const data = await response.json();
    
    // Map API status to our status
    const statusMap: Record<number, string> = {
      0: 'pending',
      1: 'pending',
      2: 'delivered',
      3: 'failed',
      4: 'failed'
    };

    const status = statusMap[data.data[0]?.status] || 'pending';

    // Update message status in database
    const { error: updateError } = await supabase
      .from('sms_messages')
      .update({ status })
      .eq('message_id', messageId);

    if (updateError) throw updateError;

    return status;

  } catch (error) {
    console.error('Status check error:', error);
    throw error instanceof Error ? error : new Error('خطا در دریافت وضعیت پیامک');
  }
}

export async function getUserMessages(): Promise<SMSMessage[]> {
  const { data: user } = await supabase.auth.getUser();
  if (!user?.user?.id) {
    throw new Error('کاربر احراز هویت نشده است');
  }

  const { data: messages, error } = await supabase
    .from('sms_messages')
    .select('*')
    .eq('user_id', user.user.id)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return messages;
}

export async function checkCredit(): Promise<number> {
  try {
    const response = await fetch(`${API_URL}/sms/accounting/credit/show`, {
      headers: {
        'Authorization': API_KEY
      }
    });

    if (!response.ok) {
      throw new Error('خطا در دریافت اعتبار');
    }

    const data = await response.json();
    return data.data.credit;

  } catch (error) {
    console.error('Credit check error:', error);
    throw error instanceof Error ? error : new Error('خطا در دریافت اعتبار');
  }
}

export { PATTERNS }