import { supabase } from '../supabase';

export interface UserSettings {
  theme: 'light' | 'dark' | 'system';
  language: 'fa' | 'en';
  fontSize: 'sm' | 'md' | 'lg';
  notifications: {
    email: boolean;
    push: boolean;
    marketing: boolean;
  };
  privacy: {
    activityVisible: boolean;
    profilePublic: boolean;
    twoFactorEnabled: boolean;
  };
}

export async function getUserSettings(): Promise<UserSettings | null> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    const { data, error } = await supabase
      .from('user_settings')
      .select('*')
      .eq('user_id', user.id)
      .single();

    if (error) throw error;

    return data;
  } catch (error) {
    console.error('Error getting user settings:', error);
    return null;
  }
}

export async function updateUserSettings(settings: Partial<UserSettings>): Promise<void> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const { error } = await supabase
      .from('user_settings')
      .upsert({
        user_id: user.id,
        ...settings,
        updated_at: new Date().toISOString()
      });

    if (error) throw error;

    // Apply theme changes
    if (settings.theme) {
      applyTheme(settings.theme);
    }

    // Apply font size changes
    if (settings.fontSize) {
      applyFontSize(settings.fontSize);
    }

  } catch (error) {
    console.error('Error updating user settings:', error);
    throw error;
  }
}

export async function deleteAccount(): Promise<void> {
  try {
    const { error } = await supabase.auth.admin.deleteUser(
      (await supabase.auth.getUser()).data.user?.id || ''
    );
    if (error) throw error;
  } catch (error) {
    console.error('Error deleting account:', error);
    throw error;
  }
}

export async function exportUserData(): Promise<Blob> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    // Get all user data
    const [
      settings,
      profile,
      activity
    ] = await Promise.all([
      supabase.from('user_settings').select('*').eq('user_id', user.id),
      supabase.from('users').select('*').eq('id', user.id),
      supabase.from('user_activity').select('*').eq('user_id', user.id)
    ]);

    const userData = {
      profile: profile.data?.[0] || null,
      settings: settings.data?.[0] || null,
      activity: activity.data || [],
      exportDate: new Date().toISOString()
    };

    // Create JSON blob
    return new Blob([JSON.stringify(userData, null, 2)], {
      type: 'application/json'
    });

  } catch (error) {
    console.error('Error exporting user data:', error);
    throw error;
  }
}

function applyTheme(theme: 'light' | 'dark' | 'system') {
  if (theme === 'system') {
    const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    document.documentElement.classList.toggle('dark', isDark);
  } else {
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }
}

function applyFontSize(size: 'sm' | 'md' | 'lg') {
  const sizes = {
    sm: '14px',
    md: '16px',
    lg: '18px'
  };
  document.documentElement.style.fontSize = sizes[size];
}