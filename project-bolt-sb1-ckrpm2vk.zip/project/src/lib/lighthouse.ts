import { METRIC_THRESHOLDS, RESOURCE_THRESHOLDS, CACHE_DURATIONS } from './lighthouse/constants';

export interface LighthouseReport {
  performance: number;
  accessibility: number;
  seo: number;
  bestPractices: number;
  progressiveWebApp: number;
  coreWebVitals: {
    lcp: number;
    fid: number;
    cls: number;
    inp: number;
    tbt: number;
  };
  metrics: {
    ttfb: number;
    firstContentfulPaint: number;
    firstMeaningfulPaint: number;
    speedIndex: number;
    timeToInteractive: number;
    totalBlockingTime: number;
    domContentLoaded: number;
    domSize: number;
    serverResponseTime: number;
    bootupTime: number;
    mainThreadWorkBreakdown: {
      scriptEvaluation: number;
      scriptParsing: number;
      styleLayout: number;
      painting: number;
      garbageCollection: number;
      other: number;
    };
    networkRtt: number;
    networkServerLatency: number;
    totalByteWeight: number;
    offscreenImages: number;
    unusedCssRules: number;
    unusedJavaScript: number;
    modernImageFormats: number;
    optimizedImages: number;
    responsiveImages: number;
    duplicatedJavaScript: number;
    legacyJavaScript: number;
    noDocumentWrite: boolean;
    timeToFirstByte: number;
    firstCpuIdle: number;
    maxPotentialFid: number;
    resourceSummary: {
      total: number;
      js: number;
      css: number;
      images: number;
      fonts: number;
      other: number;
    };
    thirdPartyUsage: {
      totalBytes: number;
      totalBlockingTime: number;
    };
    mainThreadWork: {
      scriptEvaluation: number;
      styleLayout: number;
      rendering: number;
      painting: number;
      other: number;
    };
    security: {
      score: number;
      https: boolean;
      mixedContent: boolean;
      vulnerabilities: string[];
      certificate: {
        valid: boolean;
        issuer: string;
        expiryDate: string;
      };
    };
    compression: {
      gzip: boolean;
      brotli: boolean;
      savings: number;
    };
    caching: {
      staticAssets: boolean;
      longCache: boolean;
      ttl: number;
    };
    images: {
      optimized: number;
      responsive: number;
      nextGen: number;
      lazyLoaded: number;
    };
  };
}

export async function runLighthouseAudit(url: string, device: 'desktop' | 'mobile' = 'desktop'): Promise<LighthouseReport> {
  try {
    // Simulate realistic Lighthouse metrics based on common ranges
    const generateScore = () => {
      // Mobile scores tend to be lower than desktop
      const baseScore = device === 'desktop' ? 75 : 65;
      const variance = device === 'desktop' ? 25 : 30;
      const score = Math.floor(Math.random() * variance) + baseScore;
      return {
        value: score,
        rating: score >= 90 ? 'عالی' : score >= 70 ? 'خوب' : score >= 50 ? 'متوسط' : 'ضعیف'
      };
    };

    const performance = generateScore();
    const accessibility = generateScore();
    const seo = generateScore();
    const progressiveWebApp = generateScore();
    const bestPractices = generateScore();

    // Generate realistic Core Web Vitals
    const coreWebVitals = {
      lcp: device === 'desktop' 
        ? Math.floor(Math.random() * 1500) + 1000  // 1-2.5s for desktop
        : Math.floor(Math.random() * 2000) + 2000, // 2-4s for mobile

      fid: device === 'desktop'
        ? Math.floor(Math.random() * 40) + 20      // 20-60ms for desktop
        : Math.floor(Math.random() * 100) + 50,    // 50-150ms for mobile

      cls: Number((Math.random() * 0.08 + 0.01).toFixed(3)),  // 0.01-0.09

      inp: device === 'desktop'
        ? Math.floor(Math.random() * 100) + 50     // 50-150ms for desktop
        : Math.floor(Math.random() * 150) + 100,   // 100-250ms for mobile
      
      tbt: device === 'desktop'
        ? Math.floor(Math.random() * 200) + 100    // 100-300ms for desktop
        : Math.floor(Math.random() * 300) + 200    // 200-500ms for mobile
    };

    // Generate realistic performance metrics
    const metrics = {
      ttfb: device === 'desktop'
        ? Math.floor(Math.random() * 200) + 100    // 100-300ms for desktop
        : Math.floor(Math.random() * 400) + 200,   // 200-600ms for mobile

      firstContentfulPaint: device === 'desktop'
        ? Math.floor(Math.random() * 800) + 600    // 600-1400ms for desktop
        : Math.floor(Math.random() * 1200) + 1000, // 1000-2200ms for mobile

      speedIndex: device === 'desktop'
        ? Math.floor(Math.random() * 1500) + 1000  // 1000-2500ms for desktop
        : Math.floor(Math.random() * 2000) + 2000, // 2000-4000ms for mobile

      timeToInteractive: device === 'desktop'
        ? Math.floor(Math.random() * 2000) + 1500  // 1500-3500ms for desktop
        : Math.floor(Math.random() * 3000) + 3000, // 3000-6000ms for mobile

      totalBlockingTime: Math.floor(Math.random() * 300) + 100,   // 100-400ms

      domContentLoaded: device === 'desktop'
        ? Math.floor(Math.random() * 500) + 300    // 300-800ms for desktop
        : Math.floor(Math.random() * 800) + 500,   // 500-1300ms for mobile
      
      domSize: Math.floor(Math.random() * 1000) + 500, // 500-1500 elements

      resourceSummary: {
        total: Math.floor(Math.random() * 50) + 20,
        js: Math.floor(Math.random() * 15) + 5,
        css: Math.floor(Math.random() * 5) + 1,
        images: Math.floor(Math.random() * 20) + 5,
        fonts: Math.floor(Math.random() * 3) + 1,
        other: Math.floor(Math.random() * 5) + 1
      },

      thirdPartyUsage: {
        totalBytes: Math.floor(Math.random() * 500000) + 100000, // 100KB-600KB
        totalBlockingTime: Math.floor(Math.random() * 200) + 50  // 50-250ms
      },

      mainThreadWork: {
        scriptEvaluation: device === 'desktop'
          ? Math.floor(Math.random() * 1000) + 500
          : Math.floor(Math.random() * 1500) + 800,
        styleLayout: device === 'desktop'
          ? Math.floor(Math.random() * 500) + 200
          : Math.floor(Math.random() * 800) + 400,
        rendering: device === 'desktop'
          ? Math.floor(Math.random() * 300) + 100
          : Math.floor(Math.random() * 500) + 200,
        painting: Math.floor(Math.random() * 200) + 50,
        other: Math.floor(Math.random() * 300) + 100
      },

      // Add new metrics for resource optimization
      unusedJavaScript: Math.floor(Math.random() * 200000) + 50000, // 50KB-250KB
      unusedCssRules: Math.floor(Math.random() * 50000) + 10000,    // 10KB-60KB
      optimizedImages: Math.floor(Math.random() * 40) + 60,         // 60-100%
      modernImageFormats: Math.floor(Math.random() * 30) + 40,      // 40-70%
      responsiveImages: Math.floor(Math.random() * 30) + 60,        // 60-90%

      // Security metrics
      security: {
        score: Math.floor(Math.random() * 30) + 70,
        https: Math.random() > 0.2,
        mixedContent: Math.random() > 0.8,
        vulnerabilities: [],
        certificate: {
          valid: Math.random() > 0.1,
          issuer: "Let's Encrypt",
          expiryDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString()
        }
      },

      // Compression metrics
      compression: {
        gzip: Math.random() > 0.3,
        brotli: Math.random() > 0.6,
        savings: Math.floor(Math.random() * 300000) + 100000 // 100KB-400KB savings
      },

      // Caching metrics
      caching: {
        staticAssets: Math.random() > 0.2,
        longCache: Math.random() > 0.4,
        ttl: Math.floor(Math.random() * CACHE_DURATIONS.STATIC)
      },

      // Image optimization metrics
      images: {
        optimized: Math.floor(Math.random() * 30) + 70,    // 70-100%
        responsive: Math.floor(Math.random() * 40) + 60,   // 60-100%
        nextGen: Math.floor(Math.random() * 50) + 50,      // 50-100%
        lazyLoaded: Math.floor(Math.random() * 40) + 60,   // 60-100%
        totalBytes: Math.floor(Math.random() * 2000000) + 500000, // 500KB-2.5MB
        totalCount: Math.floor(Math.random() * 30) + 10,   // 10-40 images
        webpEnabled: Math.random() > 0.3,
        avifEnabled: Math.random() > 0.7,
        lazyLoadEnabled: Math.random() > 0.2,
        sizesAttribute: Math.random() > 0.4,
        srcsetAttribute: Math.random() > 0.3
      }
    };

    return {
      performance: performance.value,
      accessibility: accessibility.value,
      seo: seo.value,
      bestPractices: bestPractices.value,
      progressiveWebApp: progressiveWebApp.value,
      coreWebVitals,
      metrics
    };
  } catch (error) {
    console.error('Lighthouse audit failed:', error);
    throw new Error('Failed to run performance audit');
  }
}