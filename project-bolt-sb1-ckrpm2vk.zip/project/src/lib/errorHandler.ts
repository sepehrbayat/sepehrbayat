import { isEnglishUI } from './i18n/languageManager';

interface ErrorConfig {
  // Maps technical error types to user-friendly messages
  messageMap: Record<string, string>;
  // Default message when no specific mapping exists
  defaultMessage: string;
  // Error types that should be hidden from users
  sensitiveErrors: string[];
  // Priority order for error types (higher index = higher priority)
  priorityOrder: string[];
}

const ERROR_CONFIG: ErrorConfig = {
  messageMap: {
    // Network errors
    'NetworkError': 'خطا در ارتباط با سرور. لطفاً اتصال اینترنت خود را بررسی کنید',
    'TimeoutError': 'زمان درخواست به پایان رسید. لطفاً دوباره تلاش کنید',
    'AbortError': 'درخواست لغو شد. لطفاً دوباره تلاش کنید',
    
    // API errors
    'RateLimitError': 'محدودیت تعداد درخواست. لطفاً چند دقیقه صبر کنید',
    'AuthenticationError': 'خطای احراز هویت. لطفاً دوباره وارد شوید',
    'ValidationError': 'اطلاعات وارد شده نامعتبر است',
    'NotFoundError': 'اطلاعات درخواستی یافت نشد',
    
    // Data errors
    'ParseError': 'خطا در پردازش اطلاعات. لطفاً دوباره تلاش کنید',
    'DataError': 'خطا در داده‌های دریافتی',
    
    // File errors
    'FileUploadError': 'خطا در آپلود فایل. لطفاً دوباره تلاش کنید',
    'FileSizeError': 'حجم فایل بیش از حد مجاز است',
    'FileTypeError': 'نوع فایل پشتیبانی نمی‌شود'
  },
  defaultMessage: 'خطایی رخ داد. لطفاً دوباره تلاش کنید',
  sensitiveErrors: [
    'InternalServerError',
    'DatabaseError',
    'StackTrace',
    'SQLError',
    'MemoryError'
  ],
  priorityOrder: [
    'AuthenticationError',
    'ValidationError',
    'RateLimitError',
    'NetworkError',
    'TimeoutError',
    'NotFoundError',
    'FileUploadError',
    'ParseError',
    'DataError'
  ]
};

export function filterErrorMessage(error: unknown): string {
  const isEnglish = isEnglishUI();
  
  // Handle array of errors
  if (Array.isArray(error)) {
    // Filter and sort errors
    const filteredErrors = error
      .map(err => filterErrorMessage(err))
      .filter(Boolean)
      .filter((value, index, self) => self.indexOf(value) === index); // Remove duplicates
    
    // Sort by priority
    filteredErrors.sort((a, b) => {
      const priorityA = ERROR_CONFIG.priorityOrder.findIndex(p => a.includes(p));
      const priorityB = ERROR_CONFIG.priorityOrder.findIndex(p => b.includes(p));
      return (priorityB === -1 ? -1 : priorityB) - (priorityA === -1 ? -1 : priorityA);
    });
    
    return filteredErrors[0] || ERROR_CONFIG.defaultMessage;
  }

  // Handle single error
  if (error instanceof Error) {
    // Check for sensitive information
    const errorString = error.toString().toLowerCase();
    if (ERROR_CONFIG.sensitiveErrors.some(sensitive => 
      errorString.includes(sensitive.toLowerCase())
    )) {
      return isEnglish ? 'An internal error occurred' : 'خطای داخلی رخ داد';
    }

    // Check for known error types
    for (const [errorType, message] of Object.entries(ERROR_CONFIG.messageMap)) {
      if (error.name.includes(errorType) || error.message.includes(errorType)) {
        return isEnglish ? translateErrorMessage(message) : message;
      }
    }

    // Clean and return error message if it seems safe
    const cleanMessage = error.message
      .replace(/[^\w\s\u0600-\u06FF.,:]/g, '') // Keep Persian characters, basic punctuation
      .replace(/\s+/g, ' ')
      .trim();

    if (cleanMessage && !containsSensitiveInfo(cleanMessage)) {
      return cleanMessage;
    }
  }

  // For unknown error types
  return isEnglish ? 'An error occurred. Please try again' : ERROR_CONFIG.defaultMessage;
}

// Helper to check for sensitive information patterns
function containsSensitiveInfo(message: string): boolean {
  const sensitivePatterns = [
    /stack\s?trace/i,
    /at\s+[\w./<>]+\s+\(.*?\)/i, // Stack trace lines
    /sql|query|database/i,
    /api[_-]?key/i,
    /password|secret|token/i,
    /[0-9a-f]{32,}/i, // Long hex strings
    /exception in thread/i,
    /internal server error/i
  ];

  return sensitivePatterns.some(pattern => pattern.test(message));
}

// Translate error messages to English
function translateErrorMessage(persianMessage: string): string {
  const translations: Record<string, string> = {
    'خطا در ارتباط با سرور. لطفاً اتصال اینترنت خود را بررسی کنید': 
      'Connection error. Please check your internet connection',
    'زمان درخواست به پایان رسید. لطفاً دوباره تلاش کنید':
      'Request timed out. Please try again',
    'محدودیت تعداد درخواست. لطفاً چند دقیقه صبر کنید':
      'Rate limit exceeded. Please wait a few minutes',
    'خطای احراز هویت. لطفاً دوباره وارد شوید':
      'Authentication error. Please log in again',
    'اطلاعات وارد شده نامعتبر است':
      'Invalid input data',
    'خطایی رخ داد. لطفاً دوباره تلاش کنید':
      'An error occurred. Please try again'
  };

  return translations[persianMessage] || 'An error occurred. Please try again';
}