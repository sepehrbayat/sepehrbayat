import { openai, openaiPro, MODELS } from '../openai';
import type { ContentPlan } from '../../types';
import { formatHeadings } from './formatter';
import i18n from '../i18n';

const CONTENT_LENGTH_RANGES = {
  short: { min: 500, max: 800 },
  medium: { min: 1000, max: 1500 },
  long: { min: 2000, max: 3000 },
  custom: { min: 0, max: 0 } // Will be set dynamically
};

interface GenerateContentOptions {
  topic: string;
  keywords: string[];
  headings?: any[];
  style?: string;
  tone?: string;
  audience?: string;
  contentLength: 'short' | 'medium' | 'long' | 'custom';
  minWords?: number;
  maxWords?: number;
  targetKeyword?: string;
  isPro?: boolean;
}

export async function generateContent(options: GenerateContentOptions): Promise<ContentPlan> {
  try {
    const isEnglish = i18n.language === 'en';
    
    // Add request timeout
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 60000); // 60 second timeout

    // Validate required fields
    if (!options.topic?.trim()) {
      throw new Error('موضوع محتوا نمی‌تواند خالی باشد');
    }

    if (!options.keywords?.length) {
      throw new Error('حداقل یک کلمه کلیدی الزامی است');
    }

    if (!options.headings?.length) {
      throw new Error('حداقل یک سرتیتر الزامی است');
    }
        
    // Get word count range based on content length
    let wordCountRange;
    if (options.contentLength === 'custom') {
      wordCountRange = {
        min: options.minWords || CONTENT_LENGTH_RANGES.medium.min,
        max: options.maxWords || CONTENT_LENGTH_RANGES.medium.max
      };
    } else {
      wordCountRange = CONTENT_LENGTH_RANGES[options.contentLength];
    }

    // Use appropriate client and model based on content type
    const client = options.isPro ? openaiPro : openai;
    const model = options.isPro ? MODELS.pro : 'ModelsLab/Mixtral-8x7B-Instruct';

    // Generate content with proper error handling and response parsing
    let response;
    try {
      response = await (options.isPro ? client.chat.completions.create({
      model: model,
      temperature: 0.5, // Lower temperature for more focused output
      presence_penalty: 0.2, // Slight penalty to avoid repetition
      messages: [
        {
          role: 'system',
          content: `You are a professional content writer. Generate comprehensive content based on the provided topic, keywords, and structure.

Content Guidelines:
1. Structure and Format:
   - Follow the provided headings structure
   - Use clear paragraphs and transitions
   - Include relevant examples and data
   - Use HTML tags for structure

2. Writing Style:
   - Professional and engaging tone
   - Clear and concise language
   - Natural keyword integration
   - Proper citations and references

3. SEO Optimization:
   - Strategic keyword placement
   - Optimized meta descriptions
   - Internal linking suggestions
   - SEO-friendly headings

4. Quality Standards:
   - Original, plagiarism-free content
   - Fact-checked information
   - Proper grammar and spelling
   - Consistent formatting

Content Structure:
${options.headings?.map(h => `${'-'.repeat(h.level)} ${h.title}`).join('\n')}

Keywords: ${options.keywords.join(', ')}

Style: ${options.style || 'professional'}
Tone: ${options.tone || 'formal'}
Audience: ${options.audience || 'general'}

Word Count Range: ${wordCountRange.min} to ${wordCountRange.max} words

Please return a JSON object with this structure:
{
  "title": "Content title",
  "description": "Meta description",
  "content": "Full HTML content",
  "wordCount": number,
  "seoScore": number (0-100),
  "readabilityScore": number (0-100),
  "sections": [{
    "title": "Section title",
    "content": "Section content",
    "wordCount": number
  }]
}`
        },
        {
          role: 'user',
          content: options.topic
        }
      ]}) : fetch("https://modelslab.com/api/uncensored-chat/v1/chat/completions", {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'key': "DIT0j1BOjKT9OSLc5d2dnHYpTqrNjhXVxGba5toE6Z5pWJiVM2uDbYdHpr2r"
        },
        body: JSON.stringify({
          model: model,
          temperature: 0.7,
          messages: [
            {
              role: 'system',
              content: `شما یک نویسنده حرفه‌ای محتوا هستید. لطفاً با استفاده از موضوع، کلمات کلیدی و ساختار داده شده، یک محتوای جامع تولید کنید.

ساختار محتوا:
${options.headings?.map(h => `${'-'.repeat(h.level)} ${h.title}`).join('\n')}

کلمات کلیدی: ${options.keywords.join('، ')}

سبک: ${options.style || 'حرفه‌ای'}
لحن: ${options.tone || 'رسمی'}
مخاطب: ${options.audience || 'عمومی'}

محدوده تعداد کلمات: ${wordCountRange.min} تا ${wordCountRange.max} کلمه

لطفاً خروجی را در قالب JSON با این ساختار برگردانید:
{
  "title": "عنوان محتوا",
  "description": "توضیحات متا",
  "content": "محتوای کامل HTML",
  "wordCount": عدد,
  "seoScore": عدد (0-100),
  "readabilityScore": عدد (0-100),
  "sections": [{
    "title": "عنوان بخش",
    "content": "محتوای بخش",
    "wordCount": عدد
  }]
}`
            },
            {
              role: 'user',
              content: options.topic
            }
          ]
        })
    }).then(res => res.json()));
    } catch (error) {
      console.error('API request error:', error);
      throw new Error('خطا در ارتباط با سرور. لطفاً دوباره تلاش کنید');
    }

    // Handle API response with proper error checking
    const generatedContent = options.isPro ? 
      response.choices?.[0]?.message?.content :
      response.choices?.[0]?.message?.content;

    if (!generatedContent) {
      console.error('Empty response:', response);
      throw new Error('خطا در دریافت پاسخ از سرور. لطفاً دوباره تلاش کنید');
    }

    // Parse the response
    let parsedContent;
    try {
      // First try parsing the entire response
      parsedContent = JSON.parse(generatedContent);
    } catch (parseError) {
      // If direct parsing fails, try to find and parse just the JSON object
      try {
        const jsonMatch = generatedContent.match(/\{[\s\S]*\}/);
        if (!jsonMatch) throw new Error('فرمت پاسخ نامعتبر است');
        parsedContent = JSON.parse(jsonMatch[0]);
      } catch {
        console.error('Parse error:', parseError);
        throw new Error('خطا در پردازش پاسخ. لطفاً دوباره تلاش کنید');
      }
    }

    // Validate parsed content structure
    if (!parsedContent || typeof parsedContent !== 'object') {
      console.error('Invalid content structure:', parsedContent);
      throw new Error('ساختار پاسخ نامعتبر است');
    }

    // Set default values for missing fields
    parsedContent = {
      title: parsedContent.title || options.topic,
      description: parsedContent.description || '',
      content: parsedContent.content || '',
      wordCount: parsedContent.wordCount || CONTENT_LENGTH_RANGES.medium.min,
      seoScore: parsedContent.seoScore || 0,
      readabilityScore: parsedContent.readabilityScore || 0,
      sections: parsedContent.sections || []
    };

    // Clear timeout
    clearTimeout(timeout);

    // Format headings and clean up content
    const formattedContent = formatHeadings(parsedContent.content);

    const contentPlan: ContentPlan = {
      title: parsedContent.title || options.topic,
      description: parsedContent.description || '',
      keywords: options.keywords,
      wordCount: Math.max(
        wordCountRange.min,
        Math.min(wordCountRange.max, parsedContent.wordCount || wordCountRange.min)
      ),
      seoScore: Math.min(100, Math.max(0, parsedContent.seoScore || 0)),
      readabilityScore: Math.min(100, Math.max(0, parsedContent.readabilityScore || 0)),
      content: formattedContent,
      sections: (parsedContent.sections || []).map((section: any) => ({
        title: section.title,
        content: section.content,
        wordCount: section.wordCount || 0,
        sources: [],
        metadata: {
          style: options.style,
          tone: options.tone,
          audience: options.audience
        }
      })),
      references: []
    };

    return contentPlan;

  } catch (error) {
    console.error('Content generation error:', error);
    throw error instanceof Error ? error : new Error('خطا در تولید محتوا');
  }
}