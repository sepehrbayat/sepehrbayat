import i18n from '../i18n';

export function validateTopic(topic: string): { isValid: boolean; suggestions: string[] } {
  const isEnglish = i18n.language === 'en';
  const result = {
    isValid: true,
    suggestions: [] as string[]
  };

  // Check minimum length
  if (topic.length < 10) {
    result.isValid = false;
    result.suggestions.push(isEnglish ? 'Topic must be at least 10 characters' : 'موضوع باید حداقل 10 کاراکتر باشد');
  }

  // Check if topic is too short (just 1-2 words)
  const words = topic.trim().split(/\s+/);
  if (words.length < 3) {
    result.isValid = false;
    result.suggestions.push(isEnglish ? 'Topic should be at least 3 words for better content generation' : 'موضوع باید حداقل 3 کلمه باشد تا بتوانیم محتوای بهتری تولید کنیم');
  }

  // Check for common issues
  if (topic.includes('?') || topic.includes('؟')) {
    result.suggestions.push(isEnglish ? 'Write the topic as a statement, not a question' : 'بهتر است موضوع را به صورت عبارت خبری بنویسید، نه سوالی');
  }

  if (/^(چگونه|چطور|روش|نحوه)/i.test(topic)) {
    result.suggestions.push(isEnglish ? 'Consider using "Complete Guide to..." or "Comprehensive Tutorial on..."' : 'می‌توانید موضوع را به صورت "راهنمای کامل..." یا "آموزش جامع..." بنویسید');
  }

  if (topic.includes('بهترین')) {
    result.suggestions.push(isEnglish ? 'Instead of "best", consider using "Selection Guide" or "Comprehensive Comparison"' : 'به جای "بهترین" می‌توانید از عبارت "راهنمای انتخاب" یا "مقایسه جامع" استفاده کنید');
  }

  // Check for vague topics
  const vagueWords = isEnglish ? ['good', 'bad', 'important', 'interesting', 'great'] : ['خوب', 'بد', 'مهم', 'جالب', 'عالی'];
  if (vagueWords.some(word => topic.includes(word))) {
    result.suggestions.push(isEnglish ? 'Use more specific and technical terms to describe the topic' : 'از کلمات دقیق‌تر و تخصصی‌تر برای توصیف موضوع استفاده کنید');
  }

  return result;
}

export function validateKeywords(keywords: string[]): { isValid: boolean; suggestions: string[] } {
  const result = {
    isValid: true,
    suggestions: [] as string[]
  };

  // Check minimum number of keywords
  if (keywords.length < 3) {
    result.isValid = false;
    result.suggestions.push('حداقل 3 کلمه کلیدی وارد کنید');
  }

  // Check keyword length
  keywords.forEach(keyword => {
    if (keyword.length < 3) {
      result.isValid = false;
      result.suggestions.push(`کلمه کلیدی "${keyword}" خیلی کوتاه است`);
    }
    if (keyword.length > 50) {
      result.isValid = false;
      result.suggestions.push(`کلمه کلیدی "${keyword}" خیلی طولانی است`);
    }
  });

  // Check for duplicates
  const duplicates = keywords.filter((item, index) => keywords.indexOf(item) !== index);
  if (duplicates.length > 0) {
    result.isValid = false;
    result.suggestions.push('کلمات کلیدی تکراری را حذف کنید');
  }

  return result;
}

export function validateHeadings(headings: any[]): { isValid: boolean; suggestions: string[] } {
  const result = {
    isValid: true,
    suggestions: [] as string[]
  };

  // Check minimum number of headings
  if (headings.length < 2) {
    result.isValid = false;
    result.suggestions.push('حداقل 2 سرتیتر وارد کنید');
  }

  // Check heading levels
  let hasH2 = false;
  headings.forEach(heading => {
    if (heading.level === 2) hasH2 = true;
    
    if (heading.level < 2 || heading.level > 4) {
      result.isValid = false;
      result.suggestions.push('سطح سرتیتر باید بین H2 تا H4 باشد');
    }
  });

  if (!hasH2) {
    result.isValid = false;
    result.suggestions.push('حداقل یک سرتیتر H2 نیاز است');
  }

  // Check heading titles
  headings.forEach(heading => {
    if (heading.title.length < 3) {
      result.isValid = false;
      result.suggestions.push('عنوان سرتیتر خیلی کوتاه است');
    }
    if (heading.title.length > 100) {
      result.isValid = false;
      result.suggestions.push('عنوان سرتیتر خیلی طولانی است');
    }
  });

  // Check heading hierarchy
  const h2Headings = headings.filter(h => h.level === 2);
  const h3Headings = headings.filter(h => h.level === 3);
  const h4Headings = headings.filter(h => h.level === 4);

  if (h3Headings.length > 0 && h2Headings.length === 0) {
    result.suggestions.push('قبل از استفاده از H3، باید حداقل یک H2 داشته باشید');
  }

  if (h4Headings.length > 0 && h3Headings.length === 0) {
    result.suggestions.push('قبل از استفاده از H4، باید حداقل یک H3 داشته باشید');
  }

  return result;
}