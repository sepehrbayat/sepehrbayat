import { HEADING_PATTERNS } from './patterns';

/**
 * Formats markdown-style headings to HTML headings
 */
export function formatHeadings(content: string): string {
  let formattedContent = content;

  // Replace markdown headings with HTML tags
  formattedContent = formattedContent
    // Replace ATX-style headings (# Heading)
    .replace(/^#{1,6}\s+(.+)$/gm, (match, text) => {
      const level = match.trim().split(' ')[0].length;
      return `<h${level}>${text.trim()}</h${level}>`;
    })
    // Replace Setext-style headings (Heading\n===== or Heading\n-----)
    .replace(/^(.+)\n=+$/gm, '<h1>$1</h1>')
    .replace(/^(.+)\n-+$/gm, '<h2>$1</h2>');

  // Replace Persian/Arabic heading patterns
  HEADING_PATTERNS.forEach(pattern => {
    formattedContent = formattedContent.replace(pattern.regex, (match, text) => {
      return `<h${pattern.level}>${text.trim()}</h${pattern.level}>`;
    });
  });

  // Clean up any remaining markdown-style formatting
  formattedContent = formattedContent
    // Remove extra newlines between headings
    .replace(/(<\/h[1-6]>)\n+/g, '$1\n')
    // Add proper spacing after headings
    .replace(/(<\/h[1-6]>)(?!\n)/g, '$1\n')
    // Remove any remaining heading markers
    .replace(/^#+\s/gm, '')
    .replace(/[=\-]+$/gm, '');

  return formattedContent;
}