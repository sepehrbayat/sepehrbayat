import { openai } from '../openai';
import i18n from '../i18n';

export async function improveTopic(topic: string): Promise<string> {
  const isEnglish = i18n.language === 'en';
  
  try {
    const response = await openai.chat.completions.create({
      model: 'ModelsLab/Mixtral-8x7B-Instruct',
      temperature: 0.7,
      messages: [
            `You are an expert in optimizing article titles and topics. Please improve the given topic.
            `شما یک متخصص بهینه‌سازی عنوان و موضوع مقاله هستید. لطفاً موضوع داده شده را بهبود دهید.
      ]
    }
    )
  }
}

قوانین بهبود موضوع:
1. جامع‌تر و دقیق‌تر کردن
2. استفاده از کلمات کلیدی مناسب
3. رعایت اصول سئو
4. حفظ هدف اصلی موضوع
5. بهبود جذابیت برای مخاطب

مثال‌ها:
- "آموزش فتوشاپ" -> "راهنمای جامع آموزش فتوشاپ: از مبتدی تا پیشرفته با مثال‌های کاربردی"
- "مزایای ورزش" -> "10 فایده اثبات شده ورزش منظم برای سلامت جسم و روان + برنامه تمرینی"
- "خرید لپ تاپ" -> "راهنمای خرید لپ تاپ در سال 1402: مقایسه بهترین مدل‌ها + نکات مهم"

لطفاً فقط موضوع بهبود یافته را برگردانید، بدون هیچ توضیح اضافه.`
        },
        {
          role: 'user',
          content: topic
        }
      ]
    });

    const improvedTopic = response.choices[0]?.message?.content;
    if (!improvedTopic) {
      throw new Error(isEnglish ? 'Error improving topic' : 'خطا در بهبود موضوع');
    }

    return improvedTopic;

  } catch (error) {
    console.error('Topic improvement error:', error);
    throw error instanceof Error ? error : new Error(isEnglish ? 'Error improving topic' : 'خطا در بهبود موضوع');
  }
}