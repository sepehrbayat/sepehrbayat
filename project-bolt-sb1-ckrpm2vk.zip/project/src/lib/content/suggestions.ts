import { openai, openaiPro, MODELS } from '../openai';
import { validateTopic } from './validation';
import { isEnglishUI } from '../i18n/languageManager';

interface HeadingSet {
  id: string;
  title: string;
  headings: Array<{
    title: string;
    level: number;
    children?: Array<{
      title: string;
      level: number;
      children?: Array<{
        title: string;
        level: number;
      }>;
    }>;
  }>;
}

interface HeadingSet {
  id: string;
  headings: Array<{
    title: string;
    level: number;
  }>;
}

export async function suggestKeywords(topic: string, isPro: boolean = false): Promise<string[]> {
  try {
    const isEnglish = isEnglishUI();
    
    const { isValid, suggestions } = validateTopic(topic);
    
    if (!isValid) {
      throw new Error(suggestions[0]);
    }

    // Use appropriate client and model based on content type
    const client = isPro && openaiPro ? openaiPro : openai;
    const model = isPro ? MODELS.pro : MODELS.default;

    const response = await client.chat.completions.create({
      model,
      temperature: 0.7,
      presence_penalty: 0.4,
      frequency_penalty: 0.4,
      messages: [
        {
          role: 'system',
          content: isPro ? 
            `شما یک متخصص سئو و تولید محتوا هستید. لطفاً برای موضوع داده شده، 5 کلمه کلیدی مرتبط و پرکاربرد پیشنهاد دهید.

نکات مهم:
1. کلمات کلیدی باید مرتبط با موضوع باشند
2. از کلمات پرجستجو استفاده کنید
3. از عبارات کوتاه (1 تا 3 کلمه) استفاده کنید
4. کلمات باید فارسی باشند

لطفاً فقط کلمات کلیدی را در قالب آرایه JSON برگردانید. مثال:
["کلمه کلیدی 1", "کلمه کلیدی 2", "کلمه کلیدی 3"]` :
            `You are an SEO and content expert. Please suggest 5 relevant keywords for the given topic.

Important notes:
1. Keywords must be relevant to the topic
2. Use high-search-volume keywords
3. Use short phrases (1-3 words)
4. Return keywords in English ONLY

Please return only the keywords in JSON array format. Example:
["keyword 1", "keyword 2", "keyword 3"]`
        },
        {
          role: 'user',
          content: topic
        }
      ]
    });

    let suggestedKeywords;
    try {
      // Handle OpenAI response format for Pro version
      const content = isPro ? response.choices[0]?.message?.content :
                     response.data?.choices?.[0]?.message?.content;

      if (!content) {
        throw new Error(isEnglish ? 'No response received' : 'پاسخی از سرور دریافت نشد');
      }
      
      // Find JSON array in response
      const match = content.match(/\[[\s\S]*\]/);
      if (!match) {
        throw new Error(isEnglish ? 'Invalid response format' : 'فرمت پاسخ نامعتبر است');
      }
      
      suggestedKeywords = JSON.parse(match[0]);
    } catch (parseError) {
      console.error('Error parsing keywords:', parseError);
      throw new Error(isEnglish ? 'Error processing suggestions' : 'خطا در پردازش پیشنهادات');
    }
    if (!Array.isArray(suggestedKeywords)) {
      throw new Error(isEnglish ? 'Invalid response format' : 'خطا در دریافت پیشنهادات');
    }

    return suggestedKeywords;

  } catch (error) {
    console.error('Error suggesting keywords:', error);
    throw error instanceof Error ? error : new Error(
      isEnglishUI() ? 'Error suggesting keywords' : 'خطا در پیشنهاد کلمات کلیدی'
    );
  }
}

interface HeadingSuggestion {
  title: string;
  level: number;
  id: string;
  parentId?: string;
}

export async function suggestHeadings(
  topic: string,
  parentId?: string,
  level: number = 2,
  isPro: boolean = false,
  openaiPro?: any
): Promise<HeadingSuggestion[]> {
  try {
    const isEnglish = isEnglishUI();
    
    if (!topic.trim()) {
      throw new Error(isEnglish ? 'Topic cannot be empty' : 'موضوع نمی‌تواند خالی باشد');
    }

    if (level > 4) {
      throw new Error(isEnglish ? 'Maximum heading level is H4' : 'حداکثر سطح سرتیتر H4 می‌باشد');
    }
    
    // Use appropriate client and model based on content type
    const client = isPro ? openaiPro : openai;
    const model = isPro ? MODELS.pro : MODELS.default;

    const response = await client.chat.completions.create({
      model,
      temperature: 0.7,
      messages: [
        {
          role: 'system',
          content: isPro ? 
            `شما یک متخصص ساختاردهی محتوا هستید. لطفاً سرتیترهای مناسب برای موضوع "${topic}" پیشنهاد دهید.

موقعیت فعلی: ${level === 2 ? 'نیاز به سرفصل‌های اصلی (H2)' : `نیاز به زیرعنوان‌های (H${level})`}

لطفاً خروجی را در قالب JSON با این ساختار برگردانید:
[{
  "title": "عنوان پیشنهادی",
  "level": ${level},
  "id": "unique-string",
  "parentId": ${parentId ? `"${parentId}"` : 'null'}
}]` :
            `You are a content structuring expert. Please suggest appropriate headings for the topic "${topic}".

Current position: ${level === 2 ? 'Need main sections (H2)' : `Need subsections (H${level})`}

Please return output in JSON format with this structure:
[{
  "title": "Suggested title",
  "level": ${level},
  "id": "unique-string",
  "parentId": ${parentId ? `"${parentId}"` : 'null'}
}]`
        },
        {
          role: 'user',
          content: topic
        }
      ]
    });

    const content = response.choices[0]?.message?.content;
    if (!content) {
      throw new Error(isEnglish ? 'No response received from server' : 'پاسخی از سرور دریافت نشد');
    }

    let suggestions;
    try {
      // Try to parse the entire response first
      try {
        suggestions = JSON.parse(content);
      } catch {
        // If that fails, try to find and parse just the JSON array
        const match = content.match(/\[[\s\S]*\]/);
        if (!match) {
          throw new Error(isEnglish ? 'Invalid response format' : 'فرمت پاسخ نامعتبر است');
        }
        suggestions = JSON.parse(match[0]);
      }
    } catch (parseError) {
      console.error('JSON parse error:', parseError);
      throw new Error(isEnglish ? 'Error processing server response' : 'خطا در پردازش پاسخ سرور');
    }

    if (!Array.isArray(suggestions)) {
      throw new Error(isEnglish ? 'Invalid response structure' : 'ساختار پاسخ نامعتبر است');
    }

    // Process suggestions
    const processedSuggestions = suggestions.map(suggestion => ({
      ...suggestion,
      id: suggestion.id || Math.random().toString(36).substr(2, 9),
      level: suggestion.level || level,
      parentId: suggestion.parentId || parentId
    }));
    
    return processedSuggestions;

  } catch (error) {
    console.error('Error suggesting headings:', error);
    throw error instanceof Error ? error : new Error(isEnglish ? 'Error suggesting headings' : 'خطا در پیشنهاد سرتیترها');
  }
}