/**
 * Common Persian/Arabic heading patterns to convert to HTML
 */
export const HEADING_PATTERNS = [
  // Persian/Arabic section markers
  {
    regex: /^بخش\s+(\d+|[۰-۹]+)[:\s]+(.+)$/gm,
    level: 2
  },
  {
    regex: /^فصل\s+(\d+|[۰-۹]+)[:\s]+(.+)$/gm,
    level: 2
  },
  {
    regex: /^قسمت\s+(\d+|[۰-۹]+)[:\s]+(.+)$/gm,
    level: 3
  },
  {
    regex: /^زیربخش\s+(\d+|[۰-۹]+)[:\s]+(.+)$/gm,
    level: 3
  },
  {
    regex: /^مبحث\s+(\d+|[۰-۹]+)[:\s]+(.+)$/gm,
    level: 3
  },
  {
    regex: /^گفتار\s+(\d+|[۰-۹]+)[:\s]+(.+)$/gm,
    level: 4
  },
  // Numbered sections
  {
    regex: /^(\d+|[۰-۹]+)[.\s]+(.+)$/gm,
    level: 2
  },
  {
    regex: /^(\d+|[۰-۹]+)\.(\d+|[۰-۹]+)[.\s]+(.+)$/gm,
    level: 3
  },
  {
    regex: /^(\d+|[۰-۹]+)\.(\d+|[۰-۹]+)\.(\d+|[۰-۹]+)[.\s]+(.+)$/gm,
    level: 4
  },
  // Common heading markers
  {
    regex: /^مقدمه[:\s]+(.+)$/gm,
    level: 2
  },
  {
    regex: /^نتیجه[‌\s]?گیری[:\s]+(.+)$/gm,
    level: 2
  },
  {
    regex: /^جمع[‌\s]?بندی[:\s]+(.+)$/gm,
    level: 2
  }
];