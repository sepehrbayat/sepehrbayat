import { jsonrepair } from 'jsonrepair';
import JSON5 from 'json5';
import type { ScriptScene } from '../../../components/script/types';

interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

interface ParseResult<T> {
  data: T | null;
  error: string | null;
  parseAttempts: number;
  cleanupApplied: boolean;
}

export class JSONParser {
  /**
   * Main parsing function that attempts multiple strategies
   */
  static parse<T>(content: string): ParseResult<T> {
    const result: ParseResult<T> = {
      data: null,
      error: null,
      parseAttempts: 0,
      cleanupApplied: false
    };

    try {
      // Strategy 1: Direct JSON.parse
      try {
        result.parseAttempts++;
        result.data = JSON.parse(content);
        return result;
      } catch (e) {
        console.warn('Direct JSON parsing failed, trying cleanup...');
      }

      // Strategy 2: Clean and repair JSON
      try {
        result.parseAttempts++;
        result.cleanupApplied = true;
        const cleaned = this.cleanupJSON(content);
        const repaired = jsonrepair(cleaned);
        result.data = JSON.parse(repaired);
        return result;
      } catch (e) {
        console.warn('JSON repair failed, trying JSON5...');
      }

      // Strategy 3: Try JSON5 parsing
      try {
        result.parseAttempts++;
        result.data = JSON5.parse(content);
        return result;
      } catch (e) {
        console.warn('JSON5 parsing failed, trying structure extraction...');
      }

      // Strategy 4: Extract and parse JSON-like structure
      const extracted = this.extractJSONStructure(content);
      if (extracted) {
        result.parseAttempts++;
        result.cleanupApplied = true;
        result.data = JSON.parse(extracted);
        return result;
      }

      result.error = 'Failed to parse JSON with all available strategies';
      return result;

    } catch (error) {
      result.error = error instanceof Error ? error.message : 'Unknown parsing error';
      return result;
    }
  }

  /**
   * Cleanup malformed JSON string
   */
  private static cleanupJSON(content: string): string {
    return content
      // Remove zero-width and control characters
      .replace(/[\u200B-\u200D\uFEFF]/g, '')
      // Remove Arabic diacritics
      .replace(/[\u064B-\u065F]/g, '')
      // Replace Persian/Arabic punctuation
      .replace(/[«»]/g, '"')
      .replace(/[،؛]/g, ',')
      // Fix common JSON structure issues
      .replace(/([{,])\s*(['"])?(\w+)(['"])?\s*:/g, '$1"$3":')
      .replace(/:\s*(['"])(.*?)(['"])\s*([,}])/g, ':"$2"$4')
      .replace(/,\s*([}\]])/g, '$1')
      .replace(/\[\s*,/g, '[')
      .replace(/,\s*\]/g, ']')
      .replace(/"{2,}/g, '"')
      .trim();
  }

  /**
   * Extract JSON-like structure from text
   */
  private static extractJSONStructure(content: string): string | null {
    const matches = content.match(/\{(?:[^{}]|{[^{}]*})*\}/g);
    if (!matches) return null;

    // Sort by length to get the largest JSON-like structure
    const sortedMatches = matches.sort((a, b) => b.length - a.length);
    return sortedMatches[0];
  }

  /**
   * Validate scene object structure
   */
  static validateScene(scene: any): ValidationResult {
    const errors: string[] = [];

    // Required fields
    const requiredFields = {
      id: 'شناسه',
      title: 'عنوان',
      description: 'توضیحات',
      duration: 'مدت زمان',
      storyboard: 'استوری‌بورد'
    };

    // Check required fields
    Object.entries(requiredFields).forEach(([field, label]) => {
      if (!scene[field]?.toString().trim()) {
        errors.push(`فیلد ${label} الزامی است`);
      }
    });

    // Validate arrays
    const arrayFields = {
      dialogues: 'دیالوگ‌ها',
      cameraAngles: 'زوایای دوربین',
      notes: 'نکات'
    };

    Object.entries(arrayFields).forEach(([field, label]) => {
      if (scene[field] && !Array.isArray(scene[field])) {
        errors.push(`${label} باید به صورت آرایه باشد`);
      }
    });

    // Validate field lengths
    const maxLengths = {
      title: 100,
      description: 1000,
      storyboard: 2000
    };

    Object.entries(maxLengths).forEach(([field, maxLength]) => {
      if (scene[field] && scene[field].length > maxLength) {
        errors.push(`طول ${requiredFields[field]} نباید بیشتر از ${maxLength} کاراکتر باشد`);
      }
    });

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  /**
   * Sanitize scene data
   */
  static sanitizeScene(scene: any, index: number): ScriptScene {
    return {
      id: scene.id?.toString() || `scene-${index + 1}`,
      title: scene.title?.toString() || 'بدون عنوان',
      description: scene.description?.toString() || '',
      duration: scene.duration?.toString() || '30 ثانیه',
      storyboard: scene.storyboard?.toString() || '',
      dialogues: Array.isArray(scene.dialogues) 
        ? scene.dialogues.map(d => d?.toString() || '').filter(Boolean)
        : [],
      cameraAngles: Array.isArray(scene.cameraAngles)
        ? scene.cameraAngles.map(a => a?.toString() || '').filter(Boolean)
        : [],
      notes: Array.isArray(scene.notes)
        ? scene.notes.map(n => n?.toString() || '').filter(Boolean)
        : []
    };
  }

  /**
   * Sanitize recommendations
   */
  static sanitizeRecommendations(recommendations: any) {
    const defaultRecommendations = {
      technical: [],
      creative: [],
      production: []
    };

    if (!recommendations || typeof recommendations !== 'object') {
      return defaultRecommendations;
    }

    return {
      technical: Array.isArray(recommendations.technical)
        ? recommendations.technical.map(t => t?.toString() || '').filter(Boolean)
        : defaultRecommendations.technical,
      creative: Array.isArray(recommendations.creative)
        ? recommendations.creative.map(c => c?.toString() || '').filter(Boolean)
        : defaultRecommendations.creative,
      production: Array.isArray(recommendations.production)
        ? recommendations.production.map(p => p?.toString() || '').filter(Boolean)
        : defaultRecommendations.production
    };
  }
}