import { createChatCompletion } from './chat';

// Export all API endpoints
export const api = {
  chat: {
    completions: {
      create: createChatCompletion
    }
  }
};