import { openai } from '../openai';
import { supabase } from '../supabase';

// Secure API endpoint for chat completions
export async function createChatCompletion(params: any) {
  try {
    // Get authenticated user
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      throw new Error('خطای احراز هویت');
    }

    // Rate limiting check
    const { data: recentRequests, error: rateError } = await supabase
      .from('user_activity')
      .select('created_at')
      .eq('user_id', user.id)
      .eq('type', 'chat')
      .gte('created_at', new Date(Date.now() - 60000).toISOString()) // Last minute
      .order('created_at', { ascending: false });

    if (rateError) throw rateError;
    
    if (recentRequests && recentRequests.length >= 5) {
      throw new Error('محدودیت تعداد درخواست. لطفاً یک دقیقه صبر کنید');
    }

    // Make API request to OpenAI
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: params.messages,
      temperature: params.temperature || 0.7,
      max_tokens: params.max_tokens || 1500,
      presence_penalty: params.presence_penalty || 0,
      frequency_penalty: params.frequency_penalty || 0
    });

    // Track activity
    await supabase.from('user_activity').insert({
      user_id: user.id,
      type: 'chat',
      content: {
        messages: params.messages,
        response: completion
      }
    });

    return completion;

  } catch (error) {
    console.error('Chat completion error:', error);
    throw error;
  }
}