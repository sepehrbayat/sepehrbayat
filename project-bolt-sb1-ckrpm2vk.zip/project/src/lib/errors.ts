// Base error classes
export class ValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ValidationError';
  }

  toJSON() {
    return {
      name: this.name,
      message: this.message
    };
  }
}

export class RetryableError extends Error {
  constructor(
    public readonly code: string,
    message?: string
  ) {
    super(message || 'خطای قابل تلاش مجدد');
    this.name = 'RetryableError';
  }

  toJSON() {
    return {
      name: this.name,
      code: this.code,
      message: this.message
    };
  }

  toJSON() {
    return {
      name: this.name,
      code: this.code,
      message: this.message
    };
  }
}

export class APIError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly status?: number
  ) {
    super(message);
    this.name = 'APIError';
  }

  toJSON() {
    return {
      name: this.name,
      code: this.code,
      message: this.message,
      status: this.status
    };
  }
}

export class TimeoutError extends Error {
  constructor(message: string = 'زمان عملیات به پایان رسید') {
    super(message);
    this.name = 'TimeoutError';
  }

  toJSON() {
    return {
      name: this.name,
      message: this.message
    };
  }
}

export function isRetryableError(error: any): boolean {
  // Network errors are generally retryable
  if (error instanceof TypeError && error.message.includes('fetch')) {
    return true;
  }

  // Timeout errors are retryable
  if (error instanceof TimeoutError || error.name === 'AbortError') {
    return true;
  }

  // API errors with certain status codes are retryable
  if (error instanceof APIError && error.status) {
    return [429, 503, 504].includes(error.status);
  }

  // Explicit RetryableError instances
  if (error instanceof RetryableError) {
    return true;
  }

  return false;
}