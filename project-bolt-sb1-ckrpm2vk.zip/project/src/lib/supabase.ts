import { createClient } from '@supabase/supabase-js';
import type { Database } from './database.types';

const supabaseUrl = 'https://zqduvqgiheyhuazybziz.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpxZHV2cWdpaGV5aHVhenlieml6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDA0ODgzODEsImV4cCI6MjA1NjA2NDM4MX0.orzJScfA7WQFyNQpGMPmmZSRgMdRjjL8JqqHiS02oAw';

// Initialize the Supabase client
export const supabase = createClient<Database>(
  supabaseUrl,
  supabaseAnonKey,
  {
    auth: {
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: true
    }
  }
);