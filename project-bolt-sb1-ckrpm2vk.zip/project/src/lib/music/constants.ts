export const MUSIC_CONFIG = {
  maxRetries: 3,
  requestTimeout: 60000,
  maxConcurrentRequests: 3,
  defaultSampleRate: 32000,
  defaultTokenLimit: 512,
  maxTokenLimit: 1024,
  minTokenLimit: 256,
  maxSampleRate: 32000,
  minSampleRate: 10000
} as const;

export const ERROR_CODES = {
  TIMEOUT: 'TIMEOUT',
  NETWORK: 'NETWORK',
  API: 'API',
  VALIDATION: 'VALIDATION',
  UNKNOWN: 'UNKNOWN'
} as const;

export const ERROR_MESSAGES = {
  [ERROR_CODES.TIMEOUT]: 'زمان درخواست به پایان رسید',
  [ERROR_CODES.NETWORK]: 'خطا در ارتباط با سرور',
  [ERROR_CODES.API]: 'خطا در سرویس تولید موسیقی',
  [ERROR_CODES.VALIDATION]: 'پارامترهای ورودی نامعتبر هستند',
  [ERROR_CODES.UNKNOWN]: 'خطای ناشناخته'
} as const;