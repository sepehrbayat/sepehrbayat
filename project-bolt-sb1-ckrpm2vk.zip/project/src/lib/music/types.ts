export interface MusicGenerationOptions {
  key: string;
  prompt: string;
  referenceAudio?: string;
  sampleRate?: number;
  tokenLimit?: number;
  base64?: boolean;
  tempLinks?: boolean;
  webhookUrl?: string;
  trackId?: number;
}

export interface MusicGenerationResponse {
  status: string;
  generationTime: number;
  id: number;
  fetch_result?: string;
  eta?: number;
  tip?: string;
  error?: {
    message: string;
    code?: string;
  };
  output: string[];
  proxy_links: string[];
  future_links?: string[];
  meta: {
    prompt: string;
    sample_rate: number;
    token_limit: number;
    base64: boolean;
    temp_links: boolean;
    webhook_url?: string;
    track_id?: number;
  };
}

export interface MusicGenerationProgress {
  status: 'pending' | 'processing' | 'completed' | 'failed';
  progress: number;
  message: string;
  error?: {
    code: string;
    message: string;
  };
}

export interface MusicGenerationError {
  code: string;
  message: string;
  details?: any;
  retryable: boolean;
}