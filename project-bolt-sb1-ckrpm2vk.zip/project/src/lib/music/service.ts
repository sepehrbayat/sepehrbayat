import { MUSIC_CONFIG } from './constants';
import { MusicGenerationError, RetryableError } from './errors';
import { validateMusicOptions } from './validation';
import type { 
  MusicGenerationOptions,
  MusicGenerationResponse,
  MusicGenerationProgress
} from './types';

export async function generateMusic(options: MusicGenerationOptions): Promise<MusicGenerationResponse> {
  try {
    // Validate input options
    validateMusicOptions(options);
    
    let retryCount = 0;
    const maxRetries = 3;
    let lastError: Error | null = null;

    // Set default values
    const requestOptions = {
      key: options.key,
      prompt: options.prompt,
      init_audio: options.referenceAudio,
      sample_rate: options.sampleRate || MUSIC_CONFIG.defaultSampleRate,
      max_new_token: options.tokenLimit || MUSIC_CONFIG.defaultTokenLimit,
      base64: options.base64 || false,
      temp: options.tempLinks || false,
      webhook_url: options.webhookUrl,
      track_id: options.trackId,
    };

    while (retryCount < maxRetries) {
      try {
        // Add exponential backoff delay with jitter
        if (retryCount > 0) {
          const delay = Math.min(1000 * Math.pow(2, retryCount - 1), 10000);
          const jitter = Math.random() * 1000;
          console.log(`Retrying request (${retryCount + 1}/${maxRetries}) after ${delay + jitter}ms delay`);
          await new Promise(resolve => setTimeout(resolve, delay + jitter));
        }

        retryCount++;

        // Add timeout to the request
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), MUSIC_CONFIG.requestTimeout);

        try {
          console.log('Making music generation request:', {
            attempt: retryCount,
            timestamp: new Date().toISOString()
          });

          const response = await fetch("https://modelslab.com/api/v6/voice/music_gen", {
            method: 'POST',
            signal: controller.signal,
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestOptions)
          });

          if (!response.ok) {
            throw new Error(
              `Server responded with ${response.status}: ${await response.text()}`
            );
          }

          const data = await response.json();

          // Handle specific error cases
          if (response.status === 429) {
            throw new RetryableError('API', 'محدودیت تعداد درخواست. لطفاً کمی صبر کنید');
          }
          if (response.status >= 500) {
            throw new RetryableError('API', 'خطای سرور. لطفاً دوباره تلاش کنید');
          }
          if (response.status === 401) {
            throw new MusicGenerationError('API', 'خطای احراز هویت API');
          }

          if (!data || data.status !== 'success') {
            console.warn('Invalid API response:', {
              status: data?.status,
              error: data?.error,
              timestamp: new Date().toISOString()
            });

            const errorMessage = data?.error?.message || 'خطا در تولید موسیقی';
            throw new RetryableError('API', errorMessage);
          }

          // Handle processing status
          if (data.status === 'processing' && data.fetch_result) {
            return {
              status: 'processing',
              fetch_result: data.fetch_result,
              eta: data.eta || 60,
              tip: data.tip || 'در حال پردازش موسیقی...',
              id: data.id,
              output: [],
              proxy_links: [],
              meta: data.meta || {}
            };
          }

          if (!Array.isArray(data.output) || data.output.length === 0) {
            throw new RetryableError('API', 'خطا در دریافت خروجی');
          }

          return data;

        } catch (error) {
          lastError = error;
          if (error.name === 'AbortError') {
            throw new RetryableError('TIMEOUT', 'زمان درخواست به پایان رسید');
          }

          if (error instanceof TypeError && error.message.includes('fetch')) {
            throw new RetryableError('NETWORK', 'خطا در ارتباط با سرور');
          }

          throw error;
        } finally {
          clearTimeout(timeout);
        }
      } catch (error) {
        if (!isRetryableError(error) || retryCount === maxRetries) {
          throw error;
        }
        lastError = error;
      }
    }

    throw lastError || new MusicGenerationError('API', 'تعداد تلاش‌های مجدد به پایان رسید');

  } catch (error) {
    console.error('Music generation error:', error);
    
    if (error instanceof MusicGenerationError || error instanceof RetryableError) {
      throw error;
    }

    // Enhance error details for better debugging
    const errorDetails = {
      originalError: error,
      timestamp: new Date().toISOString(),
      requestOptions: { ...requestOptions, key: '***' } // Hide API key
    };

    throw new RetryableError(
      'UNKNOWN',
      error instanceof Error ? error.message : 'خطا در تولید موسیقی',
      errorDetails
    );
  }
}

// Create and export singleton instance
export const musicService = {
  generateMusic
};