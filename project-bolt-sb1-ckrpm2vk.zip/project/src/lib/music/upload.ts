import { MusicGenerationError } from './errors';

export interface UploadResponse {
  url: string;
  error?: string;
  status: 'success' | 'error';
}

export async function uploadAudioFile(file: File): Promise<UploadResponse> {
  try {
    // Validate file type
    if (!file.type.startsWith('audio/')) {
      return {
        status: 'error',
        url: '',
        error: 'لطفاً فقط فایل صوتی آپلود کنید'
      };
    }
    
    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      return {
        status: 'error',
        url: '',
        error: 'حجم فایل نباید بیشتر از 10 مگابایت باشد'
      };
    }

    // Create FormData
    const formData = new FormData();
    formData.append('file', file);
    formData.append('key', "DIT0j1BOjKT9OSLc5d2dnHYpTqrNjhXVxGba5toE6Z5pWJiVM2uDbYdHpr2r");

    // Make request with timeout
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000); // 30s timeout

    try {
      const response = await fetch('https://modelslab.com/api/v6/upload', {
        method: 'POST',
        body: formData,
        signal: controller.signal
      });

      const responseData = await response.json().catch(() => null);

      if (!response.ok) {
        return {
          status: 'error',
          url: '',
          error: response.status === 413 ? 'حجم فایل بیش از حد مجاز است' :
                 response.status === 429 ? 'تعداد درخواست‌ها بیش از حد مجاز است' :
                 response.status === 401 ? 'خطای احراز هویت' :
                 response.status >= 500 ? 'خطای سرور. لطفاً دوباره تلاش کنید' :
                 responseData?.error?.message || 'خطا در آپلود فایل'
        };
      }

      if (!responseData?.url) {
        return {
          status: 'error',
          url: '',
          error: 'خطا در دریافت لینک فایل'
        };
      }

      return {
        status: 'success',
        url: responseData.url
      };

    } catch (error) {
      if (error.name === 'AbortError') {
        return {
          status: 'error',
          url: '',
          error: 'زمان آپلود به پایان رسید'
        };
      }
      return {
        status: 'error',
        url: '',
        error: error instanceof Error ? error.message : 'خطا در آپلود فایل'
      };
    } finally {
      clearTimeout(timeout);
    }

  } catch (error) {
    console.error('Upload error:', error);
    return {
      status: 'error',
      url: '',
      error: error instanceof Error ? error.message : 'خطا در آپلود فایل'
    };
  }
}