// Re-export all music-related functionality
export * from './types';
export * from './service';
export * from './constants';
export * from './errors';
export * from './validation';

// Export singleton instance
export { musicService } from './service';