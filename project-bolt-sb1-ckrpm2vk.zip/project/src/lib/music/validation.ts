import { MusicGenerationError } from './errors';
import { MUSIC_CONFIG } from './constants';
import type { MusicGenerationOptions } from './types';

export function validateMusicOptions(options: MusicGenerationOptions): void {
  // Validate required fields
  if (!options.key?.trim()) {
    throw new MusicGenerationError('VALIDATION', 'API key نمی‌تواند خالی باشد');
  }

  if (!options.prompt?.trim()) {
    throw new MusicGenerationError('VALIDATION', 'پرامپت نمی‌تواند خالی باشد');
  }

  // Validate sample rate
  if (options.sampleRate !== undefined) {
    if (!Number.isInteger(options.sampleRate)) {
      throw new MusicGenerationError('VALIDATION', 'نرخ نمونه‌برداری باید عدد صحیح باشد');
    }
    if (options.sampleRate < MUSIC_CONFIG.minSampleRate || options.sampleRate > MUSIC_CONFIG.maxSampleRate) {
      throw new MusicGenerationError(
        'VALIDATION',
        `نرخ نمونه‌برداری باید بین ${MUSIC_CONFIG.minSampleRate} و ${MUSIC_CONFIG.maxSampleRate} باشد`
      );
    }
  }

  // Validate token limit
  if (options.tokenLimit !== undefined) {
    if (!Number.isInteger(options.tokenLimit)) {
      throw new MusicGenerationError('VALIDATION', 'محدودیت توکن باید عدد صحیح باشد');
    }
    if (options.tokenLimit < MUSIC_CONFIG.minTokenLimit || options.tokenLimit > MUSIC_CONFIG.maxTokenLimit) {
      throw new MusicGenerationError(
        'VALIDATION',
        `محدودیت توکن باید بین ${MUSIC_CONFIG.minTokenLimit} و ${MUSIC_CONFIG.maxTokenLimit} باشد`
      );
    }
  }

  // Validate reference audio URL if provided
  if (options.referenceAudio) {
    try {
      new URL(options.referenceAudio);
    } catch {
      throw new MusicGenerationError('VALIDATION', 'آدرس فایل صوتی مرجع نامعتبر است');
    }
  }

  // Validate webhook URL if provided
  if (options.webhookUrl) {
    try {
      new URL(options.webhookUrl);
    } catch {
      throw new MusicGenerationError('VALIDATION', 'آدرس webhook نامعتبر است');
    }
  }

  // Validate track ID if provided
  if (options.trackId !== undefined && !Number.isInteger(options.trackId)) {
    throw new MusicGenerationError('VALIDATION', 'شناسه قطعه باید عدد صحیح باشد');
  }
}