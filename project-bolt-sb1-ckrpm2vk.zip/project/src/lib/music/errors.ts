import { ERROR_CODES, ERROR_MESSAGES } from './constants';

export class MusicGenerationError extends Error {
  constructor(
    public readonly code: keyof typeof ERROR_CODES,
    message?: string,
    public readonly details?: any,
    public readonly retryable: boolean = false
  ) {
    super(message || ERROR_MESSAGES[code]);
    this.name = 'MusicGenerationError';
  }

  toJSON() {
    return {
      name: this.name,
      code: this.code,
      message: this.message,
      details: this.details,
      retryable: this.retryable
    };
  }
}

export class RetryableError extends MusicGenerationError {
  constructor(code: keyof typeof ERROR_CODES, message?: string, details?: any) {
    super(code, message, details, true);
    this.name = 'RetryableError';
  }
}

export function isRetryableError(error: any): boolean {
  if (error instanceof RetryableError) return true;
  if (error instanceof MusicGenerationError) return error.retryable;
  
  // Network errors are generally retryable
  if (error instanceof TypeError && error.message.includes('fetch')) {
    return true;
  }
  
  // Timeout errors are retryable
  if (error.name === 'AbortError' || error.message.includes('timeout')) {
    return true;
  }
  
  // API errors with no content are retryable
  if (error.message.includes('API_NO_CONTENT') || error.message.includes('پاسخ دریافتی ناقص است')) {
    return true;
  }
  
  // Rate limit errors are retryable
  if (error.message.includes('rate limit')) {
    return true;
  }
  
  return false;
}