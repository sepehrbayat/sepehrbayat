import { openai, DEFAULT_MODEL } from '../openai';
import i18n from '../i18n/index';
import type { SEOMetric } from './types';

export async function getAISuggestions(metric: SEOMetric): Promise<string[]> {
  try {
    const response = await openai.chat.completions.create({
      model: DEFAULT_MODEL,
      temperature: 0.5,
      max_tokens: 1500,
      presence_penalty: 0.2,
      frequency_penalty: 0.3,
      messages: [
        {
          role: 'system',
          content: `You are an SEO and web optimization expert. Please provide practical and technical suggestions to improve this metric.

Language: ${i18n.language}

Rules for suggestions:
1. Each suggestion must be practical and actionable
2. Use technical terms with explanations
3. Prioritize recommendations
4. Consider technical limitations and resources
5. Provide practical examples

Please return the response in JSON format with this structure:
{
  "suggestions": ["suggestion 1", "suggestion 2", "suggestion 3"],
  "priority": "high" | "medium" | "low",
  "impact": "explanation of metric improvement impact"
}`
        },
        {
          role: 'user',
          content: `Metric: ${metric.name}
Current Value: ${metric.value}
Status: ${metric.status}
Description: ${metric.description}

Additional Information:
${JSON.stringify(metric.context, null, 2)}

Please provide practical and technical solutions to improve this metric.`
        }
      ]
    });

    let suggestions: string[];
    try {
      const content = response.choices[0]?.message?.content;
      if (!content) {
        throw new Error('پاسخی از سرور دریافت نشد');
      }

      // Simpler parsing approach
      suggestions = content
        .split('\n')
        .filter(line => line.trim())
        .map(line => line.replace(/^\d+\.\s*/, '').trim())
        .filter(line => line.length > 10);

    } catch (parseError) {
      console.error('JSON parse error:', parseError);
      throw new Error('خطا در پردازش پیشنهادات');
    }

    if (!suggestions || suggestions.length === 0) {
      throw new Error('پیشنهادی یافت نشد');
    }

    return suggestions;

  } catch (error) {
    console.error('Error getting AI suggestions:', error);
    // More informative error logging
    if (error instanceof Error) {
      console.error('Error details:', {
        name: error.name,
        message: error.message,
        stack: error.stack
      });
    }
    
    return i18n.language === 'fa' 
      ? [
          'متأسفانه در حال حاضر پیشنهادی یافت نشد.',
          'لطفاً چند لحظه دیگر دوباره تلاش کنید.',
          'اگر مشکل ادامه داشت، با پشتیبانی تماس بگیرید.'
        ]
      : [
          'No suggestions available at the moment.',
          'Please try again in a few moments.',
          'If the problem persists, please contact support.'
        ];
  }
}