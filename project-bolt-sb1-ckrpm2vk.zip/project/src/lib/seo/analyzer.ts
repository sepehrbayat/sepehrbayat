export interface SEOAnalysis {
  metaTags: {
    title: string | null;
    description: string | null;
    keywords: string[] | null;
    robots: string | null;
    ogTags: Record<string, string>;
  };
  headers: {
    h1Count: number;
    h2Count: number;
    h3Count: number;
    headerStructure: string[];
  };
  content: {
    wordCount: number;
    readabilityScore: number;
    textToHtmlRatio: number;
    uniqueWords: number;
    paragraphCount: number;
    sentenceCount: number;
    averageSentenceLength: number;
    readingTime: number;
    topicCoverage: number;
    semanticRelevance: number;
    contentQualityScore: number;
    duplicateContent: {
      percentage: number;
      sources: string[];
    };
    keywordDensity: Record<string, number>;
    keywordContext: Record<string, {
      density: number;
      locations: string[];
      prominence: number;
    }>;
    semanticKeywords: string[];
    entityAnalysis: Array<{
      type: string;
      name: string;
      mentions: number;
      sentiment: number;
    }>;
    internalLinks: number;
    externalLinks: number;
    outboundQuality: number;
    linkDistribution: {
      header: number;
      content: number;
      footer: number;
    };
    linkTypes: {
      dofollow: number;
      nofollow: number;
      sponsored: number;
      ugc: number;
    };
    brokenLinks: string[];
  };
  images: {
    total: number;
    withAlt: number;
    withLazyLoading: number;
    withWebp: number;
    withOptimizedSize: number;
    totalSize: number;
    averageSize: number;
    compressionPotential: number;
    withoutAlt: string[];
    largeImages: string[];
    unoptimizedImages: string[];
  };
  technical: {
    hasRobotsTxt: boolean;
    hasSitemap: boolean;
    isResponsive: boolean;
    hasAmp: boolean;
    hasSchema: boolean;
    schemaTypes: string[];
    canonicalTags: {
      present: boolean;
      valid: boolean;
      conflicts: boolean;
    };
    hreflang: {
      present: boolean;
      valid: boolean;
      languages: string[];
    };
    security: {
      https: boolean;
      mixedContent: boolean;
      securityHeaders: Record<string, boolean>;
      sslCertificate: {
        valid: boolean;
        expiry: string;
      };
    };
    performance: {
      caching: {
        enabled: boolean;
        headers: boolean;
        browserCaching: boolean;
      };
      compression: {
        enabled: boolean;
        gzip: boolean;
        brotli: boolean;
      };
      minification: {
        html: boolean;
        css: boolean;
        js: boolean;
      };
    };
    mobile: {
      viewport: boolean;
      touchTargets: boolean;
      fontSizes: boolean;
      tapTargetSize: boolean;
    };
    loadTime: number;
    sslCertificate: boolean;
  };
  social: {
    openGraph: {
      present: boolean;
      title: string;
      description: string;
      image: string;
    };
    twitter: {
      present: boolean;
      card: string;
      title: string;
      description: string;
      image: string;
    };
    schema: {
      present: boolean;
      types: string[];
      errors: string[];
    };
  };
  competition: {
    similarPages: Array<{
      url: string;
      overlap: number;
      strength: number;
    }>;
    keywordCompetition: Record<string, {
      difficulty: number;
      volume: number;
      competitors: string[];
    }>;
  };
}

import i18n from '../i18n/index';

export async function analyzePage(url: string, device: 'desktop' | 'mobile' = 'desktop'): Promise<SEOAnalysis> {
  try {
    if (!url.startsWith('http')) {
      throw new Error(i18n.language === 'fa' 
        ? 'آدرس باید با http یا https شروع شود.'
        : 'URL must start with http or https.');
    }

    // Validate URL format
    try {
      new URL(url);
    } catch {
      throw new Error(i18n.language === 'fa'
        ? 'آدرس وارد شده معتبر نیست.'
        : 'Invalid URL format.');
    }

    // Use a proxy service to bypass CORS
    const proxyUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(url)}`;

    try {
      const response = await fetch(proxyUrl, {
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'Mozilla/5.0'
        }
      });
      
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error(i18n.language === 'fa'
            ? 'صفحه مورد نظر یافت نشد.'
            : 'Page not found.');
        }
        throw new Error(i18n.language === 'fa'
          ? 'خطا در دسترسی به سایت. لطفاً از صحت آدرس اطمینان حاصل کنید.'
          : 'Error accessing the site. Please verify the URL.');
      }
      
      const data = await response.json();
      
      if (!data.contents) {
        throw new Error(i18n.language === 'fa'
          ? 'محتوای صفحه خالی است. لطفاً آدرس را بررسی کنید.'
          : 'Page content is empty. Please check the URL.');
      }
      
      const parser = new DOMParser();
      const doc = parser.parseFromString(data.contents, 'text/html');
      
      // Validate parsed document
      if (!doc.body) {
        throw new Error('خطا در پردازش محتوای صفحه. لطفاً آدرس را بررسی کنید.');
      }

      // Rest of the analysis code...
      // Meta Tags Analysis
      const metaTags = {
        title: doc.title || null,
        description: doc.querySelector('meta[name="description"]')?.getAttribute('content') || null,
        keywords: doc.querySelector('meta[name="keywords"]')?.getAttribute('content')?.split(',') || null,
        robots: doc.querySelector('meta[name="robots"]')?.getAttribute('content') || null,
        ogTags: Array.from(doc.querySelectorAll('meta[property^="og:"]')).reduce((acc, meta) => {
          const property = meta.getAttribute('property')?.replace('og:', '');
          if (property) {
            acc[property] = meta.getAttribute('content') || '';
          }
          return acc;
        }, {} as Record<string, string>)
      };

      // Headers Analysis
      const headers = {
        h1Count: doc.querySelectorAll('h1').length,
        h2Count: doc.querySelectorAll('h2').length,
        h3Count: doc.querySelectorAll('h3').length,
        headerStructure: Array.from(doc.querySelectorAll('h1, h2, h3, h4, h5, h6')).map(h => h.tagName)
      };

      // Content Analysis
      const content = {
        wordCount: doc.body.textContent?.trim().split(/\s+/).length || 0,
        readabilityScore: calculateReadabilityScore(doc.body.textContent || ''),
        keywordDensity: analyzeKeywordDensity(doc.body.textContent || ''),
        internalLinks: doc.querySelectorAll('a[href^="/"], a[href^="' + url + '"]').length,
        externalLinks: doc.querySelectorAll('a[href^="http"]').length,
        brokenLinks: await checkBrokenLinks(Array.from(doc.querySelectorAll('a')).map(a => a.href))
      };

      // Image Analysis
      const images = doc.querySelectorAll('img');
      const imageAnalysis = {
        total: images.length,
        withAlt: Array.from(images).filter(img => img.hasAttribute('alt')).length,
        withoutAlt: Array.from(images).filter(img => !img.hasAttribute('alt')).map(img => img.src),
        largeImages: [],
        withLazyLoading: Array.from(images).filter(img => img.loading === 'lazy').length,
        withWebp: 0,
        withOptimizedSize: 0,
        totalSize: 0,
        averageSize: 0,
        compressionPotential: 0,
        unoptimizedImages: []
      };

      // Technical Analysis
      const technical = {
        hasRobotsTxt: await checkRobotsTxt(url),
        hasSitemap: await checkSitemap(url),
        isResponsive: checkResponsiveness(doc),
        loadTime: performance.now(),
        sslCertificate: url.startsWith('https'),
        hasAmp: !!doc.querySelector('link[rel="amphtml"]'),
        hasSchema: !!doc.querySelector('script[type="application/ld+json"]'),
        schemaTypes: Array.from(doc.querySelectorAll('script[type="application/ld+json"]'))
          .map(script => {
            try {
              const schema = JSON.parse(script.textContent || '');
              return schema['@type'];
            } catch {
              return null;
            }
          })
          .filter(Boolean),
        canonicalTags: {
          present: !!doc.querySelector('link[rel="canonical"]'),
          valid: true,
          conflicts: false
        },
        hreflang: {
          present: !!doc.querySelector('link[rel="alternate"][hreflang]'),
          valid: true,
          languages: Array.from(doc.querySelectorAll('link[rel="alternate"][hreflang]'))
            .map(link => link.getAttribute('hreflang'))
            .filter(Boolean) as string[]
        }
      };

      return {
        metaTags,
        headers,
        content,
        images: imageAnalysis,
        technical
      };

    } catch (fetchError) {
      console.error('Fetch error:', fetchError);
      throw new Error('خطا در دسترسی به سایت. لطفاً از صحت آدرس و اتصال اینترنت خود اطمینان حاصل کنید.');
    }
  } catch (error) {
    console.error('SEO analysis failed:', error);
    throw error instanceof Error ? error : new Error('خطای ناشناخته در تحلیل سئو. لطفاً دوباره تلاش کنید.');
  }
}

function calculateReadabilityScore(text: string): number {
  // Implement Flesch-Kincaid readability score or similar
  const sentences = text.split(/[.!?]+/).length;
  const words = text.trim().split(/\s+/).length;
  const syllables = countSyllables(text);
  
  return Math.round(206.835 - 1.015 * (words / sentences) - 84.6 * (syllables / words));
}

function countSyllables(text: string): number {
  // Basic syllable counting implementation
  return text.toLowerCase()
    .replace(/[^a-z]/g, '')
    .replace(/[^aeiouy]+/g, ' ')
    .trim()
    .split(' ')
    .length;
}

function analyzeKeywordDensity(text: string): Record<string, number> {
  const words = text.toLowerCase().trim().split(/\s+/);
  const wordCount = words.length;
  const density: Record<string, number> = {};

  words.forEach(word => {
    if (word.length > 3) { // Ignore short words
      density[word] = ((density[word] || 0) + 1) / wordCount * 100;
    }
  });

  return Object.fromEntries(
    Object.entries(density)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 10)
  );
}

async function checkBrokenLinks(urls: string[]): Promise<string[]> {
  const brokenLinks: string[] = [];
  
  // Only check first 10 links to avoid rate limiting
  for (const url of urls.slice(0, 10)) {
    try {
      const proxyUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(url)}`;
      const response = await fetch(proxyUrl);
      if (!response.ok) {
        brokenLinks.push(url);
      }
    } catch {
      brokenLinks.push(url);
    }
  }
  
  return brokenLinks;
}

async function checkRobotsTxt(url: string): Promise<boolean> {
  try {
    const baseUrl = new URL(url).origin;
    const proxyUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(`${baseUrl}/robots.txt`)}`;
    const response = await fetch(proxyUrl);
    return response.ok;
  } catch {
    return false;
  }
}

async function checkSitemap(url: string): Promise<boolean> {
  try {
    const baseUrl = new URL(url).origin;
    const proxyUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(`${baseUrl}/sitemap.xml`)}`;
    const response = await fetch(proxyUrl);
    return response.ok;
  } catch {
    return false;
  }
}

function checkResponsiveness(doc: Document): boolean {
  return !!doc.querySelector('meta[name="viewport"]');
}