export interface LighthouseReport {
  performance: number;
  accessibility: number;
  seo: number;
  bestPractices: number;
  progressiveWebApp: number;
  coreWebVitals: {
    lcp: number; // Largest Contentful Paint
    fid: number; // First Input Delay
    cls: number; // Cumulative Layout Shift
    inp: number; // Interaction to Next Paint
    tbt: number; // Total Blocking Time
  };
  metrics: {
    ttfb: number; // Time to First Byte
    firstContentfulPaint: number;
    firstMeaningfulPaint: number;
    speedIndex: number;
    timeToInteractive: number;
    totalBlockingTime: number;
    domContentLoaded: number;
    domSize: number;
    serverResponseTime: number;
    bootupTime: number;
    mainThreadWorkBreakdown: {
      scriptEvaluation: number;
      scriptParsing: number;
      styleLayout: number;
      painting: number;
      garbageCollection: number;
      other: number;
    };
    networkRtt: number;
    networkServerLatency: number;
    totalByteWeight: number;
    offscreenImages: number;
    unusedCssRules: number;
    unusedJavaScript: number;
    modernImageFormats: number;
    optimizedImages: number;
    responsiveImages: number;
    duplicatedJavaScript: number;
    legacyJavaScript: number;
    noDocumentWrite: boolean;
    timeToFirstByte: number;
    firstCpuIdle: number;
    maxPotentialFid: number;
    resourceSummary: {
      total: number;
      js: {
        count: number;
        size: number;
        transfer: number;
      };
      css: {
        count: number;
        size: number;
        transfer: number;
      };
      images: {
        count: number;
        size: number;
        transfer: number;
      };
      fonts: {
        count: number;
        size: number;
        transfer: number;
      };
      documents: {
        count: number;
        size: number;
        transfer: number;
      };
      other: {
        count: number;
        size: number;
        transfer: number;
      };
    };
    resourceSummary: {
      total: number;
      js: number;
      css: number;
      images: number;
      fonts: number;
      other: number;
    };
    thirdPartyUsage: {
      totalBytes: number;
      totalBlockingTime: number;
    };
    mainThreadWork: {
      scriptEvaluation: number;
      styleLayout: number;
      rendering: number;
      painting: number;
      other: number;
      bestPractices: string;
      seo: string;
      pwa: string;
    };
    security: {
      score: number;
      https: boolean;
      mixedContent: boolean;
      vulnerabilities: string[];
      certificate: {
        valid: boolean;
        issuer: string;
        expiryDate: string;
      };
    };
    accessibility: {
      score: number;
      issues: {
        critical: string[];
        serious: string[];
        moderate: string[];
        minor: string[];
      };
      elements: {
        total: number;
        passing: number;
        failing: number;
      };
    };
    bestPractices: {
      score: number;
      issues: string[];
      passing: string[];
    };
    pwa: {
      score: number;
      installable: boolean;
      optimized: boolean;
      features: {
        manifest: boolean;
        serviceWorker: boolean;
        offlineCapable: boolean;
        fastAndReliable: boolean;
        installable: boolean;
        optimized: boolean;
      };
    };
  };
  scores: {
    performance: string;
    accessibility: string;
    seo: string;
    bestPractices: string;
    progressiveWebApp: string;
  };
}

export async function runLighthouseAudit(url: string, device: 'desktop' | 'mobile' = 'desktop'): Promise<LighthouseReport> {
  try {
    // Simulate realistic Lighthouse metrics based on common ranges
    const generateScore = () => {
      // Mobile scores tend to be lower than desktop
      const baseScore = device === 'desktop' ? 75 : 65;
      const variance = device === 'desktop' ? 25 : 30;
      const score = Math.floor(Math.random() * variance) + baseScore;
      return {
        value: score,
        rating: score >= 90 ? 'عالی' : score >= 70 ? 'خوب' : score >= 50 ? 'متوسط' : 'ضعیف'
      };
    };

    const performance = generateScore();
    const accessibility = generateScore();
    const seo = generateScore();
    const progressiveWebApp = generateScore();
    const bestPractices = generateScore();

    // Generate realistic Core Web Vitals
    const coreWebVitals = {
      // LCP: Good < 2.5s, Needs Improvement < 4s, Poor > 4s
      lcp: device === 'desktop' 
        ? Math.floor(Math.random() * 1500) + 1000  // 1-2.5s for desktop
        : Math.floor(Math.random() * 2000) + 2000, // 2-4s for mobile

      // FID: Good < 100ms, Needs Improvement < 300ms, Poor > 300ms
      fid: device === 'desktop'
        ? Math.floor(Math.random() * 40) + 20      // 20-60ms for desktop
        : Math.floor(Math.random() * 100) + 50,    // 50-150ms for mobile

      // CLS: Good < 0.1, Needs Improvement < 0.25, Poor > 0.25
      cls: Number((Math.random() * 0.08 + 0.01).toFixed(3)),  // 0.01-0.09 for desktop
      
      // New metrics
      inp: device === 'desktop'
        ? Math.floor(Math.random() * 100) + 50    // 50-150ms for desktop
        : Math.floor(Math.random() * 150) + 100,  // 100-250ms for mobile
      
      tbt: device === 'desktop'
        ? Math.floor(Math.random() * 200) + 100   // 100-300ms for desktop
        : Math.floor(Math.random() * 300) + 200   // 200-500ms for mobile
    };

    // Generate realistic performance metrics
    const metrics = {
      ttfb: device === 'desktop'
        ? Math.floor(Math.random() * 200) + 100    // 100-300ms for desktop
        : Math.floor(Math.random() * 400) + 200,   // 200-600ms for mobile
      firstContentfulPaint: device === 'desktop'
        ? Math.floor(Math.random() * 800) + 600    // 600-1400ms for desktop
        : Math.floor(Math.random() * 1200) + 1000, // 1000-2200ms for mobile
      speedIndex: device === 'desktop'
        ? Math.floor(Math.random() * 1500) + 1000  // 1000-2500ms for desktop
        : Math.floor(Math.random() * 2000) + 2000, // 2000-4000ms for mobile
      timeToInteractive: device === 'desktop'
        ? Math.floor(Math.random() * 2000) + 1500  // 1500-3500ms for desktop
        : Math.floor(Math.random() * 3000) + 3000, // 3000-6000ms for mobile
      totalBlockingTime: Math.floor(Math.random() * 300) + 100,   // 100-400ms for desktop
      
      // New metrics
      domContentLoaded: device === 'desktop'
        ? Math.floor(Math.random() * 500) + 300   // 300-800ms for desktop
        : Math.floor(Math.random() * 800) + 500,  // 500-1300ms for mobile
      
      domSize: Math.floor(Math.random() * 1000) + 500, // 500-1500 elements
      
      resourceSummary: {
        total: Math.floor(Math.random() * 50) + 20,
        js: Math.floor(Math.random() * 15) + 5,
        css: Math.floor(Math.random() * 5) + 1,
        images: Math.floor(Math.random() * 20) + 5,
        fonts: Math.floor(Math.random() * 3) + 1,
        other: Math.floor(Math.random() * 5) + 1
      },
      
      thirdPartyUsage: {
        totalBytes: Math.floor(Math.random() * 500000) + 100000, // 100KB-600KB
        totalBlockingTime: Math.floor(Math.random() * 200) + 50  // 50-250ms
      },
      
      mainThreadWork: {
        scriptEvaluation: device === 'desktop'
          ? Math.floor(Math.random() * 1000) + 500
          : Math.floor(Math.random() * 1500) + 800,
        styleLayout: device === 'desktop'
          ? Math.floor(Math.random() * 500) + 200
          : Math.floor(Math.random() * 800) + 400,
        rendering: device === 'desktop'
          ? Math.floor(Math.random() * 300) + 100
          : Math.floor(Math.random() * 500) + 200,
        painting: Math.floor(Math.random() * 200) + 50,
        other: Math.floor(Math.random() * 300) + 100
      }
    };

    return {
      performance: performance.value,
      accessibility: accessibility.value,
      seo: seo.value,
      bestPractices: bestPractices.value,
      progressiveWebApp: progressiveWebApp.value,
      coreWebVitals,
      metrics,
      scores: {
        performance: performance.rating,
        accessibility: accessibility.rating,
        seo: seo.rating,
        bestPractices: bestPractices.rating,
        progressiveWebApp: progressiveWebApp.rating
      },
    };
  } catch (error) {
    console.error('Lighthouse audit failed:', error);
    throw new Error('Failed to run performance audit');
  }
}