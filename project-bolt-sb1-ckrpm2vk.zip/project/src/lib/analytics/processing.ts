import { ProcessedData, ValidationRules } from './types';
import { validateColumns, validateDataTypes, validateMissingValues, runCustomValidations } from './validation';
import { FILE_CONFIG } from './config';

/**
 * Processes uploaded file data
 */
export async function processFileData(
  data: any[][],
  rules?: ValidationRules
): Promise<ProcessedData> {
  // Validate row count
  if (data.length > FILE_CONFIG.maxRows) {
    throw new Error(`تعداد سطرها (${data.length}) بیش از حد مجاز (${FILE_CONFIG.maxRows}) است`);
  }

  // Extract headers and data rows
  const headers = data[0].map(String);
  const rows = data.slice(1);

  // Validate column names
  const columnValidation = validateColumns(headers);
  if (!columnValidation.valid) {
    throw new Error(columnValidation.errors.join('\n'));
  }

  // Process and validate data
  const processedData: ProcessedData = {
    headers,
    rows,
    summary: {
      rowCount: rows.length,
      columnCount: headers.length,
      dataTypes: {},
      missingValues: {}
    }
  };

  // Calculate data types and missing values
  headers.forEach((header, colIndex) => {
    const column = rows.map(row => row[colIndex]);
    processedData.summary.dataTypes[header] = inferColumnType(column);
    processedData.summary.missingValues[header] = column.filter(
      val => val === null || val === undefined || val === ''
    ).length;
  });

  // Run validations if rules provided
  if (rules) {
    // Data type validation
    const typeValidation = validateDataTypes(data, rules);
    if (!typeValidation.valid) {
      throw new Error(typeValidation.errors.join('\n'));
    }

    // Missing values validation
    const missingValidation = validateMissingValues(processedData);
    if (!missingValidation.valid) {
      throw new Error(missingValidation.errors.join('\n'));
    }

    // Custom validations
    const customValidation = runCustomValidations(processedData, rules);
    if (!customValidation.valid) {
      throw new Error(customValidation.errors.join('\n'));
    }
  }

  return processedData;
}

/**
 * Infers the data type of a column
 */
function inferColumnType(values: any[]): string {
  const nonEmptyValues = values.filter(v => v !== null && v !== undefined && v !== '');
  if (nonEmptyValues.length === 0) return 'string';

  const types = nonEmptyValues.map(value => {
    if (typeof value === 'number') return 'number';
    if (typeof value === 'boolean') return 'boolean';
    if (typeof value === 'string') {
      if (/^\d+$/.test(value)) return 'number';
      if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return 'date';
      if (/^\d{2}\/\d{2}\/\d{4}$/.test(value)) return 'date';
      return 'string';
    }
    return 'string';
  });

  const uniqueTypes = [...new Set(types)];
  return uniqueTypes.length === 1 ? uniqueTypes[0] : 'string';
}

/**
 * Cleans and formats data
 */
export function cleanData(data: ProcessedData): ProcessedData {
  const cleanedRows = data.rows.map(row =>
    row.map((value, colIndex) => {
      const type = data.summary.dataTypes[data.headers[colIndex]];
      
      // Handle missing values
      if (value === null || value === undefined || value === '') {
        return null;
      }

      // Format based on type
      switch (type) {
        case 'number':
          return typeof value === 'number' ? value : Number(value);
        case 'date':
          return new Date(value).toISOString().split('T')[0];
        case 'boolean':
          return Boolean(value);
        default:
          return String(value).trim();
      }
    })
  );

  return {
    ...data,
    rows: cleanedRows
  };
}

/**
 * Detects and handles outliers
 */
export function handleOutliers(data: ProcessedData): ProcessedData {
  const processedRows = data.rows.map(row =>
    row.map((value, colIndex) => {
      const type = data.summary.dataTypes[data.headers[colIndex]];
      
      if (type === 'number' && typeof value === 'number') {
        const column = data.rows.map(r => r[colIndex]).filter(v => typeof v === 'number');
        const mean = column.reduce((a, b) => a + b, 0) / column.length;
        const std = Math.sqrt(
          column.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / column.length
        );
        
        // Mark as outlier if more than 3 standard deviations from mean
        if (Math.abs(value - mean) > 3 * std) {
          return {
            value,
            isOutlier: true,
            mean,
            std
          };
        }
      }
      
      return value;
    })
  );

  return {
    ...data,
    rows: processedRows
  };
}