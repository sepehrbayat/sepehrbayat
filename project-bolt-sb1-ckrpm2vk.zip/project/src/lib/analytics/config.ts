/**
 * File Processing Configuration
 */
export const FILE_CONFIG = {
  maxSize: 10 * 1024 * 1024, // 10MB
  maxRows: 100000,
  supportedFormats: {
    excel: ['.xlsx', '.xls'],
    text: ['.csv', '.txt']
  }
} as const;

/**
 * Data Validation Rules
 */
export const VALIDATION_RULES = {
  maxColumnNameLength: 50,
  maxCellLength: 5000,
  maxMissingRatio: 0.3, // 30% missing values threshold
  dateFormats: ['YYYY-MM-DD', 'DD/MM/YYYY', 'MM/DD/YYYY'],
  numberFormats: {
    decimal: '.',
    thousands: ',',
    precision: 10
  }
} as const;

/**
 * AI Analysis Configuration
 */
export const AI_CONFIG = {
  modelslab: {
    model: 'ModelsLab/Mixtral-8x7B-Instruct',
    maxTokens: 2000,
    temperature: 0.3,
    requestTimeout: 30000, // 30 seconds
    retryAttempts: 3,
    retryDelay: 1000 // 1 second
  },
  analysis: {
    minDataPoints: 10,
    maxDataPoints: 10000,
    confidenceThreshold: 0.8,
    anomalyThreshold: 2.5, // Standard deviations
    trendSignificance: 0.05,
    correlationThreshold: 0.7
  }
} as const;

/**
 * Visualization Configuration
 */
export const CHART_CONFIG = {
  colors: {
    primary: ['#a63439', '#262e43', '#4B5563', '#10B981', '#F59E0B', '#EF4444'],
    sequential: ['#fee2e2', '#fecaca', '#fca5a5', '#f87171', '#ef4444', '#dc2626'],
    diverging: ['#ef4444', '#f87171', '#fca5a5', '#a8e6cf', '#67c2a5', '#2d8659']
  },
  fonts: {
    family: 'Vazirmatn',
    sizes: {
      title: 16,
      label: 12,
      tick: 10
    }
  },
  animation: {
    duration: 500,
    easing: 'easeInOutQuart'
  },
  responsive: true,
  maintainAspectRatio: false,
  devicePixelRatio: 2
} as const;

/**
 * Export Configuration
 */
export const EXPORT_CONFIG = {
  pdf: {
    format: 'A4',
    orientation: 'portrait',
    margin: { top: 40, right: 40, bottom: 40, left: 40 },
    fonts: ['Vazirmatn'],
    compression: true
  },
  image: {
    format: 'png',
    quality: 0.92,
    backgroundColor: '#ffffff'
  },
  excel: {
    sheetName: 'Analysis Results',
    dateFormat: 'YYYY-MM-DD',
    numberFormat: '#,##0.00'
  }
} as const;

/**
 * Performance Thresholds
 */
export const PERFORMANCE_CONFIG = {
  rendering: {
    maxInitialLoadTime: 2000, // 2 seconds
    maxChartRenderTime: 500,  // 500ms
    maxInteractionDelay: 100  // 100ms
  },
  caching: {
    maxCacheSize: 50 * 1024 * 1024, // 50MB
    maxCacheAge: 24 * 60 * 60 * 1000 // 24 hours
  },
  dataProcessing: {
    chunkSize: 1000, // Process data in chunks of 1000 rows
    workerCount: 4    // Number of web workers for parallel processing
  }
} as const;

/**
 * Error Messages
 */
export const ERROR_MESSAGES = {
  fileUpload: {
    size: 'حجم فایل نباید بیشتر از 10 مگابایت باشد',
    format: 'فرمت فایل پشتیبانی نمی‌شود',
    rows: 'تعداد سطرها بیش از حد مجاز است',
    empty: 'فایل خالی است',
    corrupted: 'فایل خراب است یا قابل خواندن نیست'
  },
  validation: {
    missingColumns: 'ستون‌های اجباری وجود ندارند',
    invalidFormat: 'فرمت داده‌ها نامعتبر است',
    tooManyMissing: 'تعداد مقادیر خالی بیش از حد مجاز است'
  },
  analysis: {
    insufficientData: 'داده‌های کافی برای تحلیل وجود ندارد',
    timeout: 'زمان تحلیل به پایان رسید',
    serverError: 'خطا در ارتباط با سرور تحلیل'
  }
} as const;