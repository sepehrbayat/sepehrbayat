import { jsPDF } from 'jspdf';
import * as XLSX from 'xlsx';
import { ChartData } from './types';
import { EXPORT_CONFIG } from './config';

/**
 * Exports chart as PNG image
 */
export async function exportChartAsImage(chartRef: any): Promise<string> {
  try {
    if (!chartRef?.current) {
      throw new Error('نمودار یافت نشد');
    }

    const canvas = chartRef.current.canvas;
    const imageData = canvas.toDataURL('image/png', EXPORT_CONFIG.image.quality);
    return imageData;

  } catch (error) {
    console.error('Error exporting chart as image:', error);
    throw new Error('خطا در تولید تصویر');
  }
}

/**
 * Exports chart data as Excel file
 */
export function exportChartAsExcel(data: ChartData): void {
  try {
    // Convert chart data to worksheet format
    const wsData = [
      ['Labels', ...data.labels],
      ...data.datasets.map(dataset => 
        [dataset.label, ...dataset.data]
      )
    ];

    // Create workbook and worksheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(wsData);

    // Add worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, EXPORT_CONFIG.excel.sheetName);

    // Save file
    XLSX.writeFile(wb, 'chart-data.xlsx');

  } catch (error) {
    console.error('Error exporting chart as Excel:', error);
    throw new Error('خطا در تولید فایل اکسل');
  }
}

/**
 * Exports chart as PDF
 */
export function exportChartAsPDF(chartRef: any, title: string): void {
  try {
    if (!chartRef?.current) {
      throw new Error('نمودار یافت نشد');
    }

    const canvas = chartRef.current.canvas;
    const imageData = canvas.toDataURL('image/png', EXPORT_CONFIG.image.quality);

    // Create PDF
    const pdf = new jsPDF({
      orientation: EXPORT_CONFIG.pdf.orientation,
      unit: 'mm'
    });

    // Add title
    pdf.setFontSize(16);
    pdf.text(title, 20, 20);

    // Add chart image
    const imgWidth = pdf.internal.pageSize.getWidth() - 40;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    pdf.addImage(imageData, 'PNG', 20, 30, imgWidth, imgHeight);

    // Save file
    pdf.save('chart.pdf');

  } catch (error) {
    console.error('Error exporting chart as PDF:', error);
    throw new Error('خطا در تولید فایل PDF');
  }
}