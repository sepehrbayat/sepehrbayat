import { ValidationRules, ProcessedData } from './types';
import { VALIDATION_RULES } from './config';

/**
 * Validates column names
 */
export function validateColumns(headers: string[]): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Check for empty or invalid column names
  headers.forEach((header, index) => {
    if (!header.trim()) {
      errors.push(`ستون ${index + 1} نام ندارد`);
    } else if (header.length > VALIDATION_RULES.maxColumnNameLength) {
      errors.push(`نام ستون "${header}" بیش از حد طولانی است`);
    } else if (!/^[a-zA-Z0-9\u0600-\u06FF\s_-]+$/.test(header)) {
      errors.push(`نام ستون "${header}" حاوی کاراکترهای غیرمجاز است`);
    }
  });

  // Check for duplicate column names
  const duplicates = headers.filter((item, index) => headers.indexOf(item) !== index);
  if (duplicates.length > 0) {
    errors.push(`ستون‌های تکراری: ${duplicates.join(', ')}`);
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Validates data types and formats
 */
export function validateDataTypes(
  data: any[][],
  rules: ValidationRules
): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (rules.columnTypes) {
    data[0].forEach((header, colIndex) => {
      const expectedType = rules.columnTypes[header];
      if (expectedType) {
        data.slice(1).forEach((row, rowIndex) => {
          const value = row[colIndex];
          if (value !== null && value !== undefined && value !== '') {
            const actualType = getValueType(value);
            if (actualType !== expectedType) {
              errors.push(
                `مقدار نامعتبر در سطر ${rowIndex + 1}، ستون "${header}": ` +
                `انتظار "${expectedType}"، دریافت "${actualType}"`
              );
            }
          }
        });
      }
    });
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Validates missing values
 */
export function validateMissingValues(data: ProcessedData): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  const rowCount = data.rows.length;

  Object.entries(data.summary.missingValues).forEach(([column, count]) => {
    const missingRatio = count / rowCount;
    if (missingRatio > VALIDATION_RULES.maxMissingRatio) {
      errors.push(
        `ستون "${column}" دارای ${Math.round(missingRatio * 100)}% مقدار خالی است ` +
        `(بیش از حد مجاز ${VALIDATION_RULES.maxMissingRatio * 100}%)`
      );
    }
  });

  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Validates date formats
 */
export function validateDateFormat(value: string): boolean {
  return VALIDATION_RULES.dateFormats.some(format => {
    const regex = format
      .replace('YYYY', '\\d{4}')
      .replace('MM', '\\d{2}')
      .replace('DD', '\\d{2}');
    return new RegExp(`^${regex}$`).test(value);
  });
}

/**
 * Validates number formats
 */
export function validateNumberFormat(value: string): boolean {
  const { decimal, thousands, precision } = VALIDATION_RULES.numberFormats;
  const regex = new RegExp(
    `^-?\\d{1,3}(${thousands}\\d{3})*${decimal}?\\d{0,${precision}}$`
  );
  return regex.test(value);
}

/**
 * Gets the type of a value
 */
function getValueType(value: any): string {
  if (typeof value === 'number') return 'number';
  if (typeof value === 'boolean') return 'boolean';
  if (typeof value === 'string') {
    if (validateDateFormat(value)) return 'date';
    if (validateNumberFormat(value)) return 'number';
    return 'string';
  }
  return typeof value;
}

/**
 * Runs custom validation rules
 */
export function runCustomValidations(
  data: ProcessedData,
  rules: ValidationRules
): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (rules.customValidators) {
    rules.customValidators.forEach(validator => {
      const result = validator(data.rows);
      if (!result.valid && result.error) {
        errors.push(result.error);
      }
    });
  }

  return {
    valid: errors.length === 0,
    errors
  };
}