/**
 * File Processing Types
 */
export interface FileConfig {
  maxSize: number; // Maximum file size in bytes (10MB)
  maxRows: number; // Maximum number of rows (100,000)
  supportedFormats: {
    excel: string[];  // ['.xlsx', '.xls']
    text: string[];   // ['.csv', '.txt']
  };
}

export interface ValidationRules {
  requiredColumns?: string[];
  columnTypes?: Record<string, 'string' | 'number' | 'date' | 'boolean'>;
  customValidators?: Array<(data: any[]) => { valid: boolean; error?: string }>;
}

export interface ProcessedData {
  headers: string[];
  rows: any[][];
  summary: {
    rowCount: number;
    columnCount: number;
    dataTypes: Record<string, string>;
    missingValues: Record<string, number>;
  };
}

/**
 * AI Analysis Types
 */
export interface AIAnalysisRequest {
  data: ProcessedData;
  analysisTypes: AnalysisType[];
  options?: {
    confidence?: number;
    timeframe?: string;
    groupBy?: string[];
  };
}

export type AnalysisType = 
  | 'patterns'
  | 'trends'
  | 'anomalies'
  | 'predictions'
  | 'correlations'
  | 'clusters';

export interface AIAnalysisResponse {
  insights: Array<{
    type: AnalysisType;
    confidence: number;
    description: string;
    evidence: any[];
    recommendations?: string[];
  }>;
  visualizations: Array<{
    type: ChartType;
    data: ChartData;
    title: string;
    description: string;
  }>;
  metadata: {
    processingTime: number;
    modelVersion: string;
    dataQualityScore: number;
  };
}

/**
 * Visualization Types
 */
export type ChartType = 
  | 'line'
  | 'bar'
  | 'pie'
  | 'scatter'
  | 'heatmap'
  | 'boxplot'
  | 'treemap';

export interface ChartData {
  labels: string[];
  datasets: Array<{
    label: string;
    data: number[];
    backgroundColor?: string | string[];
    borderColor?: string;
    borderWidth?: number;
  }>;
}

export interface ChartOptions {
  responsive: boolean;
  maintainAspectRatio: boolean;
  interaction: {
    mode: 'index' | 'point' | 'nearest';
    intersect: boolean;
  };
  plugins: {
    tooltip: {
      enabled: boolean;
      mode: 'index' | 'point' | 'nearest';
    };
    zoom: {
      enabled: boolean;
      mode: 'x' | 'y' | 'xy';
    };
    legend: {
      position: 'top' | 'bottom' | 'left' | 'right';
      align: 'start' | 'center' | 'end';
    };
  };
  scales?: {
    x?: {
      type: 'linear' | 'category' | 'time';
      title?: {
        display: boolean;
        text: string;
      };
    };
    y?: {
      type: 'linear' | 'category' | 'time';
      title?: {
        display: boolean;
        text: string;
      };
    };
  };
}

/**
 * Export Types
 */
export interface ExportOptions {
  format: 'pdf' | 'png' | 'csv' | 'xlsx';
  includeAnalysis: boolean;
  charts: {
    width: number;
    height: number;
    quality: number;
  };
  customization?: {
    title?: string;
    description?: string;
    logo?: string;
    footer?: string;
  };
}

/**
 * UI Component Types
 */
export interface InsightCard {
  title: string;
  description: string;
  type: AnalysisType;
  confidence: number;
  chart?: {
    type: ChartType;
    data: ChartData;
  };
  actions?: Array<{
    label: string;
    handler: () => void;
  }>;
}

export interface FilterConfig {
  column: string;
  type: 'range' | 'select' | 'search' | 'date';
  options?: string[];
  range?: {
    min: number;
    max: number;
  };
}

export interface SearchConfig {
  columns: string[];
  caseSensitive: boolean;
  fuzzyMatch: boolean;
  debounceMs: number;
}