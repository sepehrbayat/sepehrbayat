import { openai } from '../../openai';
import { TrendAnalysisResponse, TrendData } from './types';

/**
 * Calculates the Pearson correlation coefficient between two arrays
 */
export function calculateCorrelation(x: number[], y: number[]): number {
  const n = x.length;
  const sum1 = x.reduce((a, b) => a + b);
  const sum2 = y.reduce((a, b) => a + b);
  const sum1Sq = x.reduce((a, b) => a + b * b);
  const sum2Sq = y.reduce((a, b) => a + b * b);
  const pSum = x.map((x, i) => x * y[i]).reduce((a, b) => a + b);
  const num = pSum - (sum1 * sum2 / n);
  const den = Math.sqrt((sum1Sq - sum1 * sum1 / n) * (sum2Sq - sum2 * sum2 / n));
  return num / den;
}

/**
 * Analyzes trend data and returns statistics
 */
export function analyzeTrendStatistics(data: number[]): {
  mean: number;
  stdDev: number;
  min: number;
  max: number;
  trend: 'upward' | 'downward' | 'stable' | 'cyclical';
  confidence: number;
} {
  // Calculate basic statistics
  const mean = data.reduce((a, b) => a + b) / data.length;
  const variance = data.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / data.length;
  const stdDev = Math.sqrt(variance);
  const min = Math.min(...data);
  const max = Math.max(...data);

  // Calculate trend
  const indices = Array.from({length: data.length}, (_, i) => i);
  const correlation = calculateCorrelation(indices, data);
  
  // Determine trend type and confidence
  let trend: 'upward' | 'downward' | 'stable' | 'cyclical';
  let confidence: number;

  if (Math.abs(correlation) > 0.7) {
    trend = correlation > 0 ? 'upward' : 'downward';
    confidence = Math.abs(correlation) * 100;
  } else if (Math.abs(correlation) < 0.3) {
    trend = 'stable';
    confidence = (1 - Math.abs(correlation)) * 100;
  } else {
    trend = 'cyclical';
    confidence = 50 + Math.abs(correlation) * 50;
  }

  return {
    mean,
    stdDev,
    min,
    max,
    trend,
    confidence: Math.round(confidence)
  };
}

export async function analyzeTrendData(
  data: string,
  isEnglish: boolean
): Promise<TrendAnalysisResponse> {
  try {
    const response = await openai.chat.completions.create({
      model: 'ModelsLab/Mixtral-8x7B-Instruct',
      temperature: 0.3,
      messages: [
        {
          role: 'system',
          content: isEnglish ? 
            `You are a trend analysis expert. Please analyze the provided time series data and identify trends.

Please return ONLY a valid JSON object with this exact structure:
{
  "trend": "upward" | "downward" | "stable" | "cyclical",
  "confidence": number (0-100),
  "insights": [
    "insight 1",
    "insight 2",
    "insight 3"
  ]
}` :
            `شما یک متخصص تحلیل روند هستید. لطفاً داده‌های سری زمانی ارائه شده را تحلیل کنید.

لطفاً پاسخ را فقط در قالب JSON با این ساختار دقیق برگردانید:
{
  "trend": "صعودی" | "نزولی" | "ثابت" | "نوسانی",
  "confidence": عدد بین 0 تا 100,
  "insights": [
    "نکته کلیدی 1",
    "نکته کلیدی 2",
    "نکته کلیدی 3"
  ]
}`
        },
        {
          role: 'user',
          content: data
        }
      ]
    });

    const content = response.choices[0]?.message?.content;
    if (!content) {
      throw new Error(isEnglish ? 'No response from server' : 'پاسخی از سرور دریافت نشد');
    }

    try {
      const analysis = JSON.parse(content);
      return analysis;
    } catch (parseError) {
      console.error('JSON parse error:', parseError);
      throw new Error(isEnglish ? 'Error processing analysis results' : 'خطا در پردازش نتایج تحلیل');
    }

  } catch (error) {
    console.error('Trend analysis error:', error);
    throw error instanceof Error ? error : new Error(
      isEnglish ? 'Error analyzing trend data' : 'خطا در تحلیل روند'
    );
  }
}