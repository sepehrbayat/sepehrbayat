export interface TrendData {
  dates: string[];
  values: number[];
  predictions: number[];
  trend: string;
  confidence: number;
  insights: string[];
}

export interface TrendAnalysisResponse {
  trend: string;
  confidence: number;
  insights: string[];
}

export interface TrendChartProps {
  data: {
    labels: string[];
    datasets: Array<{
      label: string;
      data: number[];
      borderColor?: string;
      backgroundColor?: string;
      borderDash?: number[];
      pointRadius?: number;
    }>;
  };
  onExport: (format: 'png' | 'pdf' | 'excel') => Promise<void>;
  isExporting: boolean;
}

export interface TrendInsightsProps {
  data: TrendData;
  isEnglish: boolean;
}