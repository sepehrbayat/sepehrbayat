export const METRIC_THRESHOLDS = {
  TTFB: {
    GOOD: 200,
    WARNING: 500,
    POOR: 1000,
    WEIGHT: 0.1
  },
  FCP: {
    GOOD: 1800,
    WARNING: 3000,
    POOR: 4500,
    WEIGHT: 0.1
  },
  LCP: {
    GOOD: 2500,
    WARNING: 4000,
    POOR: 6000,
    WEIGHT: 0.25
  },
  CLS: {
    GOOD: 0.1,
    WARNING: 0.25,
    POOR: 0.5,
    WEIGHT: 0.25
  },
  TBT: {
    GOOD: 200,
    WARNING: 600,
    POOR: 1000,
    WEIGHT: 0.3
  }
} as const;

export const RESOURCE_THRESHOLDS = {
  TOTAL_SIZE: {
    GOOD: 1024 * 1024, // 1MB
    WARNING: 2048 * 1024, // 2MB
    POOR: 3072 * 1024 // 3MB
  },
  JS_SIZE: {
    GOOD: 200 * 1024, // 200KB
    WARNING: 400 * 1024, // 400KB
    POOR: 800 * 1024 // 800KB
  },
  CSS_SIZE: {
    GOOD: 100 * 1024, // 100KB
    WARNING: 200 * 1024, // 200KB
    POOR: 400 * 1024 // 400KB
  },
  IMAGE_SIZE: {
    GOOD: 500 * 1024, // 500KB
    WARNING: 1024 * 1024, // 1MB
    POOR: 2048 * 1024 // 2MB
  }
} as const;
export const SCORE_WEIGHTS = {
  PERFORMANCE: 0.25,
  ACCESSIBILITY: 0.25,
  BEST_PRACTICES: 0.15,
  SEO: 0.25,
  PWA: 0.1
} as const;

export const RESOURCE_SIZE_LIMITS = {
  JAVASCRIPT: 250 * 1024, // 250KB
  CSS: 100 * 1024, // 100KB
  IMAGES: 500 * 1024, // 500KB
  TOTAL: 2048 * 1024 // 2MB
} as const;

export const CACHE_DURATIONS = {
  STATIC: 86400 * 30, // 30 days
  DYNAMIC: 3600 * 24, // 24 hours
  IMAGES: 86400 * 7 // 7 days
} as const;