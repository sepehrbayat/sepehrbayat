import { useState, useEffect } from 'react';
import { METRIC_THRESHOLDS } from '../constants';

interface PerformanceMetrics {
  ttfb: number | null;
  fcp: number | null;
  lcp: number | null;
  cls: number | null;
  tbt: number | null;
  si: number | null;
  tti: number | null;
  unusedJavaScript: number | null;
  unusedCSS: number | null;
  optimizedImages: number | null;
  nextGenImages: number | null;
  responsiveImages: number | null;
  compressedResources: boolean;
  cacheHeaders: boolean;
  staticCacheTtl: number | null;
}

interface PerformanceMonitoring {
  metrics: PerformanceMetrics;
  score: number;
  suggestions: string[];
}

export function usePerformanceMonitoring(): PerformanceMonitoring {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    ttfb: null,
    fcp: null,
    lcp: null,
    cls: null,
    tbt: null,
    si: null,
    tti: null,
    unusedJavaScript: null,
    unusedCSS: null,
    optimizedImages: null,
    nextGenImages: null,
    responsiveImages: null,
    compressedResources: false,
    cacheHeaders: false,
    staticCacheTtl: null
  });

  const [score, setScore] = useState(0);
  const [suggestions, setSuggestions] = useState<string[]>([]);

  useEffect(() => {
    const observer = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        switch (entry.name) {
          case 'TTFB':
            setMetrics(prev => ({ ...prev, ttfb: entry.startTime }));
            break;
          case 'FCP':
            setMetrics(prev => ({ ...prev, fcp: entry.startTime }));
            break;
          case 'LCP':
            setMetrics(prev => ({ ...prev, lcp: entry.startTime }));
            break;
          case 'CLS':
            setMetrics(prev => ({ ...prev, cls: entry.value }));
            break;
          case 'TBT':
            setMetrics(prev => ({ ...prev, tbt: entry.value }));
            break;
        }
      }
    });

    observer.observe({ entryTypes: ['paint', 'layout-shift', 'longtask'] });

    // Analyze page resources
    const resources = performance.getEntriesByType('resource');
    let jsSize = 0;
    let cssSize = 0;
    let imageCount = 0;
    let optimizedImageCount = 0;

    resources.forEach(resource => {
      if (resource.name.endsWith('.js')) {
        jsSize += resource.decodedBodySize;
      } else if (resource.name.endsWith('.css')) {
        cssSize += resource.decodedBodySize;
      } else if (/\.(jpg|jpeg|png|gif|webp|avif)$/i.test(resource.name)) {
        imageCount++;
        if (/\.(webp|avif)$/i.test(resource.name)) {
          optimizedImageCount++;
        }
      }
    });

    setMetrics(prev => ({
      ...prev,
      unusedJavaScript: jsSize * 0.3, // Estimate 30% unused
      unusedCSS: cssSize * 0.4, // Estimate 40% unused
      optimizedImages: imageCount ? (optimizedImageCount / imageCount) * 100 : null,
      nextGenImages: imageCount ? (optimizedImageCount / imageCount) * 100 : null,
      responsiveImages: 80, // Example value
      compressedResources: document.querySelector('meta[content*="gzip"]') !== null,
      cacheHeaders: true, // Example value
      staticCacheTtl: 86400 * 7 // 7 days
    }));

    // Calculate performance score
    const calculateScore = () => {
      let totalScore = 0;
      let totalWeight = 0;

      const weights = {
        ttfb: 0.1,
        fcp: 0.1,
        lcp: 0.25,
        cls: 0.25,
        tbt: 0.3
      };

      if (metrics.ttfb !== null) {
        totalScore += (metrics.ttfb <= METRIC_THRESHOLDS.TTFB.GOOD ? 1 :
                      metrics.ttfb <= METRIC_THRESHOLDS.TTFB.WARNING ? 0.5 : 0) * weights.ttfb;
        totalWeight += weights.ttfb;
      }

      if (metrics.fcp !== null) {
        totalScore += (metrics.fcp <= METRIC_THRESHOLDS.FCP.GOOD ? 1 :
                      metrics.fcp <= METRIC_THRESHOLDS.FCP.WARNING ? 0.5 : 0) * weights.fcp;
        totalWeight += weights.fcp;
      }

      if (metrics.lcp !== null) {
        totalScore += (metrics.lcp <= METRIC_THRESHOLDS.LCP.GOOD ? 1 :
                      metrics.lcp <= METRIC_THRESHOLDS.LCP.WARNING ? 0.5 : 0) * weights.lcp;
        totalWeight += weights.lcp;
      }

      if (metrics.cls !== null) {
        totalScore += (metrics.cls <= METRIC_THRESHOLDS.CLS.GOOD ? 1 :
                      metrics.cls <= METRIC_THRESHOLDS.CLS.WARNING ? 0.5 : 0) * weights.cls;
        totalWeight += weights.cls;
      }

      if (metrics.tbt !== null) {
        totalScore += (metrics.tbt <= METRIC_THRESHOLDS.TBT.GOOD ? 1 :
                      metrics.tbt <= METRIC_THRESHOLDS.TBT.WARNING ? 0.5 : 0) * weights.tbt;
        totalWeight += weights.tbt;
      }

      return totalWeight > 0 ? (totalScore / totalWeight) * 100 : 0;
    };

    const score = calculateScore();
    setScore(score);

    // Generate suggestions
    const newSuggestions: string[] = [];
    
    if (metrics.ttfb && metrics.ttfb > METRIC_THRESHOLDS.TTFB.WARNING) {
      newSuggestions.push('بهینه‌سازی سرور و کش‌ها برای بهبود TTFB');
    }
    
    if (metrics.lcp && metrics.lcp > METRIC_THRESHOLDS.LCP.WARNING) {
      newSuggestions.push('بهینه‌سازی تصاویر و محتوای اصلی برای بهبود LCP');
    }
    
    if (metrics.cls && metrics.cls > METRIC_THRESHOLDS.CLS.WARNING) {
      newSuggestions.push('جلوگیری از تغییر مکان محتوا هنگام بارگذاری');
    }

    if (metrics.unusedJavaScript && metrics.unusedJavaScript > 100 * 1024) {
      newSuggestions.push('حذف کدهای جاوااسکریپت غیرضروری');
    }

    if (metrics.unusedCSS && metrics.unusedCSS > 50 * 1024) {
      newSuggestions.push('حذف استایل‌های CSS استفاده نشده');
    }

    if (!metrics.compressedResources) {
      newSuggestions.push('فعال‌سازی فشرده‌سازی Gzip/Brotli');
    }

    setSuggestions(newSuggestions);

    return () => observer.disconnect();
  }, []);

  return { metrics, score, suggestions };
}