export interface LighthouseReport {
  performance: number;
  accessibility: number;
  seo: number;
  bestPractices: number;
  progressiveWebApp: number;
  coreWebVitals: {
    lcp: number; // Largest Contentful Paint
    fid: number; // First Input Delay
    cls: number; // Cumulative Layout Shift
    inp: number; // Interaction to Next Paint
    tbt: number; // Total Blocking Time
  };
  metrics: {
    ttfb: number; // Time to First Byte
    firstContentfulPaint: number;
    firstMeaningfulPaint: number;
    speedIndex: number;
    timeToInteractive: number;
    totalBlockingTime: number;
    domContentLoaded: number;
    domSize: number;
    serverResponseTime: number;
    bootupTime: number;
    mainThreadWorkBreakdown: {
      scriptEvaluation: number;
      scriptParsing: number;
      styleLayout: number;
      painting: number;
      garbageCollection: number;
      other: number;
    };
    networkRtt: number;
    networkServerLatency: number;
    totalByteWeight: number;
    offscreenImages: number;
    unusedCssRules: number;
    unusedJavaScript: number;
    images: {
      optimized: number;
      responsive: number;
      nextGen: number;
      lazyLoaded: number;
      totalBytes: number;
      totalCount: number;
      webpEnabled: boolean;
      avifEnabled: boolean;
      lazyLoadEnabled: boolean;
      sizesAttribute: boolean;
      srcsetAttribute: boolean;
    };
    duplicatedJavaScript: number;
    legacyJavaScript: number;
    noDocumentWrite: boolean;
    timeToFirstByte: number;
    firstCpuIdle: number;
    maxPotentialFid: number;
    resourceSummary: {
      total: number;
      js: number;
      css: number;
      images: number;
      fonts: number;
      other: number;
    };
    thirdPartyUsage: {
      totalBytes: number;
      totalBlockingTime: number;
    };
    mainThreadWork: {
      scriptEvaluation: number;
      styleLayout: number;
      rendering: number;
      painting: number;
      other: number;
    };
    security: {
      score: number;
      https: boolean;
      mixedContent: boolean;
      vulnerabilities: string[];
      certificate: {
        valid: boolean;
        issuer: string;
        expiryDate: string;
      };
    };
  };
}