// Search Configuration
export const SEARCH_CONFIG = {
  maxResults: 10,
  defaultLanguage: 'fa',
  defaultRegion: 'ir',
  timeout: 30000,
  retryAttempts: 3,
  retryDelay: 1000,
  duckDuckGoEndpoint: 'https://api.duckduckgo.com',
  userAgent: 'HooshexBot/1.0',
  minContentLength: 100,
  maxContentLength: 5000,
  
  // DuckDuckGo specific settings
  instantAnswerApi: 'https://api.duckduckgo.com',
  searchApi: 'https://duckduckgo.com',
  
  // Search parameters
  defaultSites: [
    'blog.ir',
    'virgool.io',
    'zoomit.ir',
    'digiato.com',
    'shabakeh-mag.com'
  ],
  
  // Content types to extract
  extractTypes: [
    'AbstractText',
    'RelatedTopics',
    'Results',
    'Infobox'
  ],
  
  // Rate limiting
  maxRequestsPerMinute: 60,
  maxBurstRequests: 10,
  
  // Error messages
  errors: {
    SEARCH_FAILED: 'خطا در جستجو',
    NO_RESULTS: 'نتیجه‌ای یافت نشد',
    RATE_LIMIT: 'محدودیت تعداد درخواست',
    TIMEOUT: 'زمان درخواست به پایان رسید',
    NETWORK: 'خطا در ارتباط با سرور',
    INVALID_RESPONSE: 'پاسخ نامعتبر از سرور'
  }
} as const;

// Content Processing
export const CONTENT_CONFIG = {
  maxContentLength: 5000,
  minContentLength: 100,
  readingWordsPerMinute: 200,
  excludedElements: [
    'script',
    'style',
    'iframe',
    'form',
    'nav',
    'footer',
    'header'
  ],
  
  // Content cleaning
  htmlTags: {
    remove: ['script', 'style', 'iframe', 'form', 'input', 'button'],
    keep: ['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'ul', 'ol', 'li', 'blockquote']
  },
  
  // Content analysis
  analysis: {
    minParagraphs: 3,
    maxParagraphLength: 500,
    keywordDensity: {
      min: 0.5,
      max: 3.0
    }
  }
} as const;