import { Activity } from './types';
import { Award, Target, Sparkles, Brain, Star, Crown, Zap, Trophy, Medal, Book, Rocket, Shield, Flame } from 'lucide-react';

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: any;
  category: 'content' | 'seo' | 'analytics' | 'ai' | 'general' | 'social' | 'expert';
  color: string;
  points: number;
  maxLevel: number;
  conditions: {
    type: string;
    target: number;
    current: number;
  }[];
  rewards?: {
    title: string;
    description: string;
    icon: any;
  }[];
  requiredAchievements?: string[];
}

export interface UserAchievement extends Achievement {
  progress: number;
  maxProgress: number;
  level: number;
  isUnlocked: boolean;
  unlockedAt?: string;
  nextReward?: {
    title: string;
    description: string;
    icon: any;
    progress: number;
    required: number;
  };
}

const ACHIEVEMENTS: Achievement[] = [
  // Content Creation Path
  {
    id: 'content-master',
    title: 'استاد محتوا',
    description: 'تولید محتوای با کیفیت و بهینه شده برای سئو',
    icon: Award,
    category: 'content',
    color: 'from-emerald-500 to-emerald-600',
    points: 500,
    maxLevel: 5,
    conditions: [
      {
        type: 'content_generation',
        target: 100,
        current: 0
      },
      {
        type: 'high_quality_content',
        target: 50,
        current: 0
      }
    ],
    rewards: [
      {
        title: 'نشان نویسنده برتر',
        description: 'دسترسی به ابزارهای پیشرفته تولید محتوا',
        icon: Crown
      }
    ]
  },
  
  // SEO Expert Path
  {
    id: 'seo-expert',
    title: 'متخصص سئو',
    description: 'تسلط بر بهینه‌سازی موتورهای جستجو',
    icon: Target,
    category: 'seo',
    color: 'from-blue-500 to-blue-600',
    points: 750,
    maxLevel: 5,
    conditions: [
      {
        type: 'seo_analysis',
        target: 50,
        current: 0
      },
      {
        type: 'high_seo_score',
        target: 25,
        current: 0
      }
    ],
    rewards: [
      {
        title: 'نشان سئو حرفه‌ای',
        description: 'دسترسی به ابزارهای پیشرفته تحلیل سئو',
        icon: Shield
      }
    ]
  },

  // AI Pioneer Path
  {
    id: 'ai-pioneer',
    title: 'پیشگام هوش مصنوعی',
    description: 'تسلط بر ابزارهای هوش مصنوعی',
    icon: Brain,
    category: 'ai',
    points: 1000,
    maxLevel: 5,
    color: 'from-purple-500 to-purple-600',
    conditions: [
      {
        type: 'tool_usage',
        target: 100,
        current: 0
      }
    ],
    rewards: [
      {
        title: 'نشان نوآور هوش مصنوعی',
        description: 'دسترسی به ویژگی‌های پیشرفته هوش مصنوعی',
        icon: Sparkles
      }
    ]
  },

  // Analytics Expert Path
  {
    id: 'analytics-expert',
    title: 'متخصص تحلیل داده',
    description: 'تسلط بر تحلیل و تجسم داده‌ها',
    icon: Zap,
    category: 'analytics',
    color: 'from-amber-500 to-amber-600',
    points: 800,
    maxLevel: 5,
    conditions: [
      {
        type: 'data_analysis',
        target: 50,
        current: 0
      }
    ],
    rewards: [
      {
        title: 'نشان تحلیلگر داده',
        description: 'دسترسی به ابزارهای پیشرفته تحلیل',
        icon: Star
      }
    ]
  },

  // Social Influencer Path
  {
    id: 'social-influencer',
    title: 'تأثیرگذار اجتماعی',
    description: 'ایجاد محتوای جذاب برای شبکه‌های اجتماعی',
    icon: Star,
    category: 'social',
    color: 'from-pink-500 to-pink-600',
    points: 600,
    maxLevel: 5,
    conditions: [
      {
        type: 'social_content',
        target: 50,
        current: 0
      }
    ],
    rewards: [
      {
        title: 'نشان تأثیرگذار',
        description: 'دسترسی به ابزارهای پیشرفته تولید محتوای اجتماعی',
        icon: Crown
      }
    ]
  },

  // Expert Level Achievements
  {
    id: 'content-expert',
    title: 'خبره محتوا',
    description: 'تسلط کامل بر تولید محتوای حرفه‌ای',
    icon: Crown,
    category: 'expert',
    color: 'from-amber-500 to-amber-600',
    points: 2000,
    maxLevel: 3,
    conditions: [
      {
        type: 'content_generation',
        target: 500,
        current: 0
      }
    ],
    requiredAchievements: ['content-master'],
    rewards: [
      {
        title: 'نشان استاد محتوا',
        description: 'دسترسی به تمام ویژگی‌های پیشرفته',
        icon: Trophy
      }
    ]
  },

  // Milestone Achievements
  {
    id: 'first-content',
    title: 'اولین محتوا',
    description: 'تولید اولین محتوا',
    icon: Rocket,
    category: 'general',
    color: 'from-green-500 to-green-600',
    points: 100,
    maxLevel: 1,
    conditions: [
      {
        type: 'content_generation',
        target: 1,
        current: 0
      }
    ]
  },
  
  {
    id: 'consistent-creator',
    title: 'خالق پیوسته',
    description: '7 روز متوالی فعالیت',
    icon: Flame,
    category: 'general',
    color: 'from-orange-500 to-orange-600',
    points: 300,
    maxLevel: 1,
    conditions: [
      {
        type: 'daily_streak',
        target: 7,
        current: 0
      }
    ]
  }
];

export function calculateAchievements(activities: Activity[]): UserAchievement[] {
  // Group activities by type
  const activityCounts = activities.reduce((counts, activity) => {
    counts[activity.type] = (counts[activity.type] || 0) + 1;
    return counts;
  }, {} as Record<string, number>);

  // Calculate daily streak
  const dailyStreak = calculateDailyStreak(activities);

  // Calculate achievements
  return ACHIEVEMENTS.map(achievement => {
    // Calculate progress based on conditions
    const conditionsProgress = achievement.conditions.map(condition => {
      let current = 0;

      if (condition.type === 'daily_streak') {
        current = dailyStreak;
      } else {
        current = activityCounts[condition.type] || 0;
      }

      return Math.min(current / condition.target, 1);
    });

    // Average progress across all conditions
    const totalProgress = conditionsProgress.reduce((sum, p) => sum + p, 0) / conditionsProgress.length;
    
    // Calculate level based on progress
    const level = Math.min(
      achievement.maxLevel,
      Math.floor(totalProgress * achievement.maxLevel) + 1
    );

    // Check if required achievements are unlocked
    const requiredUnlocked = !achievement.requiredAchievements?.length || 
      achievement.requiredAchievements.every(reqId => 
        ACHIEVEMENTS.find(a => a.id === reqId)?.conditions.every(c => 
          (activityCounts[c.type] || 0) >= c.target
        )
      );

    // Calculate next reward
    const nextReward = achievement.rewards?.[level - 1];
    const progress = Math.floor(totalProgress * 100);
    const required = Math.floor((level / achievement.maxLevel) * 100);

    return {
      ...achievement,
      progress: Math.floor(totalProgress * achievement.maxProgress),
      maxProgress: 100,
      level,
      isUnlocked: totalProgress >= 1 && requiredUnlocked,
      unlockedAt: totalProgress >= 1 ? new Date().toISOString() : undefined,
      nextReward: nextReward ? {
        ...nextReward,
        progress,
        required
      } : undefined
    };
  });
}

function calculateDailyStreak(activities: Activity[]): number {
  if (activities.length === 0) return 0;

  // Sort activities by date
  const sortedActivities = activities
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

  let streak = 1;
  let currentDate = new Date(sortedActivities[0].created_at);
  currentDate.setHours(0, 0, 0, 0);

  for (let i = 1; i < sortedActivities.length; i++) {
    const activityDate = new Date(sortedActivities[i].created_at);
    activityDate.setHours(0, 0, 0, 0);

    const diffDays = Math.floor((currentDate.getTime() - activityDate.getTime()) / (1000 * 60 * 60 * 24));

    if (diffDays === 1) {
      streak++;
      currentDate = activityDate;
    } else if (diffDays > 1) {
      break;
    }
  }

  return streak;
}

export function getAchievementPoints(achievements: UserAchievement[]): number {
  return achievements.reduce((total, achievement) => {
    if (achievement.isUnlocked) {
      return total + achievement.points;
    }
    return total;
  }, 0);
}

export function getNextAchievement(achievements: UserAchievement[]): UserAchievement | null {
  const unlockedAchievements = achievements.filter(a => a.isUnlocked);
  const nextAchievements = achievements
    .filter(a => !a.isUnlocked)
    .sort((a, b) => (b.progress / b.maxProgress) - (a.progress / a.maxProgress));

  return nextAchievements[0] || null;
}

export function getAchievementCategories() {
  return [
    {
      id: 'content',
      name: 'تولید محتوا',
      color: 'from-emerald-500 to-emerald-600',
      icon: Award
    },
    {
      id: 'seo',
      name: 'سئو',
      color: 'from-blue-500 to-blue-600',
      icon: Target
    },
    {
      id: 'ai',
      name: 'هوش مصنوعی',
      color: 'from-purple-500 to-purple-600',
      icon: Brain
    },
    {
      id: 'analytics',
      name: 'تحلیل داده',
      color: 'from-amber-500 to-amber-600',
      icon: Zap
    },
    {
      id: 'social',
      name: 'شبکه‌های اجتماعی',
      color: 'from-pink-500 to-pink-600',
      icon: Star
    },
    {
      id: 'expert',
      name: 'سطح خبره',
      color: 'from-amber-500 to-amber-600',
      icon: Crown
    },
    {
      id: 'general',
      name: 'عمومی',
      color: 'from-gray-500 to-gray-600',
      icon: Trophy
    }
  ];
}