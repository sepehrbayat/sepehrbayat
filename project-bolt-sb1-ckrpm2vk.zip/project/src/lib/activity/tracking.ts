import { trackActivity as trackActivityBase } from './index';
import { calculateAchievements } from './achievements';

export async function trackToolUsage(
  toolId: string,
  title: string,
  description: string | null,
  content: any,
  metadata: Record<string, any> = {}
) {
  try {
    // Format content to match database constraints
    const formattedContent = {
      prompt: content.prompt || '',
      output: content.output || null,
      metadata: content.metadata || {}
    };

    // Calculate points for this activity
    const points = calculatePoints(toolId, content);

    await trackActivityBase(
      'tool_usage',
      title,
      description,
      formattedContent,
      {
        ...metadata,
        tool_id: toolId,
        timestamp: new Date().toISOString(),
        points
      }
    );

    // Update achievements after activity is tracked
    await updateAchievements(toolId, content, points);
  } catch (error) {
    console.error('Error tracking tool usage:', error);
    // Don't throw error to prevent interrupting main flow
  }
}

async function updateAchievements(toolId: string, content: any, points: number) {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    // Get current achievements
    const { data: activities } = await supabase
      .from('user_activity')
      .select('*')
      .eq('user_id', user.id);

    if (!activities) return;

    // Calculate new achievements
    const achievements = calculateAchievements(activities);

    // Update unlocked achievements in database
    for (const achievement of achievements) {
      if (achievement.isUnlocked) {
        const { error } = await supabase
          .from('user_achievements')
          .upsert({
            user_id: user.id,
            achievement_id: achievement.id,
            progress: achievement.progress,
            level: achievement.level,
            is_unlocked: true,
            unlocked_at: achievement.unlockedAt || new Date().toISOString()
          }, {
            onConflict: 'user_id,achievement_id'
          });

        if (error) throw error;
      }
    }
  } catch (error) {
    console.error('Error updating achievements:', error);
  }
}

function calculatePoints(toolId: string, content: any): number {
  // Base points for using any tool
  let points = 10;

  // Additional points based on tool type and usage
  switch (toolId) {
    case 'content-pro':
      points += content.wordCount ? Math.floor(content.wordCount / 100) : 0;
      break;
    case 'seo-pro':
      points += 50; // Premium tool bonus
      break;
    case 'image':
      points += 20;
      break;
    case 'analytics':
      points += 30;
      break;
    default:
      points += 5;
  }

  // Bonus points for high quality content
  if (content.seoScore >= 90) points += 50;
  if (content.readabilityScore >= 90) points += 30;

  return points;
}

export { trackActivityBase as trackActivity };