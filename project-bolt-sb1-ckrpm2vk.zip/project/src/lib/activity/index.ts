import { supabase } from '../supabase';
import type { ActivityType, Activity, ActivityFilter, Achievement } from './types';

export async function trackActivity(
  type: ActivityType,
  title: string,
  description: string | null,
  content: any,
  metadata: Record<string, any> = {},
  toolId?: string
): Promise<void> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const { error } = await supabase
      .from('user_activity')
      .insert({
        user_id: user.id,
        type,
        title,
        description,
        content,
        metadata,
        tool_id: toolId
      });

    if (error) throw error;
  } catch (error) {
    console.error('Error tracking activity:', error);
    throw error;
  }
}

export async function getActivities(filters: ActivityFilter = {}): Promise<Activity[]> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    let query = supabase
      .from('user_activity')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    // Apply filters
    if (filters.type) {
      query = query.eq('type', filters.type);
    }
    if (filters.toolId) {
      query = query.eq('tool_id', filters.toolId);
    }
    if (filters.isBookmarked !== undefined) {
      query = query.eq('is_bookmarked', filters.isBookmarked);
    }
    if (filters.isArchived !== undefined) {
      query = query.eq('is_archived', filters.isArchived);
    }
    if (filters.search) {
      query = query.textSearch('search_vector', filters.search);
    }
    if (filters.dateRange) {
      query = query
        .gte('created_at', filters.dateRange.from)
        .lte('created_at', filters.dateRange.to);
    }

    const { data, error } = await query;
    if (error) throw error;

    return data || [];
  } catch (error) {
    console.error('Error getting activities:', error);
    throw error;
  }
}

export async function toggleBookmark(activityId: string): Promise<void> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const { error } = await supabase
      .from('user_activity')
      .update({
        is_bookmarked: true,
        updated_at: new Date().toISOString()
      })
      .eq('id', activityId)
      .eq('user_id', user.id);

    if (error) throw error;
  } catch (error) {
    console.error('Error toggling bookmark:', error);
    throw error;
  }
}

export async function archiveActivity(activityId: string): Promise<void> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const { error } = await supabase
      .from('user_activity')
      .update({
        is_archived: true,
        updated_at: new Date().toISOString()
      })
      .eq('id', activityId)
      .eq('user_id', user.id);

    if (error) throw error;
  } catch (error) {
    console.error('Error archiving activity:', error);
    throw error;
  }
}

export async function deleteActivity(activityId: string): Promise<void> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const { error } = await supabase
      .from('user_activity')
      .delete()
      .eq('id', activityId)
      .eq('user_id', user.id);

    if (error) throw error;
  } catch (error) {
    console.error('Error deleting activity:', error);
    throw error;
  }
}

export async function exportActivityLog(
  filters: ActivityFilter = {}
): Promise<Blob> {
  try {
    const activities = await getActivities(filters);
    
    const exportData = {
      activities,
      metadata: {
        exportDate: new Date().toISOString(),
        filters
      }
    };

    return new Blob([JSON.stringify(exportData, null, 2)], {
      type: 'application/json'
    });
  } catch (error) {
    console.error('Error exporting activity log:', error);
    throw error;
  }
}

export async function getAchievements(): Promise<Achievement[]> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const { data, error } = await supabase
      .from('user_activity')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];

  } catch (error) {
    console.error('Error getting achievements:', error);
    throw error;
  }
}