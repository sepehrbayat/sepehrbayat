export type ActivityType = 
  | 'chat'
  | 'content_generation'
  | 'image_generation'
  | 'video_generation'
  | 'seo_analysis'
  | 'data_analysis'
  | 'tool_usage'
  | 'file_upload'
  | 'file_download';

export interface Activity {
  id: string;
  user_id: string;
  type: ActivityType;
  title: string;
  description: string | null;
  content: any;
  metadata: Record<string, any>;
  tool_id?: string;
  is_bookmarked: boolean;
  is_archived: boolean;
  created_at: string;
  updated_at: string;
  expires_at: string;
  points?: number;
  achievements?: {
    id: string;
    title: string;
    description: string;
    points: number;
    unlockedAt: string;
  }[];
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: any;
  category: 'content' | 'seo' | 'analytics' | 'ai' | 'general' | 'social' | 'expert';
  color: string;
  points: number;
  maxLevel: number;
  conditions: {
    type: string;
    target: number;
    current: number;
  }[];
  rewards?: {
    title: string;
    description: string;
    icon: any;
  }[];
  requiredAchievements?: string[];
}

export interface ActivityFilter {
  type?: ActivityType;
  toolId?: string;
  isBookmarked?: boolean;
  isArchived?: boolean;
  search?: string;
  dateRange?: {
    from: string;
    to: string;
  };
  hasAchievements?: boolean;
}