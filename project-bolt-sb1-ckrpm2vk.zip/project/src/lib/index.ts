// Re-export all functionality from a single entry point
export { ValidationError } from './errors';
export * from './validation';
export * from './openai';

// Script generation
export * from './script';

// Image generation
export * from './imageGeneration';

// Export singleton instances
export { scriptService } from './script';
export { imageService, generateImage } from './imageGeneration';
export { openai } from './openai';