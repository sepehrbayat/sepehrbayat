import OpenAI from 'openai';

// Get API key from environment variable
const OPENAI_API_KEY = import.meta.env.VITE_OPENAI_API_KEY;

if (!OPENAI_API_KEY) {
  throw new Error('OpenAI API key is not configured. Please add VITE_OPENAI_API_KEY to your .env file.');
}

// Model configurations
// Using cost-optimized models for different use cases
export const MODELS = {
  default: 'gpt-4o-mini', // Fast, affordable small model for focused tasks
  pro: 'gpt-4o', // Fast, intelligent, flexible GPT model
  long: 'gpt-4.5-preview' // Largest and most capable model for complex tasks
} as const;

// Create OpenAI client
export const openai = new OpenAI({
  apiKey: OPENAI_API_KEY,
  maxRetries: 5,
  timeout: 60000, // 60 second timeout
  dangerouslyAllowBrowser: true // Enable browser usage
});

// Export the same client for pro features since we're using the same model
export const openaiPro = openai;

// Default model
export const DEFAULT_MODEL = MODELS.default;

// Export for convenience
export { OpenAI };