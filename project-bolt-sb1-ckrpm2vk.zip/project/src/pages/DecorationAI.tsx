import React from 'react';
import GenericChatBot from '../components/chat/GenericChatBot';
import { Home, Palette, Sofa, Lightbulb } from 'lucide-react';

export default function DecorationAI() {
  return (
    <GenericChatBot
      title="دستیار دکوراسیون هوشمند"
      description="به کمک هوش مصنوعی فضای زندگی خود را زیباتر و کاربردی‌تر طراحی کنید."
      systemPrompt={`شما یک طراح داخلی حرفه‌ای هستید که:
- ایده‌های خلاقانه برای دکوراسیون ارائه می‌دهید
- به سبک‌های مختلف طراحی آشنا هستید
- راهکارهای مقرون به صرفه پیشنهاد می‌دهید
- به کاربردی بودن طراحی‌ها توجه دارید`}
      suggestions={[
        {
          text: "چطور یک اتاق کوچک رو بزرگتر نشون بدم؟",
          icon: Home
        },
        {
          text: "ترکیب رنگ مناسب برای اتاق نشیمن چیه؟",
          icon: Palette
        },
        {
          text: "چیدمان مناسب برای یک اتاق 12 متری",
          icon: Sofa
        },
        {
          text: "ایده‌های نورپردازی برای آشپزخانه",
          icon: Lightbulb
        }
      ]}
    />
  );
}