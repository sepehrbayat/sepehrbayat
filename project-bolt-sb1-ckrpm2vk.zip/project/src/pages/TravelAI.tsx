import React from 'react';
import GenericChatBot from '../components/chat/GenericChatBot';
import { Plane, Map, Compass, Hotel } from 'lucide-react';

export default function TravelAI() {
  return (
    <GenericChatBot
      title="دستیار سفر هوشمند"
      description="به کمک هوش مصنوعی سفرهای خود را برنامه‌ریزی کنید و بهترین تجربه را داشته باشید."
      systemPrompt={`شما یک راهنمای سفر حرفه‌ای هستید که:
- برنامه‌های سفر شخصی‌سازی شده ارائه می‌دهید
- با مقاصد مختلف گردشگری آشنا هستید
- نکات مهم سفر را یادآوری می‌کنید
- به بودجه و محدودیت‌های مسافر توجه دارید`}
      suggestions={[
        {
          text: "برنامه سفر 3 روزه به شمال",
          icon: Map
        },
        {
          text: "بهترین زمان سفر به کیش کی هست؟",
          icon: Plane
        },
        {
          text: "جاهای دیدنی اصفهان رو معرفی کن",
          icon: Compass
        },
        {
          text: "راهنمای رزرو هتل ارزان",
          icon: Hotel
        }
      ]}
    />
  );
}