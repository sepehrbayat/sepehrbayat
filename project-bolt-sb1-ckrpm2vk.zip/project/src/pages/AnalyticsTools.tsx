import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Tool } from '../types';
import { BarChart2, TrendingUp, Target, Brain, LineChart, PieChart, Activity, Zap } from 'lucide-react';
import DataVisualizer from '../components/analytics/DataVisualizer';
import TrendAnalyzer from '../components/analytics/TrendAnalyzer';
import PerformanceTracker from '../components/analytics/PerformanceTracker';
import SmartReports from '../components/analytics/SmartReports';

type ToolType = 'data-visualizer' | 'trend-analyzer' | 'performance-tracker' | 'smart-reports';

export default function AnalyticsTools() {
  const { t } = useTranslation();
  const [selectedTool, setSelectedTool] = React.useState<ToolType | null>(null);

  const tools = [
    {
      id: 'data-visualizer',
      name: t('dashboard.tools.analytics.items.dataVisualizer.title'),
      description: t('dashboard.tools.analytics.items.dataVisualizer.description'),
      icon: BarChart2,
      isNew: true
    },
    {
      id: 'trend-analyzer',
      name: t('dashboard.tools.analytics.items.trendAnalyzer.title'),
      description: t('dashboard.tools.analytics.items.trendAnalyzer.description'),
      icon: TrendingUp,
      isNew: true
    },
    {
      id: 'performance-tracker',
      name: t('dashboard.tools.analytics.items.performanceTracker.title'),
      description: t('dashboard.tools.analytics.items.performanceTracker.description'),
      icon: Target,
      isNew: true
    },
    {
      id: 'smart-reports',
      name: t('dashboard.tools.analytics.items.smartReports.title'),
      description: t('dashboard.tools.analytics.items.smartReports.description'),
      icon: Brain,
      isNew: true,
      isLocked: true
    }
  ];

  const renderTool = () => {
    switch (selectedTool) {
      case 'data-visualizer':
        return <DataVisualizer />;
      case 'trend-analyzer':
        return <TrendAnalyzer />;
      case 'performance-tracker':
        return <PerformanceTracker />;
      case 'smart-reports':
        return <SmartReports />;
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#a63439] to-[#262e43] flex items-center justify-center">
              <BarChart2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-medium mb-1">{t('dashboard.tools.analytics.title')}</h1>
              <p className="text-gray-600">{t('dashboard.tools.analytics.description')}</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-4">
          {tools.map(tool => (
            <button
              key={tool.id}
              onClick={() => !tool.isLocked && setSelectedTool(tool.id as ToolType)}
              className={`relative p-4 rounded-xl text-right transition-all group ${
                selectedTool === tool.id
                  ? 'bg-[#a63439] text-white shadow-lg scale-[1.02]'
                  : 'bg-white hover:bg-gray-50 text-gray-800 hover:scale-[1.02] active:scale-95'
              } ${
                tool.isLocked ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer'
              }`}
            >
              {tool.isNew && (
                <span className="absolute top-2 left-2 bg-[#a63439] text-white text-[10px] px-1.5 py-0.5 rounded-full">
                  {t('common.new')}
                </span>
              )}
              {tool.isLocked && (
                <span className="absolute top-2 left-2 bg-gray-800 text-white text-[10px] px-1.5 py-0.5 rounded-full">
                  {t('common.comingSoon')}
                </span>
              )}
              <tool.icon className={`w-6 h-6 mb-3 ${
                selectedTool === tool.id ? 'text-white' : 'text-[#a63439]'
              }`} />
              <h3 className="text-sm font-medium mb-1">{tool.name}</h3>
              <p className={`text-xs ${
                selectedTool === tool.id ? 'text-white/80' : 'text-gray-500'
              }`}>
                {tool.description}
              </p>
            </button>
          ))}
        </div>

        {renderTool()}
      </div>
    </div>
  );
}