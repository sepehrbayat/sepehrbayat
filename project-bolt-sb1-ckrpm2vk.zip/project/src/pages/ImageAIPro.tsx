import { useState } from 'react';
import { Crown, Star, Download, Wand2, AlertCircle, Sparkles, Brain } from 'lucide-react';
import ImageControls from '../components/image/ImageControls';
import { generateImage } from '../lib/imageGeneration';
import { openai, DEFAULT_MODEL } from '../lib/openai';

export default function ImageAIPro() {
  const [prompt, setPrompt] = useState('');
  const [negativePrompt, setNegativePrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImages, setGeneratedImages] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [enhancedPrompt, setEnhancedPrompt] = useState<string | null>(null);
  const [generationPhase, setGenerationPhase] = useState<'analysis' | 'generation' | 'enhancement' | null>(null);
  const [progressPercent, setProgressPercent] = useState(0);
  const [settings, setSettings] = useState({
    model: 'dall-e-3',
    width: '1024',
    height: '1024',
    quality: 'hd',
    style: 'vivid',
    mood: 'dramatic',
    lighting: 'studio',
    composition: 'balanced',
    perspective: 'front',
    colorScheme: 'vibrant'
  });

  const handleEnhancePrompt = async () => {
    try {
      if (!prompt.trim()) return;
      setError(null);
      setIsEnhancing(true);

      const response = await openai.chat.completions.create({
        model: DEFAULT_MODEL,
        messages: [
          {
            role: 'system',
            content: `شما یک متخصص بهینه‌سازی پرامپت برای تولید تصویر هستید. وظیفه شما بهبود توضیحات کاربر با رعایت این محدودیت‌هاست:

محدودیت‌های اصلی:
1. حداکثر 3 جمله کوتاه و مرتبط
2. تمرکز فقط روی عناصر اصلی تصویر
3. پرهیز از توضیحات غیرضروری

عناصر مجاز برای اضافه کردن:
1. نورپردازی (فقط یک مورد):
   - نور طبیعی
   - نور استودیویی
   - نور درخشان
   - نور ملایم
   - نور دراماتیک

2. زاویه دید (فقط یک مورد):
   - نمای روبرو
   - نمای بالا
   - نمای از پایین
   - نمای نیم‌رخ
   - نمای سه‌رخ

3. فاصله (فقط یک مورد):
   - نمای نزدیک
   - نمای متوسط
   - نمای کامل

4. کیفیت (حداکثر دو مورد):
   - وضوح بالا
   - جزئیات دقیق
   - رنگ‌های زنده
   - کنتراست مناسب`
          },
          {
            role: 'user',
            content: prompt
          }
        ]
      });

      const improvedPrompt = response.choices[0]?.message?.content;
      if (!improvedPrompt) throw new Error('خطا در بهبود پرامپت');
      setEnhancedPrompt(improvedPrompt);

    } catch (error) {
      setError(error instanceof Error ? error.message : 'خطا در بهبود توضیحات');
    } finally {
      setIsEnhancing(false);
    }
  };

  const handleGenerate = async () => {
    try {
      if (!prompt.trim()) {
        throw new Error('لطفاً توضیحات تصویر را وارد کنید');
      }

      setIsGenerating(true);
      setError(null);
      setGeneratedImages([]);
      setGenerationPhase('analysis');
      setProgressPercent(0);

      // Simulate progress
      const progressInterval = setInterval(() => {
        setProgressPercent(prev => {
          if (prev >= 95) {
            clearInterval(progressInterval);
            return prev;
          }
          return prev + 1;
        });
      }, 300);

      // Add quality keywords to ensure better results
      const enhancedPrompt = `${prompt}, masterpiece, best quality, highly detailed, sharp focus, professional lighting, 8k uhd`;

      setGenerationPhase('generation');
      const response = await generateImage({
        prompt: enhancedPrompt,
        width: parseInt(settings.width),
        height: parseInt(settings.height),
        isPro: true,
        quality: settings.quality,
        style: settings.style,
        mood: settings.mood,
        lighting: settings.lighting,
        composition: settings.composition,
        perspective: settings.perspective,
        colorScheme: settings.colorScheme,
        negativePrompt: negativePrompt
      });

      setGenerationPhase('enhancement');
      setGeneratedImages(response.output);
      setProgressPercent(100);

    } catch (error) {
      console.error('Error:', error);
      setError(error instanceof Error ? error.message : 'خطا در تولید تصویر');
    } finally {
      setIsGenerating(false);
      setGenerationPhase(null);
      setProgressPercent(0);
    }
  };

  return (
    <div className="container mx-auto py-6 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="relative overflow-hidden bg-gradient-to-br from-amber-50 via-amber-100 to-amber-50 rounded-2xl p-8 shadow-xl border border-amber-200/50 backdrop-blur-sm">
          {/* Decorative background elements */}
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(251,191,36,0.1)_0%,transparent_50%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_80%,rgba(245,158,11,0.1)_0%,transparent_50%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(252,211,77,0.05)_0%,transparent_70%)]" />
          
          <div className="relative flex items-center gap-6 mb-8">
            <div className="relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-amber-500 to-amber-600 rounded-2xl blur opacity-50 group-hover:opacity-75 transition duration-1000 group-hover:duration-200 animate-tilt" />
              <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 p-1">
                <div className="w-full h-full bg-amber-50 rounded-xl flex items-center justify-center">
                  <Crown className="w-8 h-8 text-amber-600" />
                </div>
              </div>
              <div className="absolute -top-3 -right-3 animate-pulse">
                <Star className="w-6 h-6 text-amber-400 fill-amber-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-3">
                <h1 className="text-3xl font-bold bg-gradient-to-r from-amber-600 via-amber-700 to-amber-800 bg-clip-text text-transparent">
                  هوش پیک پرو
                </h1>
                <div className="flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-amber-600 text-white px-3 py-1 rounded-full shadow-lg">
                  <Star className="w-3 h-3 fill-current" />
                  <span>PRO</span>
                </div>
              </div>
              <p className="text-amber-800 mt-2 text-lg">تولید تصاویر خارق‌العاده با هوش پیک دقیق</p>
              <p className="text-amber-700/80 mt-1 text-sm">تنظیمات پیشرفته برای کنترل کامل روی خروجی</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4 bg-white/50 p-6 rounded-xl border border-amber-200/30 backdrop-blur-sm shadow-xl">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-sm font-medium text-amber-900">توضیحات تصویر</label>
                  <button
                    onClick={handleEnhancePrompt}
                    disabled={isEnhancing || !prompt.trim()}
                    className="flex items-center gap-1 text-sm text-amber-600 hover:text-amber-700 disabled:opacity-50"
                  >
                    <Sparkles className="w-4 h-4" />
                    {isEnhancing ? 'در حال بهینه‌سازی...' : 'بهبود توضیحات'}
                  </button>
                </div>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  className="w-full h-40 bg-white border border-amber-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all duration-300 resize-none"
                  placeholder="توضیحات دقیق و جزئیات تصویر مورد نظر خود را وارد کنید..."
                />
                {enhancedPrompt && (
                  <div className="mt-3 p-4 bg-gradient-to-r from-amber-50 to-amber-100 rounded-xl border border-amber-200">
                    <p className="text-sm text-amber-800 mb-2">توضیحات بهینه شده:</p>
                    <p className="text-sm text-amber-900 mb-3">{enhancedPrompt}</p>
                    <button
                      onClick={() => {
                        setPrompt(enhancedPrompt);
                        setEnhancedPrompt(null);
                      }}
                      className="text-sm text-amber-600 hover:text-amber-700 flex items-center gap-1"
                    >
                      <Sparkles className="w-4 h-4" />
                      اعمال توضیحات جدید
                    </button>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-amber-900 mb-2">پرامپت منفی</label>
                <textarea
                  value={negativePrompt}
                  onChange={(e) => setNegativePrompt(e.target.value)}
                  className="w-full h-32 bg-white border border-amber-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all duration-300 resize-none"
                  placeholder="ویژگی‌هایی که نمی‌خواهید در تصویر باشند را وارد کنید..."
                />
              </div>
            </div>

            <div className="space-y-6 bg-white/50 p-6 rounded-xl border border-amber-200/30 backdrop-blur-sm shadow-xl">
              <ImageControls
                settings={settings}
                onSettingsChange={setSettings}
              />

              <button
                onClick={handleGenerate}
                disabled={isGenerating || !prompt.trim()}
                className="w-full bg-gradient-to-r from-amber-500 to-amber-600 text-white p-4 rounded-xl flex items-center justify-center gap-2 hover:opacity-90 transition-all disabled:opacity-50 transform hover:scale-[1.02] active:scale-[0.98] duration-200 shadow-[0_0_15px_rgba(245,158,11,0.3)] hover:shadow-[0_0_25px_rgba(245,158,11,0.5)]"
              >
                {isGenerating ? (
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <div className="absolute inset-0 rounded-full bg-amber-300/20 animate-ping" />
                      <Brain className="w-5 h-5 text-white relative z-10" />
                    </div>
                    <span className="font-medium">هوشِکس در حال خلق تصویر...</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-3 relative">
                    <div className="relative flex items-center">
                      <Crown className="w-5 h-5 text-amber-100" />
                      <Star className="w-4 h-4 text-amber-200 fill-amber-200 absolute -top-2 -right-2 animate-pulse" />
                    </div>
                    <span className="font-medium">تولید تصویر حرفه‌ای</span>
                    <div className="absolute inset-0 bg-gradient-to-r from-amber-400/0 via-amber-400/10 to-amber-400/0 animate-shimmer" />
                  </div>
                )}
        <div className="relative overflow-hidden bg-gradient-to-br from-amber-50 via-amber-100 to-amber-50 rounded-2xl p-8 shadow-xl border border-amber-200/50 backdrop-blur-sm">
          {/* Decorative background elements */}
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(251,191,36,0.1)_0%,transparent_50%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_80%,rgba(245,158,11,0.1)_0%,transparent_50%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(252,211,77,0.05)_0%,transparent_70%)]" />
          
          <div className="relative flex items-center gap-6">
            <div className="relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-amber-500 to-amber-600 rounded-2xl blur opacity-50 group-hover:opacity-75 transition duration-1000 group-hover:duration-200 animate-tilt" />
              <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 p-1">
                <div className="w-full h-full bg-amber-50 rounded-xl flex items-center justify-center">
                  <Crown className="w-8 h-8 text-amber-600" />
                </div>
              </div>
              <div className="absolute -top-3 -right-3 animate-pulse">
                <Star className="w-6 h-6 text-amber-400 fill-amber-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-3">
                <h1 className="text-3xl font-bold bg-gradient-to-r from-amber-600 via-amber-700 to-amber-800 bg-clip-text text-transparent">
                  هوش پیک پرو
                </h1>
                <div className="flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-amber-600 text-white px-3 py-1 rounded-full shadow-lg">
                  <Star className="w-3 h-3 fill-current" />
                  <span>PRO</span>
                </div>
              </div>
              <p className="text-amber-800 mt-2 text-lg">تولید تصاویر خارق‌العاده با هوش پیک دقیق</p>
              <p className="text-amber-700/80 mt-1 text-sm">تنظیمات پیشرفته برای کنترل کامل روی خروجی</p>
            </div>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-center gap-3 text-red-700 animate-fadeIn">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        <GenerationOverlay 
          isVisible={isGenerating}
          progress={progressPercent}
          phase={generationPhase}
        />

        {generatedImages.length > 0 && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center">
                  <Crown className="w-5 h-5 text-white" />
                </div>
                <h2 className="text-xl font-bold bg-gradient-to-r from-amber-700 to-amber-900 bg-clip-text text-transparent">
                  تصاویر تولید شده
                </h2>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 bg-gradient-to-r from-amber-500 to-amber-600 text-white text-xs px-2 py-0.5 rounded-full">
                  <Star className="w-3 h-3 fill-current" />
                  <span>هوش پیک دقیق</span>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {generatedImages.map((image, index) => (
                <div key={index} className="relative group transform hover:scale-[1.02] transition-all duration-300">
                  <div className="relative rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300">
                    <img
                      src={image}
                      alt={`تصویر ${index + 1}`}
                      className="w-full aspect-square object-cover transform transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-amber-950/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                    <a
                      href={image}
                      download={`hooshex-pro-${index + 1}.png`}
                      className="absolute bottom-4 right-4 bg-gradient-to-r from-amber-500 to-amber-600 text-white p-3 rounded-lg opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-500 hover:shadow-lg"
                    >
                      <Download className="w-5 h-5" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}