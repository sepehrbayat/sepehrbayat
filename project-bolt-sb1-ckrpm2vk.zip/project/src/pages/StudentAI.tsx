import React, { useState } from 'react';
import { FileText, BookOpen, GraduationCap } from 'lucide-react';
import ArticleReview from './student/ArticleReview';
import ThesisConsultation from './student/ThesisConsultation';
import AdvisorSimulator from './student/AdvisorSimulator';

type Tool = 'article-review' | 'thesis-consultation' | 'advisor-simulator';

export default function StudentAI() {
  const [selectedTool, setSelectedTool] = useState<Tool | null>(null);

  const tools = [
    {
      id: 'article-review' as Tool,
      name: 'اشکالات مقاله',
      description: 'بررسی و اصلاح مقالات علمی',
      icon: FileText
    },
    {
      id: 'thesis-consultation' as Tool,
      name: 'مشاوره پایان‌نامه',
      description: 'راهنمایی در نگارش پایان‌نامه',
      icon: BookOpen
    },
    {
      id: 'advisor-simulator' as Tool,
      name: 'شبیه‌ساز استاد راهنما',
      description: 'مشاوره و راهنمایی مانند یک استاد',
      icon: GraduationCap
    }
  ];

  const renderTool = () => {
    switch (selectedTool) {
      case 'article-review':
        return <ArticleReview />;
      case 'thesis-consultation':
        return <ThesisConsultation />;
      case 'advisor-simulator':
        return <AdvisorSimulator />;
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <h1 className="text-2xl font-medium mb-2">دستیار دانشجو</h1>
          <p className="text-gray-600">به کمک هوش مصنوعی در مسیر تحصیلی خود راهنمایی بگیرید.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {tools.map(tool => (
            <button
              key={tool.id}
              onClick={() => setSelectedTool(tool.id)}
              className={`p-6 rounded-xl text-right transition-all ${
                selectedTool === tool.id
                  ? 'bg-[#a63439] text-white shadow-lg scale-[1.02]'
                  : 'bg-white hover:bg-gray-50 text-gray-800 hover:scale-[1.02]'
              }`}
            >
              <tool.icon className={`w-8 h-8 mb-4 ${
                selectedTool === tool.id ? 'text-white' : 'text-[#a63439]'
              }`} />
              <h3 className="text-lg font-medium mb-2">{tool.name}</h3>
              <p className={`text-sm ${
                selectedTool === tool.id ? 'text-white/80' : 'text-gray-500'
              }`}>
                {tool.description}
              </p>
            </button>
          ))}
        </div>

        {renderTool()}
      </div>
    </div>
  );
}