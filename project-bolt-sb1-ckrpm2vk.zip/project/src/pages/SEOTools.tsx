import React from 'react';
import { useTranslation } from 'react-i18next';
import { Search, FileText, BarChart2, Globe, Sparkles, Crown, Star, ArrowRight } from 'lucide-react';
import SEOAnalyzer from './SEOAnalyzer';
import SEOProAnalyzer from '../components/seo/SEOProAnalyzer';
import KeywordResearch from '../components/seo/tools/KeywordResearch';
import ContentOptimizer from '../components/seo/tools/ContentOptimizer';
import CompetitorAnalysis from '../components/seo/tools/CompetitorAnalysis';

type Tool = 'analyzer' | 'analyzer-pro' | 'keywords' | 'content' | 'competitors';

export default function SEOTools() {
  const { t } = useTranslation();
  const [selectedTool, setSelectedTool] = React.useState<Tool>('analyzer');

  const tools = [
    {
      id: 'analyzer-pro' as Tool,
      name: t('dashboard.tools.seo.items.seoPro.title'),
      description: t('dashboard.tools.seo.items.seoPro.description'),
      icon: Crown,
      isNew: true,
      isPro: true
    },
    {
      id: 'analyzer' as Tool,
      name: t('dashboard.tools.seo.items.seoBasic.title'),
      description: t('dashboard.tools.seo.items.seoBasic.description'),
      icon: Search,
      isNew: true
    },
    {
      id: 'keywords' as Tool,
      name: t('dashboard.tools.seo.items.keywordResearch.title'),
      description: t('dashboard.tools.seo.items.keywordResearch.description'),
      icon: Sparkles,
      isNew: true
    },
    {
      id: 'content' as Tool,
      name: t('dashboard.tools.seo.items.contentOptimizer.title'),
      description: t('dashboard.tools.seo.items.contentOptimizer.description'),
      icon: FileText,
      isNew: true
    },
    {
      id: 'competitors' as Tool,
      name: t('dashboard.tools.seo.items.competitorAnalysis.title'),
      description: t('dashboard.tools.seo.items.competitorAnalysis.description'),
      icon: BarChart2,
      isNew: true
    }
  ];

  const renderTool = () => {
    switch (selectedTool) {
      case 'analyzer-pro':
        return <SEOProAnalyzer />;
      case 'analyzer':
        return <SEOAnalyzer />;
      case 'keywords':
        return <KeywordResearch />;
      case 'content':
        return <ContentOptimizer />;
      case 'competitors':
        return <CompetitorAnalysis />;
      default:
        return null;
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
        <div className="relative overflow-hidden bg-gradient-to-br from-[#a63439]/5 via-white to-[#262e43]/5 rounded-2xl p-8 shadow-xl border border-[#a63439]/10 backdrop-blur-sm">
          {/* Decorative background elements */}
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(166,52,57,0.1)_0%,transparent_50%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_80%,rgba(38,46,67,0.1)_0%,transparent_50%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.8)_0%,transparent_70%)]" />
          
          <div className="relative flex items-center gap-6">
            <div className="relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-[#a63439] to-[#262e43] rounded-2xl blur opacity-50 group-hover:opacity-75 transition duration-1000 group-hover:duration-200 animate-tilt" />
              <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-br from-[#a63439] to-[#262e43] p-1">
                <div className="w-full h-full bg-white rounded-xl flex items-center justify-center">
                  <Search className="w-8 h-8 text-[#a63439]" />
                </div>
              </div>
              <div className="absolute -top-3 -right-3 animate-pulse">
                <div className="w-6 h-6 rounded-full bg-[#a63439] flex items-center justify-center">
                  <Sparkles className="w-3 h-3 text-white" />
                </div>
              </div>
            </div>
            <div>
              <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold bg-gradient-to-l from-[#a63439] via-[#8a2a2e] to-[#262e43] bg-clip-text text-transparent">
                {t('dashboard.tools.seo.title')}
              </h2>
              <p className="text-base md:text-lg mt-2 text-gray-600">
                {t('dashboard.tools.seo.description')}
              </p>
              <div className="flex items-center gap-3 mt-4">
                <div className="flex items-center gap-1.5 bg-[#a63439]/10 text-[#a63439] px-3 py-1 rounded-full text-sm">
                  <Search className="w-4 h-4" />
                  <span>تحلیل هوشمند</span>
                </div>
                <div className="flex items-center gap-1.5 bg-[#262e43]/10 text-[#262e43] px-3 py-1 rounded-full text-sm">
                  <Sparkles className="w-4 h-4" />
                  <span>بهینه‌سازی خودکار</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-6">
          {tools.map(tool => (
            <button
              key={tool.id}
              onClick={() => setSelectedTool(tool.id)}
              className={`relative p-6 rounded-xl text-right transition-all group ${
                selectedTool === tool.id
                  ? 'bg-gradient-to-br from-[#a63439] to-[#8a2a2e] text-white shadow-lg scale-[1.02]'
                  : 'bg-white hover:bg-gray-50/80 text-gray-800 hover:shadow-lg hover:scale-[1.02]'
              }`}
            >
              {tool.isNew && (
                <span className="absolute top-2 left-2 bg-[#a63439] text-white text-[10px] px-1.5 py-0.5 rounded-full">
                  {t('common.new')}
                </span>
              )}
              {tool.isPro && (
                <div className="absolute top-2 left-2 bg-gradient-to-r from-amber-500 to-amber-600 text-white text-xs px-2 py-0.5 rounded-full flex items-center gap-1">
                  <Star className="w-2.5 h-2.5 fill-current" />
                  <span>PRO</span>
                </div>
              )}
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${
                selectedTool === tool.id 
                  ? 'bg-white/90 text-[#a63439]' 
                  : 'bg-[#a63439]/5 text-[#a63439] group-hover:bg-[#a63439]/10 transition-colors'
              }`}>
                <tool.icon className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-medium mb-2">{tool.name}</h3>
              <p className={`text-sm ${
                selectedTool === tool.id ? 'text-white/80' : 'text-gray-500'
              }`}>
                {tool.description}
              </p>
              <div className="mt-4 flex items-center gap-2 text-[#a63439] group-hover:translate-x-1 transition-transform">
                <span className={`text-sm ${
                  selectedTool === tool.id ? 'text-white/90' : 'text-[#a63439]'
                }`}>مشاهده ابزار</span>
                <ArrowRight className={`w-4 h-4 ${
                  selectedTool === tool.id ? 'text-white/90' : 'text-[#a63439]'
                }`} />
              </div>
            </button>
          ))}
        </div>

        {renderTool()}
      </div>
  );
}