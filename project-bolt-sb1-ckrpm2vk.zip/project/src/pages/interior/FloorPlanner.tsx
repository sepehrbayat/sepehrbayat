import React, { useState } from 'react';
import { Upload, Download, Wand2, AlertCircle } from 'lucide-react';

interface GenerateResponse {
  status: string;
  output: string[];
  proxy_links: string[];
}

export default function FloorPlanner() {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImages, setGeneratedImages] = useState<string[]>([]);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        setError('لطفاً فقط فایل تصویری آپلود کنید');
        return;
      }
      
      if (file.size > 10 * 1024 * 1024) {
        setError('حجم فایل نباید بیشتر از 10 مگابایت باشد');
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result as string);
        setError(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerate = async () => {
    try {
      if (!prompt.trim() || !uploadedImage) {
        throw new Error('لطفاً تصویر و توضیحات را وارد کنید');
      }

      setIsGenerating(true);
      setError(null);
      setGeneratedImages([]);

      const response = await fetch('https://modelslab.com/api/v6/interior/floor_planning', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          key: "DIT0j1BOjKT9OSLc5d2dnHYpTqrNjhXVxGba5toE6Z5pWJiVM2uDbYdHpr2r",
          init_image: uploadedImage,
          prompt: `rendering floor plan of the apartment layout, ${prompt}, top view, white background, masterpiece, best quality, extremely detailed, best illustration, best shadow`,
          seed: Math.floor(Math.random() * 2147483647),
          guidance_scale: 8,
          strength: 0.99,
          num_inference_steps: 51,
          base64: false,
          temp: false
        })
      });

      if (!response.ok) {
        throw new Error('خطا در ارتباط با سرور');
      }

      const data: GenerateResponse = await response.json();
      
      if (data.status !== 'success' || !data.output?.length) {
        throw new Error('خطا در تولید نقشه');
      }

      setGeneratedImages(data.output);

    } catch (error) {
      console.error('Error:', error);
      setError(error instanceof Error ? error.message : 'خطا در تولید نقشه');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl p-6 space-y-6">
        <div>
          <label className="block text-sm font-medium mb-2">توضیحات نقشه</label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="w-full h-32 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 resize-none"
            placeholder="مثال: آپارتمان 120 متری با 2 اتاق خواب، سالن پذیرایی L شکل، آشپزخانه اوپن، سرویس بهداشتی مجزا، تراس 10 متری رو به جنوب، و فضای مطالعه در کنار پذیرایی"
          />
        </div>

        <div className="flex items-center gap-4">
          <div className="flex-1">
            <label
              htmlFor="floor-image"
              className={`relative flex flex-col items-center justify-center gap-2 w-full bg-gray-50 border-2 border-dashed ${
                uploadedImage ? 'border-[#a63439]' : 'border-gray-200'
              } rounded-lg p-4 cursor-pointer hover:bg-gray-100 transition-all group`}
            >
              {uploadedImage ? (
                <>
                  <img 
                    src={uploadedImage} 
                    alt="تصویر نقشه"
                    className="w-full h-32 object-contain rounded"
                  />
                  <span className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 text-white opacity-0 group-hover:opacity-100 transition-opacity rounded-lg">
                    تغییر تصویر
                  </span>
                </>
              ) : (
                <>
                  <Upload className="w-6 h-6 text-gray-500" />
                  <span className="text-sm text-gray-600">آپلود تصویر نقشه (حداکثر 10MB)</span>
                </>
              )}
            </label>
            <input
              id="floor-image"
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
          </div>
          <button
            onClick={handleGenerate}
            disabled={isGenerating || !prompt.trim() || !uploadedImage}
            className="bg-[#a63439] text-white px-6 py-4 rounded-lg flex items-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
          >
            <Wand2 className="w-5 h-5" />
            {isGenerating ? 'در حال تولید نقشه...' : 'تولید نقشه'}
          </button>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {generatedImages.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-lg font-medium">نقشه‌های تولید شده</h2>
            <div className="grid grid-cols-2 gap-4">
              {generatedImages.map((image, index) => (
                <div key={index} className="relative group">
                  <img
                    src={image}
                    alt={`نقشه ${index + 1}`}
                    className="w-full rounded-lg shadow-md"
                  />
                  <a
                    href={image}
                    download={`floor-plan-${index + 1}.png`}
                    className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-lg"
                  >
                    <Download className="w-6 h-6 text-white" />
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}