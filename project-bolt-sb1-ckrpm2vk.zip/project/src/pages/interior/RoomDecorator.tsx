import React, { useState } from 'react';
import { Download, Wand2, AlertCircle, Sparkles } from 'lucide-react';
import ImageUploader from '../../components/interior/ImageUploader';
import { openai } from '../../lib/openai';
import { interiorService } from '../../lib/interior';

interface GenerateResponse {
  status: string;
  output: string[];
  proxy_links: string[];
}

export default function RoomDecorator() {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImages, setGeneratedImages] = useState<string[]>([]);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadedImageUrl, setUploadedImageUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [enhancedPrompt, setEnhancedPrompt] = useState<string | null>(null);

  const handleEnhancePrompt = async () => {
    try {
      if (!prompt.trim()) return;
      setError(null);
      setIsEnhancing(true);

      const response = await openai.chat.completions.create({
        model: 'ModelsLab/Mixtral-8x7B-Instruct',
        messages: [
          {
            role: 'system',
            content: `شما یک متخصص دکوراسیون داخلی هستید. لطفاً توضیحات کاربر را برای تولید تصویر بهتر بهینه کنید.

نکات مهم:
1. به این موارد توجه کنید:
   - سبک دکوراسیون
   - رنگ‌ها و بافت‌ها
   - مبلمان و لوازم
   - نورپردازی
   - چیدمان

2. ساختار پاسخ:
   - توضیحات دقیق و تخصصی
   - تمرکز بر جزئیات مهم
   - حفظ ایده اصلی کاربر`
          },
          {
            role: 'user',
            content: prompt
          }
        ]
      });

      const enhancedText = response.choices[0]?.message?.content;
      if (!enhancedText) throw new Error('خطا در بهبود توضیحات');
      setEnhancedPrompt(enhancedText);

    } catch (error) {
      setError(error instanceof Error ? error.message : 'خطا در بهبود توضیحات');
    } finally {
      setIsEnhancing(false);
    }
  };

  const handleGenerate = async () => {
    try {
      if (!prompt.trim() || !uploadedImage) {
        throw new Error('لطفاً تصویر و توضیحات را وارد کنید');
      }

      setIsGenerating(true);
      setError(null);
      setGeneratedImages([]);

      const images = await interiorService.generateDesign({
        image: uploadedImage,
        prompt: prompt,
        style: 'modern'
      });

      setGeneratedImages(images);

    } catch (error) {
      console.error('Error:', error);
      setError(error instanceof Error ? error.message : 'خطا در تولید تصویر');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl p-6 space-y-6">
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="block text-sm font-medium">توضیحات دکوراسیون</label>
            <button
              onClick={handleEnhancePrompt}
              disabled={isEnhancing || !prompt.trim()}
              className="flex items-center gap-1 text-sm text-[#a63439] hover:text-[#8a2a2e] disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4" />
              {isEnhancing ? 'در حال بهینه‌سازی...' : 'بهبود توضیحات'}
            </button>
          </div>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="w-full h-32 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 resize-none"
            placeholder="مثال: دکوراسیون اتاق خواب به سبک اسکاندیناوی با تخت دو نفره چوبی، کمد دیواری سفید، پاتختی‌های چوب روشن، فرش طرح هندسی، پرده‌های کتان کرم رنگ و چراغ‌های آویز در دو طرف تخت"
          />
          {enhancedPrompt && (
            <div className="mt-2 p-3 bg-[#a63439]/5 border border-[#a63439]/10 rounded-lg">
              <p className="text-sm text-gray-600 mb-2">توضیحات بهینه شده:</p>
              <p className="text-sm mb-2">{enhancedPrompt}</p>
              <button
                onClick={() => {
                  setPrompt(enhancedPrompt);
                  setEnhancedPrompt(null);
                }}
                className="text-sm text-[#a63439] hover:text-[#8a2a2e] flex items-center gap-1"
              >
                <Sparkles className="w-4 h-4" />
                اعمال توضیحات جدید
              </button>
            </div>
          )}
        </div>

        <div className="flex items-center gap-4">
          <div className="flex-1">
            <ImageUploader
              onImageSelect={setUploadedImage}
              placeholder="آپلود تصویر اتاق"
              error={error}
            />
          </div>
          <button
            onClick={handleGenerate}
            disabled={isGenerating || !prompt.trim() || !uploadedImage}
            className="bg-[#a63439] text-white px-6 py-4 rounded-lg flex items-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
          >
            <Wand2 className="w-5 h-5" />
            {isGenerating ? 'در حال طراحی...' : 'شروع طراحی'}
          </button>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {generatedImages.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-lg font-medium">طراحی‌های تولید شده</h2>
            <div className="grid grid-cols-2 gap-4">
              {generatedImages.map((image, index) => (
                <div key={index} className="relative group">
                  <img
                    src={image}
                    alt={`طراحی ${index + 1}`}
                    className="w-full rounded-lg shadow-md"
                  />
                  <a
                    href={image}
                    download={`room-design-${index + 1}.png`}
                    className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-lg"
                  >
                    <Download className="w-6 h-6 text-white" />
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}