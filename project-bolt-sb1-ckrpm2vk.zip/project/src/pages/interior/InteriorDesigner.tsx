import React, { useState } from 'react';
import { Download, Wand2, AlertCircle, Sparkles } from 'lucide-react';
import ImageUploader from '../../components/interior/ImageUploader';
import { openai } from '../../lib/openai';
import { interiorService } from '../../lib/interior';

interface GenerateResponse {
  status: string;
  output: string[];
  proxy_links: string[];
}

export default function InteriorDesigner() {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImages, setGeneratedImages] = useState<string[]>([]);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [enhancedPrompt, setEnhancedPrompt] = useState<string | null>(null);
  const [isImageUploading, setIsImageUploading] = useState(false);
  const [isPolling, setIsPolling] = useState(false);
  const [pollProgress, setPollProgress] = useState(0);
  const [progress, setProgress] = useState<string>('');
  const [pollUrl, setPollUrl] = useState<string | null>(null);

  const startPolling = async (url: string) => {
    setPollUrl(url);
    let attempts = 0;
    const maxAttempts = 30; // 5 minutes with 10s interval
    
    while (attempts < maxAttempts) {
      try {
        await new Promise(resolve => setTimeout(resolve, 10000)); // Wait 10 seconds
        
        const pollResponse = await fetch(url, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'key': "DIT0j1BOjKT9OSLc5d2dnHYpTqrNjhXVxGba5toE6Z5pWJiVM2uDbYdHpr2r"
          }
        });
        
        if (!pollResponse.ok) {
          throw new Error(`Polling error! status: ${pollResponse.status}`);
        }
        
        const pollData = await pollResponse.json();
        
        if (pollData.status === 'success' && pollData.output?.length > 0) {
          setGeneratedImages(pollData.output);
          setPollUrl(null);
          setIsGenerating(false);
          setProgress('');
          return;
        }
        
        if (pollData.status === 'failed' || pollData.error) {
          throw new Error(pollData.error?.message || 'خطا در پردازش تصویر');
        }
        
        attempts++;
        setProgress(`در حال پردازش... (تلاش ${attempts} از ${maxAttempts})`);
        
      } catch (error) {
        setPollUrl(null);
        setIsGenerating(false);
        setProgress('');
        throw error;
      }
    }
    
    setPollUrl(null);
    setIsGenerating(false);
    setProgress('');
    throw new Error('زمان انتظار به پایان رسید');
  };

  const handleEnhancePrompt = async () => {
    try {
      if (!prompt.trim()) return;
      setError(null);
      setIsEnhancing(true);

      const response = await openai.chat.completions.create({
        model: 'ModelsLab/Mixtral-8x7B-Instruct',
        messages: [
          {
            role: 'system',
            content: `شما یک متخصص طراحی داخلی هستید. لطفاً توضیحات کاربر را برای تولید تصویر بهتر بهینه کنید.

نکات مهم:
1. به این موارد توجه کنید:
   - سبک طراحی (مدرن، کلاسیک، مینیمال و...)
   - رنگ‌ها و متریال‌ها
   - نورپردازی
   - چیدمان فضا
   - جزئیات دکوراتیو

2. ساختار پاسخ:
   - توضیحات دقیق و تخصصی
   - تمرکز بر جزئیات مهم
   - حفظ ایده اصلی کاربر`
          },
          {
            role: 'user',
            content: prompt
          }
        ]
      });

      const enhancedText = response.choices[0]?.message?.content;
      if (!enhancedText) throw new Error('خطا در بهبود توضیحات');
      setEnhancedPrompt(enhancedText);

    } catch (error) {
      setError(error instanceof Error ? error.message : 'خطا در بهبود توضیحات');
    } finally {
      setIsEnhancing(false);
    }
  };

  const handleGenerate = async () => {
    try {
      if (!prompt.trim()) {
        throw new Error('لطفاً توضیحات طراحی را وارد کنید');
      }
      
      if (!uploadedImage) {
        throw new Error('لطفاً تصویر اتاق را آپلود کنید');
      }

      setIsGenerating(true);
      setError(null);
      setGeneratedImages([]);
      setPollUrl(null);
      setProgress('در حال آماده‌سازی...');

      try {
        const images = await interiorService.generateDesign({
          image: uploadedImage,
          prompt: prompt.trim(),
          style: 'modern'
        });
        
        if (!Array.isArray(images) || images.length === 0) {
          throw new Error('خطا در دریافت تصاویر');
        }

        setGeneratedImages(images);
        setProgress('');
      } catch (error) {
        if (error.code === 'RATE_LIMIT' || error.message.includes('try again')) {
          setProgress('محدودیت سرور. لطفاً چند ثانیه صبر کنید...');
          // Wait 20 seconds before retrying
          await new Promise(resolve => setTimeout(resolve, 20000));
          return handleGenerate();
        }
        throw error;
      }

    } catch (error) {
      // Enhanced error logging
      console.error('Interior design error details:', {
        error,
        type: typeof error,
        message: error?.message,
        stack: error?.stack,
        prompt: prompt,
        timestamp: new Date().toISOString()
      });
      
      let errorMessage = 'خطا در تولید تصویر. لطفاً دوباره تلاش کنید';
      
      if (error instanceof Error) {
        if (error.message.includes('rate limit')) {
          errorMessage = 'محدودیت تعداد درخواست. لطفاً 20 ثانیه صبر کنید و دوباره تلاش کنید';
        } else if (error.message.includes('timeout')) {
          errorMessage = 'زمان پاسخگویی به پایان رسید. لطفاً دوباره تلاش کنید';
        } else if (error.message.includes('network')) {
          errorMessage = 'خطا در ارتباط با سرور. لطفاً اتصال اینترنت خود را بررسی کنید';
        } else if (error.message.includes('processing')) {
          errorMessage = 'خطا در پردازش تصویر. لطفاً دوباره تلاش کنید';
        } else if (error.message.includes('invalid')) {
          errorMessage = 'پاسخ نامعتبر از سرور. لطفاً دوباره تلاش کنید';
        } else if (error.message.includes('try again')) {
          errorMessage = 'سرور در حال پردازش درخواست‌های دیگر است. لطفاً 20 ثانیه صبر کنید و دوباره تلاش کنید';
        } else {
          errorMessage = error.message;
        }
      }
      
      setError(errorMessage);
      // Clear progress message on error
      setProgress('');
    } finally {
      // Only stop loading if we're not polling
      if (!pollUrl) setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl p-6 space-y-6">
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="block text-sm font-medium">توضیحات طراحی</label>
            <button
              onClick={handleEnhancePrompt}
              disabled={isEnhancing || !prompt.trim()}
              className="flex items-center gap-1 text-sm text-[#a63439] hover:text-[#8a2a2e] disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4" />
              {isEnhancing ? 'در حال بهینه‌سازی...' : 'بهبود توضیحات'}
            </button>
          </div>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="w-full h-32 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 resize-none focus:outline-none focus:ring-2 focus:ring-[#a63439] transition-all"
            placeholder="مثال: یک اتاق نشیمن مدرن با مبلمان راحتی خاکستری، دیوارهای سفید، پنجره‌های بزرگ، پرده‌های حریر، گلدان‌های طبیعی و نورپردازی غیرمستقیم. سبک مینیمال با تأکید بر فضای باز و نور طبیعی."
          />
          {enhancedPrompt && (
            <div className="mt-2 p-3 bg-[#a63439]/5 border border-[#a63439]/10 rounded-lg">
              <p className="text-sm text-gray-600 mb-2">توضیحات بهینه شده:</p>
              <p className="text-sm mb-2">{enhancedPrompt}</p>
              <button
                onClick={() => {
                  setPrompt(enhancedPrompt);
                  setEnhancedPrompt(null);
                }}
                className="text-sm text-[#a63439] hover:text-[#8a2a2e] flex items-center gap-1"
              >
                <Sparkles className="w-4 h-4" />
                اعمال توضیحات جدید
              </button>
            </div>
          )}
        </div>

        <div className="flex items-center gap-4">
          <div className="flex-1">
            <ImageUploader
              onImageSelect={setUploadedImage}
              onImageFile={setImageFile}
              onUploadStateChange={setIsImageUploading}
              placeholder="آپلود تصویر اتاق"
              error={error}
            />
          </div>
          <button
            onClick={handleGenerate}
            disabled={isGenerating || !prompt.trim() || !uploadedImage || !imageFile || isImageUploading}
            className="bg-[#a63439] text-white px-6 py-4 rounded-lg flex items-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
          >
            <Wand2 className="w-5 h-5" />
            {isGenerating ? 'در حال طراحی...' : 
             isImageUploading ? 'در حال آپلود تصویر...' :
             isPolling ? `در حال پردازش (${Math.round(pollProgress)}%)` :
             'شروع طراحی'}
          </button>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {generatedImages.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-lg font-medium">طراحی‌های تولید شده</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {generatedImages.map((image, index) => (
                <div key={index} className="relative group">
                  <div className="aspect-square relative">
                    <img
                      src={image}
                      alt={`طراحی ${index + 1}`}
                      className="absolute inset-0 w-full h-full object-contain rounded-lg shadow-md"
                      onError={(e) => {
                        console.error('Image load error:', e);
                        const target = e.target as HTMLImageElement;
                        target.src = 'https://via.placeholder.com/512x512?text=خطا+در+بارگذاری+تصویر';
                      }}
                    />
                  </div>
                  <a
                    href={image}
                    download={`interior-design-${index + 1}.png`}
                    className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-lg cursor-pointer"
                    onClick={(e) => {
                      e.preventDefault();
                      window.open(image, '_blank');
                    }}
                  >
                    <Download className="w-6 h-6 text-white" />
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}
        {progress && (
          <div className="flex items-center justify-center gap-3 text-gray-600">
            <div className="animate-spin rounded-full h-4 w-4 border-2 border-[#a63439] border-t-transparent" />
            <p>{progress}</p>
          </div>
        )}
      </div>
    </div>
  );
}