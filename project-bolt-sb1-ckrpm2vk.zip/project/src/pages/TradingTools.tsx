import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Tool } from '../types';
import { TrendingUp, Brain, LineChart, BarChart2, PieChart, Target } from 'lucide-react';
import TechnicalAnalyzer from './trading/TechnicalAnalyzer';
import PatternRecognizer from './trading/PatternRecognizer';
import SentimentAnalyzer from './trading/SentimentAnalyzer';
import PortfolioOptimizer from './trading/PortfolioOptimizer';

export default function TradingTools() {
  const { t } = useTranslation();
  const [selectedTool, setSelectedTool] = useState<string | null>(null);

  const tradingTools: Tool[] = [
    {
      id: 'technical-analyzer',
      name: t('dashboard.tools.trading.items.technicalAnalyzer.title'),
      description: t('dashboard.tools.trading.items.technicalAnalyzer.description'),
      icon: LineChart,
      color: 'bg-blue-100',
      isNew: true,
      isLocked: true
    },
    {
      id: 'pattern-recognizer',
      name: t('dashboard.tools.trading.items.patternRecognizer.title'),
      description: t('dashboard.tools.trading.items.patternRecognizer.description'),
      icon: Brain,
      color: 'bg-purple-100',
      isNew: true,
      isLocked: true
    },
    {
      id: 'sentiment-analyzer',
      name: t('dashboard.tools.trading.items.sentimentAnalyzer.title'),
      description: t('dashboard.tools.trading.items.sentimentAnalyzer.description'),
      icon: BarChart2,
      color: 'bg-green-100',
      isNew: true,
      isLocked: true
    },
    {
      id: 'portfolio-optimizer',
      name: t('dashboard.tools.trading.items.portfolioOptimizer.title'),
      description: t('dashboard.tools.trading.items.portfolioOptimizer.description'),
      icon: Target,
      color: 'bg-amber-100',
      isNew: true,
      isLocked: true
    }
  ];

  const renderTool = () => {
    switch (selectedTool) {
      case 'technical-analyzer':
        return <TechnicalAnalyzer />;
      case 'pattern-recognizer':
        return <PatternRecognizer />;
      case 'sentiment-analyzer':
        return <SentimentAnalyzer />;
      case 'portfolio-optimizer':
        return <PortfolioOptimizer />;
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#a63439] to-[#262e43] flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-medium mb-1">{t('dashboard.tools.trading.title')}</h1>
              <p className="text-gray-600">{t('dashboard.tools.trading.description')}</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {tradingTools.map(tool => (
            <button
              key={tool.id}
              onClick={() => setSelectedTool(tool.id)}
              className={`bg-white p-6 rounded-xl text-right transition-all hover:shadow-lg hover:scale-[1.02] group relative ${
                tool.isLocked ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer'
              }`}
            >
              <div className={`${tool.color} w-12 h-12 rounded-xl flex items-center justify-center mb-4`}>
                <tool.icon className="w-6 h-6 text-gray-700" />
              </div>
              <h3 className="text-lg font-medium mb-2">{tool.name}</h3>
              <p className="text-sm text-gray-500">{tool.description}</p>
              {tool.isNew && (
                <div className="absolute top-4 left-4 bg-gray-800 text-white text-xs px-2 py-0.5 rounded-full">
                  {t('common.comingSoon')}
                </div>
              )}
            </button>
          ))}
        </div>

        {renderTool()}
      </div>
    </div>
  );
}