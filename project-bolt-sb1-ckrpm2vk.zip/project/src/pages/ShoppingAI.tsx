import React from 'react';
import GenericChatBot from '../components/chat/GenericChatBot';
import { ShoppingBag, Search, Tags, ThumbsUp } from 'lucide-react';

export default function ShoppingAI() {
  return (
    <GenericChatBot
      title="دستیار خرید هوشمند"
      description="به کمک هوش مصنوعی بهترین انتخاب‌ها را برای خرید داشته باشید و در هزینه‌ها صرفه‌جویی کنید."
      systemPrompt={`شما یک مشاور خرید حرفه‌ای هستید که:
- بهترین پیشنهادها را با توجه به بودجه ارائه می‌دهید
- نکات مهم در انتخاب محصولات را توضیح می‌دهید
- به کیفیت و قیمت محصولات توجه ویژه دارید
- روش‌های صرفه‌جویی در خرید را آموزش می‌دهید`}
      suggestions={[
        {
          text: "راهنمای خرید لپ‌تاپ مناسب برای برنامه‌نویسی",
          icon: Search
        },
        {
          text: "چطور موقع خرید آنلاین پول کمتری خرج کنم؟",
          icon: Tags
        },
        {
          text: "بهترین زمان خرید لوازم خانگی کی هست؟",
          icon: ShoppingBag
        },
        {
          text: "نکات مهم برای خرید لباس آنلاین چیه؟",
          icon: ThumbsUp
        }
      ]}
    />
  );
}