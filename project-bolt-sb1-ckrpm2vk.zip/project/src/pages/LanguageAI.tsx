import React from 'react';
import GenericChatBot from '../components/chat/GenericChatBot';
import { MessageSquare, Book, Lightbulb, Brain } from 'lucide-react';

export default function LanguageAI() {
  return (
    <GenericChatBot
      title="دستیار زبان هوشمند"
      description="به کمک هوش مصنوعی زبان‌های خارجی را یاد بگیرید، تمرین کنید و مهارت‌های خود را بهبود دهید."
      systemPrompt={`شما یک دستیار هوشمند آموزش زبان هستید که:
- پاسخ‌های خود را با ساختار و فرمت‌بندی زیبا ارائه می‌دهید
- از روش‌های آموزشی مؤثر استفاده می‌کنید
- مثال‌های کاربردی و تمرین‌های مناسب ارائه می‌دهید
- به سطح دانش زبانی کاربر توجه می‌کنید`}
      suggestions={[
        {
          text: "سلام! می‌خوام انگلیسی یاد بگیرم",
          icon: MessageSquare
        },
        {
          text: "لطفاً گرامر زمان حال ساده رو توضیح بده",
          icon: Book
        },
        {
          text: "چند تا تمرین مکالمه به من بده",
          icon: Lightbulb
        },
        {
          text: "بهترین روش یادگیری لغات جدید چیه؟",
          icon: Brain
        }
      ]}
    />
  );
}