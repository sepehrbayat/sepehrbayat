import React, { useState } from 'react';
import { useTranslation, Trans } from 'react-i18next';
import { Tool } from '../types';
import { Image, FileText, Music, PenTool, Star, Crown } from 'lucide-react';
import ContentAI from './ContentAI';
import ImageAI from './ImageAI';
import ImageAILite from './ImageAILite';
import MusicAI from './MusicAI';

export default function ContentTools() {
  const { t, i18n } = useTranslation();
  const [selectedTool, setSelectedTool] = useState<string | null>(null);

  const contentTools: Tool[] = [
    {
      id: 'content',
      name: 'تولید محتوا',
      description: 'تولید محتوای هوشمند با کمک هوش مصنوعی',
      icon: FileText,
      color: 'bg-emerald-100',
      isNew: true
    },
    {
      id: 'image',
      name: 'هوش پیک پرو',
      description: 'تولید تصویر حرفه‌ای با هوش مصنوعی',
      icon: Image,
      color: 'bg-purple-100',
      isNew: true
    },
    {
      id: 'image-lite',
      name: 'هوش پیک لایت',
      description: 'تولید تصویر ساده با هوش مصنوعی',
      icon: Image,
      color: 'bg-indigo-100',
      isNew: true
    },
    {
      id: 'music',
      name: 'هوش موزیک',
      description: 'تولید و ویرایش موسیقی',
      icon: Music,
      color: 'bg-purple-100',
      isNew: true,
      isLocked: true
    }
  ];

  if (selectedTool === 'content') {
    return <ContentAI />;
  }
  
  if (selectedTool === 'image') {
    return <ImageAI />;
  }

  if (selectedTool === 'image-lite') {
    return <ImageAILite />;
  }

  if (selectedTool === 'music') {
    return <MusicAI />;
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#a63439] to-[#262e43] flex items-center justify-center">
              <PenTool className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-medium mb-1">
                ابزارهای تولید محتوا
              </h1>
              <p className="text-gray-600">
                با کمک هوش مصنوعی محتوای حرفه‌ای تولید کنید
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {contentTools.map(tool => (
            <button
              key={tool.id}
              onClick={() => !tool.isLocked && setSelectedTool(tool.id)}
              className={`bg-white p-6 rounded-xl text-right transition-all hover:shadow-lg hover:scale-[1.02] active:scale-95 group relative ${
                tool.isLocked ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer'
              }`}
            >
              <div className={`${tool.color} w-12 h-12 rounded-xl flex items-center justify-center mb-4`}>
                <tool.icon className="w-6 h-6 text-gray-700" />
              </div>
              <h3 className="text-lg font-medium mb-2">{tool.name}</h3>
              <p className="text-sm text-gray-500">{tool.description}</p>
              {tool.isNew && (
                <div className="absolute top-4 left-4 bg-[#a63439] text-white text-xs px-2 py-0.5 rounded-full">
                  جدید
                </div>
              )}
              {tool.isLocked && (
                <div className="absolute top-4 left-4 bg-gray-800 text-white text-xs px-2 py-0.5 rounded-full">
                  به زودی
                </div>
              )}
              {tool.id === 'content-pro' || tool.id === 'image' && (
                <div className="absolute top-4 left-4 bg-gradient-to-r from-amber-500 to-amber-600 text-white text-xs px-2 py-0.5 rounded-full flex items-center gap-1">
                  <Star className="w-3 h-3 fill-current" />
                  <span>PRO</span>
                </div>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}