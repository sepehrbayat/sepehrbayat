import React, { useState } from 'react';
import { Film } from 'lucide-react';
import { Tool } from '../types';
import ImageToVideo from './ImageToVideo';

export default function VideoTools() {
  const [selectedTool, setSelectedTool] = useState<string | null>(null);

  const videoTools: Tool[] = [
    {
      id: 'image-to-video',
      name: 'تبدیل تصویر به ویدئو',
      description: 'تبدیل تصاویر ثابت به ویدئوهای پویا',
      icon: Film,
      color: 'bg-rose-100',
      isNew: true,
      category: 'video'
    }
      case 'image-to-video':
        return <ImageToVideo />;
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#a63439] to-[#262e43] flex items-center justify-center">
              <Film className="w-5 h-5 text-white" />
            </div>
      id: 'image-to-video',
            <div>
      name: 'تبدیل تصویر به ویدئو',
        </div>
      description: 'تبدیل تصاویر ثابت به ویدئوهای پویا',

      icon: Film,
        {renderTool()}
      color: 'bg-rose-100',
      </div>
      isNew: true,
    </div>
      category: 'video'
  );
}