import React, { useState, useEffect } from 'react';
import { History, Search, Filter, Download, Star, Archive, Trash2, Clock, PenTool as Tool, AlertCircle, Loader2 } from 'lucide-react';
import { getActivities, exportActivityLog, toggleBookmark, archiveActivity, deleteActivity } from '../lib/activity';
import type { Activity, ActivityType, ActivityFilter } from '../lib/activity/types';

export default function ActivityPage() {
  const [activities, setActivities] = useState<Activity[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<ActivityType | 'all'>('all');
  const [showBookmarked, setShowBookmarked] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  useEffect(() => {
    loadActivities();
  }, [selectedType, showBookmarked, searchQuery]);

  const loadActivities = async () => {
    try {
      setIsLoading(true);
      setError(null);

      const filters: ActivityFilter = {};
      if (selectedType !== 'all') {
        filters.type = selectedType;
      }
      if (showBookmarked) {
        filters.isBookmarked = true;
      }
      if (searchQuery) {
        filters.search = searchQuery;
      }

      const data = await getActivities(filters);
      setActivities(data);
    } catch (error) {
      console.error('Error loading activities:', error);
      setError(error instanceof Error ? error.message : 'خطا در دریافت فعالیت‌ها');
    } finally {
      setIsLoading(false);
    }
  };

  const handleExport = async () => {
    try {
      setIsExporting(true);
      const blob = await exportActivityLog({
        type: selectedType !== 'all' ? selectedType : undefined,
        isBookmarked: showBookmarked
      });

      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `activity-log-${new Date().toISOString()}.json`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Error exporting activities:', error);
      setError(error instanceof Error ? error.message : 'خطا در خروجی گرفتن از فعالیت‌ها');
    } finally {
      setIsExporting(false);
    }
  };

  const handleBookmark = async (activityId: string) => {
    try {
      await toggleBookmark(activityId);
      loadActivities();
    } catch (error) {
      console.error('Error toggling bookmark:', error);
      setError(error instanceof Error ? error.message : 'خطا در نشان‌گذاری فعالیت');
    }
  };

  const handleArchive = async (activityId: string) => {
    try {
      await archiveActivity(activityId);
      loadActivities();
    } catch (error) {
      console.error('Error archiving activity:', error);
      setError(error instanceof Error ? error.message : 'خطا در بایگانی فعالیت');
    }
  };

  const handleDelete = async (activityId: string) => {
    try {
      await deleteActivity(activityId);
      loadActivities();
    } catch (error) {
      console.error('Error deleting activity:', error);
      setError(error instanceof Error ? error.message : 'خطا در حذف فعالیت');
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#a63439] to-[#262e43] flex items-center justify-center">
              <History className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-medium mb-1">تاریخچه فعالیت‌ها</h1>
              <p className="text-gray-600">مشاهده و مدیریت فعالیت‌های انجام شده</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 space-y-6">
          {/* Search and Filters */}
          <div className="flex items-center gap-4">
            <div className="flex-1 relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="جستجو در فعالیت‌ها..."
                className="w-full bg-gray-50 border border-gray-200 rounded-lg pr-10 pl-3 py-2"
              />
            </div>
            <button
              onClick={() => setShowBookmarked(!showBookmarked)}
              className={`p-2 rounded-lg transition-colors ${
                showBookmarked ? 'bg-[#a63439] text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <Star className="w-5 h-5" />
            </button>
            <button
              onClick={handleExport}
              disabled={isExporting}
              className="bg-[#a63439] text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
            >
              {isExporting ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>در حال خروجی گرفتن...</span>
                </>
              ) : (
                <>
                  <Download className="w-5 h-5" />
                  <span>خروجی</span>
                </>
              )}
            </button>
          </div>

          {/* Type Filter */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2">
            <button
              onClick={() => setSelectedType('all')}
              className={`px-3 py-1.5 rounded-lg text-sm whitespace-nowrap transition-colors ${
                selectedType === 'all'
                  ? 'bg-[#a63439] text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              همه
            </button>
            <button
              onClick={() => setSelectedType('chat')}
              className={`px-3 py-1.5 rounded-lg text-sm whitespace-nowrap transition-colors ${
                selectedType === 'chat'
                  ? 'bg-[#a63439] text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              گفتگوها
            </button>
            <button
              onClick={() => setSelectedType('content_generation')}
              className={`px-3 py-1.5 rounded-lg text-sm whitespace-nowrap transition-colors ${
                selectedType === 'content_generation'
                  ? 'bg-[#a63439] text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              تولید محتوا
            </button>
            {/* Add more type filters */}
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              <p>{error}</p>
            </div>
          )}

          {/* Activities List */}
          <div className="space-y-4">
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 text-[#a63439] animate-spin" />
              </div>
            ) : activities.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                <History className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>هیچ فعالیتی یافت نشد</p>
              </div>
            ) : (
              activities.map((activity) => (
                <div key={activity.id} className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-lg bg-[#a63439]/10 flex items-center justify-center flex-shrink-0">
                      <Tool className="w-4 h-4 text-[#a63439]" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-4 mb-2">
                        <h3 className="font-medium truncate">{activity.title}</h3>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleBookmark(activity.id)}
                            className={`p-1 rounded-lg transition-colors ${
                              activity.is_bookmarked ? 'text-[#a63439]' : 'text-gray-400 hover:text-[#a63439]'
                            }`}
                          >
                            <Star className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleArchive(activity.id)}
                            className="p-1 rounded-lg text-gray-400 hover:text-[#a63439] transition-colors"
                          >
                            <Archive className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(activity.id)}
                            className="p-1 rounded-lg text-gray-400 hover:text-red-500 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                      {activity.description && (
                        <p className="text-sm text-gray-600 mb-2">{activity.description}</p>
                      )}
                      <div className="flex items-center gap-4 text-xs text-gray-500">
                        <div className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>{new Date(activity.created_at).toLocaleDateString('fa-IR')}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Tool className="w-3 h-3" />
                          <span>{activity.tool_id || 'ابزار نامشخص'}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}