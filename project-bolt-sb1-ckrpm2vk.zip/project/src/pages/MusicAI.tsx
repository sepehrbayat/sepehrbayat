import React, { useState } from 'react';
import { Music, Upload, Download, Wand2, AlertCircle, Brain, Settings2 } from 'lucide-react';
import { generateMusic } from '../lib/music/service';
import { uploadAudioFile } from '../lib/music/upload';

interface MusicSettings {
  sampleRate: number;
  tokenLimit: number;
  base64: boolean;
  tempLinks: boolean;
}

export default function MusicAI() {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedMusic, setGeneratedMusic] = useState<string[]>([]);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [uploadedFileUrl, setUploadedFileUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [settings, setSettings] = useState<MusicSettings>({
    sampleRate: 32000,
    tokenLimit: 512,
    base64: false,
    tempLinks: false
  });

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
        // Reset states
      setUploadError(null);
      setUploadProgress(0);
      setIsUploading(false);
      setUploadedFile(null);
      setUploadedFileUrl(null);

        // Initial validation
      if (!file.type.startsWith('audio/')) {
        setUploadError('لطفاً فقط فایل صوتی آپلود کنید');
        event.target.value = ''; // Reset input
        return;
      }
      
      if (file.size > 10 * 1024 * 1024) {
        setUploadError('حجم فایل نباید بیشتر از 10 مگابایت باشد');
        event.target.value = ''; // Reset input
        return;
      }

      setIsUploading(true);
      setUploadedFile(file);

        try {
          // Start progress simulation
          const progressInterval = setInterval(() => {
            setUploadProgress(prev => Math.min(prev + 5, 95));
          }, 500);

          // Upload file using the dedicated upload service
          const result = await uploadAudioFile(file);
          clearInterval(progressInterval);

          if (result.status === 'error' || !result.url) {
            throw new Error(result.error || 'خطا در آپلود فایل');
          }

          setUploadedFileUrl(result.url);
          setUploadProgress(100);

        } catch (error) {
          console.error('Upload error:', error);
          setUploadError(error instanceof Error ? error.message : 'خطا در آپلود فایل');
          setUploadedFile(null);
          setUploadedFileUrl(null);
          event.target.value = ''; // Reset input
        } finally {
          setIsUploading(false);
        }
    }
  };

  const handleGenerate = async () => {
    try {
      if (!prompt.trim()) {
        throw new Error('لطفاً توضیحات موسیقی را وارد کنید');
      }

      // Format prompt according to documentation
      const formattedPrompt = `${prompt.trim()}, ${
        prompt.toLowerCase().includes('bpm') ? '' : '96 bpm,'
      } high quality, professional production`;

      setIsGenerating(true);
      setError(null);
      setGeneratedMusic([]);

      const response = await generateMusic({
        key: "DIT0j1BOjKT9OSLc5d2dnHYpTqrNjhXVxGba5toE6Z5pWJiVM2uDbYdHpr2r",
        prompt: formattedPrompt,
        referenceAudio: uploadedFileUrl || undefined,
        sampleRate: settings.sampleRate,
        tokenLimit: settings.tokenLimit,
        base64: settings.base64,
        tempLinks: settings.tempLinks
      });
      
      // Handle processing status
      let pollInterval: number | null = null;
      if (response.status === 'processing' && response.fetch_result) {
        // Start polling for results
        let pollAttempts = 0;
        const maxAttempts = 30; // 5 minutes with 10s interval
        
        const pollResult = async () => {
          if (pollAttempts >= maxAttempts) {
            if (pollInterval) window.clearInterval(pollInterval);
            setError('زمان تولید موسیقی به پایان رسید');
            setIsGenerating(false);
            return;
          }
          
          const pollResponse = await fetch(response.fetch_result, {
            headers: {
              'Content-Type': 'application/json',
              'key': "DIT0j1BOjKT9OSLc5d2dnHYpTqrNjhXVxGba5toE6Z5pWJiVM2uDbYdHpr2r"
            }
          });
          
          const data = await pollResponse.json();
          pollAttempts++;
          
          if (data.status === 'success' && data.output?.length > 0) {
            setGeneratedMusic(data.output);
            if (pollInterval) window.clearInterval(pollInterval);
            setIsGenerating(false);
            return;
          }
          
          if (data.status === 'failed' || data.error) {
            if (pollInterval) window.clearInterval(pollInterval);
            setError(data.error?.message || 'خطا در تولید موسیقی');
            setIsGenerating(false);
            return;
          }
          pollAttempts++;
        };
        
        // Start polling every 10 seconds
        pollInterval = window.setInterval(pollResult, 10000);
        // Cleanup on unmount
        return () => {
          if (pollInterval) window.clearInterval(pollInterval);
        };
        return;
      }

      if (response.status === 'success' && Array.isArray(response.output)) {
        setGeneratedMusic(response.output);
        if (response.output.length === 0) {
          throw new Error('هیچ موسیقی‌ای تولید نشد. لطفاً دوباره تلاش کنید.');
        }
      } else {
        throw new Error('خطا در دریافت پاسخ از سرور. لطفاً مجدداً تلاش کنید.');
      }

    } catch (error: any) {
      let errorMessage = 'خطا در تولید موسیقی. لطفاً دوباره تلاش کنید.';
      
      if (error instanceof Error) {
        if (error.message.includes('rate limit')) {
          errorMessage = 'محدودیت تعداد درخواست. لطفاً چند دقیقه صبر کنید';
        } else if (error.message.includes('timeout')) {
          errorMessage = 'زمان پاسخگویی به پایان رسید. لطفاً دوباره تلاش کنید';
        } else if (error.message.includes('network')) {
          errorMessage = 'خطا در ارتباط با سرور. لطفاً اتصال اینترنت خود را بررسی کنید';
        } else {
          errorMessage = error.message;
        }
      }
      
      setError(errorMessage);
      console.error('Music generation error:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="text-2xl font-medium mb-2">هوش موزیک</h1>
          <p className="text-gray-600">به کمک هوش مصنوعی موسیقی تولید کنید.</p>
        </div>

        <div className="bg-white rounded-xl p-6 space-y-6">
          <div className="flex items-center justify-between mb-4">
            <label className="block text-sm font-medium">توضیحات موسیقی</label>
            <button
              onClick={() => setShowSettings(!showSettings)}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <Settings2 className="w-5 h-5 text-gray-500" />
            </button>
          </div>

          {showSettings && (
            <div className="mb-6 p-4 bg-gray-50 rounded-lg space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">نرخ نمونه‌برداری</label>
                <input
                  type="number"
                  value={settings.sampleRate}
                  onChange={(e) => setSettings(s => ({ ...s, sampleRate: parseInt(e.target.value) || 32000 }))}
                  min="10000"
                  max="32000"
                  step="1000"
                  className="w-full bg-white border border-gray-200 rounded-lg px-3 py-2"
                />
                <p className="text-xs text-gray-500 mt-1">بین 10000 تا 32000 هرتز</p>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">محدودیت توکن</label>
                <input
                  type="number"
                  value={settings.tokenLimit}
                  onChange={(e) => setSettings(s => ({ ...s, tokenLimit: parseInt(e.target.value) || 512 }))}
                  min="256"
                  max="1024"
                  step="32"
                  className="w-full bg-white border border-gray-200 rounded-lg px-3 py-2"
                />
                <p className="text-xs text-gray-500 mt-1">بین 256 تا 1024 توکن</p>
              </div>

              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={settings.base64}
                    onChange={(e) => setSettings(s => ({ ...s, base64: e.target.checked }))}
                    className="rounded text-[#a63439]"
                  />
                  <span className="text-sm">خروجی Base64</span>
                </label>

                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={settings.tempLinks}
                    onChange={(e) => setSettings(s => ({ ...s, tempLinks: e.target.checked }))}
                    className="rounded text-[#a63439]"
                  />
                  <span className="text-sm">لینک‌های موقت</span>
                </label>
              </div>
            </div>
          )}

          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="w-full h-32 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 resize-none"
            placeholder="سبک، ابزارها، تمپو، کلید و سایر ویژگی‌های موسیقی مورد نظر خود را توضیح دهید..."
          />

          <div className="flex items-center gap-4">
            <div className="flex-1">
              <label
                htmlFor="audio-upload"
                className={`flex items-center justify-center gap-2 w-full bg-gray-50 border-2 border-dashed ${
                  isUploading ? 'border-[#a63439]' : 'border-gray-200'
                } rounded-lg p-4 cursor-pointer hover:bg-gray-100 transition-colors`}
                title={uploadedFile ? `فایل انتخاب شده: ${uploadedFile.name}` : 'آپلود موسیقی مرجع (حداکثر 10 مگابایت)'}
              >
                {isUploading ? (
                  <>
                    <Brain className="w-5 h-5 text-[#a63439] animate-pulse" />
                    <span className="text-[#a63439]">در حال آپلود فایل... {uploadProgress}%</span>
                  </>
                ) : uploadedFile ? (
                  <>
                    <Music className="w-5 h-5 text-[#a63439]" />
                    <span className="text-[#a63439] truncate">
                      {uploadedFile.name} ({Math.round(uploadedFile.size / 1024)} KB)
                    </span>
                  </>
                ) : (
                  <>
                    <Upload className="w-5 h-5 text-gray-500" />
                    <span className="text-gray-600">آپلود موسیقی مرجع (حداکثر 10 مگابایت)</span>
                  </>
                )}
              </label>
              <input
                id="audio-upload"
                type="file"
                accept="audio/*"
                onChange={handleFileUpload}
                className="hidden"
                disabled={isUploading}
              />
              {uploadError && (
                <p className="mt-2 text-xs text-red-600">{uploadError}</p>
              )}
            </div>
            <button
              onClick={handleGenerate}
              disabled={isGenerating || !prompt.trim()}
              className="bg-[#a63439] text-white px-6 py-4 rounded-lg flex items-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
            >
              {isGenerating ? (
                <>
                  <Brain className="w-5 h-5 animate-pulse" />
                  <span>هوشِکس در حال فکر کردن...</span>
                </>
              ) : (
                <>
                  <Music className="w-5 h-5" />
                  <span>تولید موسیقی</span>
                </>
              )}
            </button>
          </div>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {generatedMusic.length > 0 && (
          <div className="bg-white rounded-xl p-6 space-y-4">
            <h2 className="text-lg font-medium">موسیقی تولید شده</h2>
            <div className="space-y-4">
              {generatedMusic.map((url, index) => (
                <div key={index} className="bg-gray-50 rounded-lg p-4">
                  <audio
                    controls
                    className="w-full mb-4"
                    src={url}
                  >
                    مرورگر شما از پخش صدا پشتیبانی نمی‌کند
                  </audio>
                  <a
                    href={url}
                    download={`generated-music-${index + 1}.mp3`}
                    className="inline-flex items-center gap-2 bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 transition-colors"
                  >
                    <Download className="w-4 h-4" />
                    <span>دانلود موسیقی</span>
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}