import { useState, useCallback } from 'react';
import { Image, Upload, Download, Wand2, AlertCircle, Sparkles } from 'lucide-react';
import ImageControls from '../components/image/ImageControls';
import { generateImage } from '../lib/imageGeneration';
import { openai, DEFAULT_MODEL } from '../lib/openai';

interface ImageGenerationState {
  isLoading: boolean;
  error: string | null;
  images: string[];
}

interface PromptState {
  text: string;
  isEnhancing: boolean;
  enhanced: string | null;
  negative: string;
}

const defaultSettings = {
  model_id: 'stable-diffusion',
  controlnet_model: 'openpose',
  controlnet_type: 'openpose',
  width: '1080',
  height: '1080',
  samples: '1',
  scheduler: 'UniPCMultistepScheduler',
  num_inference_steps: '30',
  guidance_scale: 7.5,
  controlnet_conditioning_scale: 0.7,
  strength: 0.55,
  clip_skip: '2',
};

export default function ImageAI() {
  const [settings, setSettings] = useState(defaultSettings);
  const [prompt, setPrompt] = useState('');
  const [negativePrompt, setNegativePrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImages, setGeneratedImages] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [enhancedPrompt, setEnhancedPrompt] = useState<string | null>(null);

  const handleEnhancePrompt = async () => {
    try {
      if (!prompt.trim()) return;
      setError(null);
      setIsEnhancing(true);

      const enhancementResponse = await openai.chat.completions.create({
        model: DEFAULT_MODEL,
        messages: [
          {
            role: 'system',
            content: `شما یک متخصص بهینه‌سازی پرامپت برای تولید تصویر هستید. وظیفه شما بهبود توضیحات کاربر با رعایت این محدودیت‌هاست:

محدودیت‌های اصلی:
1. حداکثر 3 جمله کوتاه و مرتبط
2. تمرکز فقط روی عناصر اصلی تصویر
3. پرهیز از توضیحات غیرضروری

عناصر مجاز برای اضافه کردن:
1. نورپردازی (فقط یک مورد):
   - نور طبیعی
   - نور استودیویی
   - نور درخشان
   - نور ملایم
   - نور دراماتیک

2. زاویه دید (فقط یک مورد):
   - نمای روبرو
   - نمای بالا
   - نمای از پایین
   - نمای نیم‌رخ
   - نمای سه‌رخ

3. فاصله (فقط یک مورد):
   - نمای نزدیک
   - نمای متوسط
   - نمای کامل

4. کیفیت (حداکثر دو مورد):
   - وضوح بالا
   - جزئیات دقیق
   - رنگ‌های زنده
   - کنتراست مناسب

نکات مهم:
- فقط متن بهبود یافته را برگردانید
- از افزودن توضیحات اضافه خودداری کنید
- ساختار جملات ساده و روان باشد
- اصل پیام کاربر حفظ شود`
          },
          {
            role: 'user',
            content: `لطفاً این توضیحات را برای تولید تصویر با کیفیت بالاتر و حرفه‌ای‌تر بهبود دهید. متن اصلی: "${prompt}"

نکات مهم:
- جزئیات بصری را افزایش دهید
- به نورپردازی و رنگ‌ها توجه کنید
- ترکیب‌بندی و زاویه دید را مشخص کنید
- حس و حال کلی تصویر را حفظ کنید`
          }
        ]
      });
      
      const improvedPrompt = enhancementResponse.choices[0].message.content;
      setEnhancedPrompt(improvedPrompt);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'خطا در بهبود توضیحات';
      setError(errorMessage);
    } finally {
      setIsEnhancing(false);
    }
  };
  
  const applyEnhancedPrompt = () => {
    if (enhancedPrompt) {
      setPrompt(enhancedPrompt);
      setEnhancedPrompt(null);
    }
  };

  const handleGenerate = async () => {
    try {
      if (!prompt.trim()) throw new Error('لطفاً توضیحات تصویر را وارد کنید');
      
      setIsGenerating(true);
      setError(null);
      setGeneratedImages([]);

      const translationResponse = await openai.chat.completions.create({
        model: DEFAULT_MODEL,
        messages: [
          {
            role: 'system',
            content: `You are an expert in translating image prompts from Persian to English. Your task:

1. Translation Approach:
   - Precise translation of core concepts
   - Preservation of artistic intent
   - Enhancement of visual descriptions

2. Technical Details:
   - Professional photography terms
   - Artistic style descriptors
   - Composition keywords
   - Lighting terminology
   - Material and texture details

IMPORTANT: Return ONLY the translated text, without any explanations or additional text.`
          },
          {
            role: 'user',
            content: prompt.trim()
          }
        ]
      });

      const translatedPrompt = translationResponse.choices[0]?.message?.content;
      if (!translatedPrompt) throw new Error('خطا در ترجمه پرامپت');

      // Add quality keywords in English to ensure better results
      const enhancedPrompt = `${translatedPrompt}, masterpiece, best quality, highly detailed, sharp focus, professional lighting, 8k uhd`;
      
      console.log('Sending prompt:', enhancedPrompt); // For debugging
      console.log('Settings:', settings); // For debugging

      const response = await generateImage({ 
        prompt: enhancedPrompt,
        width: settings.width,
        height: settings.height,
        isPro: false
      });

      // Set generated images if response is valid
      setGeneratedImages(response.output);

    } catch (error: any) {
      let errorMessage = 'خطا در تولید تصویر. لطفاً دوباره تلاش کنید.';
      
      // Log full error details for debugging
      console.error('Image generation error details:', {
        error,
        type: typeof error,
        message: error?.message,
        stack: error?.stack,
        keys: error ? Object.keys(error) : [],
        stringified: JSON.stringify(error, null, 2)
      });
      
      if (error instanceof Error) {
        if (error.message.includes('rate limit')) {
          errorMessage = 'محدودیت تعداد درخواست. لطفاً چند دقیقه صبر کنید';
        } else if (error.message.includes('timeout')) {
          errorMessage = 'زمان پاسخگویی به پایان رسید. لطفاً دوباره تلاش کنید';
        } else if (error.message.includes('network')) {
          errorMessage = 'خطا در ارتباط با سرور. لطفاً اتصال اینترنت خود را بررسی کنید';
        } else if (error.message.includes('API_NO_CONTENT')) {
          errorMessage = 'خطا در دریافت تصویر. لطفاً دوباره تلاش کنید';
        } else if (error.message.includes('Invalid API key')) {
          errorMessage = 'خطای احراز هویت API. لطفاً با پشتیبانی تماس بگیرید';
        } else {
          errorMessage = error.message;
        }
      } else if (error?.response?.data?.error) {
        // Handle API error response
        errorMessage = error.response.data.error.message || 'خطا در ارتباط با سرور';
      } else if (error?.code) {
        // Handle error codes
        errorMessage = `خطای ${error.code}. لطفاً دوباره تلاش کنید`;
      } else {
        errorMessage = 'خطای ناشناخته. لطفاً دوباره تلاش کنید';
      }
      
      setError(errorMessage);
      console.error('Image generation failed:', {
        error,
        errorMessage,
        prompt: enhancedPrompt,
        settings
      });
      
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="mx-auto max-w-xs sm:max-w-2xl md:max-w-3xl lg:max-w-4xl xl:max-w-5xl py-6 md:py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="text-2xl font-medium mb-2">هوش پیک پرو</h1>
          <p className="text-gray-600">با استفاده از هوش پیک تصاویر حرفه‌ای و خلاقانه بسازید. تنظیمات پیشرفته برای کنترل کامل روی خروجی.</p>
        </div>

        <div className="grid grid-cols-2 gap-6">
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium">پرامپت</label>
              <button
                onClick={handleEnhancePrompt}
                disabled={isEnhancing || !prompt.trim()}
                className="flex items-center gap-1 text-sm text-[#a63439] hover:text-[#8a2a2e] disabled:opacity-50"
              >
                <Sparkles className="w-4 h-4" />
                {isEnhancing ? 'هوشِکس در حال فکر کردن...' : 'بهبود توضیحات'}
              </button>
            </div>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="w-full h-32 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 resize-none focus:outline-none focus:ring-2 focus:ring-[#a63439] transition-all dir-rtl"
              placeholder="مثال: یک عکس پرتره حرفه‌ای از یک خانم جوان با لباس رسمی، در یک دفتر کار مدرن، نور طبیعی از پنجره، عمق میدان کم، لنز 85mm، با کیفیت عالی و رنگ‌های طبیعی"
            />
            {enhancedPrompt && (
              <div className="mt-2 p-3 bg-[#a63439]/5 border border-[#a63439]/10 rounded-lg">
                <p className="text-sm text-gray-600 mb-2">توضیحات بهبود یافته:</p>
                <p className="text-sm mb-2">{enhancedPrompt}</p>
                <button
                  onClick={applyEnhancedPrompt}
                  className="text-sm text-[#a63439] hover:text-[#8a2a2e] flex items-center gap-1"
                >
                  <Sparkles className="w-4 h-4" />
                  اعمال توضیحات جدید
                </button>
              </div>
            )}
          </div>
          <div className="col-span-2 md:col-span-1">
            <label className="block text-sm font-medium mb-2">پرامپت منفی</label>
            <textarea
              value={negativePrompt}
              onChange={(e) => setNegativePrompt(e.target.value)}
              className="w-full h-32 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 resize-none focus:outline-none focus:ring-2 focus:ring-[#a63439] transition-all dir-rtl"
              placeholder="مثال: کیفیت پایین، تار بودن تصویر، نویز دیجیتال، رنگ‌های غیرطبیعی، اعوجاج در چهره، پس‌زمینه شلوغ، سایه‌های تیره"
            />
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={handleGenerate}
            disabled={isGenerating || !prompt.trim()}
            className="w-full bg-[#a63439] text-white px-6 py-4 rounded-lg flex items-center justify-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
          >
            <Wand2 className="w-5 h-5" />
            {isGenerating ? 'هوشِکس در حال فکر کردن...' : 'ساخت تصویر'}
          </button>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 sm:p-4 flex items-center gap-2 sm:gap-3 text-red-700 animate-fadeIn">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        <ImageControls
          settings={settings}
          onSettingsChange={setSettings}
        />

        {generatedImages.length > 0 && (
          <div className="space-y-4 animate-fadeIn">
            <h2 className="text-lg font-medium">تصاویر تولید شده</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {generatedImages.map((image, index) => (
                <div key={index} className="relative group">
                  <img
                    src={image}
                    alt={`Generated ${index + 1}`}
                    className="w-full rounded-lg shadow-md hover:shadow-lg transition-shadow"
                  />
                  <a
                    href={image}
                    download={`generated-${index + 1}.png`}
                    className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-lg"
                  >
                    <Download className="w-6 h-6 text-white" />
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}