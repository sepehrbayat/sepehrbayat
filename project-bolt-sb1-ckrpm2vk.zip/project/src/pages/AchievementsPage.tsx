import React, { useEffect, useState } from 'react';
import { Trophy, Star, Target, Sparkles, Medal, Crown, Award, Zap, Filter, Search } from 'lucide-react';
import { useAuth } from '../lib/auth/AuthContext';
import { getActivities } from '../lib/activity';
import { calculateAchievements, UserAchievement, getAchievementCategories, getNextAchievement } from '../lib/activity/achievements';

export default function AchievementsPage() {
  const { user } = useAuth();
  const [achievements, setAchievements] = useState<UserAchievement[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showUnlocked, setShowUnlocked] = useState(true);
  const [showLocked, setShowLocked] = useState(true);

  useEffect(() => {
    loadAchievements();
  }, []);

  const loadAchievements = async () => {
    try {
      setIsLoading(true);
      setError(null);

      const activities = await getActivities();
      const calculatedAchievements = calculateAchievements(activities);
      setAchievements(calculatedAchievements);

    } catch (error) {
      console.error('Error loading achievements:', error);
      setError('خطا در بارگذاری دستاوردها');
    } finally {
      setIsLoading(false);
    }
  };

  const categories = getAchievementCategories();
  const nextAchievement = getNextAchievement(achievements);
  const totalPoints = achievements.reduce((sum, a) => sum + (a.isUnlocked ? a.points : 0), 0);
  const totalAchievements = achievements.filter(a => a.isUnlocked).length;
  
  // Filter achievements
  const filteredAchievements = achievements.filter(achievement => {
    if (selectedCategory && achievement.category !== selectedCategory) return false;
    if (!showUnlocked && achievement.isUnlocked) return false;
    if (!showLocked && !achievement.isUnlocked) return false;
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return (
        achievement.title.toLowerCase().includes(query) ||
        achievement.description.toLowerCase().includes(query)
      );
    }
    return true;
  });
  
  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#a63439] to-[#262e43] flex items-center justify-center">
              <Trophy className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-medium mb-1">دستاوردها</h1>
              <p className="text-gray-600">مسیر پیشرفت و موفقیت‌های شما</p>
            </div>
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center h-40">
            <div className="animate-spin rounded-full h-8 w-8 border-2 border-[#a63439] border-t-transparent" />
          </div>
        ) : error ? (
          <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-red-700 text-center">
            {error}
          </div>
        ) : (
          <>
            {/* User Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-white rounded-xl p-6 text-center">
                <div className="w-12 h-12 rounded-xl bg-[#a63439]/10 flex items-center justify-center mx-auto mb-3">
                  <Star className="w-6 h-6 text-[#a63439]" />
                </div>
                <div className="text-2xl font-bold text-[#a63439]">{totalPoints}</div>
                <div className="text-sm text-gray-600">امتیاز کل</div>
              </div>
              
              <div className="bg-white rounded-xl p-6 text-center">
                <div className="w-12 h-12 rounded-xl bg-[#a63439]/10 flex items-center justify-center mx-auto mb-3">
                  <Trophy className="w-6 h-6 text-[#a63439]" />
                </div>
                <div className="text-2xl font-bold text-[#a63439]">{totalAchievements}</div>
                <div className="text-sm text-gray-600">دستاوردهای باز شده</div>
              </div>
              
              <div className="bg-white rounded-xl p-6 text-center">
                <div className="w-12 h-12 rounded-xl bg-[#a63439]/10 flex items-center justify-center mx-auto mb-3">
                  <Medal className="w-6 h-6 text-[#a63439]" />
                </div>
                <div className="text-2xl font-bold text-[#a63439]">3</div>
                <div className="text-sm text-gray-600">رتبه در لیدربورد</div>
              </div>
            </div>

            {/* Next Achievement */}
            {nextAchievement && (
              <div className="bg-gradient-to-br from-[#a63439]/5 to-white border border-[#a63439]/10 rounded-xl p-6">
                <h2 className="text-lg font-medium mb-4 flex items-center gap-2">
                  <Target className="w-5 h-5 text-[#a63439]" />
                  <span>دستاورد بعدی</span>
                </h2>
                <div className="flex items-center gap-4">
                  <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${nextAchievement.color} flex items-center justify-center`}>
                    <nextAchievement.icon className="w-8 h-8 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium mb-1">{nextAchievement.title}</h3>
                    <p className="text-sm text-gray-600 mb-3">{nextAchievement.description}</p>
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">پیشرفت</span>
                        <span className="font-medium">
                          {nextAchievement.progress}/{nextAchievement.maxProgress}
                        </span>
                      </div>
                      <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div 
                          className={`h-full bg-gradient-to-l ${nextAchievement.color} transition-all`}
                          style={{ width: `${(nextAchievement.progress / nextAchievement.maxProgress) * 100}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Filters */}
            <div className="bg-white rounded-xl p-4 space-y-4">
              <div className="flex items-center gap-4">
                <div className="relative flex-1">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="جستجو در دستاوردها..."
                    className="w-full bg-gray-50 border border-gray-200 rounded-lg pr-10 pl-3 py-2"
                  />
                </div>
                <button
                  onClick={() => setShowUnlocked(!showUnlocked)}
                  className={`p-2 rounded-lg transition-colors ${
                    showUnlocked ? 'bg-[#a63439] text-white' : 'bg-gray-100 text-gray-700'
                  }`}
                >
                  باز شده
                </button>
                <button
                  onClick={() => setShowLocked(!showLocked)}
                  className={`p-2 rounded-lg transition-colors ${
                    showLocked ? 'bg-[#a63439] text-white' : 'bg-gray-100 text-gray-700'
                  }`}
                >
                  قفل شده
                </button>
              </div>

              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setSelectedCategory(null)}
                  className={`px-3 py-1 rounded-lg text-sm transition-colors ${
                    selectedCategory === null
                      ? 'bg-[#a63439] text-white'
                      : 'bg-gray-100 text-gray-700'
                  }`}
                >
                  همه
                </button>
                {categories.map(category => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`px-3 py-1 rounded-lg text-sm transition-colors flex items-center gap-1 ${
                      selectedCategory === category.id
                        ? 'bg-[#a63439] text-white'
                        : 'bg-gray-100 text-gray-700'
                    }`}
                  >
                    <category.icon className="w-4 h-4" />
                    <span>{category.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Achievements Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredAchievements.map(achievement => (
                <div 
                  key={achievement.id}
                  className={`bg-white rounded-xl p-6 ${
                    achievement.isUnlocked ? '' : 'opacity-50'
                  }`}
                >
                  <div className="flex items-center gap-4 mb-4">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${achievement.color} flex items-center justify-center`}>
                      <achievement.icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-medium">{achievement.title}</h3>
                      <p className="text-sm text-gray-500">{achievement.description}</p>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    {/* Progress Bar */}
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">پیشرفت</span>
                        <span className="font-medium">
                          {achievement.progress}/{achievement.maxProgress}
                        </span>
                      </div>
                      <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div 
                          className={`h-full bg-gradient-to-l ${achievement.color} transition-all`}
                          style={{ width: `${(achievement.progress / achievement.maxProgress) * 100}%` }}
                        />
                      </div>
                    </div>

                    {/* Level */}
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">سطح</span>
                      <div className="flex items-center gap-1">
                        {Array.from({ length: achievement.maxLevel }).map((_, i) => (
                          <div 
                            key={i}
                            className={`w-2 h-2 rounded-full ${
                              i < achievement.level 
                                ? `bg-gradient-to-l ${achievement.color}`
                                : 'bg-gray-200'
                            }`}
                          />
                        ))}
                      </div>
                    </div>

                    {/* Points */}
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">امتیاز</span>
                      <span className="font-medium">{achievement.points}</span>
                    </div>

                    {/* Next Reward */}
                    {achievement.nextReward && (
                      <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <achievement.nextReward.icon className="w-4 h-4 text-[#a63439]" />
                          <span className="text-sm font-medium">{achievement.nextReward.title}</span>
                        </div>
                        <p className="text-xs text-gray-500">{achievement.nextReward.description}</p>
                        <div className="mt-2 h-1 bg-gray-200 rounded-full overflow-hidden">
                          <div
                            className={`h-full bg-gradient-to-l ${achievement.color}`}
                            style={{ width: `${(achievement.nextReward.progress / achievement.nextReward.required) * 100}%` }}
                          />
                        </div>
                      </div>
                    )}

                    {/* Required Achievements */}
                    {achievement.requiredAchievements && achievement.requiredAchievements.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-gray-100">
                        <span className="text-xs text-gray-500">نیازمند:</span>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {achievement.requiredAchievements.map(reqId => {
                            const req = achievements.find(a => a.id === reqId);
                            return req ? (
                              <div
                                key={reqId}
                                className={`px-2 py-0.5 rounded text-xs ${
                                  req.isUnlocked
                                    ? 'bg-green-100 text-green-700'
                                    : 'bg-gray-100 text-gray-600'
                                }`}
                              >
                                {req.title}
                              </div>
                            ) : null;
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}