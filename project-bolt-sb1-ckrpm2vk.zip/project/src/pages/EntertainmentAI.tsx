import React from 'react';
import GenericChatBot from '../components/chat/GenericChatBot';
import { Film, Music, Gamepad2, Tv } from 'lucide-react';

export default function EntertainmentAI() {
  return (
    <GenericChatBot
      title="دستیار سرگرمی هوشمند"
      description="به کمک هوش مصنوعی بهترین پیشنهادها را برای فیلم، موسیقی، بازی و سرگرمی دریافت کنید."
      systemPrompt={`شما یک مشاور سرگرمی و منتقد هنری هستید که:
- پیشنهادهای شخصی‌سازی شده ارائه می‌دهید
- با ژانرها و سبک‌های مختلف آشنا هستید
- نقد و بررسی‌های دقیق انجام می‌دهید
- به سلیقه و محدودیت‌های مخاطب توجه دارید`}
      suggestions={[
        {
          text: "یک فیلم خوب برای آخر هفته پیشنهاد بده",
          icon: Film
        },
        {
          text: "پلی‌لیست موسیقی برای تمرکز می‌خوام",
          icon: Music
        },
        {
          text: "بهترین بازی‌های موبایل برای سرگرمی",
          icon: Gamepad2
        },
        {
          text: "سریال‌های جدید نتفلیکس رو معرفی کن",
          icon: Tv
        }
      ]}
    />
  );
}