import React from 'react';
import { Book, Search, MessageSquare } from 'lucide-react';
import HelpCategory from '../components/help/HelpCategory';
import HelpHeader from '../components/help/HelpHeader';
import SmartAssistant from '../components/help/SmartAssistant';
import { toolsHelp, faqHelp, supportHelp } from '../data/helpContent';

const helpCategories = [
  {
    title: 'راهنمای ابزارها',
    description: 'آشنایی با ابزارهای مختلف هوشِکس و نحوه استفاده از آنها',
    icon: Book,
    items: toolsHelp
  },
  {
    title: 'سوالات متداول',
    description: 'پاسخ به سوالات رایج کاربران',
    icon: Search,
    items: faqHelp
  },
  {
    title: 'پشتیبانی',
    description: 'راه‌های ارتباط با تیم پشتیبانی',
    icon: MessageSquare,
    items: supportHelp
  }
];

export default function HelpPage() {
  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <HelpHeader 
          title="راهنما و پشتیبانی"
          description="پاسخ سوالات و راهنمای استفاده از هوشِکس"
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {helpCategories.map((category, index) => (
            <HelpCategory
              key={index}
              title={category.title}
              description={category.description}
              icon={category.icon}
              items={category.items}
            />
          ))}
        </div>

        <SmartAssistant />
      </div>
    </div>
  );
}