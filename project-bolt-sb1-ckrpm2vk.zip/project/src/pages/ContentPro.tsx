import React, { useState } from 'react';
import { Crown, Star, AlertCircle } from 'lucide-react';
import { suggestKeywords } from '../lib/content/suggestions';
import { useContentGeneration } from '../components/content-pro/hooks/useContentGeneration';
import GenerationOverlay from '../components/content-pro/components/GenerationOverlay';
import ContentSettings from '../components/content-pro/components/ContentSettings';
import KeywordManager from '../components/content/KeywordManager';
import HeadingManager from '../components/content/HeadingManager';
import RichTextEditor from '../components/editor/RichTextEditor';
import type { ContentSettings as ContentSettingsType, ResearchResult } from '../components/content-pro/types';

export default function ContentPro() {
  const [topic, setTopic] = useState('');
  const [keywords, setKeywords] = useState<string[]>([]);
  const [headings, setHeadings] = useState<any[]>([]);
  const [suggestedKeywords, setSuggestedKeywords] = useState<string[]>([]);
  const [isSuggestingKeywords, setIsSuggestingKeywords] = useState(false);
  const [showKeywordSuggestions, setShowKeywordSuggestions] = useState(false);
  const [settings, setSettings] = useState<ContentSettingsType>({
    contentLength: 'medium',
    minWords: 1000,
    maxWords: 1500,
    style: 'professional',
    tone: 'formal',
    audience: 'general'
  });
  const [editorContent, setEditorContent] = useState('');

  const {
    isGenerating,
    error,
    generate,
    setError
  } = useContentGeneration({
    onProgress: (message) => setProgress(message),
    onSuccess: (content) => setEditorContent(content.content)
  });

  const [progress, setProgress] = useState('');
  const [generationPhase, setGenerationPhase] = useState<'research' | 'analysis' | 'generation' | null>(null);
  const [progressPercent, setProgressPercent] = useState(0);
  const [suggestError, setSuggestError] = useState<string | null>(null);

  const handleSuggestKeywords = async () => {
    try {
      if (!topic.trim()) {
        setError('لطفاً موضوع را وارد کنید');
        return;
      }

      setIsSuggestingKeywords(true);
      setError(null);
      setSuggestedKeywords([]);

      // Use the suggestKeywords function with isPro=true for ContentPro
      const suggestions = await suggestKeywords(topic, true);
      
      // Filter out already selected keywords
      const filteredSuggestions = suggestions.filter(k => !keywords.includes(k));
      
      if (filteredSuggestions.length === 0) {
        setError('تمام کلمات کلیدی پیشنهادی قبلاً اضافه شده‌اند');
        return;
      }

      setSuggestedKeywords(filteredSuggestions);
      setShowKeywordSuggestions(true);

    } catch (error) {
      console.error('Error suggesting keywords:', error);
      const errorMessage = error instanceof Error ? error.message : 'خطا در پیشنهاد کلمات کلیدی';
      setError(errorMessage);
      setSuggestedKeywords([]);
    } finally {
      setIsSuggestingKeywords(false);
    }
  };

  const handleGenerateContent = async () => {
    try {
      if (!topic.trim()) {
        setError('لطفاً موضوع محتوا را وارد کنید');
        return;
      }

      if (keywords.length === 0) {
        setError('لطفاً حداقل یک کلمه کلیدی وارد کنید');
        return;
      }

      if (headings.length === 0) {
        setError('لطفاً حداقل یک سرتیتر وارد کنید');
        return;
      }
      setGenerationPhase('research');
      setProgressPercent(0);

      // Simulate progress
      const progressInterval = setInterval(() => {
        setProgressPercent(prev => {
          if (prev >= 95) {
            clearInterval(progressInterval);
            return prev;
          }
          return prev + 1;
        });
      }, 300);

      await generate(topic, keywords, headings);
      setProgressPercent(100);
      setGenerationPhase(null);
      clearInterval(progressInterval);
    } catch (error) {
      console.error('Content generation error:', error);
      setError(error instanceof Error ? error.message : 'خطا در تولید محتوا');
      setGenerationPhase(null);
      setProgressPercent(0);
    }
  };

  return (
    <div className="container mx-auto py-4 sm:py-6 md:py-8 px-2 sm:px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 sm:gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#a63439] to-[#262e43] flex items-center justify-center">
              <Crown className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-2xl font-medium">تولید مقاله پرو</h1>
                <div className="flex items-center gap-1 bg-gradient-to-r from-amber-500 to-amber-600 text-white text-xs px-2 py-0.5 rounded-full">
                  <Star className="w-3 h-3 fill-current" />
                  <span>PRO</span>
                </div>
              </div>
              <p className="text-gray-600 text-sm sm:text-base mt-1 sm:mt-0">تولید محتوای حرفه‌ای با تحقیق خودکار و هوش مصنوعی</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg sm:rounded-xl p-4 sm:p-6 space-y-4 sm:space-y-6">
          <div>
            <label className="block text-sm font-medium mb-2">موضوع محتوا</label>
            <textarea
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="w-full h-24 sm:h-32 bg-gray-50 border border-gray-200 rounded-lg px-2 sm:px-3 py-2 resize-none text-sm sm:text-base"
              placeholder="موضوع مورد نظر خود را وارد کنید..."
            />
          </div>

          <KeywordManager
            keywords={keywords}
            onAddKeyword={(keyword) => {
              if (!keywords.includes(keyword)) {
                setKeywords([...keywords, keyword]);
              }
            }}
            onRemoveKeyword={(keyword) => setKeywords(keywords.filter(k => k !== keyword))}
            onSuggestKeywords={handleSuggestKeywords}
            suggestedKeywords={suggestedKeywords}
            isSuggestingKeywords={isSuggestingKeywords}
            showSuggestions={showKeywordSuggestions}
            onSelectSuggestion={(keyword) => {
              if (!keywords.includes(keyword)) {
                setKeywords([...keywords, keyword]);
                // Remove selected keyword from suggestions
                setSuggestedKeywords(prev => prev.filter(k => k !== keyword));
                // Hide suggestions if no more suggestions
                if (suggestedKeywords.length <= 1) {
                  setShowKeywordSuggestions(false);
                }
              }
            }}
            onHideSuggestions={() => setShowKeywordSuggestions(false)}
          />

          <HeadingManager
            headings={headings}
            onAddHeading={(heading) => setHeadings([...headings, heading])}
            onRemoveHeading={(id) => setHeadings(headings.filter(h => h.id !== id))}
            topic={topic}
          />

          <ContentSettings
            settings={settings}
            onSettingsChange={setSettings}
          />

          <button
            onClick={handleGenerateContent}
            disabled={isGenerating || !topic.trim() || !keywords?.length || !headings?.length}
            className="w-full bg-gradient-to-r from-amber-500 to-amber-600 text-white p-3 sm:p-4 rounded-lg flex items-center justify-center gap-2 hover:opacity-90 transition-all disabled:opacity-50 shadow-[0_0_15px_rgba(245,158,11,0.3)] hover:shadow-[0_0_25px_rgba(245,158,11,0.5)] text-sm sm:text-base"
          >
            {isGenerating ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
                <span>در حال تولید محتوا...</span>
              </>
            ) : (
              <>
                <div className="relative">
                  <Crown className="w-5 h-5 text-white" />
                  <div className="absolute -top-1 -right-1">
                    <Star className="w-3 h-3 text-white fill-white" />
                  </div>
                </div>
                <span>تولید محتوا با هوشِکس پرو</span>
              </>
            )}
          </button>
        </div>

        <GenerationOverlay 
          isVisible={isGenerating}
          progress={progressPercent}
          phase={generationPhase}
        />

        {suggestError && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 sm:p-4 flex items-center gap-2 sm:gap-3 text-red-700 text-sm sm:text-base">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p>{suggestError}</p>
          </div>
        )}

        {progress && (
          <div className="flex items-center justify-center gap-2 sm:gap-3 text-gray-600 text-sm sm:text-base">
            <div className="animate-spin rounded-full h-4 w-4 border-2 border-[#a63439] border-t-transparent" />
            <p>{progress}</p>
          </div>
        )}

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 sm:p-4 flex items-center gap-2 sm:gap-3 text-red-700 text-sm sm:text-base">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {editorContent && (
          <div className="bg-white rounded-lg sm:rounded-xl p-4 sm:p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base sm:text-lg font-medium">محتوای تولید شده</h2>
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 bg-gradient-to-r from-amber-500 to-amber-600 text-white text-xs px-2 py-0.5 rounded-full animate-pulse">
                  <Star className="w-3 h-3 fill-current" />
                  <span>هوش مصنوعی پیشرفته</span>
                </div>
              </div>
            </div>
            <RichTextEditor
              content={editorContent}
              onChange={setEditorContent}
              placeholder="محتوای مقاله..."
            />
          </div>
        )}
      </div>
    </div>
  );
}