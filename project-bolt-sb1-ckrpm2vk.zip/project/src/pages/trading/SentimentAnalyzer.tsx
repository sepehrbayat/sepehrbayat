import React, { useState } from 'react';
import { Brain, Upload, Download, Wand2, AlertCircle, Settings2, BarChart2, LineChart, PieChart } from 'lucide-react';
import { analyzeSentiment } from '../../lib/trading/sentiment/analysis';
import { MarketSentiment, SentimentAnalysisOptions } from '../../lib/trading/sentiment/types';
import { Bar, Line, Pie } from 'react-chartjs-2';

export default function SentimentAnalyzer() {
  const [text, setText] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<MarketSentiment | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [options, setOptions] = useState<SentimentAnalysisOptions>({
    timeframe: '24h',
    sources: ['news', 'social', 'technical'],
    keywords: [],
    language: 'fa'
  });

  const handleAnalyze = async () => {
    try {
      if (!text.trim()) {
        throw new Error('لطفاً متن مورد نظر را وارد کنید');
      }

      setIsAnalyzing(true);
      setError(null);

      const result = await analyzeSentiment(text, options);
      setAnalysis(result);

    } catch (error) {
      console.error('Analysis error:', error);
      setError(error instanceof Error ? error.message : 'خطا در تحلیل سنتیمنت');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl p-6 space-y-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-medium">تحلیل سنتیمنت</h2>
          <button
            onClick={() => setShowSettings(!showSettings)}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <Settings2 className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {showSettings && (
          <div className="mb-6 p-4 bg-gray-50 rounded-lg space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">بازه زمانی</label>
              <select
                value={options.timeframe}
                onChange={(e) => setOptions(prev => ({ ...prev, timeframe: e.target.value }))}
                className="w-full bg-white border border-gray-200 rounded-lg px-3 py-2"
              >
                <option value="1h">1 ساعت گذشته</option>
                <option value="4h">4 ساعت گذشته</option>
                <option value="24h">24 ساعت گذشته</option>
                <option value="7d">1 هفته گذشته</option>
                <option value="30d">1 ماه گذشته</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">منابع</label>
              <div className="flex flex-wrap gap-2">
                {['news', 'social', 'technical'].map(source => (
                  <label key={source} className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={options.sources.includes(source)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setOptions(prev => ({
                            ...prev,
                            sources: [...prev.sources, source]
                          }));
                        } else {
                          setOptions(prev => ({
                            ...prev,
                            sources: prev.sources.filter(s => s !== source)
                          }));
                        }
                      }}
                      className="rounded text-[#a63439]"
                    />
                    <span className="text-sm">
                      {source === 'news' ? 'اخبار' :
                       source === 'social' ? 'شبکه‌های اجتماعی' :
                       'تحلیل تکنیکال'}
                    </span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">کلمات کلیدی</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="کلمه کلیدی را وارد کنید..."
                  className="flex-1 bg-white border border-gray-200 rounded-lg px-3 py-2"
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      const value = (e.target as HTMLInputElement).value.trim();
                      if (value && !options.keywords.includes(value)) {
                        setOptions(prev => ({
                          ...prev,
                          keywords: [...prev.keywords, value]
                        }));
                        (e.target as HTMLInputElement).value = '';
                      }
                    }
                  }}
                />
              </div>
              {options.keywords.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {options.keywords.map((keyword, index) => (
                    <span
                      key={index}
                      className="bg-gray-100 text-gray-700 px-2 py-1 rounded-full text-sm flex items-center gap-1"
                    >
                      {keyword}
                      <button
                        onClick={() => setOptions(prev => ({
                          ...prev,
                          keywords: prev.keywords.filter((_, i) => i !== index)
                        }))}
                        className="text-gray-500 hover:text-red-500"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        <div>
          <label className="block text-sm font-medium mb-2">متن برای تحلیل</label>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            className="w-full h-32 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 resize-none"
            placeholder="متن خبر، پست یا محتوای مورد نظر را وارد کنید..."
          />
        </div>

        <button
          onClick={handleAnalyze}
          disabled={isAnalyzing || !text.trim()}
          className="w-full bg-[#a63439] text-white p-4 rounded-lg flex items-center justify-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
        >
          {isAnalyzing ? (
            <>
              <Brain className="w-5 h-5 animate-pulse" />
              <span>در حال تحلیل...</span>
            </>
          ) : (
            <>
              <BarChart2 className="w-5 h-5" />
              <span>تحلیل سنتیمنت</span>
            </>
          )}
        </button>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {analysis && (
          <div className="space-y-6">
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="text-sm font-medium mb-3">سنتیمنت کلی</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">وضعیت</span>
                    <span className={`text-sm font-medium ${
                      analysis.overall.label === 'bullish' ? 'text-green-600' :
                      analysis.overall.label === 'bearish' ? 'text-red-600' :
                      'text-gray-600'
                    }`}>
                      {analysis.overall.label === 'bullish' ? 'صعودی' :
                       analysis.overall.label === 'bearish' ? 'نزولی' :
                       'خنثی'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">اطمینان</span>
                    <span className="text-sm font-medium">{analysis.overall.confidence}%</span>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="text-sm font-medium mb-3">تحلیل اخبار</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">امتیاز</span>
                    <span className="text-sm font-medium">{analysis.news.score.toFixed(2)}</span>
                  </div>
                  <div className="text-sm text-gray-600">کلمات کلیدی پرتکرار:</div>
                  <div className="flex flex-wrap gap-1">
                    {analysis.news.topKeywords.map((keyword, index) => (
                      <span key={index} className="bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full text-xs">
                        {keyword}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="text-sm font-medium mb-3">تحلیل شبکه‌های اجتماعی</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">امتیاز</span>
                    <span className="text-sm font-medium">{analysis.social.score.toFixed(2)}</span>
                  </div>
                  <div className="text-sm text-gray-600">ترندهای داغ:</div>
                  <div className="flex flex-wrap gap-1">
                    {analysis.social.trending.map((trend, index) => (
                      <span key={index} className="bg-purple-100 text-purple-800 px-2 py-0.5 rounded-full text-xs">
                        {trend}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="text-sm font-medium mb-3">اخبار تأثیرگذار</h3>
                <div className="space-y-3">
                  {analysis.news.items.slice(0, 3).map((item, index) => (
                    <div key={index} className="space-y-1">
                      <div className="flex items-center justify-between">
                        <a
                          href={item.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-sm font-medium hover:text-[#a63439]"
                        >
                          {item.title}
                        </a>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${
                          item.sentiment.label === 'positive' ? 'bg-green-100 text-green-800' :
                          item.sentiment.label === 'negative' ? 'bg-red-100 text-red-800' :
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {item.sentiment.score.toFixed(2)}
                        </span>
                      </div>
                      <div className="text-xs text-gray-500">
                        {item.source} • {new Date(item.publishDate).toLocaleDateString('fa-IR')}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="text-sm font-medium mb-3">پست‌های پربازدید</h3>
                <div className="space-y-3">
                  {analysis.social.posts.slice(0, 3).map((post, index) => (
                    <div key={index} className="space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">{post.content.slice(0, 100)}...</span>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${
                          post.sentiment.label === 'positive' ? 'bg-green-100 text-green-800' :
                          post.sentiment.label === 'negative' ? 'bg-red-100 text-red-800' :
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {post.sentiment.score.toFixed(2)}
                        </span>
                      </div>
                      <div className="flex items-center gap-4 text-xs text-gray-500">
                        <span>{post.platform}</span>
                        <span>👍 {post.engagement.likes}</span>
                        <span>🔄 {post.engagement.shares}</span>
                        <span>💬 {post.engagement.comments}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="text-sm font-medium mb-3">پیشنهادات معاملاتی</h3>
                <div className="space-y-2">
                  {analysis.recommendations.map((rec, index) => (
                    <div key={index} className="flex items-start gap-2 text-sm">
                      <div className="w-2 h-2 rounded-full bg-[#a63439] mt-1.5" />
                      <span>{rec}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="text-sm font-medium mb-3">بینش‌های کلیدی</h3>
                <div className="space-y-2">
                  {analysis.insights.map((insight, index) => (
                    <div key={index} className="flex items-start gap-2 text-sm">
                      <Brain className="w-4 h-4 text-[#a63439] mt-1 flex-shrink-0" />
                      <span>{insight}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}