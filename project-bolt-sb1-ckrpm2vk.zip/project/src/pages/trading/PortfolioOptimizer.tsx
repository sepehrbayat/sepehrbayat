import React, { useState } from 'react';
import { Brain, Upload, Download, Wand2, AlertCircle } from 'lucide-react';
import { openai } from '../../lib/openai';

export default function PortfolioOptimizer() {
  const [data, setData] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl p-6 space-y-6">
        <h2 className="text-lg font-medium">بهینه‌ساز سبد سهام</h2>
        <p className="text-gray-600">به زودی...</p>
      </div>
    </div>
  );
}