import React, { useState, useRef } from 'react';
import { Brain, Upload, Download, Wand2, AlertCircle, Settings2 } from 'lucide-react';
import { createChart, IChartApi } from 'lightweight-charts';
import { PatternData, PatternAnalysis } from '../../lib/trading/patterns/types';
import { analyzePatterns } from '../../lib/trading/patterns/analysis';
import { prepareVisualization } from '../../lib/trading/patterns/visualization';
import Papa from 'papaparse';

export default function PatternRecognizer() {
  const [data, setData] = useState<PatternData[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<PatternAnalysis | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [selectedPatterns, setSelectedPatterns] = useState<string[]>([
    'Double Top', 'Double Bottom', 'Head and Shoulders',
    'Inverse Head and Shoulders', 'Triangle', 'Flag'
  ]);
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      Papa.parse(file, {
        complete: (results) => {
          try {
            const parsedData: PatternData[] = results.data
              .slice(1) // Skip header row
              .map((row: any[]) => ({
                time: row[0],
                open: parseFloat(row[1]),
                high: parseFloat(row[2]),
                low: parseFloat(row[3]),
                close: parseFloat(row[4]),
                volume: parseFloat(row[5])
              }))
              .filter(d => !isNaN(d.open));

            setData(parsedData);
            setError(null);
            initializeChart(parsedData);
          } catch (error) {
            setError('خطا در خواندن فایل. لطفاً فرمت صحیح را رعایت کنید');
          }
        },
        error: (error) => {
          setError('خطا در خواندن فایل CSV');
        }
      });
    }
  };

  const initializeChart = (chartData: PatternData[]) => {
    if (!chartContainerRef.current) return;

    // Remove existing chart
    if (chartRef.current) {
      chartRef.current.remove();
    }

    // Create new chart
    const chart = createChart(chartContainerRef.current, {
      layout: {
        background: { color: '#ffffff' },
        textColor: '#333333',
      },
      grid: {
        vertLines: { color: '#f0f0f0' },
        horzLines: { color: '#f0f0f0' },
      },
      rightPriceScale: {
        borderColor: '#f0f0f0',
      },
      timeScale: {
        borderColor: '#f0f0f0',
        timeVisible: true,
      },
      crosshair: {
        mode: 0,
      },
    });

    // Add candlestick series
    const candlestickSeries = chart.addCandlestickSeries({
      upColor: '#10b981',
      downColor: '#ef4444',
      borderVisible: false,
      wickUpColor: '#10b981',
      wickDownColor: '#ef4444',
    });

    // Add data
    candlestickSeries.setData(chartData);

    // Fit content
    chart.timeScale().fitContent();

    chartRef.current = chart;
  };

  const analyzeChart = async () => {
    try {
      if (data.length === 0) {
        throw new Error('لطفاً ابتدا داده‌های نمودار را وارد کنید');
      }

      setIsAnalyzing(true);
      setError(null);

      const result = await analyzePatterns(data);
      setAnalysis(result);

      // Visualize patterns
      if (chartRef.current) {
        const visualization = prepareVisualization(data, result.patterns);
        
        // Add pattern annotations
        visualization.annotations.forEach(annotation => {
          if (annotation.type === 'pattern') {
            const series = chartRef.current?.addLineSeries({
              color: annotation.color,
              lineWidth: 2,
              title: annotation.label,
            });
            series?.setData(annotation.points.map(p => ({
              time: data[p.x].time,
              value: p.y
            })));
          }
        });

        // Add indicators
        visualization.indicators.forEach(indicator => {
          const series = chartRef.current?.addLineSeries({
            color: indicator.color,
            lineWidth: 1,
            title: indicator.name,
          });
          series?.setData(indicator.values.map((value, i) => ({
            time: data[i].time,
            value: value || 0
          })));
        });
      }

    } catch (error) {
      console.error('Analysis error:', error);
      setError(error instanceof Error ? error.message : 'خطا در تحلیل نمودار');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl p-6 space-y-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-medium">تشخیص الگو</h2>
          <button
            onClick={() => setShowSettings(!showSettings)}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <Settings2 className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {showSettings && (
          <div className="mb-6 p-4 bg-gray-50 rounded-lg space-y-4">
            <h3 className="text-sm font-medium mb-2">الگوهای قابل تشخیص</h3>
            <div className="grid grid-cols-2 gap-2">
              {[
                'Double Top', 'Double Bottom',
                'Head and Shoulders', 'Inverse Head and Shoulders',
                'Triangle', 'Flag', 'Wedge', 'Channel',
                'Cup and Handle', 'Rounding Bottom'
              ].map(pattern => (
                <label key={pattern} className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={selectedPatterns.includes(pattern)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedPatterns([...selectedPatterns, pattern]);
                      } else {
                        setSelectedPatterns(selectedPatterns.filter(p => p !== pattern));
                      }
                    }}
                    className="rounded text-[#a63439]"
                  />
                  <span className="text-sm">{pattern}</span>
                </label>
              ))}
            </div>
          </div>
        )}

        <div className="flex items-center gap-4">
          <div className="flex-1">
            <label
              htmlFor="chart-data"
              className="flex items-center justify-center gap-2 w-full bg-gray-50 border-2 border-dashed border-gray-200 rounded-lg p-4 cursor-pointer hover:bg-gray-100 transition-colors"
            >
              <Upload className="w-5 h-5 text-gray-500" />
              <span className="text-gray-600">آپلود فایل CSV قیمت‌ها</span>
            </label>
            <input
              id="chart-data"
              type="file"
              accept=".csv"
              onChange={handleFileUpload}
              className="hidden"
            />
          </div>
          <button
            onClick={analyzeChart}
            disabled={isAnalyzing || data.length === 0}
            className="bg-[#a63439] text-white px-6 py-4 rounded-lg flex items-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
          >
            {isAnalyzing ? (
              <>
                <Brain className="w-5 h-5 animate-pulse" />
                <span>در حال تحلیل...</span>
              </>
            ) : (
              <>
                <Wand2 className="w-5 h-5" />
                <span>تشخیص الگوها</span>
              </>
            )}
          </button>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        <div ref={chartContainerRef} className="w-full h-[500px]" />

        {analysis && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="text-sm font-medium mb-3">آمار الگوها</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">تعداد کل الگوها</span>
                    <span className="font-medium">{analysis.statistics.totalPatterns}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">درصد اعتبار</span>
                    <span className="font-medium">{analysis.statistics.reliability.toFixed(1)}%</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">بازدهی متوسط</span>
                    <span className="font-medium">{analysis.statistics.averageReturn.toFixed(2)}%</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">نرخ موفقیت</span>
                    <span className="font-medium">{analysis.statistics.successRate.toFixed(1)}%</span>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="text-sm font-medium mb-3">الگوهای شناسایی شده</h3>
                <div className="space-y-2">
                  {analysis.patterns.map((pattern, index) => (
                    <div key={index} className="flex items-center justify-between text-sm">
                      <span>{pattern.pattern}</span>
                      <span className={`px-2 py-0.5 rounded-full text-xs ${
                        pattern.prediction.direction === 'bullish' ? 'bg-green-100 text-green-800' :
                        pattern.prediction.direction === 'bearish' ? 'bg-red-100 text-red-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {pattern.confidence}%
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="text-sm font-medium mb-3">پیشنهادات معاملاتی</h3>
              <div className="space-y-2">
                {analysis.recommendations.map((rec, index) => (
                  <div key={index} className="flex items-start gap-2 text-sm">
                    <div className="w-2 h-2 rounded-full bg-[#a63439] mt-1.5" />
                    <span>{rec}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="text-sm font-medium mb-3">بینش‌های کلیدی</h3>
              <div className="space-y-2">
                {analysis.insights.map((insight, index) => (
                  <div key={index} className="flex items-start gap-2 text-sm">
                    <Brain className="w-4 h-4 text-[#a63439] mt-1 flex-shrink-0" />
                    <span>{insight}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}