import React, { useState } from 'react';
import { Image, Upload, Download, Wand2, AlertCircle, Sparkles } from 'lucide-react';
import { generateImage } from '../lib/imageGeneration';
import { openai, DEFAULT_MODEL } from '../lib/openai';

const defaultSettings = {
  model_id: 'stable-diffusion',
  controlnet_model: 'تشخیص لبه',
  controlnet_type: 'canny',
  width: '1080',
  height: '1080',
  samples: '1',
  scheduler: 'پردازش تدریجی ساده',
  num_inference_steps: '30',
  guidance_scale: 7.5,
  controlnet_conditioning_scale: 0.7,
  strength: 0.55,
  clip_skip: '2'
};

export default function ImageAILite() {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImages, setGeneratedImages] = useState<string[]>([]);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [selectedStyle, setSelectedStyle] = useState<string>('realistic');
  const [error, setError] = useState<string | null>(null);
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [enhancedPrompt, setEnhancedPrompt] = useState<string | null>(null);

  const handleEnhancePrompt = async () => {
    try {
      setIsEnhancing(true);
      setError(null);

      const enhancementResponse = await openai.chat.completions.create({
        model: DEFAULT_MODEL,
        messages: [
          {
            role: 'system',
            content: `شما یک متخصص بهینه‌سازی پرامپت برای تولید تصویر هستید. وظیفه شما بهبود توضیحات کاربر با رعایت این محدودیت‌هاست:

محدودیت‌های اصلی:
1. حداکثر 3 جمله کوتاه و مرتبط
2. تمرکز فقط روی عناصر اصلی تصویر
3. پرهیز از توضیحات غیرضروری

عناصر مجاز برای اضافه کردن:
1. نورپردازی (فقط یک مورد):
   - نور طبیعی روز
   - نور استودیویی
   - نور درخشان
   - نور ملایم
   - نور دراماتیک

2. زاویه دید (فقط یک مورد):
   - نمای روبرو
   - نمای از بالا
   - نمای از پایین
   - نمای نیم‌رخ
   - نمای سه‌رخ

3. فاصله (فقط یک مورد):
   - نمای نزدیک
   - نمای متوسط
   - نمای دور

4. کیفیت (حداکثر دو مورد):
   - وضوح بالا
   - جزئیات دقیق
   - رنگ‌های زنده
   - کنتراست مناسب

قالب پاسخ:
- فقط متن بهبود یافته را برگردانید
- از افزودن توضیحات اضافه خودداری کنید
- ساختار جملات ساده و روان باشد
- اصل پیام کاربر حفظ شود`
          },
          {
            role: 'user',
            content: `لطفاً این توضیحات را برای تولید تصویر با کیفیت‌تر و حرفه‌ای‌تر بهبود دهید. متن اصلی: "${prompt}"

نکات مهم:
- جزئیات بصری را افزایش دهید
- به نورپردازی و رنگ‌ها توجه کنید
- ترکیب‌بندی و زاویه دید را مشخص کنید
- حس و حال کلی تصویر را حفظ کنید`
          }
        ]
      });

      const improvedPrompt = enhancementResponse.choices[0]?.message?.content;
      if (!improvedPrompt) throw new Error('خطا در بهبود پرامپت');
      setEnhancedPrompt(improvedPrompt);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'خطا در بهبود توضیحات';
      setError(errorMessage);
    } finally {
      setIsEnhancing(false);
    }
  };

  const applyEnhancedPrompt = () => {
    if (enhancedPrompt) {
      setPrompt(enhancedPrompt);
      setEnhancedPrompt(null);
    }
  };

  const styles = {
    realistic: 'عکاسی حرفه‌ای',
    portrait: 'پرتره هنری',
    anime: 'انیمه ژاپنی',
    painting: 'نقاشی رنگ روغن',
    watercolor: 'آبرنگ',
    sketch: 'طراحی سیاه قلم',
    cartoon: 'کارتونی فانتزی',
    digital: 'دیجیتال آرت',
    minimalist: 'مینیمال',
    vintage: 'قدیمی و کلاسیک',
    cyberpunk: 'سایبرپانک',
    fantasy: 'فانتزی جادویی'
  };

  const stylePrompts = {
    realistic: 'ultra realistic, professional photography, 8k uhd, highly detailed, studio lighting, sharp focus',
    portrait: 'professional portrait photography, dramatic lighting, bokeh, artistic, emotional, expressive',
    anime: 'anime style, Studio Ghibli, vibrant colors, cel shaded, beautiful anime art, manga style',
    painting: 'oil painting on canvas, masterpiece, fine art, classical painting style, detailed brushstrokes',
    watercolor: 'watercolor painting, soft colors, flowing textures, artistic, dreamy watercolor effects',
    sketch: 'detailed pencil sketch, graphite drawing, black and white, realistic shading, artistic',
    cartoon: 'cartoon style, colorful, cute, whimsical, playful, simple shapes, bold colors',
    digital: 'digital art, concept art, trending on artstation, highly detailed digital painting',
    minimalist: 'minimalist design, simple shapes, clean lines, limited color palette, modern aesthetic',
    vintage: 'vintage photography, retro style, old film grain, muted colors, nostalgic atmosphere',
    cyberpunk: 'cyberpunk style, neon lights, futuristic, high tech, dark atmosphere, cyber aesthetic',
    fantasy: 'fantasy art, magical, mystical atmosphere, ethereal lighting, enchanted, dreamlike'
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerate = async () => {
    try {
      setIsGenerating(true);
      setError(null);
      setGeneratedImages([]);

      if (!prompt.trim()) {
        throw new Error('خطا در ترجمه توضیحات. لطفاً دوباره تلاش کنید');
      }

      // ترجمه پرامپت فارسی به انگلیسی با استفاده از OpenAI
      const translationResponse = await openai.chat.completions.create({
        model: DEFAULT_MODEL,
        messages: [
          {
            role: 'system',
            content: `You are an expert in translating image prompts from Persian to English. Your task:

1. Translation Approach:
   - Precise translation of core concepts
   - Preservation of artistic intent
   - Enhancement of visual descriptions

2. Technical Optimization:
   - Professional photography terms
   - Artistic style descriptors
   - Composition keywords
   - Lighting terminology
   - Material and texture details

3. Visual Elements:
   - Color palettes and schemes
   - Lighting conditions and effects
   - Camera angles and perspectives
   - Depth and dimensionality
   - Texture and material qualities

4. Artistic Enhancement:
   - Style-specific terminology
   - Mood and atmosphere words
   - Visual effect descriptors
   - Quality-focused adjectives

5. AI-Optimization:
   - Clear, structured phrasing
   - Effective keyword placement
   - Balanced detail distribution
   - Technical accuracy

6. Quality Standards:
   - Professional terminology
   - Artistic integrity
   - Technical precision
   - Visual clarity`
          },
          {
            role: 'user',
            content: prompt.trim()
          }
        ]
      });

      const translatedPrompt = translationResponse.choices[0]?.message?.content;
      if (!translatedPrompt) throw new Error('خطا در ترجمه پرامپت');

      // Add quality keywords in English to ensure better results
      const enhancedPrompt = `${translatedPrompt}, ${stylePrompts[selectedStyle as keyof typeof stylePrompts]}, masterpiece, best quality, highly detailed, sharp focus, 8k uhd`;
      
      console.log('Enhanced Prompt:', enhancedPrompt); // برای دیباگ

      const response = await generateImage({
        key: "DIT0j1BOjKT9OSLc5d2dnHYpTqrNjhXVxGba5toE6Z5pWJiVM2uDbYdHpr2r",
        prompt: enhancedPrompt,
        negative_prompt: null,
        width: "1024",
        height: "1024",
        samples: "1",
        safety_checker: false,
        seed: null,
        base64: false
      });

      // Set generated images if response is valid
      setGeneratedImages(response.output);

    } catch (error) {
      let errorMessage = 'خطا در تولید تصویر. لطفاً دوباره تلاش کنید.';
      
      // Log full error details for debugging
      console.error('Image generation error details:', {
        error,
        type: typeof error,
        message: error?.message,
        stack: error?.stack,
        keys: error ? Object.keys(error) : [],
        stringified: JSON.stringify(error, null, 2)
      });
      
      if (error instanceof Error) {
        if (error.message.includes('rate limit')) {
          errorMessage = 'محدودیت تعداد درخواست. لطفاً چند دقیقه صبر کنید';
        } else if (error.message.includes('timeout')) {
          errorMessage = 'زمان پاسخگویی به پایان رسید. لطفاً دوباره تلاش کنید';
        } else if (error.message.includes('network')) {
          errorMessage = 'خطا در ارتباط با سرور. لطفاً اتصال اینترنت خود را بررسی کنید';
        } else if (error.message.includes('API_NO_CONTENT')) {
          errorMessage = 'خطا در دریافت تصویر. لطفاً دوباره تلاش کنید';
        } else if (error.message.includes('Invalid API key')) {
          errorMessage = 'خطای احراز هویت API. لطفاً با پشتیبانی تماس بگیرید';
        } else {
          errorMessage = error.message;
        }
      } else if (error?.response?.data?.error) {
        // Handle API error response
        errorMessage = error.response.data.error.message || 'خطا در ارتباط با سرور';
      } else if (error?.code) {
        // Handle error codes
        errorMessage = `خطای ${error.code}. لطفاً دوباره تلاش کنید`;
      } else {
        errorMessage = 'خطای ناشناخته. لطفاً دوباره تلاش کنید';
      }
      
      setError(errorMessage);
      console.error('Image generation failed:', {
        error,
        errorMessage,
        prompt: enhancedPrompt,
        style: selectedStyle
      });
      
      setError(errorMessage);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="text-2xl font-medium mb-2">هوش پیک لایت</h1>
          <p className="text-gray-600">به سادگی تصاویر خلاقانه بسازید</p>
        </div>

        <div className="bg-white rounded-xl p-6 space-y-6">
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium">توضیحات تصویر</label>
              <button
                onClick={handleEnhancePrompt}
                disabled={isEnhancing || !prompt.trim()}
                className="flex items-center gap-1 text-sm text-[#a63439] hover:text-[#8a2a2e] disabled:opacity-50"
              >
                <Sparkles className="w-4 h-4" />
                {isEnhancing ? 'هوشِکس در حال فکر کردن...' : 'بهبود توضیحات'}
              </button>
            </div>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="w-full h-32 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 resize-none"
              placeholder="مثال: یک منظره زیبا از غروب خورشید در ساحل، با آسمان نارنجی و بنفش، موج‌های آرام دریا، نخل‌های سایه‌دار در کنار ساحل، و چند پرنده در حال پرواز در آسمان"
            />
            {enhancedPrompt && (
              <div className="mt-2 p-3 bg-[#a63439]/5 border border-[#a63439]/10 rounded-lg">
                <p className="text-sm text-gray-600 mb-2">توضیحات بهبود یافته:</p>
                <p className="text-sm mb-2">{enhancedPrompt}</p>
                <button
                  onClick={applyEnhancedPrompt}
                  className="text-sm text-[#a63439] hover:text-[#8a2a2e] flex items-center gap-1"
                >
                  <Sparkles className="w-4 h-4" />
                  اعمال توضیحات جدید
                </button>
              </div>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">سبک تصویر</label>
            <div className="grid grid-cols-4 gap-3">
              {Object.entries(styles).map(([key, value]) => (
                <button
                  key={key}
                  onClick={() => setSelectedStyle(key)}
                  className={`p-3 rounded-lg text-sm transition-colors ${
                    selectedStyle === key
                      ? 'bg-[#a63439] text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {value}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex-1">
              <label
                htmlFor="image-upload-lite"
                className="flex items-center justify-center gap-2 w-full bg-gray-50 border-2 border-dashed border-gray-200 rounded-lg p-4 cursor-pointer hover:bg-gray-100 transition-colors"
              >
                <Upload className="w-5 h-5 text-gray-500" />
                <span className="text-gray-600">آپلود تصویر اولیه (اختیاری)</span>
              </label>
              <input
                id="image-upload-lite"
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
            </div>
            <button
              onClick={handleGenerate}
              disabled={isGenerating || !prompt}
              className="bg-[#a63439] text-white px-6 py-4 rounded-lg flex items-center gap-2 hover:bg-[#8a2a2e] transition-colors disabled:opacity-50"
            >
              <Wand2 className="w-5 h-5" />
              {isGenerating ? 'هوشِکس در حال فکر کردن...' : 'ساخت تصویر'}
            </button>
          </div>
        </div>
        
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700 mt-4">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {generatedImages.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-lg font-medium">تصاویر ساخته شده</h2>
            <div className="grid grid-cols-2 gap-4">
              {generatedImages.map((image, index) => (
                <div key={index} className="relative group">
                  <img
                    src={image}
                    alt={`Generated ${index + 1}`}
                    className="w-full rounded-lg shadow-md"
                  />
                  <a
                    href={image}
                    download={`generated-${index + 1}.png`}
                    className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-lg"
                  >
                    <Download className="w-6 h-6 text-white" />
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}