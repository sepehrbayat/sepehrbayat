import React, { useState } from 'react';
import { BookOpen, Brain, AlertCircle, Sparkles, FileText, GraduationCap, Target, Search, CheckCircle2, XCircle } from 'lucide-react';
import { openai, DEFAULT_MODEL } from '../../lib/openai';

interface ThesisAnalysis {
  topic: {
    score: number;
    strengths: string[];
    weaknesses: string[];
    suggestions: string[];
  };
  methodology: {
    recommended: string[];
    tools: string[];
    considerations: string[];
  };
  resources: {
    papers: string[];
    books: string[];
    websites: string[];
  };
  timeline: {
    phases: Array<{
      name: string;
      duration: string;
      tasks: string[];
    }>;
  };
}

export default function ThesisConsultation() {
  const [topic, setTopic] = useState('');
  const [field, setField] = useState('');
  const [level, setLevel] = useState<'bachelors' | 'masters' | 'phd'>('masters');
  const [question, setQuestion] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [analysis, setAnalysis] = useState<ThesisAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [response, setResponse] = useState<string | null>(null);
  const [showTopicAnalysis, setShowTopicAnalysis] = useState(false);

  const handleAnalyzeTopic = async () => {
    try {
      if (!topic.trim() || !field.trim()) {
        throw new Error('لطفاً موضوع و رشته تحصیلی را وارد کنید');
      }

      setIsLoading(true);
      setError(null);
      setAnalysis(null);

      const response = await openai.chat.completions.create({
        model: DEFAULT_MODEL,
        temperature: 0.7,
        messages: [
          {
            role: 'system',
            content: `شما یک استاد دانشگاه و متخصص راهنمایی پایان‌نامه هستید. لطفاً موضوع پایان‌نامه پیشنهادی را برای مقطع ${
              level === 'bachelors' ? 'کارشناسی' :
              level === 'masters' ? 'کارشناسی ارشد' : 'دکتری'
            } تحلیل کنید.

لطفاً نتایج تحلیل را در قالب JSON با این ساختار برگردانید:
{
  "topic": {
    "score": عدد,
    "strengths": ["نقطه قوت 1", "نقطه قوت 2"],
    "weaknesses": ["نقطه ضعف 1", "نقطه ضعف 2"],
    "suggestions": ["پیشنهاد 1", "پیشنهاد 2"]
  },
  "methodology": {
    "recommended": ["روش 1", "روش 2"],
    "tools": ["ابزار 1", "ابزار 2"],
    "considerations": ["ملاحظه 1", "ملاحظه 2"]
  },
  "resources": {
    "papers": ["مقاله 1", "مقاله 2"],
    "books": ["کتاب 1", "کتاب 2"],
    "websites": ["سایت 1", "سایت 2"]
  },
  "timeline": {
    "phases": [
      {
        "name": "نام فاز",
        "duration": "مدت زمان",
        "tasks": ["وظیفه 1", "وظیفه 2"]
      }
    ]
  }
}`
          },
          {
            role: 'user',
            content: `موضوع پایان‌نامه: ${topic}\nرشته تحصیلی: ${field}`
          }
        ]
      });

      const analysisText = response.choices[0]?.message?.content;
      if (!analysisText) {
        throw new Error('خطا در تحلیل موضوع');
      }

      try {
        const analysisData = JSON.parse(analysisText);
        setAnalysis(analysisData);
        setShowTopicAnalysis(true);
      } catch (parseError) {
        throw new Error('خطا در پردازش نتایج تحلیل');
      }

    } catch (error) {
      console.error('Error analyzing topic:', error);
      setError(error instanceof Error ? error.message : 'خطا در تحلیل موضوع');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async () => {
    try {
      if (!topic.trim() || !field.trim() || !question.trim()) {
        throw new Error('لطفاً تمام فیلدها را پر کنید');
      }

      setIsLoading(true);
      setError(null);
      setResponse(null);

      const completion = await openai.chat.completions.create({
        model: DEFAULT_MODEL,
        temperature: 0.7,
        messages: [
          {
            role: 'system',
            content: `شما یک استاد دانشگاه و متخصص راهنمایی پایان‌نامه هستید. با توجه به موضوع، رشته و سوال دانشجو، راهنمایی‌های دقیق و کاربردی ارائه دهید.

نکات مهم:
1. پاسخ‌ها باید عملی و قابل اجرا باشند
2. به استانداردهای علمی و آکادمیک توجه کنید
3. منابع و مراجع معتبر را پیشنهاد دهید
4. روش‌های تحقیق مناسب را معرفی کنید
5. از مثال‌های مرتبط استفاده کنید`
          },
          {
            role: 'user',
            content: `موضوع پایان‌نامه: ${topic}
رشته تحصیلی: ${field}
سوال: ${question}`
          }
        ]
      });

      const response = completion.choices[0]?.message?.content;
      if (!response) {
        throw new Error('خطا در دریافت پاسخ');
      }

      setResponse(response);

    } catch (error) {
      console.error('Error:', error);
      setError(error instanceof Error ? error.message : 'خطا در دریافت مشاوره');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6 mt-8">
      <div className="bg-white rounded-xl p-6 space-y-6">
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div>
            <label className="block text-sm font-medium mb-2">مقطع تحصیلی</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setLevel('bachelors')}
                className={`p-2 rounded-lg text-sm transition-colors ${
                  level === 'bachelors'
                    ? 'bg-[#a63439] text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                کارشناسی
              </button>
              <button
                onClick={() => setLevel('masters')}
                className={`p-2 rounded-lg text-sm transition-colors ${
                  level === 'masters'
                    ? 'bg-[#a63439] text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                ارشد
              </button>
              <button
                onClick={() => setLevel('phd')}
                className={`p-2 rounded-lg text-sm transition-colors ${
                  level === 'phd'
                    ? 'bg-[#a63439] text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                دکتری
              </button>
            </div>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">موضوع پایان‌نامه</label>
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2"
            placeholder="موضوع پایان‌نامه خود را وارد کنید..."
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">رشته تحصیلی</label>
          <input
            type="text"
            value={field}
            onChange={(e) => setField(e.target.value)}
            className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2"
            placeholder="رشته تحصیلی خود را وارد کنید..."
          />
        </div>

        <button
          onClick={handleAnalyzeTopic}
          disabled={isLoading || !topic.trim() || !field.trim()}
          className="w-full bg-gray-100 text-gray-700 p-4 rounded-lg flex items-center justify-center gap-2 hover:bg-gray-200 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? (
            <>
              <Brain className="w-5 h-5 animate-pulse" />
              <span>هوشِکس در حال فکر کردن...</span>
            </>
          ) : (
            <>
              <Target className="w-5 h-5" />
              <span>تحلیل موضوع پایان‌نامه</span>
            </>
          )}
        </button>

        <div>
          <label className="block text-sm font-medium mb-2">سوال شما</label>
          <textarea
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            className="w-full h-32 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 resize-none"
            placeholder="سوال خود درباره پایان‌نامه را بپرسید..."
          />
        </div>

        <button
          onClick={handleSubmit}
          disabled={isLoading || !topic.trim() || !field.trim() || !question.trim()}
          className="w-full bg-[#a63439] text-white p-4 rounded-lg flex items-center justify-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? (
            <>
              <Brain className="w-5 h-5 animate-pulse" />
              <span>هوشِکس در حال فکر کردن...</span>
            </>
          ) : (
            <>
              <BookOpen className="w-5 h-5" />
              <span>دریافت مشاوره</span>
            </>
          )}
        </button>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <p>{error}</p>
        </div>
      )}

      {showTopicAnalysis && analysis && (
        <div className="bg-white rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-medium">تحلیل موضوع پایان‌نامه</h2>
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <Brain className="w-4 h-4" />
              <span>تحلیل هوشمند</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="text-sm font-medium mb-3 flex items-center gap-2">
                  <Target className="w-4 h-4 text-[#a63439]" />
                  <span>ارزیابی موضوع</span>
                </h3>
                <div className="space-y-2">
                  {analysis.topic.strengths.map((strength, index) => (
                    <div key={index} className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="w-4 h-4 text-green-500 mt-1 flex-shrink-0" />
                      <span>{strength}</span>
                    </div>
                  ))}
                  {analysis.topic.weaknesses.map((weakness, index) => (
                    <div key={index} className="flex items-start gap-2 text-sm">
                      <XCircle className="w-4 h-4 text-red-500 mt-1 flex-shrink-0" />
                      <span>{weakness}</span>
                    </div>
                  ))}
                  {analysis.topic.suggestions.map((suggestion, index) => (
                    <div key={index} className="flex items-start gap-2 text-sm">
                      <Sparkles className="w-4 h-4 text-[#a63439] mt-1 flex-shrink-0" />
                      <span>{suggestion}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="text-sm font-medium mb-3 flex items-center gap-2">
                  <Search className="w-4 h-4 text-[#a63439]" />
                  <span>منابع پیشنهادی</span>
                </h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="text-xs font-medium text-gray-500 mb-2">مقالات علمی</h4>
                    <div className="space-y-2">
                      {analysis.resources.papers.map((paper, index) => (
                        <div key={index} className="text-sm">{paper}</div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h4 className="text-xs font-medium text-gray-500 mb-2">کتاب‌ها</h4>
                    <div className="space-y-2">
                      {analysis.resources.books.map((book, index) => (
                        <div key={index} className="text-sm">{book}</div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h4 className="text-xs font-medium text-gray-500 mb-2">منابع آنلاین</h4>
                    <div className="space-y-2">
                      {analysis.resources.websites.map((website, index) => (
                        <div key={index} className="text-sm">{website}</div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="text-sm font-medium mb-3 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-[#a63439]" />
                  <span>روش‌شناسی پیشنهادی</span>
                </h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="text-xs font-medium text-gray-500 mb-2">روش‌های تحقیق</h4>
                    <div className="space-y-2">
                      {analysis.methodology.recommended.map((method, index) => (
                        <div key={index} className="text-sm">{method}</div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h4 className="text-xs font-medium text-gray-500 mb-2">ابزارها</h4>
                    <div className="space-y-2">
                      {analysis.methodology.tools.map((tool, index) => (
                        <div key={index} className="text-sm">{tool}</div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h4 className="text-xs font-medium text-gray-500 mb-2">ملاحظات مهم</h4>
                    <div className="space-y-2">
                      {analysis.methodology.considerations.map((consideration, index) => (
                        <div key={index} className="text-sm">{consideration}</div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="text-sm font-medium mb-3 flex items-center gap-2">
                  <GraduationCap className="w-4 h-4 text-[#a63439]" />
                  <span>برنامه زمانی پیشنهادی</span>
                </h3>
                <div className="space-y-4">
                  {analysis.timeline.phases.map((phase, index) => (
                    <div key={index}>
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-sm font-medium">{phase.name}</h4>
                        <span className="text-xs text-gray-500">{phase.duration}</span>
                      </div>
                      <div className="space-y-1">
                        {phase.tasks.map((task, taskIndex) => (
                          <div key={taskIndex} className="text-sm flex items-start gap-2">
                            <div className="w-1.5 h-1.5 rounded-full bg-[#a63439] mt-1.5" />
                            <span>{task}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {response && (
        <div className="bg-white rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-medium">پاسخ مشاور</h2>
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <Brain className="w-4 h-4" />
              <span>تحلیل هوشمند</span>
            </div>
          </div>
          <div className="bg-gray-50 rounded-lg p-4 whitespace-pre-wrap text-gray-700">
            {response}
          </div>
        </div>
      )}
    </div>
  );
}