import React, { useState } from 'react';
import { FileText, Upload, AlertCircle, Brain, CheckCircle2, XCircle, Sparkles, FileUp } from 'lucide-react';
import { openai, DEFAULT_MODEL } from '../../lib/openai';

interface ArticleAnalysis {
  structure: {
    score: number;
    issues: string[];
    suggestions: string[];
  };
  content: {
    score: number;
    strengths: string[];
    weaknesses: string[];
    suggestions: string[];
  };
  language: {
    score: number;
    issues: string[];
    suggestions: string[];
  };
  references: {
    score: number;
    issues: string[];
    suggestions: string[];
  };
  overall: {
    score: number;
    summary: string;
    mainPoints: string[];
  };
}

export default function ArticleReview() {
  const [content, setContent] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<ArticleAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [articleType, setArticleType] = useState<'research' | 'review' | 'case-study'>('research');
  const [language, setLanguage] = useState<'persian' | 'english'>('persian');

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.type !== 'application/pdf' && !file.type.startsWith('text/')) {
        setError('لطفاً فقط فایل PDF یا متنی آپلود کنید');
        return;
      }
      
      if (file.size > 10 * 1024 * 1024) { // 10MB limit
        setError('حجم فایل نباید بیشتر از 10 مگابایت باشد');
        return;
      }

      setUploadedFile(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setContent(e.target?.result as string);
      };
      reader.readAsText(file);
    }
  };

  const handleAnalyze = async () => {
    try {
      if (!content.trim()) {
        throw new Error('لطفاً متن مقاله را وارد کنید');
      }

      setIsAnalyzing(true);
      setError(null);
      setAnalysis(null);

      const response = await openai.chat.completions.create({
        model: DEFAULT_MODEL,
        temperature: 0.7,
        messages: [
          {
            role: 'system',
            content: `شما یک متخصص ویرایش و بررسی مقالات علمی هستید. لطفاً مقاله ${articleType === 'research' ? 'پژوهشی' : articleType === 'review' ? 'مروری' : 'مطالعه موردی'} به زبان ${language === 'persian' ? 'فارسی' : 'انگلیسی'} ارائه شده را با دقت بررسی کرده و موارد زیر را مشخص کنید:

1. ساختار و فرمت:
   - بررسی ساختار کلی مقاله
   - فرمت‌بندی و پاراگراف‌بندی
   - نحوه ارجاع‌دهی

2. محتوا و نگارش:
   - کیفیت نگارش و روانی متن
   - انسجام و پیوستگی مطالب
   - قوت استدلال‌ها

3. اشکالات و پیشنهادات:
   - اشکالات نگارشی و دستوری
   - ضعف‌های محتوایی
   - پیشنهادات بهبود

لطفاً نتایج بررسی را به صورت دسته‌بندی شده و با جزئیات کامل ارائه دهید.`
          },
          {
            role: 'user',
            content: content.trim()
          }
        ]
      });

      const analysisText = response.choices[0]?.message?.content;
      if (!analysisText) {
        throw new Error('خطا در تحلیل مقاله');
      }

      try {
        const analysisData = JSON.parse(analysisText);
        setAnalysis(analysisData);
      } catch (parseError) {
        throw new Error('خطا در پردازش نتایج تحلیل');
      }

    } catch (error) {
      console.error('Error analyzing article:', error);
      setError(error instanceof Error ? error.message : 'خطا در تحلیل مقاله');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-6 mt-8">
      <div className="bg-white rounded-xl p-6 space-y-6">
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div>
            <label className="block text-sm font-medium mb-2">نوع مقاله</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setArticleType('research')}
                className={`p-2 rounded-lg text-sm transition-colors ${
                  articleType === 'research'
                    ? 'bg-[#a63439] text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                پژوهشی
              </button>
              <button
                onClick={() => setArticleType('review')}
                className={`p-2 rounded-lg text-sm transition-colors ${
                  articleType === 'review'
                    ? 'bg-[#a63439] text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                مروری
              </button>
              <button
                onClick={() => setArticleType('case-study')}
                className={`p-2 rounded-lg text-sm transition-colors ${
                  articleType === 'case-study'
                    ? 'bg-[#a63439] text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                مطالعه موردی
              </button>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">زبان مقاله</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setLanguage('persian')}
                className={`p-2 rounded-lg text-sm transition-colors ${
                  language === 'persian'
                    ? 'bg-[#a63439] text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                فارسی
              </button>
              <button
                onClick={() => setLanguage('english')}
                className={`p-2 rounded-lg text-sm transition-colors ${
                  language === 'english'
                    ? 'bg-[#a63439] text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                انگلیسی
              </button>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4 mb-6">
          <div className="flex-1">
            <label
              htmlFor="file-upload"
              className="flex items-center justify-center gap-2 w-full bg-gray-50 border-2 border-dashed border-gray-200 rounded-lg p-4 cursor-pointer hover:bg-gray-100 transition-colors"
            >
              <FileUp className="w-5 h-5 text-gray-500" />
              <span className="text-gray-600">آپلود فایل مقاله (PDF یا متنی)</span>
            </label>
            <input
              id="file-upload"
              type="file"
              accept=".pdf,.txt,.doc,.docx"
              onChange={handleFileUpload}
              className="hidden"
            />
          </div>
          {uploadedFile && (
            <div className="flex items-center gap-2 text-sm text-green-600">
              <CheckCircle2 className="w-4 h-4" />
              <span>{uploadedFile.name}</span>
            </div>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">متن مقاله</label>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="w-full h-64 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 resize-none"
            placeholder="متن مقاله خود را وارد کنید..."
          />
        </div>

        <button
          onClick={handleAnalyze}
          disabled={isAnalyzing || !content.trim()}
          className="w-full bg-[#a63439] text-white p-4 rounded-lg flex items-center justify-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isAnalyzing ? (
            <>
              <Brain className="w-5 h-5 animate-pulse" />
              <span>هوشِکس در حال فکر کردن...</span>
            </>
          ) : (
            <>
              <FileText className="w-5 h-5" />
              <span>تحلیل مقاله</span>
            </>
          )}
        </button>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <p>{error}</p>
        </div>
      )}

      {analysis && (
        <div className="bg-white rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-medium">نتایج تحلیل</h2>
              <p className="text-sm text-gray-500 mt-1">امتیاز کلی: {analysis.overall.score}/100</p>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <Brain className="w-4 h-4" />
              <span>تحلیل هوشمند</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="text-sm font-medium mb-3 flex items-center justify-between">
                  <span>ساختار و فرمت</span>
                  <span className={`${
                    analysis.structure.score >= 20 ? 'text-green-600' :
                    analysis.structure.score >= 15 ? 'text-yellow-600' :
                    'text-red-600'
                  }`}>{analysis.structure.score}/25</span>
                </h3>
                <div className="space-y-2">
                  {analysis.structure.issues.map((issue, index) => (
                    <div key={index} className="flex items-start gap-2 text-sm">
                      <XCircle className="w-4 h-4 text-red-500 mt-1 flex-shrink-0" />
                      <span>{issue}</span>
                    </div>
                  ))}
                  {analysis.structure.suggestions.map((suggestion, index) => (
                    <div key={index} className="flex items-start gap-2 text-sm">
                      <Sparkles className="w-4 h-4 text-[#a63439] mt-1 flex-shrink-0" />
                      <span>{suggestion}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="text-sm font-medium mb-3 flex items-center justify-between">
                  <span>محتوا و کیفیت علمی</span>
                  <span className={`${
                    analysis.content.score >= 28 ? 'text-green-600' :
                    analysis.content.score >= 21 ? 'text-yellow-600' :
                    'text-red-600'
                  }`}>{analysis.content.score}/35</span>
                </h3>
                <div className="space-y-2">
                  {analysis.content.strengths.map((strength, index) => (
                    <div key={index} className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="w-4 h-4 text-green-500 mt-1 flex-shrink-0" />
                      <span>{strength}</span>
                    </div>
                  ))}
                  {analysis.content.weaknesses.map((weakness, index) => (
                    <div key={index} className="flex items-start gap-2 text-sm">
                      <XCircle className="w-4 h-4 text-red-500 mt-1 flex-shrink-0" />
                      <span>{weakness}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="text-sm font-medium mb-3 flex items-center justify-between">
                  <span>نگارش و زبان</span>
                  <span className={`${
                    analysis.language.score >= 16 ? 'text-green-600' :
                    analysis.language.score >= 12 ? 'text-yellow-600' :
                    'text-red-600'
                  }`}>{analysis.language.score}/20</span>
                </h3>
                <div className="space-y-2">
                  {analysis.language.issues.map((issue, index) => (
                    <div key={index} className="flex items-start gap-2 text-sm">
                      <XCircle className="w-4 h-4 text-red-500 mt-1 flex-shrink-0" />
                      <span>{issue}</span>
                    </div>
                  ))}
                  {analysis.language.suggestions.map((suggestion, index) => (
                    <div key={index} className="flex items-start gap-2 text-sm">
                      <Sparkles className="w-4 h-4 text-[#a63439] mt-1 flex-shrink-0" />
                      <span>{suggestion}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="text-sm font-medium mb-3 flex items-center justify-between">
                  <span>منابع و ارجاعات</span>
                  <span className={`${
                    analysis.references.score >= 16 ? 'text-green-600' :
                    analysis.references.score >= 12 ? 'text-yellow-600' :
                    'text-red-600'
                  }`}>{analysis.references.score}/20</span>
                </h3>
                <div className="space-y-2">
                  {analysis.references.issues.map((issue, index) => (
                    <div key={index} className="flex items-start gap-2 text-sm">
                      <XCircle className="w-4 h-4 text-red-500 mt-1 flex-shrink-0" />
                      <span>{issue}</span>
                    </div>
                  ))}
                  {analysis.references.suggestions.map((suggestion, index) => (
                    <div key={index} className="flex items-start gap-2 text-sm">
                      <Sparkles className="w-4 h-4 text-[#a63439] mt-1 flex-shrink-0" />
                      <span>{suggestion}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 p-4 bg-[#a63439]/5 rounded-lg border border-[#a63439]/10">
            <h3 className="text-sm font-medium mb-3">خلاصه تحلیل</h3>
            <p className="text-sm text-gray-700 mb-4">{analysis.overall.summary}</p>
            <div className="space-y-2">
              {analysis.overall.mainPoints.map((point, index) => (
                <div key={index} className="flex items-start gap-2 text-sm">
                  <Brain className="w-4 h-4 text-[#a63439] mt-1 flex-shrink-0" />
                  <span>{point}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}