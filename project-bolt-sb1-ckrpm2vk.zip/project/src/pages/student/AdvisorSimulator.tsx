import React, { useState } from 'react';
import { GraduationCap, Send, Brain, Sparkles, Book, FileText, Search, Target, Settings2 } from 'lucide-react';
import { openai, DEFAULT_MODEL } from '../../lib/openai';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  metadata?: {
    type?: 'general' | 'methodology' | 'literature' | 'analysis' | 'writing';
    references?: string[];
    suggestions?: string[];
  };
}

interface AdvisorPreferences {
  style: 'formal' | 'friendly';
  detail: 'concise' | 'detailed';
  focus: 'theoretical' | 'practical';
}

export default function AdvisorSimulator() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showPreferences, setShowPreferences] = useState(false);
  const [preferences, setPreferences] = useState<AdvisorPreferences>({
    style: 'friendly',
    detail: 'detailed',
    focus: 'practical'
  });
  const [field, setField] = useState('');
  const [topic, setTopic] = useState('');
  const [showSetup, setShowSetup] = useState(true);

  const handleStartChat = () => {
    if (!field.trim() || !topic.trim()) return;
    
    // ابتدا موضوع را تحلیل می‌کنیم
    setIsLoading(true);
    openai.chat.completions.create({
      model: DEFAULT_MODEL,
      temperature: 0.7,
      messages: [
        {
          role: 'system',
          content: `شما یک استاد راهنمای دانشگاه با تخصص در رشته ${field} هستید. لطفاً موضوع پایان‌نامه پیشنهادی را تحلیل کنید و نظر تخصصی خود را در قالب یک پیام خوشامدگویی ارائه دهید.

نکات مهم:
1. به نقاط قوت و ضعف موضوع اشاره کنید
2. پیشنهادات اولیه برای شروع کار ارائه دهید
3. منابع کلیدی را معرفی کنید
4. مسیر پژوهش را مشخص کنید

لطفاً پاسخ را در قالب JSON با این ساختار برگردانید:
{
  "content": "متن پیام خوشامدگویی",
  "metadata": {
    "type": "initial_analysis",
    "strengths": ["نقطه قوت 1", "نقطه قوت 2"],
    "suggestions": ["پیشنهاد 1", "پیشنهاد 2"],
    "references": ["منبع 1", "منبع 2"]
  }
}`
        },
        {
          role: 'user',
          content: `رشته: ${field}\nموضوع پایان‌نامه: ${topic}`
        }
      ]
    }).then(response => {
      try {
        let analysisData;
        const content = response.choices[0]?.message?.content;
        
        if (!content) {
          throw new Error('پاسخی از سرور دریافت نشد');
        }

        try {
          // Find the first occurrence of a JSON object
          const jsonStart = content.indexOf('{');
          const jsonEnd = content.lastIndexOf('}') + 1;
          const jsonStr = content.slice(jsonStart, jsonEnd);
          analysisData = JSON.parse(jsonStr);
        } catch (parseError) {
          console.error('JSON parse error:', parseError);
          throw new Error('خطا در پردازش پاسخ سرور');
        }

        if (!analysisData?.content) {
          throw new Error('ساختار پاسخ نامعتبر است');
        }

        setMessages([{
          role: 'assistant',
          content: analysisData.content || 'سلام! من استاد راهنمای شما هستم. چطور می‌تونم کمکتون کنم؟',
          metadata: analysisData.metadata
        }]);
      } catch (error) {
        console.error('Error parsing initial analysis:', error);
        setMessages([{
          role: 'assistant',
          content: `سلام! من استاد راهنمای شما در زمینه ${field} هستم. موضوع پایان‌نامه شما "${topic}" بسیار جالب است. چطور می‌تونم کمکتون کنم؟`,
          metadata: {
            type: 'general'
          }
        }]);
      }
      setIsLoading(false);
    }).catch(error => {
      console.error('Error getting initial analysis:', error);
      setMessages([{
        role: 'assistant',
        content: `سلام! من استاد راهنمای شما در زمینه ${field} هستم. موضوع پایان‌نامه شما "${topic}" بسیار جالب است. چطور می‌تونم کمکتون کنم؟`,
        metadata: {
          type: 'general'
        }
      }]);
      setIsLoading(false);
    });
    setShowSetup(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = { role: 'user' as const, content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const completion = await openai.chat.completions.create({
        model: DEFAULT_MODEL,
        temperature: 0.7,
        presence_penalty: 0.6,
        frequency_penalty: 0.3,
        messages: [
          {
            role: 'system',
            content: `شما یک استاد راهنمای دانشگاه هستید که:

1. با دقت به سوالات دانشجویان گوش می‌دهید
2. راهنمایی‌های عملی و کاربردی ارائه می‌دهید
3. از تجربیات آکادمیک خود استفاده می‌کنید
4. به استانداردهای علمی پایبند هستید
5. دانشجو را به تفکر و تحقیق تشویق می‌کنید

رشته تحصیلی دانشجو: ${field}
موضوع پایان‌نامه: ${topic}

سبک پاسخ‌دهی:
- لحن: ${preferences.style === 'formal' ? 'رسمی و آکادمیک' : 'دوستانه و صمیمی'}
- جزئیات: ${preferences.detail === 'detailed' ? 'کامل و مفصل' : 'مختصر و مفید'}
- تمرکز: ${preferences.focus === 'theoretical' ? 'مباحث تئوری و نظری' : 'جنبه‌های عملی و کاربردی'}

لطفاً پاسخ را در قالب JSON با این ساختار برگردانید:
{
  "content": "متن پاسخ",
  "metadata": {
    "type": "نوع پاسخ",
    "references": ["منبع 1", "منبع 2"],
    "suggestions": ["پیشنهاد 1", "پیشنهاد 2"]
  }
}`
          },
          ...messages.map(msg => ({
            role: msg.role === 'user' ? 'user' as const : 'assistant' as const,
            content: msg.content
          })),
          userMessage
        ]
      });
      
      const responseText = completion.choices[0]?.message?.content;
      if (!responseText) {
        throw new Error('خطا در دریافت پاسخ');
      }

      let parsedResponse;
      try {
        parsedResponse = JSON.parse(responseText);
      } catch {
        parsedResponse = { content: responseText };
      }

      const assistantMessage: Message = {
        role: 'assistant' as const,
        content: parsedResponse.content || 'متاسفانه پاسخی دریافت نشد.',
        metadata: parsedResponse.metadata
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Error:', error);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'متاسفانه خطایی رخ داد. لطفاً دوباره تلاش کنید.'
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6 mt-8">
      <div className="bg-white rounded-xl p-6">
        {showSetup ? (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium mb-2">رشته تحصیلی</label>
              <input
                type="text"
                value={field}
                onChange={(e) => setField(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2"
                placeholder="رشته تحصیلی خود را وارد کنید..."
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">موضوع پایان‌نامه</label>
              <input
                type="text"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2"
                placeholder="موضوع پایان‌نامه خود را وارد کنید..."
              />
            </div>
            <button
              onClick={handleStartChat}
              disabled={!field.trim() || !topic.trim()}
              className={`w-full bg-[#a63439] text-white p-4 rounded-lg flex items-center justify-center gap-2 hover:bg-[#8a2a2e] transition-all ${
                isLoading ? 'animate-pulse' : ''
              } disabled:opacity-50`}
            >
              {isLoading ? (
                <>
                  <Brain className="w-5 h-5 animate-pulse" />
                  <span>هوشِکس در حال فکر کردن...</span>
                </>
              ) : (
                <>
                  <GraduationCap className="w-5 h-5" />
                  <span>شروع گفتگو با استاد راهنما</span>
                </>
              )}
            </button>
          </div>
        ) : (
          <div className="flex flex-col h-[500px]">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-lg font-medium">گفتگو با استاد راهنما</h2>
                <p className="text-sm text-gray-500">رشته: {field} | موضوع: {topic}</p>
              </div>
              <button
                onClick={() => setShowPreferences(!showPreferences)}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <Settings2 className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            {showPreferences && (
              <div className="mb-4 p-4 bg-gray-50 rounded-lg space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">لحن گفتگو</label>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setPreferences(p => ({ ...p, style: 'friendly' }))}
                      className={`px-3 py-1 rounded ${
                        preferences.style === 'friendly'
                          ? 'bg-[#a63439] text-white'
                          : 'bg-gray-200'
                      }`}
                    >
                      دوستانه
                    </button>
                    <button
                      onClick={() => setPreferences(p => ({ ...p, style: 'formal' }))}
                      className={`px-3 py-1 rounded ${
                        preferences.style === 'formal'
                          ? 'bg-[#a63439] text-white'
                          : 'bg-gray-200'
                      }`}
                    >
                      رسمی
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">سطح جزئیات</label>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setPreferences(p => ({ ...p, detail: 'concise' }))}
                      className={`px-3 py-1 rounded ${
                        preferences.detail === 'concise'
                          ? 'bg-[#a63439] text-white'
                          : 'bg-gray-200'
                      }`}
                    >
                      مختصر
                    </button>
                    <button
                      onClick={() => setPreferences(p => ({ ...p, detail: 'detailed' }))}
                      className={`px-3 py-1 rounded ${
                        preferences.detail === 'detailed'
                          ? 'bg-[#a63439] text-white'
                          : 'bg-gray-200'
                      }`}
                    >
                      مفصل
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">تمرکز راهنمایی</label>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setPreferences(p => ({ ...p, focus: 'practical' }))}
                      className={`px-3 py-1 rounded ${
                        preferences.focus === 'practical'
                          ? 'bg-[#a63439] text-white'
                          : 'bg-gray-200'
                      }`}
                    >
                      عملی
                    </button>
                    <button
                      onClick={() => setPreferences(p => ({ ...p, focus: 'theoretical' }))}
                      className={`px-3 py-1 rounded ${
                        preferences.focus === 'theoretical'
                          ? 'bg-[#a63439] text-white'
                          : 'bg-gray-200'
                      }`}
                    >
                      نظری
                    </button>
                  </div>
                </div>
              </div>
            )}

            <div className="flex-1 overflow-y-auto space-y-4 mb-4">
              {messages.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-gray-500">
                  <GraduationCap className="w-12 h-12 mb-4 text-[#a63439]" />
                  <p>سوال خود را از استاد راهنما بپرسید</p>
                </div>
              ) : (
                messages.map((message, index) => (
                  <div
                    key={index}
                    className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-2xl p-3 ${
                        message.role === 'user'
                          ? 'bg-[#a63439] text-white'
                          : 'bg-gray-100 text-gray-800 space-y-3'
                      }`}
                    >
                      <p className="whitespace-pre-wrap">{message.content}</p>
                      {message.role === 'assistant' && message.metadata && (
                        <>
                          {message.metadata.references && message.metadata.references.length > 0 && (
                            <div className="border-t border-gray-200 pt-2 mt-2">
                              <div className="text-xs font-medium text-gray-500 mb-1 flex items-center gap-1">
                                <Book className="w-3 h-3" />
                                منابع مرتبط:
                              </div>
                              <div className="space-y-1">
                                {message.metadata.references.map((ref, index) => (
                                  <div key={index} className="text-xs text-gray-600">{ref}</div>
                                ))}
                              </div>
                            </div>
                          )}
                          {message.metadata.suggestions && message.metadata.suggestions.length > 0 && (
                            <div className="border-t border-gray-200 pt-2 mt-2">
                              <div className="text-xs font-medium text-gray-500 mb-1 flex items-center gap-1">
                                <Sparkles className="w-3 h-3" />
                                پیشنهادات:
                              </div>
                              <div className="space-y-1">
                                {message.metadata.suggestions.map((suggestion, index) => (
                                  <div key={index} className="text-xs text-gray-600 flex items-start gap-1">
                                    <div className="w-1 h-1 rounded-full bg-[#a63439] mt-1.5 flex-shrink-0" />
                                    {suggestion}
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </>
                      )}
                    </div>
                  </div>
                ))
              )}
              {isLoading && (
                <div className="flex items-center gap-3 text-gray-500">
                  <Brain className="w-5 h-5 text-[#a63439] animate-pulse" />
                  <p>هوشِکس در حال فکر کردن...</p>
                </div>
              )}
            </div>

            <form onSubmit={handleSubmit} className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={isLoading ? "در حال پردازش..." : "پیام خود را بنویسید..."}
                className="flex-1 bg-gray-100 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#a63439] transition-all"
                disabled={isLoading}
              />
              <button
                type="submit"
                disabled={isLoading || !input.trim()}
                className="bg-[#a63439] text-white p-2 rounded-xl hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
              >
                <Send className="w-6 h-6" />
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}