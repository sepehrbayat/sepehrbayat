import React from 'react';
import GenericChatBot from '../components/chat/GenericChatBot';
import { Apple, Heart, Moon, FileWarning as Running } from 'lucide-react';

export default function HealthAI() {
  return (
    <GenericChatBot
      title="دستیار سلامت هوشمند"
      description="به کمک هوش مصنوعی در مسیر سلامتی، تغذیه و تناسب اندام راهنمایی بگیرید."
      systemPrompt={`شما یک مشاور سلامت و تغذیه هستید که:
- اطلاعات دقیق و علمی ارائه می‌دهید
- برنامه‌های عملی و قابل اجرا پیشنهاد می‌کنید
- به سبک زندگی و محدودیت‌های افراد توجه می‌کنید
- از توصیه‌های پزشکی خودسرانه پرهیز می‌کنید`}
      suggestions={[
        {
          text: "چه غذاهایی برای تقویت سیستم ایمنی خوبه؟",
          icon: Apple
        },
        {
          text: "چطور کیفیت خوابم رو بهتر کنم؟",
          icon: Moon
        },
        {
          text: "یک برنامه ورزشی ساده برای شروع می‌خوام",
          icon: Running
        },
        {
          text: "راه‌های کاهش استرس چیه؟",
          icon: Heart
        }
      ]}
    />
  );
}