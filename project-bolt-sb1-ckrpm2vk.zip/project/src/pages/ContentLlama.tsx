import React, { useState, useRef, useEffect } from 'react';
import { PenTool, AlertCircle, Hash, Sparkles, Loader2, Search, Brain, Crown, Star } from 'lucide-react';
import { openai } from '../lib/openai';
import RichTextEditor from '../components/editor/RichTextEditor';

interface Heading {
  title: string;
  level: number;
  id: string;
  children?: Heading[];
  parentId?: string;
}

export default function ContentLlama() {
  const [topic, setTopic] = useState('');
  const [keywords, setKeywords] = useState<string[]>([]);
  const [newKeyword, setNewKeyword] = useState('');
  const [headings, setHeadings] = useState<Heading[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSuggestingKeywords, setIsSuggestingKeywords] = useState(false);
  const [isSuggestingHeadings, setIsSuggestingHeadings] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [suggestedKeywords, setSuggestedKeywords] = useState<string[]>([]);
  const [suggestedHeadings, setSuggestedHeadings] = useState<Heading[]>([]);
  const [editorContent, setEditorContent] = useState<string>('');
  const [showKeywordSuggestions, setShowKeywordSuggestions] = useState(false);
  const [showHeadingSuggestions, setShowHeadingSuggestions] = useState(false);
  const [progress, setProgress] = useState<string>('');
  const keywordRef = useRef<HTMLDivElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (keywordRef.current && !keywordRef.current.contains(event.target as Node)) {
        setShowKeywordSuggestions(false);
      }
      if (headingRef.current && !headingRef.current.contains(event.target as Node)) {
        setShowHeadingSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleAddKeyword = () => {
    if (newKeyword.trim() && !keywords.includes(newKeyword.trim())) {
      setKeywords([...keywords, newKeyword.trim()]);
      setNewKeyword('');
    }
  };

  const handleRemoveKeyword = (keyword: string) => {
    setKeywords(keywords.filter(k => k !== keyword));
  };

  const handleRemoveHeading = (headingId: string) => {
    setHeadings(prev => prev.filter(h => h.id !== headingId));
  };

  const handleSuggestKeywords = async () => {
    try {
      if (!topic.trim()) {
        throw new Error('لطفاً موضوع را وارد کنید');
      }

      setIsSuggestingKeywords(true);
      setError(null);

      const response = await openai.chat.completions.create({
        model: 'Meta-Llama-3-8B-Instruct',
        temperature: 0.7,
        messages: [
          {
            role: 'system',
            content: `شما یک متخصص سئو و تولید محتوا هستید. لطفاً برای موضوع داده شده، 5 کلمه کلیدی مرتبط و پرکاربرد پیشنهاد دهید.

نکات مهم:
- کلمات کلیدی باید مرتبط با موضوع باشند
- از کلمات پرجستجو استفاده کنید
- کلمات باید فارسی باشند
- از عبارات کوتاه (1 تا 3 کلمه) استفاده کنید

لطفاً فقط کلمات کلیدی را در قالب آرایه JSON برگردانید. مثال:
["کلمه کلیدی 1", "کلمه کلیدی 2", "کلمه کلیدی 3"]`
          },
          {
            role: 'user',
            content: topic
          }
        ]
      });

      const suggestedKeywords = JSON.parse(response.choices[0]?.message?.content || '[]');
      setSuggestedKeywords(suggestedKeywords.filter(k => !keywords.includes(k)));
      setShowKeywordSuggestions(true);

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'خطا در پیشنهاد کلمات کلیدی';
      console.error('Error suggesting keywords:', errorMessage);
      setError(errorMessage);
      setSuggestedKeywords([]);
    } finally {
      setIsSuggestingKeywords(false);
    }
  };

  const handleSuggestHeadings = async (parentId?: string) => {
    try {
      if (!topic.trim()) {
        throw new Error('لطفاً موضوع را وارد کنید');
      }

      setIsSuggestingHeadings(true);
      setError(null);

      const parentHeading = parentId ? headings.find(h => h.id === parentId) : null;
      const level = parentHeading ? parentHeading.level + 1 : 2;

      if (level > 4) {
        throw new Error('حداکثر سطح سرتیتر H4 می‌باشد');
      }

      const headingContext = parentHeading ? `${parentHeading.title} > ` : '';

      const response = await openai.chat.completions.create({
        model: 'Meta-Llama-3-8B-Instruct',
        temperature: 0.7,
        messages: [
          {
            role: 'system',
            content: `شما یک متخصص ساختاردهی محتوا هستید. لطفاً سرتیترهای مناسب برای موضوع "${topic}" پیشنهاد دهید.

موقعیت فعلی: ${level === 2 ? 'نیاز به سرفصل‌های اصلی (H2)' : `نیاز به زیرعنوان‌های (H${level}) برای "${headingContext}"`}

لطفاً خروجی را فقط در قالب JSON با این ساختار برگردانید:
[{
  "title": "عنوان پیشنهادی",
  "level": ${level},
  "id": "unique-string",
  "parentId": ${parentId ? `"${parentId}"` : 'null'}
}]`
          }
        ]
      });

      const suggestions = JSON.parse(response.choices[0]?.message?.content || '[]');
      setSuggestedHeadings(suggestions.map(h => ({
        ...h,
        id: Math.random().toString(36).substr(2, 9)
      })));
      setShowHeadingSuggestions(true);

    } catch (error) {
      console.error('Error suggesting headings:', error);
      setError(error instanceof Error ? error.message : 'خطا در پیشنهاد سرتیترها');
    } finally {
      setIsSuggestingHeadings(false);
    }
  };

  const handleGenerateContent = async () => {
    try {
      if (!topic.trim()) {
        throw new Error('لطفاً موضوع محتوا را وارد کنید');
      }

      if (keywords.length === 0) {
        throw new Error('لطفاً حداقل یک کلمه کلیدی وارد کنید');
      }

      if (headings.length === 0) {
        throw new Error('لطفاً حداقل یک سرتیتر وارد کنید');
      }

      setIsGenerating(true);
      setError(null);
      setEditorContent('');
      setProgress('در حال تولید محتوا با Meta-Llama...');

      const response = await openai.chat.completions.create({
        model: 'Meta-Llama-3-8B-Instruct',
        temperature: 0.7,
        messages: [
          {
            role: 'system',
            content: `شما یک نویسنده حرفه‌ای محتوا هستید. لطفاً با استفاده از ساختار سرتیترها و کلمات کلیدی، یک محتوای جامع و حرفه‌ای تولید کنید.

ساختار محتوا:
${headings.map(h => `${'-'.repeat(h.level)} ${h.title}`).join('\n')}

کلمات کلیدی: ${keywords.join('، ')}

نکات مهم:
1. از کلمات کلیدی به صورت طبیعی استفاده کنید
2. محتوا باید کاملاً فارسی و روان باشد
3. از ساختار سرتیترها پیروی کنید
4. محتوا باید جامع و کاربردی باشد
5. از مثال‌های عملی استفاده کنید`
          }
        ]
      });

      const generatedContent = response.choices[0]?.message?.content;
      if (!generatedContent) {
        throw new Error('خطا در تولید محتوا');
      }

      setEditorContent(generatedContent);

    } catch (error) {
      console.error('Content generation error:', error);
      setError(error instanceof Error ? error.message : 'خطا در تولید محتوا');
    } finally {
      setIsGenerating(false);
      setProgress('');
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#a63439] to-[#262e43] flex items-center justify-center">
              <Crown className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-medium">تولید محتوا</h1>
                <div className="flex items-center gap-1 bg-gradient-to-r from-amber-500 to-amber-600 text-white text-xs px-2 py-0.5 rounded-full">
                  <Star className="w-3 h-3 fill-current" />
                  <span>PREMIUM</span>
                </div>
              </div>
              <p className="text-gray-600">تولید محتوای هوشمند با Meta-Llama</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 space-y-6">
          <div>
            <label className="block text-sm font-medium mb-2">موضوع محتوا</label>
            <textarea
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="w-full h-32 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 resize-none"
              placeholder="موضوع مورد نظر خود را وارد کنید..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">کلمات کلیدی</label>
            <div className="flex gap-2 mb-3">
              <div ref={keywordRef} className="relative flex-1 flex gap-2">
                <Hash className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  value={newKeyword}
                  onChange={(e) => setNewKeyword(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleAddKeyword()}
                  className="w-full bg-gray-50 border border-gray-200 rounded-lg px-9 py-2"
                  placeholder="کلمه کلیدی را وارد کنید..."
                />
                <button
                  onClick={handleSuggestKeywords}
                  disabled={isSuggestingKeywords || !topic.trim()}
                  className="bg-gray-100 text-gray-700 px-3 py-2 rounded-lg hover:bg-gray-200 transition-colors flex items-center gap-1 disabled:opacity-50"
                >
                  {isSuggestingKeywords ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Sparkles className="w-4 h-4" />
                  )}
                  <span>پیشنهاد هوشمند</span>
                </button>
                {showKeywordSuggestions && suggestedKeywords.length > 0 && (
                  <div className="absolute top-full right-0 mt-1 w-full bg-white border border-gray-200 rounded-lg shadow-lg p-2 space-y-1 z-10">
                    {suggestedKeywords.map((keyword, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-2 hover:bg-gray-50 rounded-lg"
                      >
                        <span className="text-sm">{keyword}</span>
                        <button
                          onClick={() => {
                            setKeywords(prev => [...prev, keyword]);
                            setSuggestedKeywords(prev => prev.filter(k => k !== keyword));
                            if (suggestedKeywords.length === 1) {
                              setShowKeywordSuggestions(false);
                            }
                          }}
                          className="text-[#a63439] hover:text-[#8a2a2e] p-1"
                        >
                          +
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <button
                onClick={handleAddKeyword}
                disabled={!newKeyword.trim()}
                className="bg-[#a63439] text-white px-4 py-2 rounded-lg hover:bg-[#8a2a2e] transition-colors disabled:opacity-50"
              >
                افزودن
              </button>
            </div>
            {keywords.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {keywords.map((keyword, index) => (
                  <span
                    key={index}
                    className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm flex items-center gap-2"
                  >
                    {keyword}
                    <button
                      onClick={() => handleRemoveKeyword(keyword)}
                      className="text-gray-500 hover:text-red-500"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">سرتیترها</label>
            <div className="flex gap-2 mb-3">
              <div ref={headingRef} className="relative flex-1">
                <button
                  onClick={() => handleSuggestHeadings()}
                  disabled={isSuggestingHeadings || !topic.trim()}
                  className="w-full bg-gray-100 text-gray-700 px-3 py-2 rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isSuggestingHeadings ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Sparkles className="w-4 h-4" />
                  )}
                  <span>پیشنهاد سرتیترهای هوشمند</span>
                </button>
                {showHeadingSuggestions && suggestedHeadings.length > 0 && (
                  <div className="absolute top-full right-0 mt-1 w-full bg-white border border-gray-200 rounded-lg shadow-lg p-2 space-y-1 z-10">
                    {suggestedHeadings.map((heading) => (
                      <div
                        key={heading.id}
                        className="flex items-center justify-between p-2 hover:bg-gray-50 rounded-lg"
                      >
                        <span className="text-sm">{heading.title}</span>
                        <button
                          onClick={() => {
                            setHeadings(prev => [...prev, heading]);
                            setSuggestedHeadings(prev => prev.filter(h => h.id !== heading.id));
                            if (suggestedHeadings.length === 1) {
                              setShowHeadingSuggestions(false);
                            }
                          }}
                          className="text-[#a63439] hover:text-[#8a2a2e] p-1"
                        >
                          +
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
            {headings.length > 0 && (
              <div className="space-y-4">
                {headings.map((heading) => (
                  <div
                    key={heading.id}
                    className="bg-gray-50 rounded-lg p-3 flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-[#a63439] text-sm">H{heading.level}</span>
                      <span className="text-sm">{heading.title}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {heading.level < 4 && (
                        <button
                          onClick={() => handleSuggestHeadings(heading.id)}
                          className="text-[#a63439] hover:text-[#8a2a2e] p-1"
                        >
                          <Sparkles className="w-4 h-4" />
                        </button>
                      )}
                      <button
                        onClick={() => handleRemoveHeading(heading.id)}
                        className="text-gray-500 hover:text-red-500 p-1"
                      >
                        ×
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <button
            onClick={handleGenerateContent}
            disabled={isGenerating || !topic.trim() || keywords.length === 0 || headings.length === 0}
            className="w-full bg-gradient-to-r from-amber-500 to-amber-600 text-white p-4 rounded-lg flex items-center justify-center gap-2 hover:opacity-90 transition-all disabled:opacity-50 shadow-[0_0_15px_rgba(245,158,11,0.3)] hover:shadow-[0_0_25px_rgba(245,158,11,0.5)]"
          >
            {isGenerating ? (
              <>
                <Brain className="w-5 h-5 animate-pulse" />
                <span>در حال تولید محتوا...</span>
              </>
            ) : (
              <>
                <div className="relative">
                  <Crown className="w-5 h-5 text-amber-100" />
                  <div className="absolute -top-1 -right-1">
                    <Star className="w-3 h-3 text-amber-200 fill-amber-200" />
                  </div>
                </div>
                <span>تولید محتوا با هوشِکس پرو</span>
              </>
            )}
          </button>
        </div>

        {progress && (
          <div className="flex items-center justify-center gap-3 text-gray-600">
            <Brain className="w-5 h-5 text-[#a63439] animate-pulse" />
            <p>{progress}</p>
          </div>
        )}

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {editorContent && (
          <div className="bg-white rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-medium">محتوای تولید شده</h2>
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 bg-gradient-to-r from-amber-500 to-amber-600 text-white text-xs px-2 py-0.5 rounded-full">
                  <Star className="w-3 h-3 fill-current" />
                  <span>Meta-Llama</span>
                </div>
              </div>
            </div>
            <RichTextEditor
              content={editorContent}
              onChange={setEditorContent}
              placeholder="محتوای مقاله..."
            />
          </div>
        )}
      </div>
    </div>
  );
}