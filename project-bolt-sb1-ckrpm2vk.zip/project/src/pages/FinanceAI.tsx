import React from 'react';
import GenericChatBot from '../components/chat/GenericChatBot';
import { Calculator, DollarSign, PiggyBank, Wallet } from 'lucide-react';

export default function FinanceAI() {
  return (
    <GenericChatBot
      title="دستیار مالی هوشمند"
      description="به کمک هوش مصنوعی در مدیریت مالی، سرمایه‌گذاری و برنامه‌ریزی اقتصادی خود مشاوره بگیرید."
      systemPrompt={`شما یک مشاور مالی حرفه‌ای هستید که:
- به زبان ساده و قابل فهم صحبت می‌کنید
- از اصطلاحات تخصصی فقط در صورت نیاز استفاده می‌کنید
- همواره محتاطانه و با در نظر گرفتن ریسک‌ها مشاوره می‌دهید
- از مثال‌های عملی و کاربردی استفاده می‌کنید`}
      suggestions={[
        {
          text: "چطور می‌تونم پس‌انداز کردن رو شروع کنم؟",
          icon: PiggyBank
        },
        {
          text: "بهترین روش سرمایه‌گذاری برای شروع چیه؟",
          icon: DollarSign
        },
        {
          text: "چطور بودجه‌بندی ماهانه انجام بدم؟",
          icon: Calculator
        },
        {
          text: "راه‌های کسب درآمد جانبی چیه؟",
          icon: Wallet
        }
      ]}
    />
  );
}