import React, { useState } from 'react';
import { Settings2, Bell, Globe, Palette, Shield, User, Moon } from 'lucide-react';
import NotificationSettings from '../components/settings/NotificationSettings';
import AppearanceSettings from '../components/settings/AppearanceSettings';
import PrivacySettings from '../components/settings/PrivacySettings';
import AccountSettings from '../components/settings/AccountSettings';

type SettingsTab = 'notifications' | 'appearance' | 'privacy' | 'account';

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState<SettingsTab>('notifications');

  const tabs = [
    { id: 'notifications', name: 'اعلان‌ها', icon: Bell },
    { id: 'appearance', name: 'ظاهر و زبان', icon: Palette },
    { id: 'privacy', name: 'حریم خصوصی', icon: Shield },
    { id: 'account', name: 'حساب کاربری', icon: User }
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'notifications':
        return <NotificationSettings />;
      case 'appearance':
        return <AppearanceSettings />;
      case 'privacy':
        return <PrivacySettings />;
      case 'account':
        return <AccountSettings />;
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#a63439] to-[#262e43] flex items-center justify-center">
              <Settings2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-medium mb-1">تنظیمات</h1>
              <p className="text-gray-600">تنظیمات و شخصی‌سازی حساب کاربری</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-4">
            <div className="bg-gray-50 p-4 md:p-6 border-b md:border-b-0 md:border-l border-gray-100">
              <nav className="space-y-1">
                {tabs.map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as SettingsTab)}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${
                      activeTab === tab.id
                        ? 'bg-[#a63439] text-white'
                        : 'hover:bg-gray-100 text-gray-600'
                    }`}
                  >
                    <tab.icon className="w-5 h-5" />
                    <span>{tab.name}</span>
                  </button>
                ))}
              </nav>
            </div>
            <div className="p-6 md:col-span-3">
              {renderContent()}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}