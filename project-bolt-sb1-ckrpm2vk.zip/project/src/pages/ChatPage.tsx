import React from 'react';
import { MessageSquare, Brain, Send, Loader2 } from 'lucide-react';
import { openai } from '../lib/openai';
import { useAuth } from '../lib/auth/AuthContext';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

const SYSTEM_PROMPT = `شما دستیار هوشمند هوشِکس هستید که دانش کاملی از تمام ابزارها و قابلیت‌های پلتفرم دارید:

1. ابزارهای اصلی هوشِکس:
   - تولید محتوا: تولید محتوای حرفه‌ای با هوش مصنوعی
   - تحلیل سئو: بررسی و بهبود سئو سایت
   - تحلیل داده: تجسم و تحلیل داده‌ها
   - هوش پیک: تولید تصاویر هوشمند
   - دستیارهای تخصصی: زبان، مالی، سلامت، آشپزی و...

2. نحوه پاسخگویی:
   - به سوالات مرتبط با ابزارها و خدمات هوشِکس پاسخ دهید
   - برای سوالات نامرتبط، کاربر را به سمت ابزارهای مناسب هدایت کنید
   - از مثال‌های عملی و کاربردی استفاده کنید
   - راهنمایی‌های گام به گام ارائه دهید

3. قالب پاسخ برای سوالات مرتبط با ابزارها:
   - معرفی ابزار مناسب
   - توضیح قابلیت‌ها
   - مراحل استفاده
   - نکات و ترفندها
   - لینک به راهنمای تکمیلی

4. قالب پاسخ برای سوالات عمومی:
   - پاسخ مختصر و مفید
   - معرفی ابزار مرتبط هوشِکس
   - راهنمایی برای شروع کار
   - لینک به منابع بیشتر

5. موارد ممنوعه:
   - پاسخ به سوالات نامناسب یا غیراخلاقی
   - ارائه اطلاعات محرمانه
   - قول‌های غیرواقعی
   - راهنمایی‌های فنی خارج از حوزه هوشِکس`;

export default function ChatPage() {
  const [messages, setMessages] = React.useState<Message[]>([]);
  const [input, setInput] = React.useState('');
  const [isLoading, setIsLoading] = React.useState(false);
  const messagesEndRef = React.useRef<HTMLDivElement>(null);
  const { user } = useAuth();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  React.useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = { role: 'user' as const, content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const completion = await openai.chat.completions.create({
        model: 'ModelsLab/Mixtral-8x7B-Instruct',
        temperature: 0.7,
        presence_penalty: 0.6,
        frequency_penalty: 0.3,
        messages: [
          {
            role: 'system',
            content: SYSTEM_PROMPT
          },
          {
            role: 'system',
            content: `اطلاعات کاربر فعلی:
نام: ${user?.fullName || 'کاربر هوشِکس'}
ایمیل: ${user?.email || '-'}
نوع حساب: ${user?.companyName ? 'سازمانی' : 'شخصی'}`
          },
          ...messages,
          userMessage
        ]
      });

      const assistantMessage = {
        role: 'assistant' as const,
        content: completion.choices[0]?.message?.content || 'متاسفانه پاسخی دریافت نشد.'
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Error:', error);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'متاسفانه خطایی رخ داد. لطفاً دوباره تلاش کنید.'
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#a63439] to-[#262e43] flex items-center justify-center">
              <MessageSquare className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-medium mb-1">گفتگو با هوشِکس</h1>
              <p className="text-gray-600">هر سوالی دارید از هوش مصنوعی بپرسید</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6">
          <div className="flex flex-col h-[500px]">
            <div className="flex-1 overflow-y-auto space-y-4 mb-4">
              {messages.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-gray-500">
                  <Brain className="w-12 h-12 mb-4 text-[#a63439] animate-pulse" />
                  <p className="text-center mb-2">سوال خود را بپرسید تا به شما کمک کنم</p>
                  <p className="text-sm text-gray-400 text-center">
                    می‌توانید درباره ابزارهای هوشِکس، نحوه استفاده از آنها و یا هر سوال دیگری بپرسید
                  </p>
                </div>
              ) : (
                messages.map((message, index) => (
                  <div
                    key={index}
                    className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-2xl p-3 ${
                        message.role === 'user'
                          ? 'bg-[#a63439] text-white'
                          : 'bg-gray-100 text-gray-800'
                      }`}
                    >
                      <p className="whitespace-pre-wrap">{message.content}</p>
                    </div>
                  </div>
                ))
              )}
              {isLoading && (
                <div className="flex items-center gap-3 text-gray-500">
                  <Brain className="w-5 h-5 text-[#a63439] animate-pulse" />
                  <p>هوشِکس در حال فکر کردن...</p>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            <form onSubmit={handleSubmit} className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={isLoading ? "در حال پردازش..." : "پیام خود را بنویسید..."}
                className="flex-1 bg-gray-100 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#a63439] transition-all"
                disabled={isLoading}
              />
              <button
                type="submit"
                disabled={isLoading || !input.trim()}
                className="bg-[#a63439] text-white p-2 rounded-xl hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
              >
                <Send className="w-6 h-6" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}