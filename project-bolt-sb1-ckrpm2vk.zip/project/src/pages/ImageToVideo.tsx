import React, { useState, useCallback } from 'react';
import { Upload, Wand2, AlertCircle, Film } from 'lucide-react';
import { generateVideo, getTaskStatus, cancelTask } from '../lib/video/imageToVideo';
import GenerationOverlay from '../components/video/GenerationOverlay';
import ImageToVideoHeader from '../components/video/ImageToVideoHeader';
import InputModeSelector from '../components/video/InputModeSelector';
import VideoSettings from '../components/video/VideoSettings';
import GenerationProgress from '../components/video/GenerationProgress';
import VideoResult from '../components/video/VideoResult';
import ImageGenerator from '../components/video/ImageGenerator';
import ImageConfirmation from '../components/video/ImageConfirmation';
import VideoPrompt from '../components/video/VideoPrompt';

type InputMode = 'upload' | 'generate' | null;
type GenerationStep = 'input' | 'confirm' | 'prompt' | 'generate';

export default function ImageToVideo() {
  const [inputMode, setInputMode] = useState<InputMode>(null);
  const [currentStep, setCurrentStep] = useState<GenerationStep>('input');
  const [prompt, setPrompt] = useState('');
  const [videoPrompt, setVideoPrompt] = useState('');
  const [showVideoButton, setShowVideoButton] = useState(false);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedVideo, setGeneratedVideo] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState<string>('');
  const [duration, setDuration] = useState<5 | 10>(5);
  const [orientation, setOrientation] = useState<'landscape' | 'portrait'>('landscape');
  const [generationId, setGenerationId] = useState<string | null>(null);
  const [generationPhase, setGenerationPhase] = useState<'analysis' | 'generation' | 'enhancement' | null>(null);
  const [progressPercent, setProgressPercent] = useState(0);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setError(null);
      try {
        if (!file.type.match(/^image\/(jpeg|png)$/)) {
          throw new Error('فقط فرمت‌های JPG و PNG پشتیبانی می‌شوند');
        }
        
        if (file.size > 10 * 1024 * 1024) {
          throw new Error('حجم فایل نباید بیشتر از 10 مگابایت باشد');
        }

        const reader = new FileReader();
        reader.onloadend = () => {
          setUploadedImage(reader.result as string);
          setCurrentStep('confirm');
        };
        reader.readAsDataURL(file);
      } catch (error) {
        setError(error instanceof Error ? error.message : 'خطا در آپلود تصویر');
        setUploadedImage(null);
      }
    }
  };

  const handleImageGenerated = (imageUrl: string) => {
    setUploadedImage(imageUrl);
    setError(null);
    setShowVideoButton(true);
    setCurrentStep('confirm');
  };

  const handleImageConfirm = () => {
    setCurrentStep('prompt');
    setShowVideoButton(true);
    setError(null);
  };

  const handleImageReject = () => {
    setUploadedImage(null);
    setShowVideoButton(false);
    setCurrentStep('input');
    setError(null);
  };

  const pollStatus = useCallback(async (id: string) => {
    let attempts = 0;
    const maxAttempts = 300; // 5 minutes with exponential backoff
    
    while (attempts < maxAttempts) {
      try {
        const result = await getTaskStatus(id);
        
        if (result.status === 'success' && result.output?.[0]) {
          setGeneratedVideo(result.output[0]);
          setProgress('');
          setGenerationId(null);
          return;
        }
        
        if (result.status === 'failed' || result.error) {
          throw new Error(result.error?.message || 'خطا در تولید ویدئو');
        }
        
        attempts++;
        const progress = Math.min(95, Math.round((attempts / maxAttempts) * 100));
        setProgressPercent(progress);
        setProgress('در حال بهبود کیفیت ویدئو...');
        
        // Exponential backoff with jitter
        const delay = Math.min(1000 * Math.pow(1.5, attempts), 10000);
        await new Promise(resolve => setTimeout(resolve, delay + (Math.random() * 1000)));
        
      } catch (error) {
        console.error('Polling error:', error);
        throw error;
      }
    }
    
    throw new Error('زمان پردازش به پایان رسید');
  }, []);

  const handleGenerate = async () => {
    try {
      if (!uploadedImage) {
        throw new Error('لطفاً یک تصویر آپلود کنید');
      }

      setIsGenerating(true);
      setError(null);
      setGeneratedVideo(null);
      setGenerationId(null);
      setGenerationPhase('analysis');
      setProgressPercent(0);
      setProgress('در حال تحلیل تصویر...');

      setGenerationPhase('enhancement');
      setProgressPercent(50);
      setProgress('در حال تبدیل به ویدئو...');

      const result = await generateVideo({
        image: uploadedImage,
        prompt: videoPrompt,
        duration: duration * 30, // Convert seconds to frames
        ratio: orientation === 'landscape' ? '1280:768' : '768:1280',
        seed: Math.floor(Math.random() * 2147483647)
      });

      if (['PENDING', 'RUNNING', 'THROTTLED'].includes(result.status) && result.id) {
        setGenerationId(result.id);
        await pollStatus(result.id);
      } else if (result.status === 'SUCCEEDED' && result.output?.[0]) {
        setGeneratedVideo(result.output[0]);
      } else {
        throw new Error('خطا در تولید ویدئو');
      }

    } catch (error) {
      console.error('Error:', error);
      setError(error instanceof Error ? error.message : 'خطا در تولید ویدئو');
      setProgress('');
      setGenerationPhase(null);
      setProgressPercent(0);
    } finally {
      if (!generationId) {
        setIsGenerating(false);
      }
    }
  };

  const handleCancel = async () => {
    if (generationId) {
      try {
        await cancelTask(generationId);
        setGenerationId(null);
        setIsGenerating(false);
        setProgress('');
      } catch (error) {
        console.error('Cancel error:', error);
      }
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <ImageToVideoHeader />

        <div className="bg-white rounded-xl p-6 space-y-6">
          <InputModeSelector
            selectedMode={inputMode}
            onModeSelect={setInputMode}
          />

          {inputMode && currentStep === 'input' && (
            <>
              {inputMode === 'generate' ? (
                <ImageGenerator
                  onImageGenerated={handleImageGenerated}
                  onError={setError}
                />
              ) : (
                <div className="flex-1">
                  <label
                    htmlFor="image-upload"
                    className={`relative flex flex-col items-center justify-center gap-2 w-full bg-gray-50 border-2 border-dashed ${
                      uploadedImage ? 'border-[#a63439]' : 'border-gray-200'
                    } rounded-lg p-4 cursor-pointer hover:bg-gray-100 transition-all group`}
                  >
                    {uploadedImage ? (
                      <>
                        <img 
                          src={uploadedImage} 
                          alt="تصویر انتخاب شده"
                          className="w-full h-32 object-contain rounded"
                        />
                        <span className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 text-white opacity-0 group-hover:opacity-100 transition-opacity rounded-lg">
                          تغییر تصویر
                        </span>
                      </>
                    ) : (
                      <>
                        <Upload className="w-6 h-6 text-gray-500" />
                        <span className="text-gray-600">آپلود تصویر (JPG یا PNG، حداکثر 10MB)</span>
                      </>
                    )}
                  </label>
                  <input
                    id="image-upload"
                    type="file"
                    accept="image/jpeg,image/png"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </div>
              )}
            </>
          )}


          {currentStep === 'confirm' && uploadedImage && (
            <ImageConfirmation
              imageUrl={uploadedImage}
              onConfirm={handleImageConfirm}
              onReject={handleImageReject}
            />
          )}

          {currentStep === 'prompt' && uploadedImage && showVideoButton && (
            <div className="space-y-6">
              <VideoSettings
                duration={duration}
                orientation={orientation}
                onDurationChange={setDuration}
                onOrientationChange={setOrientation}
              />

              <VideoPrompt
                value={videoPrompt}
                onChange={setVideoPrompt}
              />

              <button
                onClick={handleGenerate}
                disabled={isGenerating || !videoPrompt.trim()}
                className="w-full bg-[#a63439] text-white p-4 rounded-lg flex items-center justify-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
              >
                {isGenerating ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
                    <span>در حال پردازش...</span>
                  </>
                ) : (
                  <>
                    <Film className="w-5 h-5" />
                    <span>تولید ویدئو</span>
                  </>
                )}
              </button>
            </div>
          )}

          {progress && (
            <GenerationProgress
              progress={progress}
              generationId={generationId}
              onCancel={handleCancel}
            />
          )}

          <GenerationOverlay 
            isVisible={isGenerating}
            progress={progressPercent}
            phase={generationPhase}
          />

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              <p>{error}</p>
            </div>
          )}

          {generatedVideo && (
            <VideoResult
              videoUrl={generatedVideo}
              onError={setError}
            />
          )}
        </div>
      </div>
    </div>
  );
}