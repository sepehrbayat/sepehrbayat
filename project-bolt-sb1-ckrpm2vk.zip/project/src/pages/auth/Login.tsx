import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogIn, Phone, Lock, Loader2, AlertCircle } from 'lucide-react';
import { ValidationError } from '../../lib/errors';
import { sendVerificationCode, generateVerificationCode } from '../../lib/auth/ippanel';
import { isValidIranianPhone } from '../../lib/utils';

export default function Login() {
  const navigate = useNavigate();
  const [phoneNumber, setPhoneNumber] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [step, setStep] = useState<'phone' | 'verify'>('phone');
  const [timer, setTimer] = useState(0);

  const startTimer = () => {
    setTimer(120); // 2 minutes
    const interval = setInterval(() => {
      setTimer(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleSendCode = async () => {
    try {
      if (!isValidIranianPhone(phoneNumber)) {
        throw new ValidationError('شماره موبایل نامعتبر است');
      }

      setIsLoading(true);
      setError(null);

      const code = generateVerificationCode();
      await sendVerificationCode({
        phoneNumber,
        code: code.toString()
      });

      setStep('verify');
      startTimer();

    } catch (error) {
      console.error('Login error:', error);
      setError(error instanceof Error ? error.message : 'خطا در ورود. لطفاً دوباره تلاش کنید.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyCode = async () => {
    try {
      if (!verificationCode.match(/^\d{6}$/)) {
        throw new Error('کد تایید نامعتبر است');
      }

      setIsLoading(true);
      setError(null);

      // TODO: Verify code with backend
      
      // Redirect to dashboard on success
      navigate('/dashboard');

    } catch (error) {
      console.error('Verification error:', error);
      setError(error instanceof Error ? error.message : 'خطا در تایید کد. لطفاً دوباره تلاش کنید.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div>
          <h2 className="mt-6 text-center text-3xl font-bold text-gray-900">
            {step === 'phone' ? 'ورود به حساب کاربری' : 'تایید شماره موبایل'}
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            {step === 'phone' ? 
              'شماره موبایل خود را وارد کنید' :
              'کد تایید ارسال شده را وارد کنید'
            }
          </p>
        </div>

        <div className="mt-8 space-y-6">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              <p>{error}</p>
            </div>
          )}

          {step === 'phone' ? (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                شماره موبایل
              </label>
              <div className="relative">
                <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full bg-white border border-gray-300 rounded-lg pr-10 pl-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#a63439] focus:border-transparent transition-all"
                  placeholder="09xxxxxxxxx"
                  dir="ltr"
                />
              </div>
              <button
                onClick={handleSendCode}
                disabled={isLoading || !phoneNumber.trim()}
                className="mt-4 w-full bg-[#a63439] text-white p-3 rounded-lg flex items-center justify-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>در حال ارسال کد...</span>
                  </>
                ) : (
                  <>
                    <LogIn className="w-5 h-5" />
                    <span>دریافت کد تایید</span>
                  </>
                )}
              </button>
            </div>
          ) : (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                کد تایید
              </label>
              <div className="relative">
                <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={verificationCode}
                  onChange={(e) => setVerificationCode(e.target.value)}
                  className="w-full bg-white border border-gray-300 rounded-lg pr-10 pl-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#a63439] focus:border-transparent transition-all"
                  placeholder="کد 6 رقمی"
                  dir="ltr"
                />
              </div>
              {timer > 0 && (
                <p className="mt-2 text-sm text-gray-500 text-center">
                  {Math.floor(timer / 60)}:{(timer % 60).toString().padStart(2, '0')} تا ارسال مجدد کد
                </p>
              )}
              <button
                onClick={handleVerifyCode}
                disabled={isLoading || !verificationCode.trim()}
                className="mt-4 w-full bg-[#a63439] text-white p-3 rounded-lg flex items-center justify-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>در حال بررسی...</span>
                  </>
                ) : (
                  <>
                    <LogIn className="w-5 h-5" />
                    <span>ورود به حساب</span>
                  </>
                )}
              </button>
              {timer === 0 && (
                <button
                  onClick={handleSendCode}
                  disabled={isLoading}
                  className="mt-2 w-full text-[#a63439] p-2 rounded-lg hover:bg-[#a63439]/5 transition-all text-sm"
                >
                  ارسال مجدد کد
                </button>
              )}
              <button
                onClick={() => setStep('phone')}
                disabled={isLoading}
                className="mt-2 w-full text-gray-500 p-2 rounded-lg hover:bg-gray-100 transition-all text-sm"
              >
                تغییر شماره موبایل
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}