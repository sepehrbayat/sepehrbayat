import React, { useState, useEffect } from 'react';
import { User, Building2, Phone, Mail, MapPin, Save, Loader2, AlertCircle, Camera, Globe, Calendar, CheckCircle } from 'lucide-react';
import { useAuth } from '../../lib/auth/AuthContext';
import { supabase } from '../../lib/supabase';

interface ProfileForm {
  fullName: string;
  companyName: string;
  phoneNumber: string;
  email: string;
  nationalId: string;
  address: string;
  postalCode: string;
  avatarUrl: string | null;
}

export default function Profile() {
  const { user, updateUser } = useAuth();
  const [form, setForm] = useState<ProfileForm>({
    fullName: user?.fullName || '',
    companyName: user?.companyName || '',
    phoneNumber: user?.phoneNumber || '',
    email: user?.email || '',
    nationalId: user?.nationalId || '',
    address: user?.address || '',
    postalCode: user?.postalCode || '',
    avatarUrl: user?.avatarUrl || null
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  useEffect(() => {
    // Update form when user data changes (e.g. after Google login)
    if (user) {
      setForm(prev => ({
        ...prev,
        fullName: user.fullName || prev.fullName,
        email: user.email || prev.email,
        avatarUrl: user.avatarUrl || prev.avatarUrl
      }));
    }
  }, [user]);

  const handleAvatarUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    try {
      const file = event.target.files?.[0];
      if (!file) return;

      // Validate file type
      if (!file.type.startsWith('image/')) {
        throw new Error('لطفاً فقط فایل تصویری آپلود کنید');
      }

      // Validate file size (max 2MB)
      if (file.size > 2 * 1024 * 1024) {
        throw new Error('حجم فایل نباید بیشتر از 2 مگابایت باشد');
      }

      setIsUploading(true);
      setUploadProgress(0);

      // Upload to Supabase Storage
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random()}.${fileExt}`;
      const filePath = `${user?.id}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file, {
          upsert: true,
          onUploadProgress: (progress) => {
            setUploadProgress(Math.round((progress.loaded / progress.total) * 100));
          }
        });

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('avatars')
        .getPublicUrl(filePath);

      // Update profile
      const { error: updateError } = await supabase.auth.updateUser({
        data: { avatar_url: publicUrl }
      });

      if (updateError) throw updateError;

      setForm(prev => ({ ...prev, avatarUrl: publicUrl }));

    } catch (error) {
      console.error('Avatar upload error:', error);
      setError(error instanceof Error ? error.message : 'خطا در آپلود تصویر');
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  const handleSubmit = async () => {
    try {
      setIsLoading(true);
      setError(null);
      setSuccess(false);

      // Update user metadata in Supabase
      const { error: updateError } = await supabase.auth.updateUser({
        data: {
          full_name: form.fullName,
          company_name: form.companyName,
          phone_number: form.phoneNumber,
          national_id: form.nationalId,
          address: form.address,
          postal_code: form.postalCode,
          avatar_url: form.avatarUrl // Include avatar URL in metadata
        }
      });

      if (updateError) throw updateError;

      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);

    } catch (error) {
      console.error('Profile update error:', error);
      setError(error instanceof Error ? error.message : 'خطا در بروزرسانی پروفایل');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <h1 className="text-2xl font-medium mb-2">پروفایل کاربری</h1>
          <p className="text-gray-600">اطلاعات حساب کاربری خود را مدیریت کنید</p>
        </div>

        <div className="bg-white rounded-xl p-6 space-y-6">
          {/* Avatar Section */}
          <div className="flex items-center gap-6 pb-6 border-b border-gray-100">
            <div className="relative">
              <div className="w-24 h-24 rounded-full bg-gray-100 overflow-hidden">
                {form.avatarUrl ? (
                  <img 
                    src={form.avatarUrl} 
                    alt="avatar"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-[#a63439] text-white flex items-center justify-center text-2xl font-medium">
                    {form.fullName ? form.fullName[0].toUpperCase() : 'ک'}
                  </div>
                )}
                {isUploading && (
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <div className="text-white text-sm">{uploadProgress}%</div>
                  </div>
                )}
              </div>
              <label className="absolute bottom-0 right-0 w-8 h-8 bg-[#a63439] rounded-full flex items-center justify-center cursor-pointer hover:bg-[#8a2a2e] transition-colors">
                <Camera className="w-4 h-4 text-white" />
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleAvatarUpload}
                  className="hidden"
                  disabled={isUploading}
                />
              </label>
            </div>
            <div>
              <h2 className="text-xl font-medium">{form.fullName || 'کاربر هوشِکس'}</h2>
              <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                {user?.email && (
                  <div className="flex items-center gap-1">
                    <Mail className="w-4 h-4" />
                    <span>{user.email}</span>
                  </div>
                )}
                {user?.createdAt && (
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    <span>عضویت: {new Date(user.createdAt).toLocaleDateString('fa-IR')}</span>
                  </div>
                )}
              </div>
              {user?.isEmailVerified && (
                <div className="flex items-center gap-1 text-green-600 text-sm mt-2">
                  <CheckCircle className="w-4 h-4" />
                  <span>ایمیل تایید شده</span>
                </div>
              )}
            </div>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              <p>{error}</p>
            </div>
          )}

          {success && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center gap-3 text-green-700">
              <CheckCircle className="w-5 h-5 flex-shrink-0" />
              <p>اطلاعات با موفقیت بروزرسانی شد</p>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                نام و نام خانوادگی
              </label>
              <div className="relative">
                <User className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  name="fullName"
                  value={form.fullName}
                  onChange={(e) => setForm(prev => ({ ...prev, fullName: e.target.value }))}
                  className="w-full bg-gray-50 border border-gray-200 rounded-lg pr-10 pl-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#a63439] focus:border-transparent transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                نام شرکت
              </label>
              <div className="relative">
                <Building2 className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  name="companyName"
                  value={form.companyName}
                  onChange={(e) => setForm(prev => ({ ...prev, companyName: e.target.value }))}
                  className="w-full bg-gray-50 border border-gray-200 rounded-lg pr-10 pl-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#a63439] focus:border-transparent transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                شماره موبایل
              </label>
              <div className="relative">
                <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="tel"
                  name="phoneNumber"
                  value={form.phoneNumber}
                  onChange={(e) => setForm(prev => ({ ...prev, phoneNumber: e.target.value }))}
                  className="w-full bg-gray-50 border border-gray-200 rounded-lg pr-10 pl-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#a63439] focus:border-transparent transition-all"
                  dir="ltr"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                ایمیل
              </label>
              <div className="relative">
                <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="email"
                  name="email"
                  value={form.email}
                  onChange={(e) => setForm(prev => ({ ...prev, email: e.target.value }))}
                  className="w-full bg-gray-50 border border-gray-200 rounded-lg pr-10 pl-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#a63439] focus:border-transparent transition-all"
                  dir="ltr"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                کد ملی
              </label>
              <div className="relative">
                <input
                  type="text"
                  name="nationalId"
                  value={form.nationalId}
                  onChange={(e) => setForm(prev => ({ ...prev, nationalId: e.target.value }))}
                  className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#a63439] focus:border-transparent transition-all"
                  dir="ltr"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                کد پستی
              </label>
              <div className="relative">
                <input
                  type="text"
                  name="postalCode"
                  value={form.postalCode}
                  onChange={(e) => setForm(prev => ({ ...prev, postalCode: e.target.value }))}
                  className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#a63439] focus:border-transparent transition-all"
                  dir="ltr"
                />
              </div>
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                آدرس
              </label>
              <div className="relative">
                <MapPin className="absolute right-3 top-3 w-5 h-5 text-gray-400" />
                <textarea
                  name="address"
                  value={form.address}
                  onChange={(e) => setForm(prev => ({ ...prev, address: e.target.value }))}
                  rows={3}
                  className="w-full bg-gray-50 border border-gray-200 rounded-lg pr-10 pl-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#a63439] focus:border-transparent transition-all resize-none"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end gap-4 pt-6 border-t border-gray-100">
            <button
              onClick={handleSubmit}
              disabled={isLoading}
              className="bg-[#a63439] text-white px-6 py-2 rounded-lg flex items-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>در حال ذخیره...</span>
                </>
              ) : (
                <>
                  <Save className="w-5 h-5" />
                  <span>ذخیره تغییرات</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}