import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogIn, Phone, Lock, Loader2, AlertCircle, ArrowRight, UserPlus, Mail } from 'lucide-react';
import { signInWithPhone, verifyOtp, signInWithEmail, signInWithSocial, signUpWithEmail } from '../../lib/auth/supabase';
import { ValidationError } from '../../lib/errors';
import { isValidIranianPhone } from '../../lib/utils';
import { useAuth } from '../../lib/auth/AuthContext';
import { useLocation } from 'react-router-dom';

export default function Auth() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [step, setStep] = useState<'method' | 'email' | 'verify'>('method');
  const [timer, setTimer] = useState(0);
  const [otpCode, setOtpCode] = useState('');
  const [isEmailSent, setIsEmailSent] = useState(false);

  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      const from = location.state?.from?.pathname || '/dashboard';
      navigate(from, { replace: true });
    }
  }, [user, navigate, location]);

  const startTimer = () => {
    setTimer(120); // 2 minutes
    const interval = setInterval(() => {
      setTimer(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleSendCode = async () => {
    try {
      setError(null);
      setIsLoading(true);

      await signInWithPhone(phoneNumber);

      setStep('verify');
      startTimer();

    } catch (error) {
      console.error('Auth error:', error);
      if (error instanceof ValidationError) {
        setError(error.message);
      } else if (error instanceof Error && error.message.includes('rate limit')) {
        setError('تعداد درخواست‌ها بیش از حد مجاز است. لطفاً کمی صبر کنید');
      } else {
        setError('خطا در ارسال کد. لطفاً دوباره تلاش کنید');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyCode = async () => {
    try {
      setError(null);
      setIsLoading(true);

      await verifyOtp(phoneNumber, otpCode);
      navigate('/dashboard');

    } catch (error) {
      console.error('Verification error:', error);
      setError(error instanceof ValidationError ? error.message : 'خطا در تایید کد');
    } finally {
      setIsLoading(false);
    }
  };

  const handleEmailSignIn = async () => {
    try {
      setError(null);
      setIsLoading(true);

      if (mode === 'login') {
        const response = await signInWithEmail(email, password);
        if (response?.user?.id) {
          const from = location.state?.from?.pathname || '/dashboard';
          navigate(from, { replace: true });
        }
      } else {
        await signUpWithEmail(email, password);
        // Show OTP verification screen
        setStep('verify');
        startTimer();
        setIsEmailSent(true);
        return;
      }

    } catch (error) {
      console.error('Email auth error:', error);
      let errorMessage = 'خطا در ورود با ایمیل';

      if (error instanceof Error) {
        if (error.message.includes('already exists')) {
          errorMessage = 'این ایمیل قبلاً ثبت شده است';
        } else if (error.message.includes('invalid credentials')) {
          errorMessage = 'ایمیل یا رمز عبور اشتباه است';
        } else if (error.message.includes('Email not confirmed')) {
          errorMessage = 'لطفاً ایمیل خود را تایید کنید';
        } else if (error.message.includes('Invalid email')) {
          errorMessage = 'ایمیل نامعتبر است';
        } else if (error.message.includes('Weak password')) {
          errorMessage = 'رمز عبور باید حداقل 8 کاراکتر باشد';
        } else {
          errorMessage = error.message;
        }
      }
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyOTP = async () => {
    try {
      setError(null);
      setIsLoading(true);

      // Validate inputs
      if (!email || !otpCode) {
        throw new ValidationError('ایمیل و کد تایید الزامی هستند');
      }

      if (!otpCode.match(/^\d{6}$/)) {
        throw new ValidationError('کد تایید باید 6 رقمی باشد');
      }

      // Attempt verification
      const success = await verifyOTP(email, otpCode);
      if (success) {
        // Clear verification state
        setOtpCode('');
        setIsEmailSent(false);
        setTimer(0);
        // Navigate to dashboard or previous page
        const from = location.state?.from?.pathname || '/dashboard';
        navigate(from, { replace: true });
      }
    } catch (error) {
      console.error('OTP verification error:', error);
      // Handle specific error cases
      if (error instanceof ValidationError) {
        setError(error.message);
        // Reset states for specific error cases
        if (error.message.includes('منقضی شده') || 
            error.message.includes('تعداد تلاش‌ها') ||
            error.message.includes('نامعتبر')) {
          setTimer(0);
          setOtpCode(''); // Clear invalid code
          setIsEmailSent(false); // Reset email sent state
        }
      } else {
        setError('خطا در تایید کد. لطفاً دوباره تلاش کنید');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    try {
      setError(null);
      setIsLoading(true);
      
      // Check if online
      if (!navigator.onLine) {
        throw new Error('اتصال اینترنت برقرار نیست. لطفاً اتصال خود را بررسی کنید');
      }

      // Don't wait for response since it will redirect
      signInWithSocial('google')
        .catch(error => {
          console.error('Google auth error:', error);
          setIsLoading(false);
          
          if (error instanceof Error) {
            if (error.message.includes('provider is not enabled')) {
              setError('ورود با گوگل در حال حاضر فعال نیست. لطفاً از روش دیگری استفاده کنید');
            } else if (error.message.includes('popup blocked')) {
              setError('لطفاً پاپ‌آپ مرورگر را فعال کنید');
            } else if (error.message.includes('cancelled')) {
              setError('ورود با گوگل لغو شد');
            } else if (error.message.includes('network') || error.message.includes('اتصال اینترنت')) {
              setError('خطا در ارتباط با سرور. لطفاً اتصال اینترنت خود را بررسی کنید');
            } else if (error.message.includes('timeout')) {
              setError('زمان درخواست به پایان رسید. لطفاً دوباره تلاش کنید');
            } else {
              setError('خطا در ورود با گوگل. لطفاً دوباره تلاش کنید');
            }
          } else {
            setError('خطا در ورود با گوگل. لطفاً دوباره تلاش کنید');
          }
        });

    } catch (error) {
      console.error('Google auth error:', error);
      
      setError(error instanceof Error ? error.message : 'خطا در ورود با گوگل');
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#a63439]/5 via-gray-50 to-[#262e43]/5 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 relative">
        <div className="absolute inset-0 bg-white/40 backdrop-blur-xl rounded-2xl -z-10" />
        <div className="bg-white/80 backdrop-blur-sm shadow-xl rounded-2xl p-8 space-y-8">
          <div>
            <img
              src="http://hooshex.com/wp-content/uploads/2025/02/6019137301315174720-removebg-preview.png"
              alt="Logo"
              className="h-16 mx-auto transform hover:scale-105 transition-transform duration-300"
            />
            <h2 className="mt-6 text-center text-3xl font-bold bg-gradient-to-l from-[#a63439] to-[#262e43] bg-clip-text text-transparent">
              {step === 'method' ? (mode === 'login' ? 'ورود به هوشِکس' : 'ثبت‌نام در هوشِکس') : 
               step === 'verify' ? 'تایید ایمیل' :
               mode === 'login' ? 'ورود با ایمیل' : 'ثبت‌نام با ایمیل'}
            </h2>
            <p className="mt-2 text-center text-sm text-gray-500">
              {step === 'method' ? 'روش ورود را انتخاب کنید' : 
               step === 'verify' ? 'کد تایید ارسال شده به ایمیل خود را وارد کنید' :
               step === 'verify' ? 'کد تایید ارسال شده به ایمیل خود را وارد کنید' :
               'ایمیل و رمز عبور خود را وارد کنید'
              }
            </p>
          </div>

          {step === 'method' && (
            <div className="flex rounded-lg p-1 bg-gray-100">
              <button
                onClick={() => setMode('login')}
                className={`flex-1 py-2 px-4 rounded-md transition-all duration-300 ${
                  mode === 'login'
                    ? 'bg-white shadow-sm text-[#a63439]'
                    : 'text-gray-600 hover:text-[#a63439]'
                }`}
              >
                ورود
              </button>
              <button
                onClick={() => setMode('register')}
                className={`flex-1 py-2 px-4 rounded-md transition-all duration-300 ${
                  mode === 'register'
                    ? 'bg-white shadow-sm text-[#a63439]'
                    : 'text-gray-600 hover:text-[#a63439]'
                }`}
              >
                ثبت‌نام
              </button>
            </div>
          )}

          {step === 'method' && (
            <div className="space-y-4">
              <button
                onClick={() => setStep('email')}
                className="w-full bg-white border border-gray-200 p-4 rounded-lg flex items-center justify-center gap-3 hover:bg-gray-50 transition-all"
              >
                <Mail className="w-5 h-5 text-[#a63439]" />
                <span>{mode === 'login' ? 'ورود با ایمیل' : 'ثبت‌نام با ایمیل'}</span>
              </button>
              
              <button
                onClick={handleGoogleSignIn}
                className="w-full bg-white border border-gray-200 p-4 rounded-lg flex items-center justify-center gap-3 hover:bg-gray-50 transition-all relative disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>در حال اتصال به گوگل...</span>
                  </>
                ) : (
                  <>
                    <img src="https://www.google.com/favicon.ico" alt="Google" className="w-5 h-5" />
                    <span>ورود با گوگل</span>
                  </>
                )}
              </button>
            </div>
          )}

          <div className="mt-8 space-y-6">
            {error && (
              <div className="bg-red-50/50 backdrop-blur-sm border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700 animate-fadeIn">
                <AlertCircle className="w-5 h-5 flex-shrink-0" />
                <p>{error}</p>
              </div>
            )}

            {step === 'verify' ? (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    کد تایید
                  </label>
                  <div className="relative group">
                    <input
                      type="text"
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value)}
                      className="w-full bg-white/50 backdrop-blur-sm border border-gray-200 rounded-lg px-3 py-3 focus:outline-none focus:ring-2 focus:ring-[#a63439] focus:border-transparent transition-all group-hover:bg-white"
                      placeholder="کد 6 رقمی"
                      maxLength={6}
                      dir="ltr"
                    />
                  </div>
                  <button
                    onClick={handleVerifyOTP}
                    disabled={isLoading || !otpCode.trim()}
                    className="w-full bg-gradient-to-l from-[#a63439] to-[#262e43] text-white p-3 rounded-lg flex items-center justify-center gap-2 hover:opacity-90 transition-all disabled:opacity-50 mt-4"
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        <span>در حال بررسی...</span>
                      </>
                    ) : (
                      <>
                        <Mail className="w-5 h-5" />
                        <span>تایید کد</span>
                      </>
                    )}
                  </button>
                  {timer > 0 && (
                    <p className="mt-2 text-sm text-gray-500 text-center">
                      {Math.floor(timer / 60)}:{(timer % 60).toString().padStart(2, '0')} تا ارسال مجدد کد
                    </p>
                  )}
                  {timer === 0 && (
                    <button
                      onClick={handleEmailSignIn}
                      disabled={isLoading}
                      className="mt-2 w-full text-[#a63439] p-2 rounded-lg hover:bg-[#a63439]/5 transition-all text-sm"
                    >
                      ارسال مجدد کد
                    </button>
                  )}
                </div>
              </div>
            ) : step === 'email' && (
              <div className="space-y-4">
                {step === 'verify' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      کد تایید
                    </label>
                   <p className="text-sm text-gray-500 mb-4">
                     دریافت کد تایید ممکن است تا 2 دقیقه طول بکشد. لطفاً صبور باشید و پوشه Spam را نیز بررسی کنید.
                   </p>
                    <div className="relative group">
                      <input
                        type="text"
                        value={otpCode}
                        onChange={(e) => setOtpCode(e.target.value)}
                        className="w-full bg-white/50 backdrop-blur-sm border border-gray-200 rounded-lg px-3 py-3 focus:outline-none focus:ring-2 focus:ring-[#a63439] focus:border-transparent transition-all group-hover:bg-white"
                        placeholder="کد 6 رقمی"
                        maxLength={6}
                        dir="ltr"
                      />
                    </div>
                    <button
                      onClick={handleVerifyOTP}
                      disabled={isLoading || !otpCode.trim()}
                      className="w-full bg-gradient-to-l from-[#a63439] to-[#262e43] text-white p-3 rounded-lg flex items-center justify-center gap-2 hover:opacity-90 transition-all disabled:opacity-50 mt-4"
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="w-5 h-5 animate-spin" />
                          <span>در حال بررسی...</span>
                        </>
                      ) : (
                        <>
                          <Mail className="w-5 h-5" />
                          <span>تایید کد</span>
                        </>
                      )}
                    </button>
                    {timer > 0 && (
                      <p className="mt-2 text-sm text-gray-500 text-center">
                        {Math.floor(timer / 60)}:{(timer % 60).toString().padStart(2, '0')} تا ارسال مجدد کد
                      </p>
                    )}
                    {timer === 0 && (
                      <button
                        onClick={handleEmailSignIn}
                        disabled={isLoading}
                        className="mt-2 w-full text-[#a63439] p-2 rounded-lg hover:bg-[#a63439]/5 transition-all text-sm"
                      >
                        ارسال مجدد کد
                      </button>
                    )}
                  </div>
                )}
                {step === 'email' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        ایمیل
                      </label>
                      <div className="relative group">
                        <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="w-full bg-white/50 backdrop-blur-sm border border-gray-200 rounded-lg pr-10 pl-3 py-3 focus:outline-none focus:ring-2 focus:ring-[#a63439] focus:border-transparent transition-all group-hover:bg-white"
                          placeholder="example@email.com"
                          dir="ltr"
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        رمز عبور
                      </label>
                      <div className="relative group">
                        <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type="password"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="w-full bg-white/50 backdrop-blur-sm border border-gray-200 rounded-lg pr-10 pl-3 py-3 focus:outline-none focus:ring-2 focus:ring-[#a63439] focus:border-transparent transition-all group-hover:bg-white"
                          placeholder="********"
                          dir="ltr"
                        />
                      </div>
                    </div>

                    <button
                      onClick={handleEmailSignIn}
                      disabled={isLoading || !email || !password}
                      className="w-full bg-gradient-to-l from-[#a63439] to-[#262e43] text-white p-3 rounded-lg flex items-center justify-center gap-2 hover:opacity-90 transition-all disabled:opacity-50 transform hover:scale-[1.02] disabled:hover:scale-100"
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="w-5 h-5 animate-spin" />
                          <span>در حال پردازش...</span>
                        </>
                      ) : (
                        <>
                          <Mail className="w-5 h-5" />
                          <span>{mode === 'login' ? 'ورود به حساب' : 'ادامه ثبت‌نام'}</span>
                        </>
                      )}
                    </button>
                    
                    {isEmailSent && mode === 'register' && (
                      <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                        <p className="text-sm text-green-700">
                         کد تایید برای شما ارسال شد. دریافت کد ممکن است تا 2 دقیقه طول بکشد. لطفاً صبور باشید و پوشه Spam را نیز بررسی کنید.
                        </p>
                      </div>
                    )}

                    <button
                      onClick={() => setStep('method')}
                      className="w-full text-gray-500 p-2 rounded-lg hover:bg-gray-100 transition-all text-sm flex items-center justify-center gap-2"
                    >
                      <ArrowRight className="w-4 h-4" />
                      بازگشت
                    </button>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}