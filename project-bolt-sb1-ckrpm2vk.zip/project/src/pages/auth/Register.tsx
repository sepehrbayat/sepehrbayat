import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { UserPlus, Phone, User, Building2, MapPin, Mail, Loader2, AlertCircle } from 'lucide-react';
import { ValidationError } from '../../lib/errors';
import { sendVerificationCode, generateVerificationCode } from '../../lib/auth/ippanel';
import { isValidIranianPhone } from '../../lib/utils';

interface RegisterForm {
  phoneNumber: string;
  fullName: string;
  email: string;
  companyName: string;
  nationalId: string;
  address: string;
  postalCode: string;
}

export default function Register() {
  const navigate = useNavigate();
  const [form, setForm] = useState<RegisterForm>({
    phoneNumber: '',
    fullName: '',
    email: '',
    companyName: '',
    nationalId: '',
    address: '',
    postalCode: ''
  });
  const [verificationCode, setVerificationCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [step, setStep] = useState<'form' | 'verify'>('form');
  const [timer, setTimer] = useState(0);

  const startTimer = () => {
    setTimer(120); // 2 minutes
    const interval = setInterval(() => {
      setTimer(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    if (!isValidIranianPhone(form.phoneNumber)) {
      throw new Error('شماره موبایل نامعتبر است');
    }
    if (!form.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
      throw new Error('ایمیل نامعتبر است');
    }
    if (!form.nationalId.match(/^\d{10}$/)) {
      throw new Error('کد ملی نامعتبر است');
    }
    if (!form.postalCode.match(/^\d{10}$/)) {
      throw new Error('کد پستی نامعتبر است');
    }
    if (!form.fullName || !form.address) {
      throw new Error('لطفاً تمام فیلدها را پر کنید');
    }
  };

  const handleSubmit = async () => {
    try {
      validateForm();

      setIsLoading(true);
      setError(null);

      const code = generateVerificationCode();
      await sendVerificationCode({
        phoneNumber: form.phoneNumber,
        code: code.toString()
      });

      setStep('verify');
      startTimer();

    } catch (error) {
      console.error('Registration error:', error);
      setError(error instanceof Error ? error.message : 'خطا در ثبت‌نام. لطفاً دوباره تلاش کنید.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyCode = async () => {
    try {
      if (!verificationCode.match(/^\d{6}$/)) {
        throw new Error('کد تایید نامعتبر است');
      }

      setIsLoading(true);
      setError(null);

      // TODO: Send registration data to backend
      
      // Redirect to dashboard on success
      navigate('/dashboard');

    } catch (error) {
      console.error('Verification error:', error);
      setError(error instanceof Error ? error.message : 'خطا در تایید کد. لطفاً دوباره تلاش کنید.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div>
          <h2 className="mt-6 text-center text-3xl font-bold text-gray-900">
            {step === 'form' ? 'ثبت‌نام در سامانه' : 'تایید شماره موبایل'}
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            {step === 'form' ? 
              'اطلاعات خود را وارد کنید' :
              'کد تایید ارسال شده را وارد کنید'
            }
          </p>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {step === 'form' ? (
          <div className="mt-8 space-y-6">
            <div className="grid grid-cols-1 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  شماره موبایل
                </label>
                <div className="relative">
                  <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="tel"
                    name="phoneNumber"
                    value={form.phoneNumber}
                    onChange={handleChange}
                    className="w-full bg-white border border-gray-300 rounded-lg pr-10 pl-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#a63439] focus:border-transparent transition-all"
                    placeholder="09xxxxxxxxx"
                    dir="ltr"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  نام و نام خانوادگی
                </label>
                <div className="relative">
                  <User className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    name="fullName"
                    value={form.fullName}
                    onChange={handleChange}
                    className="w-full bg-white border border-gray-300 rounded-lg pr-10 pl-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#a63439] focus:border-transparent transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  ایمیل
                </label>
                <div className="relative">
                  <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="email"
                    name="email"
                    value={form.email}
                    onChange={handleChange}
                    className="w-full bg-white border border-gray-300 rounded-lg pr-10 pl-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#a63439] focus:border-transparent transition-all"
                    dir="ltr"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  نام شرکت
                </label>
                <div className="relative">
                  <Building2 className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    name="companyName"
                    value={form.companyName}
                    onChange={handleChange}
                    className="w-full bg-white border border-gray-300 rounded-lg pr-10 pl-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#a63439] focus:border-transparent transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  کد ملی
                </label>
                <div className="relative">
                  <input
                    type="text"
                    name="nationalId"
                    value={form.nationalId}
                    onChange={handleChange}
                    className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#a63439] focus:border-transparent transition-all"
                    dir="ltr"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  آدرس
                </label>
                <div className="relative">
                  <MapPin className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    name="address"
                    value={form.address}
                    onChange={handleChange}
                    className="w-full bg-white border border-gray-300 rounded-lg pr-10 pl-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#a63439] focus:border-transparent transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  کد پستی
                </label>
                <div className="relative">
                  <input
                    type="text"
                    name="postalCode"
                    value={form.postalCode}
                    onChange={handleChange}
                    className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#a63439] focus:border-transparent transition-all"
                    dir="ltr"
                  />
                </div>
              </div>
            </div>

            <button
              onClick={handleSubmit}
              disabled={isLoading}
              className="w-full bg-[#a63439] text-white p-3 rounded-lg flex items-center justify-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>در حال ارسال کد...</span>
                </>
              ) : (
                <>
                  <UserPlus className="w-5 h-5" />
                  <span>ثبت‌نام</span>
                </>
              )}
            </button>
          </div>
        ) : (
          <div className="mt-8 space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                کد تایید
              </label>
              <input
                type="text"
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value)}
                className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#a63439] focus:border-transparent transition-all"
                placeholder="کد 6 رقمی"
                dir="ltr"
              />
              {timer > 0 && (
                <p className="mt-2 text-sm text-gray-500 text-center">
                  {Math.floor(timer / 60)}:{(timer % 60).toString().padStart(2, '0')} تا ارسال مجدد کد
                </p>
              )}
            </div>

            <button
              onClick={handleVerifyCode}
              disabled={isLoading || !verificationCode.trim()}
              className="w-full bg-[#a63439] text-white p-3 rounded-lg flex items-center justify-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>در حال بررسی...</span>
                </>
              ) : (
                <>
                  <UserPlus className="w-5 h-5" />
                  <span>تکمیل ثبت‌نام</span>
                </>
              )}
            </button>

            {timer === 0 && (
              <button
                onClick={handleSubmit}
                disabled={isLoading}
                className="w-full text-[#a63439] p-2 rounded-lg hover:bg-[#a63439]/5 transition-all text-sm"
              >
                ارسال مجدد کد
              </button>
            )}

            <button
              onClick={() => setStep('form')}
              disabled={isLoading}
              className="w-full text-gray-500 p-2 rounded-lg hover:bg-gray-100 transition-all text-sm"
            >
              ویرایش اطلاعات
            </button>
          </div>
        )}
      </div>
    </div>
  );
}