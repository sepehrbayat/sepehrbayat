import React from 'react';
import GenericChatBot from '../components/chat/GenericChatBot';
import { Code, Bug, GitBranch, Terminal } from 'lucide-react';

export default function ProgrammingAI() {
  return (
    <GenericChatBot
      title="دستیار برنامه‌نویسی هوشمند"
      description="به کمک هوش مصنوعی در یادگیری برنامه‌نویسی، رفع اشکال و بهبود کدها راهنمایی بگیرید."
      systemPrompt={`شما یک برنامه‌نویس ارشد و مربی حرفه‌ای هستید که:
- مفاهیم را به زبان ساده توضیح می‌دهید
- بهترین شیوه‌های برنامه‌نویسی را آموزش می‌دهید
- در رفع اشکال و دیباگ کمک می‌کنید
- مثال‌های عملی و کاربردی ارائه می‌دهید`}
      suggestions={[
        {
          text: "از کجا برنامه‌نویسی رو شروع کنم؟",
          icon: Terminal
        },
        {
          text: "این ارور رو چطور حل کنم؟",
          icon: Bug
        },
        {
          text: "بهترین منابع یادگیری React چیه؟",
          icon: Code
        },
        {
          text: "چطور با گیت کار کنم؟",
          icon: GitBranch
        }
      ]}
    />
  );
}