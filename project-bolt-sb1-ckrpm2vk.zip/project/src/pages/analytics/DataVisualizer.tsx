import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { BarChart2, PieChart, LineChart, Upload, Download, Wand2, Brain, AlertCircle } from 'lucide-react';
import { Bar, Line, Pie } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement, Title, Tooltip, Legend } from 'chart.js';
import { openai } from '../../lib/openai';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

interface ChartData {
  labels: string[];
  datasets: {
    label: string;
    data: number[];
    backgroundColor?: string | string[];
    borderColor?: string;
    borderWidth?: number;
  }[];
}

export default function DataVisualizer() {
  const { t, i18n } = useTranslation();
  const isEnglish = i18n.language === 'en';
  const [data, setData] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [chartType, setChartType] = useState<'bar' | 'line' | 'pie'>('bar');
  const [chartData, setChartData] = useState<ChartData | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleDataAnalysis = async () => {
    try {
      if (!data.trim()) {
        throw new Error(isEnglish ? 'Please enter data to analyze' : 'لطفاً داده‌ها را وارد کنید');
      }

      setIsAnalyzing(true);
      setError(null);

      const response = await openai.chat.completions.create({
        model: 'ModelsLab/Mixtral-8x7B-Instruct',
        temperature: 0.3,
        messages: [
          {
            role: 'system',
            content: `You are a data visualization expert. Please analyze the provided data and suggest the best visualization format.

Please return the response in this JSON format:
{
  "chartType": "bar" | "line" | "pie",
  "data": {
    "labels": string[],
    "datasets": [{
      "label": string,
      "data": number[],
      "backgroundColor": string[],
      "borderColor": string,
      "borderWidth": number
    }]
  },
  "insights": string[]
}`
          },
          {
            role: 'user',
            content: data
          }
        ]
      });

      const result = JSON.parse(response.choices[0]?.message?.content || '{}');
      
      setChartType(result.chartType);
      setChartData(result.data);

    } catch (error) {
      console.error('Data analysis error:', error);
      setError(error instanceof Error ? error.message : 'Error analyzing data');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl p-6 space-y-6">
        <div>
          <label className="block text-sm font-medium mb-2">
            {isEnglish ? 'Enter Your Data' : 'داده‌های خود را وارد کنید'}
          </label>
          <textarea
            value={data}
            onChange={(e) => setData(e.target.value)}
            className="w-full h-32 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 resize-none"
            placeholder={isEnglish 
              ? "Enter your data (CSV, JSON, or plain text)..."
              : "داده‌های خود را وارد کنید (CSV، JSON یا متن ساده)..."
            }
          />
        </div>

        <div className="flex gap-4">
          <button
            onClick={() => setChartType('bar')}
            className={`p-3 rounded-lg flex items-center gap-2 ${
              chartType === 'bar'
                ? 'bg-[#a63439] text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <BarChart2 className="w-5 h-5" />
            <span>{isEnglish ? 'Bar Chart' : 'نمودار میله‌ای'}</span>
          </button>
          <button
            onClick={() => setChartType('line')}
            className={`p-3 rounded-lg flex items-center gap-2 ${
              chartType === 'line'
                ? 'bg-[#a63439] text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <LineChart className="w-5 h-5" />
            <span>{isEnglish ? 'Line Chart' : 'نمودار خطی'}</span>
          </button>
          <button
            onClick={() => setChartType('pie')}
            className={`p-3 rounded-lg flex items-center gap-2 ${
              chartType === 'pie'
                ? 'bg-[#a63439] text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <PieChart className="w-5 h-5" />
            <span>{isEnglish ? 'Pie Chart' : 'نمودار دایره‌ای'}</span>
          </button>
        </div>

        <button
          onClick={handleDataAnalysis}
          disabled={isAnalyzing || !data.trim()}
          className="w-full bg-[#a63439] text-white p-4 rounded-lg flex items-center justify-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
        >
          {isAnalyzing ? (
            <>
              <Brain className="w-5 h-5 animate-pulse" />
              <span>{isEnglish ? 'Analyzing data...' : 'در حال تحلیل داده‌ها...'}</span>
            </>
          ) : (
            <>
              <Wand2 className="w-5 h-5" />
              <span>{isEnglish ? 'Analyze Data' : 'تحلیل داده‌ها'}</span>
            </>
          )}
        </button>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {chartData && (
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="aspect-[16/9] w-full">
              {chartType === 'bar' && <Bar data={chartData} />}
              {chartType === 'line' && <Line data={chartData} />}
              {chartType === 'pie' && <Pie data={chartData} />}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}