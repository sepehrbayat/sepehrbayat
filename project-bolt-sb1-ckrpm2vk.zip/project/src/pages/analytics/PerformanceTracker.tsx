import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Target, Brain, AlertCircle, Wand2 } from 'lucide-react';
import { Bar } from 'react-chartjs-2';
import { openai } from '../../lib/openai';

interface PerformanceData {
  metrics: {
    name: string;
    value: number;
    target: number;
    status: 'good' | 'warning' | 'poor';
  }[];
  insights: string[];
  recommendations: string[];
}

export default function PerformanceTracker() {
  const { t, i18n } = useTranslation();
  const isEnglish = i18n.language === 'en';
  const [data, setData] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [performanceData, setPerformanceData] = useState<PerformanceData | null>(null);
  const [error, setError] = useState<string | null>(null);

  const analyzePerformance = async () => {
    try {
      if (!data.trim()) {
        throw new Error(isEnglish ? 'Please enter data to analyze' : 'لطفاً داده‌ها را وارد کنید');
      }

      setIsAnalyzing(true);
      setError(null);

      const response = await openai.chat.completions.create({
        model: 'ModelsLab/Mixtral-8x7B-Instruct',
        temperature: 0.3,
        messages: [
          {
            role: 'system',
            content: `You are a performance analysis expert. Please analyze the provided metrics and provide insights.

Please return the response in this JSON format:
{
  "metrics": [{
    "name": string,
    "value": number,
    "target": number,
    "status": "good" | "warning" | "poor"
  }],
  "insights": string[],
  "recommendations": string[]
}`
          },
          {
            role: 'user',
            content: data
          }
        ]
      });

      const analysisData = JSON.parse(response.choices[0]?.message?.content || '{}');
      setPerformanceData(analysisData);

    } catch (error) {
      console.error('Performance analysis error:', error);
      setError(error instanceof Error ? error.message : 'Error analyzing performance');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl p-6 space-y-6">
        <div>
          <label className="block text-sm font-medium mb-2">
            {isEnglish ? 'Enter Performance Metrics' : 'معیارهای عملکرد را وارد کنید'}
          </label>
          <textarea
            value={data}
            onChange={(e) => setData(e.target.value)}
            className="w-full h-32 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 resize-none"
            placeholder={isEnglish 
              ? "Enter metrics in format: metric_name,current_value,target_value"
              : "معیارها را در این قالب وارد کنید: نام_معیار،مقدار_فعلی،مقدار_هدف"
            }
          />
        </div>

        <button
          onClick={analyzePerformance}
          disabled={isAnalyzing || !data.trim()}
          className="w-full bg-[#a63439] text-white p-4 rounded-lg flex items-center justify-center gap-2 hover:bg-[#8a2a2e] transition-all disabled:opacity-50"
        >
          {isAnalyzing ? (
            <>
              <Brain className="w-5 h-5 animate-pulse" />
              <span>{isEnglish ? 'Analyzing performance...' : 'در حال تحلیل عملکرد...'}</span>
            </>
          ) : (
            <>
              <Wand2 className="w-5 h-5" />
              <span>{isEnglish ? 'Analyze Performance' : 'تحلیل عملکرد'}</span>
            </>
          )}
        </button>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {performanceData && (
          <div className="space-y-6">
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="aspect-[16/9] w-full">
                <Bar
                  data={{
                    labels: performanceData.metrics.map(m => m.name),
                    datasets: [
                      {
                        label: isEnglish ? 'Current Value' : 'مقدار فعلی',
                        data: performanceData.metrics.map(m => m.value),
                        backgroundColor: performanceData.metrics.map(m => 
                          m.status === 'good' ? '#10B981' :
                          m.status === 'warning' ? '#F59E0B' :
                          '#EF4444'
                        )
                      },
                      {
                        label: isEnglish ? 'Target' : 'هدف',
                        data: performanceData.metrics.map(m => m.target),
                        backgroundColor: '#4B5563',
                        type: 'line'
                      }
                    ]
                  }}
                  options={{
                    responsive: true,
                    plugins: {
                      legend: {
                        position: 'top' as const,
                        align: 'end' as const,
                        rtl: !isEnglish,
                        labels: {
                          usePointStyle: true,
                          padding: 20,
                          font: {
                            family: 'Vazirmatn'
                          }
                        }
                      }
                    },
                    scales: {
                      y: {
                        beginAtZero: true,
                        ticks: {
                          font: {
                            family: 'Vazirmatn'
                          }
                        }
                      },
                      x: {
                        ticks: {
                          font: {
                            family: 'Vazirmatn'
                          }
                        }
                      }
                    }
                  }}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="text-sm font-medium mb-2">
                  {isEnglish ? 'Key Insights' : 'نکات کلیدی'}
                </h3>
                <div className="space-y-2">
                  {performanceData.insights.map((insight, index) => (
                    <div key={index} className="text-sm">• {insight}</div>
                  ))}
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="text-sm font-medium mb-2">
                  {isEnglish ? 'Recommendations' : 'پیشنهادات'}
                </h3>
                <div className="space-y-2">
                  {performanceData.recommendations.map((rec, index) => (
                    <div key={index} className="text-sm">• {rec}</div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}