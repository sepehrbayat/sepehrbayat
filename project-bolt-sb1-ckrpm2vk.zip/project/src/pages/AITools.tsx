import React from 'react';
import { Tool } from '../types';
import { Globe, DollarSign, Heart, Brain, ChefHat, ShoppingBag, Code, Home, Film, Plane, GraduationCap, BookOpen } from 'lucide-react';
import LanguageAI from './LanguageAI';
import FinanceAI from './FinanceAI';
import HealthAI from './HealthAI';
import CookingAI from './CookingAI';
import ShoppingAI from './ShoppingAI';
import ProgrammingAI from './ProgrammingAI';
import DecorationAI from './DecorationAI';
import EntertainmentAI from './EntertainmentAI';
import TravelAI from './TravelAI';
import StudentAI from './StudentAI';

const aiTools: Tool[] = [
  {
    id: 'student',
    name: 'دستیار دانشجو',
    description: 'کمک در امور تحصیلی و دانشگاهی',
    icon: BookOpen,
    color: 'bg-blue-100',
    isNew: true
  },
  // دستیارهای چت‌بات
  {
    id: 'language',
    name: 'دستیار زبان',
    description: 'یادگیری و تمرین زبان‌های خارجی',
    icon: Globe,
    color: 'bg-blue-100'
  },
  {
    id: 'finance',
    name: 'دستیار مالی',
    description: 'مشاوره مالی و سرمایه‌گذاری',
    icon: DollarSign,
    color: 'bg-yellow-100'
  },
  {
    id: 'health',
    name: 'دستیار سلامت',
    description: 'مشاوره سلامت و تغذیه',
    icon: Heart,
    color: 'bg-green-100'
  },
  {
    id: 'cooking',
    name: 'دستیار آشپزی',
    description: 'آموزش آشپزی و دستور پخت',
    icon: ChefHat,
    color: 'bg-red-100'
  },
  {
    id: 'shopping',
    name: 'دستیار خرید',
    description: 'راهنمای خرید هوشمند',
    icon: ShoppingBag,
    color: 'bg-teal-100'
  },
  {
    id: 'programming',
    name: 'دستیار برنامه‌نویسی',
    description: 'کمک در کدنویسی و دیباگ',
    icon: Code,
    color: 'bg-gray-100'
  },
  {
    id: 'decoration',
    name: 'دستیار دکوراسیون',
    description: 'مشاوره طراحی داخلی',
    icon: Home,
    color: 'bg-orange-100'
  },
  {
    id: 'entertainment',
    name: 'دستیار سرگرمی',
    description: 'پیشنهاد فیلم و سرگرمی',
    icon: Film,
    color: 'bg-red-100'
  },
  {
    id: 'travel',
    name: 'دستیار سفر',
    description: 'برنامه‌ریزی و راهنمای سفر',
    icon: Plane,
    color: 'bg-cyan-100'
  },
  {
    id: 'education',
    name: 'دستیار آموزش',
    description: 'کمک در یادگیری و آموزش',
    icon: GraduationCap,
    color: 'bg-blue-100'
  }
];

export default function AITools() {
  const [selectedTool, setSelectedTool] = React.useState<string | null>(null);

  // Reset selectedTool when returning to grid
  React.useEffect(() => {
    setSelectedTool(null);
  }, []);

  if (selectedTool === 'language') {
    return <LanguageAI />;
  }
  
  if (selectedTool === 'finance') {
    return <FinanceAI />;
  }
  
  if (selectedTool === 'health') {
    return <HealthAI />;
  }
  
  if (selectedTool === 'cooking') {
    return <CookingAI />;
  }
  
  if (selectedTool === 'shopping') {
    return <ShoppingAI />;
  }
  
  if (selectedTool === 'programming') {
    return <ProgrammingAI />;
  }
  
  if (selectedTool === 'decoration') {
    return <DecorationAI />;
  }
  
  if (selectedTool === 'entertainment') {
    return <EntertainmentAI />;
  }
  
  if (selectedTool === 'travel') {
    return <TravelAI />;
  }

  if (selectedTool === 'student' || selectedTool === 'education') {
    return <StudentAI />;
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <h1 className="text-2xl font-medium mb-2">دستیارهای هوش مصنوعی</h1>
          <p className="text-gray-600">با کمک هوش مصنوعی در زمینه‌های مختلف راهنمایی بگیرید</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {aiTools.map(tool => (
            <button
              key={tool.id}
              onClick={() => !tool.isLocked && setSelectedTool(tool.id)}
              className={`bg-white p-6 rounded-xl text-right transition-all hover:shadow-lg hover:scale-[1.02] group relative ${
                tool.isLocked ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer'
              }`}
            >
              <div className={`${tool.color} w-12 h-12 rounded-xl flex items-center justify-center mb-4`}>
                <tool.icon className="w-6 h-6 text-gray-700" />
              </div>
              <h3 className="text-lg font-medium mb-2">{tool.name}</h3>
              <p className="text-sm text-gray-500">{tool.description}</p>
              {tool.isNew && (
                <div className="absolute top-4 left-4 bg-[#a63439] text-white text-xs px-2 py-0.5 rounded-full">
                  جدید
                </div>
              )}
              {tool.isLocked && (
                <div className="absolute top-4 left-4 bg-gray-800 text-white text-xs px-2 py-0.5 rounded-full">
                  به زودی
                </div>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}