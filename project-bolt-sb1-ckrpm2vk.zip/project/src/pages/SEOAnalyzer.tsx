import React from 'react';
import { useTranslation } from 'react-i18next';
import SEODashboard from '../components/seo/SEODashboard';

export default function SEOAnalyzer() {
  const { t } = useTranslation();
  return (
    <SEODashboard />
  );
}