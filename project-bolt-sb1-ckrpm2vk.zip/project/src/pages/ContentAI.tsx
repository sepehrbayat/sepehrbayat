import React, { useState } from 'react';
import { PenTool, AlertCircle, Brain, Sparkles, Loader2, FileText, Crown, Star, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import RichTextEditor from '../components/editor/RichTextEditor';
import KeywordManager from '../components/content/KeywordManager';
import HeadingManager from '../components/content/HeadingManager';
import { useContentGeneration } from '../hooks/useContentGeneration';
import GenerationOverlay from '../components/content-pro/components/GenerationOverlay';
import ContentSettings from '../components/content-pro/components/ContentSettings';
import type { ContentSettings as ContentSettingsType } from '../components/content-pro/types';

export default function ContentAI() {
  const [topic, setTopic] = useState('');
  const [keywords, setKeywords] = useState<string[]>([]);
  const [headings, setHeadings] = useState<any[]>([]);
  const [suggestedKeywords, setSuggestedKeywords] = useState<string[]>([]);
  const [isSuggestingKeywords, setIsSuggestingKeywords] = useState(false);
  const [showKeywordSuggestions, setShowKeywordSuggestions] = useState(false);
  const [settings, setSettings] = useState<ContentSettingsType>({
    contentLength: 'medium',
    minWords: 1000,
    maxWords: 1500,
    style: 'professional',
    tone: 'formal',
    audience: 'general'
  });
  const [editorContent, setEditorContent] = useState('');

  const {
    isGenerating,
    error,
    generate,
    setError
  } = useContentGeneration({
    onProgress: (message) => setProgress(message),
    onSuccess: (content) => setEditorContent(content.content)
  });

  const [progress, setProgress] = useState('');
  const [generationPhase, setGenerationPhase] = useState<'research' | 'analysis' | 'generation' | null>(null);
  const [progressPercent, setProgressPercent] = useState(0);
  const [suggestError, setSuggestError] = useState<string | null>(null);

  const handleSuggestKeywords = async () => {
    try {
      if (!topic.trim()) {
        setError('لطفاً موضوع را وارد کنید');
        return;
      }

      setIsSuggestingKeywords(true);
      setError(null);
      setSuggestedKeywords([]);

      const response = await fetch("https://modelslab.com/api/uncensored-chat/v1/chat/completions", {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'key': "DIT0j1BOjKT9OSLc5d2dnHYpTqrNjhXVxGba5toE6Z5pWJiVM2uDbYdHpr2r"
        },
        body: JSON.stringify({
          model: 'ModelsLab/Mixtral-8x7B-Instruct',
          temperature: 0.7,
          messages: [
            {
              role: 'system',
              content: `شما یک متخصص سئو و تولید محتوا هستید. لطفاً برای موضوع داده شده، 5 کلمه کلیدی مرتبط و پرکاربرد پیشنهاد دهید.

نکات مهم:
- کلمات کلیدی باید مرتبط با موضوع باشند
- از کلمات پرجستجو استفاده کنید
- کلمات باید فارسی باشند
- از عبارات کوتاه (1 تا 3 کلمه) استفاده کنید

لطفاً فقط کلمات کلیدی را در قالب آرایه JSON برگردانید. مثال:
["کلمه کلیدی 1", "کلمه کلیدی 2", "کلمه کلیدی 3"]`
            },
            {
              role: 'user',
              content: topic
            }
          ]
        })
      });

      const data = await response.json();
      const suggestedKeywords = JSON.parse(data.choices[0]?.message?.content || '[]');
      
      // Filter out already selected keywords
      const filteredSuggestions = suggestedKeywords.filter(k => !keywords.includes(k));
      
      if (filteredSuggestions.length === 0) {
        setError('تمام کلمات کلیدی پیشنهادی قبلاً اضافه شده‌اند');
        return;
      }

      setSuggestedKeywords(filteredSuggestions);
      setShowKeywordSuggestions(true);

    } catch (error) {
      console.error('Error suggesting keywords:', error);
      const errorMessage = error instanceof Error ? error.message : 'خطا در پیشنهاد کلمات کلیدی';
      setError(errorMessage);
      setSuggestedKeywords([]);
    } finally {
      setIsSuggestingKeywords(false);
    }
  };

  const handleGenerateContent = async () => {
    try {
      if (!topic.trim()) {
        setError('لطفاً موضوع محتوا را وارد کنید');
        return;
      }

      if (keywords.length === 0) {
        setError('لطفاً حداقل یک کلمه کلیدی وارد کنید');
        return;
      }

      if (headings.length === 0) {
        setError('لطفاً حداقل یک سرتیتر وارد کنید');
        return;
      }

      setGenerationPhase('research');
      setProgressPercent(0);

      // Simulate progress
      const progressInterval = setInterval(() => {
        setProgressPercent(prev => {
          if (prev >= 95) {
            clearInterval(progressInterval);
            return prev;
          }
          return prev + 1;
        });
      }, 300);

      await generate(topic, keywords, headings);
      setProgressPercent(100);
      setGenerationPhase(null);
      clearInterval(progressInterval);

    } catch (error) {
      console.error('Content generation error:', error);
      setError(error instanceof Error ? error.message : 'خطا در تولید محتوا');
      setGenerationPhase(null);
      setProgressPercent(0);
    }
  };

  return (
    <div className="container mx-auto py-4 sm:py-6 md:py-8 px-2 sm:px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Pro Version Banner */}
        <div className="bg-gradient-to-r from-gray-100 to-gray-50 border border-gray-200 rounded-xl p-4 sm:p-6 shadow-sm">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#a63439] to-[#262e43] flex items-center justify-center">
              <Crown className="w-4 h-4 text-white" />
            </div>
            <h3 className="font-medium">ارتقا به نسخه پرو</h3>
          </div>
          <p className="text-sm text-gray-600 mb-4">
            برای تولید محتوای حرفه‌ای‌تر و بهینه‌سازی شده برای سئو، از نسخه پرو استفاده کنید.
          </p>
          <Link 
            to="/content-pro"
            className="inline-flex items-center gap-2 text-[#a63439] hover:text-[#8a2a2e] text-sm group"
          >
            <span>مشاهده نسخه پرو</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        <div>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 sm:gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-gray-600 to-gray-700 flex items-center justify-center">
              <PenTool className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-medium mb-1">تولید محتوا</h1>
              <p className="text-gray-600 text-sm sm:text-base">تولید محتوای هوشمند با کمک هوش مصنوعی</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg sm:rounded-xl p-4 sm:p-6 space-y-4 sm:space-y-6">
          <div>
            <label className="block text-sm font-medium mb-2">موضوع محتوا</label>
            <textarea
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="w-full h-24 sm:h-32 bg-gray-50 border border-gray-200 rounded-lg px-2 sm:px-3 py-2 resize-none text-sm sm:text-base"
              placeholder="موضوع مورد نظر خود را وارد کنید..."
            />
          </div>

          <KeywordManager
            keywords={keywords}
            onAddKeyword={(keyword) => {
              if (!keywords.includes(keyword)) {
                setKeywords([...keywords, keyword]);
              }
            }}
            onRemoveKeyword={(keyword) => setKeywords(keywords.filter(k => k !== keyword))}
            onSuggestKeywords={handleSuggestKeywords}
            suggestedKeywords={suggestedKeywords}
            isSuggestingKeywords={isSuggestingKeywords}
            showSuggestions={showKeywordSuggestions}
            onSelectSuggestion={(keyword) => {
              if (!keywords.includes(keyword)) {
                setKeywords([...keywords, keyword]);
                // Remove selected keyword from suggestions
                setSuggestedKeywords(prev => prev.filter(k => k !== keyword));
                // Hide suggestions if no more suggestions
                if (suggestedKeywords.length <= 1) {
                  setShowKeywordSuggestions(false);
                }
              }
            }}
            onHideSuggestions={() => setShowKeywordSuggestions(false)}
          />

          <HeadingManager
            headings={headings}
            onAddHeading={(heading) => setHeadings([...headings, heading])}
            onRemoveHeading={(id) => setHeadings(headings.filter(h => h.id !== id))}
            topic={topic}
          />

          <ContentSettings
            settings={settings}
            onSettingsChange={setSettings}
          />

          <button
            onClick={handleGenerateContent}
            disabled={isGenerating || !topic.trim() || !keywords?.length || !headings?.length}
            className="w-full bg-gradient-to-r from-gray-600 to-gray-700 text-white p-3 sm:p-4 rounded-lg flex items-center justify-center gap-2 hover:opacity-90 transition-all disabled:opacity-50 text-sm sm:text-base shadow-md hover:shadow-lg transform hover:scale-[1.01] active:scale-[0.99] duration-200"
          >
            {isGenerating ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
                <span>در حال تولید محتوا...</span>
              </>
            ) : (
              <>
                <FileText className="w-5 h-5" />
                <span>تولید محتوا</span>
              </>
            )}
          </button>
          <p className="text-xs text-gray-500 text-center mt-2">
            برای محتوای بهینه‌سازی شده برای سئو، از{' '}
            <Link to="/content-pro" className="text-[#a63439] hover:text-[#8a2a2e]">
              تولید مقاله پرو
            </Link>
            {' '}استفاده کنید
          </p>
        </div>

        <GenerationOverlay 
          isVisible={isGenerating}
          progress={progressPercent}
          phase={generationPhase}
        />

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3 text-red-700">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {editorContent && (
          <div className="bg-white rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-medium">محتوای تولید شده</h2>
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 bg-gradient-to-r from-gray-500 to-gray-600 text-white text-xs px-2 py-0.5 rounded-full">
                  <Brain className="w-4 h-4" />
                  <span>تولید هوشمند</span>
                </div>
              </div>
            </div>
            <RichTextEditor
              content={editorContent}
              onChange={setEditorContent}
              placeholder="محتوای مقاله..."
            />
            <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-100">
              <div className="flex items-center gap-2 mb-3">
                <Star className="w-4 h-4 text-gray-600" />
                <h3 className="font-medium text-gray-700">ارتقا به نسخه پرو</h3>
              </div>
              <p className="text-sm text-gray-600 mb-3">
                با ارتقا به نسخه پرو از امکانات پیشرفته‌تر بهره‌مند شوید:
              </p>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-center gap-2">
                  <div className="w-1 h-1 rounded-full bg-gray-400" />
                  <span>بهینه‌سازی خودکار محتوا برای سئو</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1 h-1 rounded-full bg-gray-400" />
                  <span>تحقیق و تحلیل محتوای رقبا</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1 h-1 rounded-full bg-gray-400" />
                  <span>پیشنهادات پیشرفته کلمات کلیدی</span>
                </li>
              </ul>
              <Link
                to="/content-pro"
                className="mt-4 inline-flex items-center gap-2 text-[#a63439] hover:text-[#8a2a2e] text-sm group"
              >
                <span>مشاهده نسخه پرو</span>
                <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}