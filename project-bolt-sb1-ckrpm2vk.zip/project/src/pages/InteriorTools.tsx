import React, { useState } from 'react';
import { Tool } from '../types';
import { Home, Ruler, Wand2, Building2, Mountain, PencilRuler } from 'lucide-react';
import InteriorDesigner from './interior/InteriorDesigner';
import FloorPlanner from './interior/FloorPlanner';
import RoomDecorator from './interior/RoomDecorator';
import ExteriorRestorer from './interior/ExteriorRestorer';
import ScenarioChanger from './interior/ScenarioChanger';
import SketchRenderer from './interior/SketchRenderer';

const interiorTools: Tool[] = [
  {
    id: 'interior-designer',
    name: 'طراح داخلی هوشمند',
    description: 'طراحی خودکار دکوراسیون داخلی با هوش مصنوعی',
    icon: Home,
    color: 'bg-orange-100',
    isNew: true,
    isLocked: true
  },
  {
    id: 'floor-planner',
    name: 'نقشه‌کشی هوشمند',
    description: 'تبدیل تصویر به نقشه حرفه‌ای',
    icon: Ruler,
    color: 'bg-blue-100',
    isNew: true,
    isLocked: true
  },
  {
    id: 'room-decorator',
    name: 'دکوراتور اتاق',
    description: 'طراحی دکوراسیون اتاق با توضیحات',
    icon: Wand2,
    color: 'bg-purple-100',
    isNew: true,
    isLocked: true
  },
  {
    id: 'exterior-restorer',
    name: 'بازسازی نمای خارجی',
    description: 'بازسازی و بهبود نمای ساختمان',
    icon: Building2,
    color: 'bg-green-100',
    isNew: true,
    isLocked: true
  },
  {
    id: 'scenario-changer',
    name: 'تغییر محیط',
    description: 'تغییر محیط اطراف ساختمان',
    icon: Mountain,
    color: 'bg-yellow-100',
    isNew: true,
    isLocked: true
  },
  {
    id: 'sketch-renderer',
    name: 'رندر طرح اولیه',
    description: 'تبدیل طرح دستی به تصویر واقعی',
    icon: PencilRuler,
    color: 'bg-red-100',
    isNew: true,
    isLocked: true
  }
];

export default function InteriorTools() {
  const [selectedTool, setSelectedTool] = useState<string | null>(null);

  const renderTool = () => {
    switch (selectedTool) {
      case 'interior-designer':
        return <InteriorDesigner />;
      case 'floor-planner':
        return <FloorPlanner />;
      case 'room-decorator':
        return <RoomDecorator />;
      case 'exterior-restorer':
        return <ExteriorRestorer />;
      case 'scenario-changer':
        return <ScenarioChanger />;
      case 'sketch-renderer':
        return <SketchRenderer />;
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#a63439] to-[#262e43] flex items-center justify-center">
              <Home className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-medium mb-1">ابزارهای طراحی داخلی</h1>
              <p className="text-gray-600">با کمک هوش مصنوعی فضای زندگی خود را زیباتر کنید</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {interiorTools.map(tool => (
            <button
              key={tool.id}
              onClick={() => !tool.isLocked && setSelectedTool(tool.id)}
              className={`bg-white p-6 rounded-xl text-right transition-all hover:shadow-lg hover:scale-[1.02] group relative ${
                tool.isLocked ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer'
              }`}
            >
              <div className={`${tool.color} w-12 h-12 rounded-xl flex items-center justify-center mb-4`}>
                <tool.icon className="w-6 h-6 text-gray-700" />
              </div>
              <h3 className="text-lg font-medium mb-2">{tool.name}</h3>
              <p className="text-sm text-gray-500">{tool.description}</p>
              {tool.isNew && (
                <div className="absolute top-4 left-4 bg-[#a63439] text-white text-xs px-2 py-0.5 rounded-full">
                  جدید
                </div>
              )}
              {tool.isLocked && (
                <div className="absolute top-4 left-4 bg-gray-800 text-white text-xs px-2 py-0.5 rounded-full">
                  به زودی
                </div>
              )}
            </button>
          ))}
        </div>

        {renderTool()}
      </div>
    </div>
  );
}