/*
  # Configure OAuth Settings

  1. Configuration
    - Set up OAuth redirect URIs
    - Configure allowed callback URLs
    - Enable secure authentication flow

  2. Security
    - Add secure authentication policies
    - Configure rate limiting
*/

-- Create auth redirect URLs table if not exists
CREATE TABLE IF NOT EXISTS auth.redirect_urls (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  uri text NOT NULL UNIQUE,
  created_at timestamptz DEFAULT now()
);

-- Add redirect URIs
INSERT INTO auth.redirect_urls (uri)
VALUES 
  ('https://app.hooshex.com/auth/callback'),
  ('https://auth.hooshex.com/auth/v1/callback'),
  ('http://localhost:5173/auth/callback')
ON CONFLICT (uri) DO NOTHING;

-- Enable RLS
ALTER TABLE auth.redirect_urls ENABLE ROW LEVEL SECURITY;

-- Add RLS policy
CREATE POLICY "Allow authenticated users to read redirect urls"
  ON auth.redirect_urls
  FOR SELECT
  TO authenticated
  USING (true);

-- Create function to handle auth settings
CREATE OR REPLACE FUNCTION auth.handle_auth_settings()
RETURNS void AS $$
BEGIN
  -- Configure auth settings via Supabase's management API
  -- Note: Actual provider configuration should be done through Supabase dashboard
  -- This migration only handles redirect URLs
  RETURN;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;