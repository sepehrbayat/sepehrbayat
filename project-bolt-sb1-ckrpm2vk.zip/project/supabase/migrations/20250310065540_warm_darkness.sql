/*
  # Configure SMTP Settings

  1. Email Settings
    - Set up SMTP server configuration
    - Configure authentication details
    - Set sender identity

  2. Security
    - Configure non-SSL settings
    - Set up rate limiting
    - Enable email features
*/

-- Create email configuration table
CREATE TABLE IF NOT EXISTS smtp_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  host text NOT NULL,
  port text NOT NULL,
  username text NOT NULL,
  password text NOT NULL,
  sender_name text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Insert SMTP configuration
INSERT INTO smtp_config (
  host,
  port,
  username,
  password,
  sender_name
) VALUES (
  'mail.hooshex.com',
  '587',
  'info@hooshex.com',
  'bQ!BD%Jp,[Lt',
  'HooshEx'
);

-- Enable RLS
ALTER TABLE smtp_config ENABLE ROW LEVEL SECURITY;

-- Create policy for authenticated users
CREATE POLICY "Only authenticated users can read SMTP config"
  ON smtp_config
  FOR SELECT
  TO authenticated
  USING (true);

-- Create function to handle email configuration
CREATE OR REPLACE FUNCTION handle_smtp_config()
RETURNS trigger AS $$
DECLARE
  config smtp_config;
BEGIN
  SELECT * INTO config FROM smtp_config LIMIT 1;
  
  -- Set email configuration
  PERFORM set_config('app.smtp.host', config.host, false);
  PERFORM set_config('app.smtp.port', config.port, false);
  PERFORM set_config('app.smtp.user', config.username, false);
  PERFORM set_config('app.smtp.pass', config.password, false);
  PERFORM set_config('app.smtp.sender_name', config.sender_name, false);
  
  -- Configure email features
  PERFORM set_config('auth.email.enable_signup', 'true', false);
  PERFORM set_config('auth.email.enable_confirmations', 'true', false);
  PERFORM set_config('auth.email.double_confirm_changes', 'true', false);
  
  -- Configure rate limiting
  PERFORM set_config('auth.email.rate_limit_count', '3', false);
  PERFORM set_config('auth.email.rate_limit_period', '60s', false);
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for SMTP configuration
CREATE TRIGGER on_smtp_config_change
  AFTER INSERT OR UPDATE ON smtp_config
  FOR EACH ROW
  EXECUTE FUNCTION handle_smtp_config();