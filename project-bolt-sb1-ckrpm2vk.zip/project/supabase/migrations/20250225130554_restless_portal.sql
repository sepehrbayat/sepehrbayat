/*
  # Create SMS messages table

  1. New Tables
    - `sms_messages`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to users)
      - `recipient` (text)
      - `message` (text)
      - `sender` (text)
      - `message_id` (text)
      - `status` (text)
      - `type` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `sms_messages` table
    - Add policy for authenticated users to read their own messages
*/

CREATE TABLE IF NOT EXISTS sms_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  recipient text NOT NULL,
  message text NOT NULL,
  sender text NOT NULL,
  message_id text,
  status text DEFAULT 'pending',
  type text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE sms_messages ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read own messages"
  ON sms_messages
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own messages"
  ON sms_messages
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);