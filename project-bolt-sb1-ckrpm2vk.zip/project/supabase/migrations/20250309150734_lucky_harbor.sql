/*
  # Email Verification System

  1. New Tables
    - `email_verification_tokens_v3`
      - `id` (uuid, primary key)
      - `email` (text, not null)
      - `token` (text, not null) 
      - `expires_at` (timestamptz, not null)
      - `created_at` (timestamptz)
      - `attempts` (integer)

  2. Security
    - Enable RLS on table
    - Add policy for anonymous users to insert tokens
    - Add policy for users to read their own tokens
*/

-- Drop existing tables and policies if they exist
DROP TABLE IF EXISTS email_verification_tokens CASCADE;
DROP TABLE IF EXISTS email_verification_tokens_v2 CASCADE;

-- Create new table with v3 suffix to avoid conflicts
CREATE TABLE email_verification_tokens_v3 (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  token text NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  attempts integer DEFAULT 0
);

-- Enable RLS
ALTER TABLE email_verification_tokens_v3 ENABLE ROW LEVEL SECURITY;

-- Create policies with unique names
CREATE POLICY "Anyone can insert verification tokens v3"
  ON email_verification_tokens_v3
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Users can read own verification tokens v3"
  ON email_verification_tokens_v3
  FOR SELECT
  TO anon
  USING (email = CURRENT_USER);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_email_verification_tokens_v3_email 
  ON email_verification_tokens_v3(email);

CREATE INDEX IF NOT EXISTS idx_email_verification_tokens_v3_created_at 
  ON email_verification_tokens_v3(created_at);