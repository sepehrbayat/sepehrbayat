/*
  # Add verification codes table

  1. New Tables
    - `verification_codes`
      - `id` (uuid, primary key)
      - `phone_number` (text)
      - `code` (text)
      - `expires_at` (timestamptz)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on `verification_codes` table
    - Add policy for inserting verification codes
    - Add policy for reading verification codes
*/

CREATE TABLE IF NOT EXISTS verification_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phone_number text NOT NULL,
  code text NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE verification_codes ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can insert verification codes"
  ON verification_codes
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Anyone can read verification codes"
  ON verification_codes
  FOR SELECT
  TO anon
  USING (true);

-- Create index for faster lookups
CREATE INDEX verification_codes_phone_number_idx ON verification_codes(phone_number);

-- Add function to clean up expired codes
CREATE OR REPLACE FUNCTION cleanup_expired_verification_codes()
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  DELETE FROM verification_codes
  WHERE expires_at < now();
END;
$$;