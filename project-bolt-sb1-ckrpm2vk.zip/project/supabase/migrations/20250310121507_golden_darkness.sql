/*
  # Email OTP Codes V9 Migration

  1. New Tables
    - `email_otp_codes_v9`
      - `id` (uuid, primary key)
      - `email` (text, not null)
      - `code` (text, not null)
      - `expires_at` (timestamptz, not null)
      - `created_at` (timestamptz)
      - `attempts` (integer)

  2. Constraints
    - Valid email format
    - 6-digit code validation
    - Attempts limit (0-3)
    - Valid expiration time
    - Indexes for performance

  3. Security
    - Enable RLS
    - Policies for insert and select
*/

-- Create email OTP codes table
CREATE TABLE IF NOT EXISTS email_otp_codes_v9 (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  code text NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  attempts integer DEFAULT 0
);

-- Add constraints
DO $$ BEGIN
  -- Email format validation
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'email_otp_codes_v9_email_check'
  ) THEN
    ALTER TABLE email_otp_codes_v9
      ADD CONSTRAINT email_otp_codes_v9_email_check 
      CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$');
  END IF;

  -- Code format validation (6 digits)
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'email_otp_codes_v9_code_check'
  ) THEN
    ALTER TABLE email_otp_codes_v9
      ADD CONSTRAINT email_otp_codes_v9_code_check 
      CHECK (code ~ '^\d{6}$');
  END IF;

  -- Attempts limit validation
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'email_otp_codes_v9_attempts_check'
  ) THEN
    ALTER TABLE email_otp_codes_v9
      ADD CONSTRAINT email_otp_codes_v9_attempts_check 
      CHECK (attempts >= 0 AND attempts <= 3);
  END IF;

  -- Expiration time validation
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'email_otp_codes_v9_expires_check'
  ) THEN
    ALTER TABLE email_otp_codes_v9
      ADD CONSTRAINT email_otp_codes_v9_expires_check 
      CHECK (expires_at > created_at);
  END IF;
END $$;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_email_otp_codes_v9_email 
  ON email_otp_codes_v9 USING btree (email);

CREATE INDEX IF NOT EXISTS idx_email_otp_codes_v9_created_at 
  ON email_otp_codes_v9 USING btree (created_at);

CREATE INDEX IF NOT EXISTS idx_email_otp_codes_v9_code 
  ON email_otp_codes_v9 USING btree (code);

-- Enable RLS
ALTER TABLE email_otp_codes_v9 ENABLE ROW LEVEL SECURITY;

-- Create policies
DO $$ BEGIN
  -- Insert policy
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE policyname = 'email_otp_insert_policy_v9'
  ) THEN
    CREATE POLICY "email_otp_insert_policy_v9" ON email_otp_codes_v9
      FOR INSERT TO anon
      WITH CHECK (true);
  END IF;

  -- Select policy
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE policyname = 'email_otp_select_policy_v9'
  ) THEN
    CREATE POLICY "email_otp_select_policy_v9" ON email_otp_codes_v9
      FOR SELECT TO anon
      USING (email = CURRENT_USER);
  END IF;
END $$;