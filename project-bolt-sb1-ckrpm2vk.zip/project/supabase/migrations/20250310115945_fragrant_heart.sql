/*
  # Create email OTP codes v9 table with safe constraint handling
  
  1. New Tables
    - `email_otp_codes_v9`
      - `id` (uuid, primary key)
      - `email` (text, not null)
      - `code` (text, not null)
      - `expires_at` (timestamptz, not null)
      - `created_at` (timestamptz, default now())
      - `attempts` (integer, default 0)

  2. Security
    - Enable RLS on `email_otp_codes_v9` table
    - Add policies for:
      - Anonymous users can insert OTP codes
      - Users can read own OTP codes
    
  3. Constraints
    - Valid email format
    - Valid 6-digit code format
    - Maximum 3 attempts
    - Expiration time must be in future
*/

-- Create email OTP codes table
CREATE TABLE IF NOT EXISTS email_otp_codes_v9 (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  code text NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  attempts integer DEFAULT 0
);

-- Add constraints using DO block to handle existing constraints
DO $$ 
BEGIN
  -- Add email format constraint if not exists
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'email_otp_codes_v9_email_check'
  ) THEN
    ALTER TABLE email_otp_codes_v9
      ADD CONSTRAINT email_otp_codes_v9_email_check 
      CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$');
  END IF;

  -- Add code format constraint if not exists
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'email_otp_codes_v9_code_check'
  ) THEN
    ALTER TABLE email_otp_codes_v9
      ADD CONSTRAINT email_otp_codes_v9_code_check 
      CHECK (code ~ '^\d{6}$');
  END IF;

  -- Add attempts constraint if not exists
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'email_otp_codes_v9_attempts_check'
  ) THEN
    ALTER TABLE email_otp_codes_v9
      ADD CONSTRAINT email_otp_codes_v9_attempts_check 
      CHECK (attempts >= 0 AND attempts <= 3);
  END IF;

  -- Add expiry constraint if not exists
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'email_otp_codes_v9_expires_check'
  ) THEN
    ALTER TABLE email_otp_codes_v9
      ADD CONSTRAINT email_otp_codes_v9_expires_check 
      CHECK (expires_at > created_at);
  END IF;
END $$;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_email_otp_codes_v9_email ON email_otp_codes_v9 USING btree (email);
CREATE INDEX IF NOT EXISTS idx_email_otp_codes_v9_created_at ON email_otp_codes_v9 USING btree (created_at);

-- Enable RLS
ALTER TABLE email_otp_codes_v9 ENABLE ROW LEVEL SECURITY;

-- Create policies
DO $$ 
BEGIN
  -- Drop existing policies if they exist
  DROP POLICY IF EXISTS "Anyone can insert OTP codes" ON email_otp_codes_v9;
  DROP POLICY IF EXISTS "Users can read own OTP codes" ON email_otp_codes_v9;
  
  -- Create new policies
  CREATE POLICY "Anyone can insert OTP codes" ON email_otp_codes_v9
    FOR INSERT TO anon
    WITH CHECK (true);

  CREATE POLICY "Users can read own OTP codes" ON email_otp_codes_v9
    FOR SELECT TO anon
    USING (email = CURRENT_USER);
END $$;