/*
  # Create email OTP codes table

  1. New Tables
    - `email_otp_codes`
      - `id` (uuid, primary key)
      - `email` (text, not null)
      - `code` (text, not null)
      - `expires_at` (timestamptz, not null)
      - `created_at` (timestamptz)
      - `attempts` (integer)

  2. Security
    - Enable RLS on `email_otp_codes` table
    - Add policies for anonymous users to:
      - Insert new OTP codes
      - Read their own OTP codes
    
  3. Indexes
    - Create index on email column
    - Create index on created_at column
*/

-- Create OTP verification table
CREATE TABLE IF NOT EXISTS email_otp_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  code text NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  attempts integer DEFAULT 0
);

-- Enable RLS
ALTER TABLE email_otp_codes ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can insert OTP codes v2"
  ON email_otp_codes
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Users can read own OTP codes v2"
  ON email_otp_codes
  FOR SELECT
  TO anon
  USING (email = current_user);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_email_otp_codes_email_v2 
  ON email_otp_codes(email);

CREATE INDEX IF NOT EXISTS idx_email_otp_codes_created_at_v2 
  ON email_otp_codes(created_at);