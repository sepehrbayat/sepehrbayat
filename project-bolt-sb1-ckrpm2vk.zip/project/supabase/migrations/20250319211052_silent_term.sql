/*
  # Add achievements tracking system

  1. New Tables
    - `user_achievements`
      - Track user achievement progress
      - Store unlocked achievements
      - Track achievement levels and points

  2. Security
    - Enable RLS
    - Add policies for user access
    - Add validation constraints
*/

-- Create achievements table
CREATE TABLE IF NOT EXISTS user_achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  achievement_id text NOT NULL,
  progress integer DEFAULT 0,
  level integer DEFAULT 1,
  is_unlocked boolean DEFAULT false,
  unlocked_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  
  -- Add constraints
  CONSTRAINT valid_level CHECK (level >= 1),
  CONSTRAINT valid_progress CHECK (progress >= 0)
);

-- Enable RLS
ALTER TABLE user_achievements ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read own achievements"
  ON user_achievements
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own achievements"
  ON user_achievements
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create indices
CREATE INDEX idx_user_achievements_user_id 
  ON user_achievements(user_id);

CREATE INDEX idx_user_achievements_achievement_id 
  ON user_achievements(achievement_id);

-- Create function to update updated_at
CREATE OR REPLACE FUNCTION update_achievements_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger
CREATE TRIGGER update_user_achievements_updated_at
  BEFORE UPDATE ON user_achievements
  FOR EACH ROW
  EXECUTE FUNCTION update_achievements_updated_at();