/*
  # Configure Email Settings

  1. Email Configuration
    - Set up email delivery settings
    - Configure sender identity
    - Enable email templates and confirmations

  2. Security
    - Configure non-SSL settings as specified
    - Set up authentication requirements
    - Configure rate limiting
*/

-- Create custom settings table if not exists
CREATE TABLE IF NOT EXISTS email_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  smtp_host text NOT NULL,
  smtp_port text NOT NULL,
  smtp_username text NOT NULL,
  smtp_password text NOT NULL,
  smtp_sender_name text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Insert SMTP settings
INSERT INTO email_settings (
  smtp_host,
  smtp_port,
  smtp_username,
  smtp_password,
  smtp_sender_name
) VALUES (
  'mail.hooshex.com',
  '587',
  'info@hooshex.com',
  'your-smtp-password-here', -- Replace with actual password
  'HooshEx'
);

-- Enable RLS
ALTER TABLE email_settings ENABLE ROW LEVEL SECURITY;

-- Create policy for authenticated users
CREATE POLICY "Only authenticated users can read email settings"
  ON email_settings
  FOR SELECT
  TO authenticated
  USING (true);

-- Configure email templates and settings
CREATE OR REPLACE FUNCTION public.handle_email_settings()
RETURNS trigger AS $$
BEGIN
  -- Configure email settings
  PERFORM set_config('auth.email.enable_signup', 'true', false);
  PERFORM set_config('auth.email.enable_confirmations', 'true', false);
  PERFORM set_config('auth.email.double_confirm_changes', 'true', false);
  PERFORM set_config('auth.email.template_fetch_url', '', false);
  
  -- Configure rate limiting
  PERFORM set_config('auth.email.rate_limit_count', '3', false);
  PERFORM set_config('auth.email.rate_limit_period', '60s', false);
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for email settings
CREATE TRIGGER on_email_settings_change
  AFTER INSERT OR UPDATE ON email_settings
  FOR EACH ROW
  EXECUTE FUNCTION handle_email_settings();