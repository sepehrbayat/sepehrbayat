/*
  # Fix Email OTP System

  1. New Tables
    - `email_otp_codes`
      - For email OTP verification
      - Includes rate limiting and attempt tracking
      - Secure and efficient design

  2. Security
    - Enable RLS
    - Add unique policies with versioned names
    - Add validation constraints

  3. Performance
    - Add indices for common queries
    - Optimize for fast lookups
*/

-- Create email OTP codes table if not exists
DO $$ BEGIN
  CREATE TABLE IF NOT EXISTS email_otp_codes (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    email text NOT NULL,
    code text NOT NULL,
    expires_at timestamptz NOT NULL,
    created_at timestamptz DEFAULT now(),
    attempts integer DEFAULT 0,
    CONSTRAINT valid_attempts CHECK ((attempts >= 0) AND (attempts <= 3))
  );
EXCEPTION
  WHEN duplicate_table THEN
    NULL;
END $$;

-- Enable RLS if not already enabled
DO $$ BEGIN
  ALTER TABLE email_otp_codes ENABLE ROW LEVEL SECURITY;
EXCEPTION
  WHEN duplicate_object THEN
    NULL;
END $$;

-- Drop existing policies if they exist
DO $$ BEGIN
  DROP POLICY IF EXISTS "Anyone can insert OTP codes v2" ON email_otp_codes;
  DROP POLICY IF EXISTS "Users can read own OTP codes v2" ON email_otp_codes;
EXCEPTION
  WHEN undefined_object THEN
    NULL;
END $$;

-- Create new policies with unique names
CREATE POLICY "Anyone can insert OTP codes v3" ON email_otp_codes
  FOR INSERT TO anon
  WITH CHECK (true);

CREATE POLICY "Users can read own OTP codes v3" ON email_otp_codes
  FOR SELECT TO anon
  USING (email = CURRENT_USER);

-- Create indices with unique names if they don't exist
DO $$ BEGIN
  CREATE INDEX IF NOT EXISTS idx_email_otp_codes_email_v3 
    ON email_otp_codes (email);
  
  CREATE INDEX IF NOT EXISTS idx_email_otp_codes_created_at_v3 
    ON email_otp_codes (created_at);
EXCEPTION
  WHEN duplicate_table THEN
    NULL;
END $$;