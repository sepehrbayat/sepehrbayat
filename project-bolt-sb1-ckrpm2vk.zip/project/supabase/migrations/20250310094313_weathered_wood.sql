/*
  # Fix OTP verification system

  1. New Tables
    - Create new consolidated OTP codes table
    - Add proper constraints and indexes
    - Enable RLS and policies

  2. Security
    - Enable RLS
    - Add policies for anonymous users
    - Add attempts validation
    - Add expiry validation
    - Add rate limiting constraints

  3. Indexes
    - Created at index for rate limiting
    - Email index for lookups
    - Code index for verification
*/

-- Create new OTP codes table
CREATE TABLE IF NOT EXISTS email_otp_codes_v9 (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  code text NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  attempts integer DEFAULT 0,
  
  -- Add constraints
  CONSTRAINT valid_attempts CHECK (attempts >= 0 AND attempts <= 3),
  CONSTRAINT valid_email CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'),
  CONSTRAINT valid_code CHECK (code ~ '^\d{6}$')
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_email_otp_codes_v9_email ON email_otp_codes_v9 (email);
CREATE INDEX IF NOT EXISTS idx_email_otp_codes_v9_created_at ON email_otp_codes_v9 (created_at);
CREATE INDEX IF NOT EXISTS idx_email_otp_codes_v9_code ON email_otp_codes_v9 (code);

-- Enable RLS
ALTER TABLE email_otp_codes_v9 ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can insert OTP codes"
  ON email_otp_codes_v9
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Users can read own OTP codes"
  ON email_otp_codes_v9
  FOR SELECT
  TO anon
  USING (email = current_user);