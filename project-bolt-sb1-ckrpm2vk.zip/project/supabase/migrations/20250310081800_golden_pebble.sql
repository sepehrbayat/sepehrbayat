/*
  # User and SMS Message Policies Migration

  1. Security Changes
    - Enable RLS on users table
    - Add policies for user data access
    - Add policies for SMS messages

  2. Policies Added
    - Users can insert own data
    - Users can read own data
    - Users can insert own messages
    - Users can read own messages

  3. Notes
    - All policies are user-scoped for security
    - Uses auth.uid() for user identification
*/

-- Enable RLS on users table if not already enabled
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_tables 
    WHERE schemaname = 'public' 
    AND tablename = 'users' 
    AND rowsecurity = true
  ) THEN
    ALTER TABLE users ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;

-- Insert policy for users table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'users' 
    AND policyname = 'Users can insert own data'
  ) THEN
    CREATE POLICY "Users can insert own data"
    ON users
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = id);
  END IF;
END $$;

-- Select policy for users table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'users' 
    AND policyname = 'Users can read own data'
  ) THEN
    CREATE POLICY "Users can read own data"
    ON users
    FOR SELECT
    TO authenticated
    USING (auth.uid() = id);
  END IF;
END $$;

-- Insert policy for sms_messages table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'sms_messages' 
    AND policyname = 'Users can insert own messages'
  ) THEN
    CREATE POLICY "Users can insert own messages"
    ON sms_messages
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = user_id);
  END IF;
END $$;

-- Select policy for sms_messages table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'sms_messages' 
    AND policyname = 'Users can read own messages'
  ) THEN
    CREATE POLICY "Users can read own messages"
    ON sms_messages
    FOR SELECT
    TO authenticated
    USING (auth.uid() = user_id);
  END IF;
END $$;