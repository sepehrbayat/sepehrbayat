/*
  # Email OTP System Update

  1. New Tables
    - `email_otp_codes`
      - For email OTP verification
      - Includes rate limiting and attempt tracking
      - Secure and efficient design

  2. Changes
    - Added attempt tracking
    - Added expiration handling
    - Added proper indices
*/

-- Create email OTP codes table if not exists
CREATE TABLE IF NOT EXISTS email_otp_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  code text NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  attempts integer DEFAULT 0,
  CONSTRAINT valid_attempts CHECK ((attempts >= 0) AND (attempts <= 3))
);

-- Enable RLS
ALTER TABLE email_otp_codes ENABLE ROW LEVEL SECURITY;

-- Create indices for performance
CREATE INDEX IF NOT EXISTS idx_email_otp_codes_email_v2 
  ON email_otp_codes (email);

CREATE INDEX IF NOT EXISTS idx_email_otp_codes_created_at_v2 
  ON email_otp_codes (created_at);