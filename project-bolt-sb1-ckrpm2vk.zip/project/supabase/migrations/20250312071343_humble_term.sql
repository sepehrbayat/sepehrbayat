/*
  # Add Activity Tracking System

  1. New Tables
    - `user_activity`
      - Track all user interactions and content
      - Store activity metadata and content
      - Enable activity search and filtering

  2. Security
    - Enable RLS
    - Add policies for user access
    - Add validation constraints

  3. Indices
    - Optimize for common queries
    - Support full-text search
*/

-- Create activity types enum
CREATE TYPE activity_type AS ENUM (
  'chat',
  'content_generation',
  'image_generation',
  'video_generation',
  'seo_analysis',
  'data_analysis',
  'tool_usage',
  'file_upload',
  'file_download'
);

-- Create activity table
CREATE TABLE IF NOT EXISTS user_activity (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  type activity_type NOT NULL,
  title text NOT NULL,
  description text,
  content jsonb,
  metadata jsonb DEFAULT '{}',
  tool_id text,
  is_bookmarked boolean DEFAULT false,
  is_archived boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  expires_at timestamptz DEFAULT (now() + interval '30 days'),
  
  -- Add constraints
  CONSTRAINT valid_content CHECK (
    CASE 
      WHEN type = 'chat' THEN 
        (content ? 'messages' AND jsonb_typeof(content->'messages') = 'array')
      WHEN type IN ('content_generation', 'image_generation', 'video_generation') THEN
        (content ? 'prompt' AND content ? 'output')
      ELSE true
    END
  ),
  
  CONSTRAINT valid_metadata CHECK (
    jsonb_typeof(metadata) = 'object'
  )
);

-- Enable RLS
ALTER TABLE user_activity ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read own activity"
  ON user_activity
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own activity"
  ON user_activity
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own activity"
  ON user_activity
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own activity"
  ON user_activity
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indices
CREATE INDEX idx_user_activity_user_id_created_at 
  ON user_activity(user_id, created_at DESC);

CREATE INDEX idx_user_activity_type 
  ON user_activity(type);

CREATE INDEX idx_user_activity_tool_id 
  ON user_activity(tool_id);

CREATE INDEX idx_user_activity_bookmarked 
  ON user_activity(is_bookmarked) 
  WHERE is_bookmarked = true;

-- Add full-text search using simple configuration
ALTER TABLE user_activity 
  ADD COLUMN search_vector tsvector 
  GENERATED ALWAYS AS (
    setweight(to_tsvector('simple', coalesce(title, '')), 'A') ||
    setweight(to_tsvector('simple', coalesce(description, '')), 'B') ||
    setweight(to_tsvector('simple', coalesce(content->>'prompt', '')), 'C')
  ) STORED;

CREATE INDEX idx_user_activity_search 
  ON user_activity USING gin(search_vector);

-- Create function to update updated_at
CREATE OR REPLACE FUNCTION update_activity_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger
CREATE TRIGGER update_user_activity_updated_at
  BEFORE UPDATE ON user_activity
  FOR EACH ROW
  EXECUTE FUNCTION update_activity_updated_at();

-- Create function to clean up expired activities
CREATE OR REPLACE FUNCTION cleanup_expired_activities()
RETURNS void AS $$
BEGIN
  DELETE FROM user_activity
  WHERE expires_at < now();
END;
$$ LANGUAGE plpgsql;