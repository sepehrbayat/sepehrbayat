/*
  # Authentication System Setup

  1. New Tables
    - `users`
      - Core user information and profile data
    - `email_verification_tokens`
      - Email verification tokens with 5-minute expiry
    - `password_reset_tokens`
      - Password reset tokens with expiry
    - `user_sessions`
      - Active user sessions tracking

  2. Security
    - Enable RLS on all tables
    - Add appropriate policies
    - Set up email verification flow

  3. Indices
    - Optimize common queries
    - Support unique constraints
*/

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  password_hash text NOT NULL,
  full_name text,
  avatar_url text,
  is_email_verified boolean DEFAULT false,
  last_login timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create email verification tokens table
CREATE TABLE IF NOT EXISTS email_verification_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  token text NOT NULL,
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz NOT NULL,
  attempts integer DEFAULT 0,
  CONSTRAINT valid_attempts CHECK (attempts >= 0 AND attempts <= 3)
);

-- Create password reset tokens table
CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  token text NOT NULL,
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz NOT NULL,
  used boolean DEFAULT false
);

-- Create user sessions table
CREATE TABLE IF NOT EXISTS user_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  token text NOT NULL,
  ip_address text,
  user_agent text,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_verification_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE password_reset_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_sessions ENABLE ROW LEVEL SECURITY;

-- Create policies with unique names
CREATE POLICY "auth_users_select_own" ON users
  FOR SELECT TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "auth_users_update_own" ON users
  FOR UPDATE TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "auth_tokens_select_own" ON email_verification_tokens
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "auth_reset_select_own" ON password_reset_tokens
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "auth_sessions_select_own" ON user_sessions
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

-- Create indices
CREATE INDEX IF NOT EXISTS users_email_idx ON users (email);
CREATE INDEX IF NOT EXISTS verification_tokens_user_id_idx ON email_verification_tokens (user_id);
CREATE INDEX IF NOT EXISTS verification_tokens_expires_at_idx ON email_verification_tokens (expires_at);
CREATE INDEX IF NOT EXISTS reset_tokens_user_id_idx ON password_reset_tokens (user_id);
CREATE INDEX IF NOT EXISTS reset_tokens_expires_at_idx ON password_reset_tokens (expires_at);
CREATE INDEX IF NOT EXISTS sessions_user_id_idx ON user_sessions (user_id);
CREATE INDEX IF NOT EXISTS sessions_expires_at_idx ON user_sessions (expires_at);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for users table
CREATE TRIGGER update_users_updated_at
  BEFORE UPDATE ON users
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create function to clean up expired tokens and sessions
CREATE OR REPLACE FUNCTION cleanup_expired_data() 
RETURNS void AS $$
BEGIN
  -- Delete expired verification tokens
  DELETE FROM email_verification_tokens WHERE expires_at < now();
  
  -- Delete expired reset tokens
  DELETE FROM password_reset_tokens WHERE expires_at < now();
  
  -- Delete expired sessions
  DELETE FROM user_sessions WHERE expires_at < now();
END;
$$ LANGUAGE plpgsql;