/*
  # Add attempts column to verification_codes table

  1. Changes
    - Add attempts column to verification_codes table with default value 0
    - Add check constraint to ensure attempts is non-negative
    - Add index on attempts column for faster lookups

  2. Security
    - No changes to RLS policies needed
*/

-- Add attempts column with default value 0
ALTER TABLE verification_codes 
ADD COLUMN IF NOT EXISTS attempts integer NOT NULL DEFAULT 0;

-- Add check constraint to ensure attempts is non-negative
ALTER TABLE verification_codes 
ADD CONSTRAINT verification_codes_attempts_check 
CHECK (attempts >= 0);

-- Add index for faster lookups
CREATE INDEX IF NOT EXISTS verification_codes_attempts_idx 
ON verification_codes(attempts);

-- Update existing rows to have 0 attempts
UPDATE verification_codes 
SET attempts = 0 
WHERE attempts IS NULL;