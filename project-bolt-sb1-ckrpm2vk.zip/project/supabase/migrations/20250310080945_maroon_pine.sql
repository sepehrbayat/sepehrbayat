/*
  # Email OTP Policies

  1. Security Policies
    - Enable RLS on email_otp_codes table
    - Allow anonymous users to insert OTP codes
    - Allow users to read their own OTP codes
    - Prevent any other access

  2. Changes
    - Add RLS policies for email_otp_codes table
    - Add performance indices
    - Add data validation constraints

  3. Notes
    - Policies ensure users can only access their own verification codes
    - Rate limiting and attempt tracking are enforced
*/

-- Enable RLS
ALTER TABLE email_otp_codes ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "email_otp_insert_policy_v4" ON email_otp_codes
  FOR INSERT TO anon
  WITH CHECK (true);

CREATE POLICY "email_otp_select_policy_v4" ON email_otp_codes
  FOR SELECT TO anon
  USING (email = CURRENT_USER);

-- Create indices for performance
CREATE INDEX IF NOT EXISTS idx_email_otp_codes_created_at_v4 
  ON email_otp_codes (created_at);

CREATE INDEX IF NOT EXISTS idx_email_otp_codes_email_v4 
  ON email_otp_codes (email);