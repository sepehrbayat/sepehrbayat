/*
  # Email OTP Verification System

  1. New Tables
    - `email_otp_codes`
      - `id` (uuid, primary key)
      - `email` (text, not null)
      - `code` (text, not null) 
      - `expires_at` (timestamptz, not null)
      - `created_at` (timestamptz)
      - `attempts` (integer)

  2. Security
    - Enable RLS
    - Add policy for anonymous users to insert codes
    - Add policy for users to read their own codes
    - Add indexes for performance

  3. Changes
    - Drop existing table and policies if they exist
    - Create new table with updated schema
    - Add new policies with unique names
*/

-- Drop existing table if it exists
DROP TABLE IF EXISTS email_otp_codes CASCADE;

-- Create OTP verification table
CREATE TABLE email_otp_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  code text NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  attempts integer DEFAULT 0
);

-- Enable RLS
ALTER TABLE email_otp_codes ENABLE ROW LEVEL SECURITY;

-- Create policies with unique names
CREATE POLICY "email_otp_insert_policy" 
  ON email_otp_codes
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "email_otp_select_policy"
  ON email_otp_codes
  FOR SELECT
  TO anon
  USING (email = current_user);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_email_otp_codes_email 
  ON email_otp_codes(email);

CREATE INDEX IF NOT EXISTS idx_email_otp_codes_created_at 
  ON email_otp_codes(created_at);