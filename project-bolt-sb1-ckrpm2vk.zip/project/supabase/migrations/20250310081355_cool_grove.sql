/*
  # Email OTP System Migration V5

  1. New Tables
    - `email_otp_codes_v5`
      - `id` (uuid, primary key)
      - `email` (text, required)
      - `code` (text, required)
      - `expires_at` (timestamptz, required)
      - `created_at` (timestamptz)
      - `attempts` (integer)

  2. Security
    - Enable RLS
    - Add policies for insert and select
    - Add validation constraints
    - Add performance indices

  3. Changes
    - Create new version of email OTP codes table
    - Add security policies
    - Add validation checks
*/

-- Create email OTP codes table
CREATE TABLE IF NOT EXISTS email_otp_codes_v5 (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  code text NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  attempts integer DEFAULT 0
);

-- Enable RLS
ALTER TABLE email_otp_codes_v5 ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "email_otp_insert_policy_v5" ON email_otp_codes_v5
  FOR INSERT TO anon
  WITH CHECK (true);

CREATE POLICY "email_otp_select_policy_v5" ON email_otp_codes_v5
  FOR SELECT TO anon
  USING (email = CURRENT_USER);

-- Add validation constraint for attempts
ALTER TABLE email_otp_codes_v5
  ADD CONSTRAINT valid_attempts 
  CHECK ((attempts >= 0) AND (attempts <= 3));

-- Create indices for performance
CREATE INDEX IF NOT EXISTS idx_email_otp_codes_v5_created_at 
  ON email_otp_codes_v5 (created_at);

CREATE INDEX IF NOT EXISTS idx_email_otp_codes_v5_email 
  ON email_otp_codes_v5 (email);