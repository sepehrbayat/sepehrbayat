/*
  # Fix email OTP codes table and policies

  1. Changes
    - Create new OTP codes table with proper structure
    - Add appropriate indexes
    - Enable RLS
    - Add proper policies
    - Add validation constraints

  2. Security
    - Enable RLS
    - Add policies for anonymous users
    - Add attempts validation
    - Add expiry validation

  3. Indexes
    - Created at index for performance
    - Email index for lookups
*/

-- Create new OTP codes table
CREATE TABLE IF NOT EXISTS email_otp_codes_v8 (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  code text NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  attempts integer DEFAULT 0
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_email_otp_codes_v8_created_at ON email_otp_codes_v8 (created_at);
CREATE INDEX IF NOT EXISTS idx_email_otp_codes_v8_email ON email_otp_codes_v8 (email);

-- Enable RLS
ALTER TABLE email_otp_codes_v8 ENABLE ROW LEVEL SECURITY;

-- Add attempts validation
ALTER TABLE email_otp_codes_v8 ADD CONSTRAINT valid_attempts CHECK (attempts >= 0 AND attempts <= 3);

-- Create policies
CREATE POLICY "Anyone can insert OTP codes v8"
  ON email_otp_codes_v8
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Users can read own OTP codes v8"
  ON email_otp_codes_v8
  FOR SELECT
  TO anon
  USING (email = CURRENT_USER);