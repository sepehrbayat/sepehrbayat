/*
  # Add email verification support
  
  1. New Tables
    - `email_verification_tokens`
      - `id` (uuid, primary key)
      - `email` (text, not null)
      - `token` (text, not null)
      - `expires_at` (timestamptz, not null)
      - `created_at` (timestamptz)
      - `attempts` (integer)

  2. Security
    - Enable RLS on `email_verification_tokens` table
    - Add policy for inserting tokens
    - Add policy for reading own tokens
*/

CREATE TABLE IF NOT EXISTS email_verification_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  token text NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  attempts integer DEFAULT 0
);

-- Enable RLS
ALTER TABLE email_verification_tokens ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can insert verification tokens"
  ON email_verification_tokens
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Users can read own verification tokens"
  ON email_verification_tokens
  FOR SELECT
  TO anon
  USING (email = current_user);

-- Create index on email for faster lookups
CREATE INDEX IF NOT EXISTS email_verification_tokens_email_idx ON email_verification_tokens(email);