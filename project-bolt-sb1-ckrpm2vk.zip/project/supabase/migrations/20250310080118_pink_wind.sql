/*
  # Email Verification System

  1. New Tables
    - `email_otp_codes`
      - `id` (uuid, primary key)
      - `email` (text, required)
      - `code` (text, required)
      - `expires_at` (timestamp with time zone, required)
      - `created_at` (timestamp with time zone)
      - `attempts` (integer)

  2. Security
    - Enable RLS on all tables
    - Add policies for:
      - Anonymous users can insert OTP codes
      - Users can read their own OTP codes
    
  3. Indices
    - Email index for faster lookups
    - Created at index for cleanup
*/

-- Create email OTP codes table
CREATE TABLE IF NOT EXISTS email_otp_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  code text NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  attempts integer DEFAULT 0,
  CONSTRAINT valid_attempts CHECK ((attempts >= 0) AND (attempts <= 3))
);

-- Enable RLS
ALTER TABLE email_otp_codes ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "email_otp_insert_policy_v3" ON email_otp_codes
  FOR INSERT TO anon
  WITH CHECK (true);

CREATE POLICY "email_otp_select_policy_v3" ON email_otp_codes
  FOR SELECT TO anon
  USING (email = CURRENT_USER);

-- Create indices for performance
CREATE INDEX IF NOT EXISTS idx_email_otp_codes_email_v3 
  ON email_otp_codes (email);

CREATE INDEX IF NOT EXISTS idx_email_otp_codes_created_at_v3 
  ON email_otp_codes (created_at);