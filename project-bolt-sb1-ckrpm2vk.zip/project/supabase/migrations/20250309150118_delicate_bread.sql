/*
  # Email Verification System

  1. New Tables
    - `email_verification_tokens`
      - `id` (uuid, primary key)
      - `email` (text, not null)
      - `token` (text, not null) 
      - `expires_at` (timestamptz, not null)
      - `created_at` (timestamptz)
      - `attempts` (integer)

  2. Security
    - Enable RLS on `email_verification_tokens` table
    - Add policy for anonymous users to insert tokens
    - Add policy for users to read their own tokens
*/

-- Create table if it doesn't exist
CREATE TABLE IF NOT EXISTS email_verification_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  token text NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  attempts integer DEFAULT 0
);

-- Enable RLS
ALTER TABLE email_verification_tokens ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DO $$ 
BEGIN
  -- Drop insert policy if exists
  IF EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'email_verification_tokens' 
    AND policyname = 'Anyone can insert verification tokens'
  ) THEN
    DROP POLICY "Anyone can insert verification tokens" ON email_verification_tokens;
  END IF;

  -- Drop select policy if exists
  IF EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'email_verification_tokens' 
    AND policyname = 'Users can read own verification tokens'
  ) THEN
    DROP POLICY "Users can read own verification tokens" ON email_verification_tokens;
  END IF;
END $$;

-- Create new policies
CREATE POLICY "Anyone can insert verification tokens"
  ON email_verification_tokens
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Users can read own verification tokens"
  ON email_verification_tokens
  FOR SELECT
  TO anon
  USING (email = CURRENT_USER);

-- Create index on email for faster lookups
CREATE INDEX IF NOT EXISTS idx_email_verification_tokens_email 
  ON email_verification_tokens(email);

-- Create index on created_at for cleanup jobs
CREATE INDEX IF NOT EXISTS idx_email_verification_tokens_created_at 
  ON email_verification_tokens(created_at);