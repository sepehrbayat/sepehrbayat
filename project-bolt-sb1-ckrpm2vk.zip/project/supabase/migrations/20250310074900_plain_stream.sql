/*
  # Authentication Schema Update

  1. New Tables
    - `email_verification_tokens_v3`
      - For email verification with rate limiting
      - Includes attempts tracking
      - Auto-expiry handling
    
    - `password_reset_tokens`
      - For password reset flow
      - Secure token management
      - Usage tracking
    
    - `user_sessions`
      - For session management
      - Device tracking
      - Auto-expiry

  2. Security
    - RLS enabled on all tables
    - Strict access policies
    - Rate limiting support

  3. Indices
    - Optimized for common queries
    - Support for expiry cleanup
*/

-- Create email verification tokens table v3
CREATE TABLE IF NOT EXISTS email_verification_tokens_v3 (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  token text NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  attempts integer DEFAULT 0,
  CONSTRAINT valid_attempts CHECK ((attempts >= 0) AND (attempts <= 3))
);

-- Create password reset tokens table
CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users ON DELETE CASCADE,
  token text NOT NULL,
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz NOT NULL,
  used boolean DEFAULT false
);

-- Create user sessions table
CREATE TABLE IF NOT EXISTS user_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users ON DELETE CASCADE,
  token text NOT NULL,
  ip_address text,
  user_agent text,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE email_verification_tokens_v3 ENABLE ROW LEVEL SECURITY;
ALTER TABLE password_reset_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_sessions ENABLE ROW LEVEL SECURITY;

-- Create unique policies with descriptive names
CREATE POLICY "email_verification_insert_policy" ON email_verification_tokens_v3
  FOR INSERT TO anon
  WITH CHECK (true);

CREATE POLICY "email_verification_select_policy" ON email_verification_tokens_v3
  FOR SELECT TO anon
  USING (email = CURRENT_USER);

CREATE POLICY "password_reset_select_policy" ON password_reset_tokens
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "user_sessions_select_policy" ON user_sessions
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

-- Create indices for performance
CREATE INDEX IF NOT EXISTS idx_email_verification_tokens_v3_email 
  ON email_verification_tokens_v3 (email);

CREATE INDEX IF NOT EXISTS idx_email_verification_tokens_v3_created_at 
  ON email_verification_tokens_v3 (created_at);

CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_user_id 
  ON password_reset_tokens (user_id);

CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_expires_at 
  ON password_reset_tokens (expires_at);

CREATE INDEX IF NOT EXISTS idx_user_sessions_user_id 
  ON user_sessions (user_id);

CREATE INDEX IF NOT EXISTS idx_user_sessions_expires_at 
  ON user_sessions (expires_at);