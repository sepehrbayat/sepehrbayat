/*
  # Create email OTP codes table v7

  1. New Tables
    - `email_otp_codes_v7`
      - `id` (uuid, primary key)
      - `email` (text, not null)
      - `code` (text, not null)
      - `expires_at` (timestamptz, not null)
      - `created_at` (timestamptz)
      - `attempts` (integer)

  2. Security
    - Enable RLS
    - Add policies for insert and select
    - Add attempts validation

  3. Indexes
    - Created at index for cleanup
    - Email index for lookups
*/

-- Create the table
CREATE TABLE IF NOT EXISTS email_otp_codes_v7 (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  code text NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  attempts integer DEFAULT 0
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_email_otp_codes_v7_created_at ON email_otp_codes_v7 (created_at);
CREATE INDEX IF NOT EXISTS idx_email_otp_codes_v7_email ON email_otp_codes_v7 (email);

-- Enable RLS
ALTER TABLE email_otp_codes_v7 ENABLE ROW LEVEL SECURITY;

-- Add attempts validation
ALTER TABLE email_otp_codes_v7 ADD CONSTRAINT valid_attempts CHECK (attempts >= 0 AND attempts <= 3);

-- Create policies
CREATE POLICY "Anyone can insert OTP codes v7"
  ON email_otp_codes_v7
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Users can read own OTP codes v7"
  ON email_otp_codes_v7
  FOR SELECT
  TO anon
  USING (email = CURRENT_USER);