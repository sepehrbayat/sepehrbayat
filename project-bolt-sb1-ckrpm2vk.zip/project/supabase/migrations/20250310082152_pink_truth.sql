/*
  # Email OTP System Migration V6

  1. New Tables
    - `email_otp_codes_v6`
      - `id` (uuid, primary key)
      - `email` (text, not null)
      - `code` (text, not null)
      - `expires_at` (timestamptz, not null)
      - `created_at` (timestamptz)
      - `attempts` (integer)

  2. Security
    - Enable RLS on table
    - Add policies for:
      - Anonymous users can insert codes
      - Users can read their own codes

  3. Indices
    - Created_at index for cleanup
    - Email index for lookups

  4. Validation
    - Attempts limited to 0-3
*/

-- Create new OTP codes table
CREATE TABLE IF NOT EXISTS email_otp_codes_v6 (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  code text NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  attempts integer DEFAULT 0
);

-- Enable RLS
ALTER TABLE email_otp_codes_v6 ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "email_otp_insert_policy_v6" ON email_otp_codes_v6
  FOR INSERT TO anon
  WITH CHECK (true);

CREATE POLICY "email_otp_select_policy_v6" ON email_otp_codes_v6
  FOR SELECT TO anon
  USING (email = CURRENT_USER);

-- Add validation constraint for attempts
ALTER TABLE email_otp_codes_v6
  ADD CONSTRAINT valid_attempts 
  CHECK ((attempts >= 0) AND (attempts <= 3));

-- Create indices for performance
CREATE INDEX IF NOT EXISTS idx_email_otp_codes_v6_created_at 
  ON email_otp_codes_v6 (created_at);

CREATE INDEX IF NOT EXISTS idx_email_otp_codes_v6_email 
  ON email_otp_codes_v6 (email);