/*
  # Email OTP Verification System

  1. New Tables
    - `email_otp_codes`
      - `id` (uuid, primary key)
      - `email` (text, not null)
      - `code` (text, not null) 
      - `expires_at` (timestamptz, not null)
      - `created_at` (timestamptz)
      - `attempts` (integer)

  2. Security
    - Enable RLS
    - Add policy for anonymous users to insert codes
    - Add policy for users to read their own codes
    - Add indexes for performance
*/

-- Create OTP verification table
CREATE TABLE email_otp_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  code text NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  attempts integer DEFAULT 0
);

-- Enable RLS
ALTER TABLE email_otp_codes ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can insert OTP codes"
  ON email_otp_codes
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Users can read own OTP codes"
  ON email_otp_codes
  FOR SELECT
  TO anon
  USING (email = current_user);

-- Create indexes
CREATE INDEX idx_email_otp_codes_email 
  ON email_otp_codes(email);

CREATE INDEX idx_email_otp_codes_created_at 
  ON email_otp_codes(created_at);